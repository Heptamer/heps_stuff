import base64
import hashlib
import hmac
import os

from .constants import ADDON_ID, ADDON_DATA
from .utils import get_setting, log, set_setting

_PREFIX = 'encv1:'
_IV_LEN = 16
_MAC_LEN = 32
_KEY_FILE = os.path.join(ADDON_DATA, ADDON_ID, 'secret.key') if ADDON_DATA else None

CREDENTIAL_SETTINGS = (
    'webdav_password',
    'dropbox_app_key',
    'dropbox_app_secret',
    'dropbox_refresh_token',
)

_key_cache = None


def _load_key():
    global _key_cache
    if _key_cache is not None:
        return _key_cache
    if not _KEY_FILE:
        return None
    try:
        if os.path.exists(_KEY_FILE):
            with open(_KEY_FILE, 'rb') as f:
                key = f.read()
        else:
            key = os.urandom(32)
            os.makedirs(os.path.dirname(_KEY_FILE), exist_ok=True)
            fd = os.open(_KEY_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            try:
                os.write(fd, key)
            finally:
                os.close(fd)
        if len(key) != 32:
            log('Secure settings: invalid key file, credentials will be unavailable')
            return None
        _key_cache = key
        return key
    except OSError as e:
        log(f'Secure settings: could not load key: {e}')
        return None


def _stream_key(key, iv, length):
    blocks = b''
    counter = 0
    while len(blocks) < length:
        blocks += hmac.new(key, iv + counter.to_bytes(8, 'big'), hashlib.sha256).digest()
        counter += 1
    return blocks[:length]


def _encrypt(plain, key):
    plain = plain.encode('utf-8')
    iv = os.urandom(_IV_LEN)
    stream = _stream_key(key, iv, len(plain))
    cipher = bytes(a ^ b for a, b in zip(plain, stream))
    mac = hmac.new(key, iv + cipher, hashlib.sha256).digest()
    return _PREFIX + base64.b64encode(iv + mac + cipher).decode('ascii')


def _decrypt(blob, key):
    try:
        raw = base64.b64decode(blob[len(_PREFIX):])
        iv, mac, cipher = raw[:_IV_LEN], raw[_IV_LEN:_IV_LEN + _MAC_LEN], raw[_IV_LEN + _MAC_LEN:]
    except Exception:
        return None
    expected = hmac.new(key, iv + cipher, hashlib.sha256).digest()
    if not hmac.compare_digest(mac, expected):
        return None
    stream = _stream_key(key, iv, len(cipher))
    return bytes(a ^ b for a, b in zip(cipher, stream)).decode('utf-8', 'replace')


def get_secret_setting(setting_id):
    """Returns the plaintext value of a credential setting. Values stored in
    Kodi's settings.xml are decrypted on the fly; legacy plaintext values are
    re-encrypted in place. Returns '' when no value is set or decryption fails."""
    raw = get_setting(setting_id) or ''
    if not raw:
        return ''
    if raw.startswith(_PREFIX):
        key = _load_key()
        if key is None:
            return ''
        plain = _decrypt(raw, key)
        if plain is None:
            log(f'Secure settings: cannot decrypt {setting_id} (wrong or missing key)')
            return ''
        return plain
    plain = raw
    key = _load_key()
    if key is not None:
        set_secret_setting(setting_id, plain)
    return plain


def set_secret_setting(setting_id, value):
    """Encrypts value and stores it in the addon settings. Empty values are
    stored as-is so unset credentials stay empty."""
    if not value:
        set_setting(setting_id, '')
        return
    key = _load_key()
    if key is None:
        set_setting(setting_id, '')
        return
    set_setting(setting_id, _encrypt(value, key))


def migrate_legacy():
    """Re-encrypts legacy plaintext credential settings in place. Runs at
    addon/service start so existing values are encrypted without re-entry."""
    for setting_id in CREDENTIAL_SETTINGS:
        try:
            get_secret_setting(setting_id)
        except Exception as e:
            log(f'Secure settings: migration of {setting_id} failed: {e}')
