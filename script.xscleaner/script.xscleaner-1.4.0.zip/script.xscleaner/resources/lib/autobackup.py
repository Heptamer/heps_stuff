import json
import os
import time
from datetime import datetime, timedelta

import xbmc

from .constants import ADDON_ID, ADDON_DATA
from .utils import (
    log, notify, yesno_dialog,
    get_setting, get_localized_string
)
from .backup import create_backup, _resolve_path

STATE_FILE = os.path.join(ADDON_DATA, ADDON_ID, 'backup_state.json')


def run_scheduled_backup():
    if get_setting('auto_backup_enabled') != 'true':
        return

    interval_days = max(1, _get_int_setting('auto_backup_interval_days', 7))
    hour = min(23, max(0, _get_int_setting('auto_backup_hour', 3)))

    backup_path = _resolve_path(get_setting('backup_path'))
    if not backup_path:
        log('Auto backup skipped: no backup path configured')
        return

    state = _load_state()
    monitor = xbmc.Monitor()
    startup = True

    while not monitor.abortRequested():
        sched = state['scheduled']
        if sched <= 0:
            sched = _next_scheduled(_anchor(state), interval_days, hour)
            state['scheduled'] = sched
            _save_state(state)
        now = time.time()

        if now < sched:
            startup = False
            if monitor.waitForAbort(int(sched - now) + 1):
                return
            continue

        if state['last_backup'] >= sched or state['last_prompt'] >= sched:
            sched = _next_scheduled(_anchor(state), interval_days, hour)
            state['scheduled'] = sched
            _save_state(state)
            continue

        if not startup and state['last_attempt'] >= sched:
            log('Auto backup failed earlier, waiting for next Kodi start')
            monitor.waitForAbort()
            return

        state['last_attempt'] = now
        _save_state(state)

        if startup:
            startup = False
            log('Auto backup missed, asking the user')
            if not yesno_dialog(
                get_localized_string(32574),
                get_localized_string(32573)
            ):
                state['last_prompt'] = now
                state['scheduled'] = _next_scheduled(
                    _anchor(state), interval_days, hour
                )
                _save_state(state)
                continue

        notify(get_localized_string(32574), get_localized_string(32575))
        ok = _run_backup(backup_path, silent=True)
        notify(
            get_localized_string(32574),
            get_localized_string(32576 if ok else 32577)
        )

        if ok:
            state['last_backup'] = time.time()
            state['scheduled'] = _next_scheduled(
                _anchor(state), interval_days, hour
            )
            _save_state(state)
            log('Auto backup completed successfully')


def _run_backup(backup_path, silent):
    try:
        return create_backup(backup_path, 'full', silent=silent)
    except Exception as e:
        log(f'Auto backup failed: {e}', level=xbmc.LOGERROR)
        return False


def _anchor(state):
    return max(state['last_backup'], state['last_prompt'])


def _next_scheduled(anchor, interval_days, hour):
    if anchor <= 0:
        scheduled = datetime.now().replace(
            hour=hour, minute=0, second=0, microsecond=0
        )
        if scheduled.timestamp() <= time.time():
            scheduled += timedelta(days=1)
        return scheduled.timestamp()
    scheduled = datetime.fromtimestamp(anchor).replace(
        hour=hour, minute=0, second=0, microsecond=0
    ) + timedelta(days=interval_days)
    return scheduled.timestamp()


def _get_int_setting(setting_id, default):
    try:
        return int(get_setting(setting_id) or default)
    except (ValueError, TypeError):
        return default


def _load_state():
    default = {
        'last_backup': 0.0,
        'last_attempt': 0.0,
        'last_prompt': 0.0,
        'scheduled': 0.0
    }
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, 'r') as f:
                state = json.load(f)
            for key in default:
                state[key] = float(state.get(key, 0.0))
            return state
    except Exception as e:
        log(f'Auto backup state could not be read: {e}')
    return dict(default)


def _save_state(state):
    try:
        if not STATE_FILE:
            return
        os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f)
    except OSError as e:
        log(f'Auto backup state could not be saved: {e}', level=xbmc.LOGERROR)
