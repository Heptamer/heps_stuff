import sys
import os
import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'lib'))

from urllib.parse import parse_qsl
import xbmcplugin

from resources.lib.constants import (
    ADDON_NAME, ADDON_ICON, ADDON_FANART
)
from resources.lib.utils import (
    create_dir_item, open_settings,
    human_size, get_localized_string,
    is_setting_enabled
)
from resources.lib.dashboard import get_storage_info


def get_handle():
    if len(sys.argv) > 1:
        return int(sys.argv[1])
    return -1


def show_dashboard():
    storage = get_storage_info()
    total = storage[0][1]

    lines = []
    for name, size in storage:
        lines.append(f'{name}: {human_size(size)}')
    lines.append('')
    lines.append(f'{get_localized_string(32238)}: {human_size(total)}')

    create_dir_item(
        f'[B]{ADDON_NAME}[/B] - {human_size(total)}',
        'dashboard_info', 'dashboard_info', ADDON_ICON, ADDON_FANART,
        '\n'.join(lines)
    )


def main_menu():
    show_dashboard()

    if is_setting_enabled('clean_cache') or is_setting_enabled('clean_temp'):
        create_dir_item(
            get_localized_string(32100),
            'url', 'cache_clean', ADDON_ICON, ADDON_FANART,
            get_localized_string(32150)
        )

    if is_setting_enabled('clean_thumbnails_unused') or is_setting_enabled('clean_thumbnails_old'):
        create_dir_item(
            get_localized_string(32101),
            'url', 'thumbnails_clean', ADDON_ICON, ADDON_FANART,
            get_localized_string(32151)
        )

    if is_setting_enabled('clean_addon_leftovers'):
        create_dir_item(
            get_localized_string(32102),
            'url', 'addons_clean', ADDON_ICON, ADDON_FANART,
            get_localized_string(32152)
        )

    create_dir_item(
        get_localized_string(32550),
        'url', 'addon_sizes', ADDON_ICON, ADDON_FANART,
        get_localized_string(32551), is_folder=True
    )

    if is_setting_enabled('clean_packages'):
        create_dir_item(
            get_localized_string(32103),
            'url', 'packages_clean', ADDON_ICON, ADDON_FANART,
            get_localized_string(32153)
        )

    if is_setting_enabled('clean_crashlogs'):
        create_dir_item(
            get_localized_string(32104),
            'url', 'crashlogs_clean', ADDON_ICON, ADDON_FANART,
            get_localized_string(32154)
        )

    create_dir_item(
        get_localized_string(32105),
        'url', 'database_optimize', ADDON_ICON, ADDON_FANART,
        get_localized_string(32155)
    )

    create_dir_item(
        get_localized_string(32106),
        'url', 'sources_check', ADDON_ICON, ADDON_FANART,
        get_localized_string(32156)
    )

    create_dir_item(
        get_localized_string(32114),
        'url', 'favorites_clean', ADDON_ICON, ADDON_FANART,
        get_localized_string(32164)
    )

    create_dir_item(
        get_localized_string(32107),
        'url', 'advanced_settings', ADDON_ICON, ADDON_FANART,
        get_localized_string(32157)
    )

    create_dir_item(
        get_localized_string(32108),
        'url', 'backup_restore', ADDON_ICON, ADDON_FANART,
        get_localized_string(32158)
    )

    create_dir_item(
        get_localized_string(32109),
        'url', 'startup_manager', ADDON_ICON, ADDON_FANART,
        get_localized_string(32159)
    )

    create_dir_item(
        get_localized_string(32110),
        'url', 'log_viewer', ADDON_ICON, ADDON_FANART,
        get_localized_string(32160)
    )

    create_dir_item(
        get_localized_string(32440),
        'url', 'activity_log', ADDON_ICON, ADDON_FANART,
        get_localized_string(32441)
    )

    if is_setting_enabled('enable_fresh_start'):
        create_dir_item(
            get_localized_string(32112),
            'url', 'fresh_start', ADDON_ICON, ADDON_FANART,
            get_localized_string(32162)
        )

    create_dir_item(
        get_localized_string(32113),
        'url', 'settings', ADDON_ICON, ADDON_FANART,
        get_localized_string(32163)
    )

    handle = get_handle()
    if handle != -1:
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def get_params():
    if len(sys.argv) > 2:
        raw = sys.argv[2]
        query = raw.split('?', 1)[1] if '?' in raw else raw
        return dict(parse_qsl(query))
    return {}


if __name__ == '__main__':
    params = get_params()
    action = params.get('action')

    try:
        from resources.lib.secure import migrate_legacy
        migrate_legacy()
    except Exception:
        pass

    if action is None:
        main_menu()

    elif action == 'settings':
        open_settings()

    elif action == 'cache_clean':
        from resources.lib.cache import clean_cache
        clean_cache()

    elif action == 'thumbnails_clean':
        from resources.lib.thumbnails import clean_thumbnails
        clean_thumbnails()

    elif action == 'addons_clean':
        from resources.lib.addons import clean_addon_leftovers
        clean_addon_leftovers()

    elif action == 'addon_sizes':
        from resources.lib.addonsizes import show_addon_sizes
        show_addon_sizes(get_handle())

    elif action == 'addon_sizes_list':
        from resources.lib.addonsizes import show_addon_sizes_list
        show_addon_sizes_list(params.get('url'), get_handle())

    elif action == 'addon_sizes_show':
        from resources.lib.addonsizes import show_addon_size_info
        show_addon_size_info(params.get('url'))

    elif action == 'packages_clean':
        from resources.lib.packages import clean_packages
        clean_packages()

    elif action == 'crashlogs_clean':
        from resources.lib.crashlogs import clean_crashlogs
        clean_crashlogs()

    elif action == 'database_optimize':
        from resources.lib.database import optimize_databases
        optimize_databases()

    elif action == 'sources_check':
        from resources.lib.sources import check_sources
        check_sources()

    elif action == 'favorites_clean':
        from resources.lib.favorites import clean_favorites
        clean_favorites()

    elif action == 'advanced_settings':
        from resources.lib.advancedsettings import edit_advanced_settings
        edit_advanced_settings()

    elif action == 'backup_restore':
        from resources.lib.backup import backup_restore_menu
        backup_restore_menu()

    elif action == 'browse_backup_path':
        from resources.lib.backup import _select_backup_path
        _select_backup_path()

    elif action == 'test_dropbox':
        from resources.lib import dropbox
        from resources.lib.utils import notify, ok_dialog
        if not dropbox.configured():
            ok_dialog(ADDON_NAME, get_localized_string(32597))
        elif dropbox.writable('dropbox://'):
            notify(ADDON_NAME, get_localized_string(32598))
        else:
            ok_dialog(ADDON_NAME, get_localized_string(32599).format(''))

    elif action == 'test_webdav':
        from resources.lib.backup import test_webdav_connection
        test_webdav_connection()

    elif action == 'startup_manager':
        from resources.lib.startup import manage_startup
        manage_startup()

    elif action == 'log_viewer':
        from resources.lib.logviewer import view_logs
        view_logs()

    elif action == 'activity_log':
        from resources.lib.activitylog import show_activity_log
        show_activity_log()

    elif action == 'fresh_start':
        from resources.lib.freshstart import fresh_start
        fresh_start()

    elif action == 'dashboard_info':
        from resources.lib.dashboard import show_system_info
        show_system_info()

    if action in ('cache_clean', 'thumbnails_clean', 'addons_clean',
                  'packages_clean', 'crashlogs_clean', 'database_optimize'):
        xbmc.executebuiltin('Container.Refresh()')
