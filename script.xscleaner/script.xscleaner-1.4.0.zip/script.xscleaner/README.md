[![Kodi Version](https://img.shields.io/badge/kodi-19%2B-blue)](https://kodi.tv/)
[![License: GPLv3](https://img.shields.io/badge/License-GPLv3-yellow.svg)](https://opensource.org/licenses/GPL-3.0)
![Python application](https://img.shields.io/badge/Build_with-Pycharm-green)

# XSCleaner Kodi Add-on
**script.xscleaner** is a [Kodi](https://kodi.tv/) maintenance add-on that cleans cache, thumbnails, addon leftovers, packages, crash logs, optimizes databases, manages backup/restore, and more. Fully localized in German and English.

##
**script.xscleaner** ist ein [Kodi](https://kodi.tv/) Wartungs-Add-on das Cache, Thumbnails, Addon-Overlaps, Pakete, Absturzprotokolle bereinigt, Datenbanken optimiert, Backup/Restore verwaltet und vieles mehr. Vollständig auf Deutsch und Englisch lokalisiert.

---

## Features
- Dashboard with storage overview and performance tips
- Cache & temp file cleanup (with HTTP, weather, downloads, search history sub-options)
- Thumbnail cleanup (unused, old, orphan, all)
- Addon leftover & orphan data removal
- Addon Storage viewer (per-addon disk usage for addons and addon data)
- Package cleanup (with unused language cleanup)
- Crash log cleanup
- Database optimization (VACUUM, integrity check, orphan cleanup, TMDBHelper cache, celebrity/artist cache, textures rebuild)
- Broken sources detection & removal (supports remote URLs)
- Favorites Manager (detect and remove broken favorites)
- Advanced settings editor (version-aware, RAM detection, network/video/samba)
- Full backup & restore system (with configurable per-type retention)
- Optional Dropbox backup destination (never-expiring refresh token, large uploads via upload sessions)
- Optional WebDAV backup destination (dav:// / davs:// — native client, credentials stored in the settings)
- Kodi factory reset (off by default in settings)
- Startup service manager
- Log file viewer
- Activity log with detailed path tracking
- Automatic cleanup at Kodi startup (optional)
- Automatic scheduled full backups (interval + hour, with missed-backup catch-up)
- User-friendly interface in German and English

##
- Dashboard mit Speicherübersicht und Leistungstipps
- Cache- & Temporärdateien-Bereinigung (mit HTTP-, Wetter-, Downloads-, Suchverlauf-Sub-Optionen)
- Thumbnail-Bereinigung (ungenutzt, alt, Waisen, alle)
- Addon-Überreste & verwaiste Daten entfernen (mit Sprachdateien-Bereinigung)
- Addon-Speicherplatz-Ansicht (Speicherverbrauch pro Addon und Addon-Daten)
- Paket-Cache bereinigen
- Absturzprotokolle bereinigen
- Datenbankoptimierung (VACUUM, Integritätsprüfung, Waisen-Bereinigung, TMDBHelper-Cache, Celebrity/Artist-Cache, Textures-Neubau)
- Defekte Quellen erkennen & entfernen (unterstützt Remote-URLs)
- Favorites-Manager (defekte Favoriten erkennen und entfernen)
- Advanced Settings Editor (Buffer, Cache, Netzwerk, Video, Samba)
- Vollständiges Backup & Wiederherstellung (mit konfigurierbarer Aufbewahrung pro Typ)
- Optionale Dropbox-Backup-Ziel (nicht ablaufender Refresh-Token, große Uploads per Upload-Sessions)
- Optionale WebDAV-Backup-Ziele (dav:// / davs:// — nativer Client, Zugangsdaten in den Einstellungen)
- Kodi auf Werkseinstellungen zurücksetzen (in den Einstellungen standardmäßig deaktiviert)
- Startup Service Manager
- Logdatei-Betrachter
- Aktivitätsprotokoll mit detaillierter Pfadverfolgung
- Automatische Bereinigung beim Kodi-Start (optional)
- Automatische geplante Voll-Backups (Intervall + Uhrzeit, mit Nachholen verpasster Backups)
- Benutzerfreundliche Oberfläche auf Deutsch und Englisch

---

## Requirements
- Kodi 19 (Matrix) or higher
- Python 3

##
- Kodi 19 (Matrix) oder höher
- Python 3

---

## Installation

### From Repository
Coming soon.

### Manual Installation
1. Download the latest release ZIP file
2. In Kodi go to **Settings > Add-ons > Install from ZIP file**
3. Select the downloaded ZIP file

##
### Aus dem Repository
In Kürze verfügbar.

### Manuelle Installation
1. Die neueste Release-ZIP-Datei herunterladen
2. In Kodi zu **Einstellungen > Add-ons > Aus ZIP-Datei installieren** gehen
3. Die heruntergeladene ZIP-Datei auswählen

---

## Usage / Benutzung

Open XSCleaner from the Kodi main menu under **Add-ons**. The add-on appears as a plugin with a clickable dashboard and a list of all available tools.

##
Öffne XSCleaner über das Kodi-Hauptmenü unter **Add-ons**. Das Add-on erscheint als Plugin mit einem klickbaren Dashboard und einer Liste aller verfügbaren Werkzeuge.

---

## Features in Detail / Funktionen im Detail

### Dashboard
Displays the current size of key Kodi directories: Home, Addons, Addon Data, Thumbnails, Packages, Temp, Databases, and total cache. Click on it to see detailed system info (Kodi version, Python version, build) with **performance tips** — actionable hints when directories exceed recommended sizes (e.g., thumbnails >500MB, low RAM detected).

##
Zeigt die aktuelle Größe wichtiger Kodi-Verzeichnisse an: Home, Addons, Addon Data, Thumbnails, Packages, Temp, Datenbanken und Gesamtcache. Klicke darauf für detaillierte Systeminfos (Kodi-Version, Python-Version, Build) mit **Leistungstipps** — Hinweise wenn Verzeichnisse empfohlene Größen überschreiten (z.B. Thumbnails >500MB, wenig RAM erkannt).

---

### Cache & Temp Cleanup / Cache- & Temp-Bereinigung

Controlled by settings: `Clean Cache` (master toggle) with sub-options, and `Clean Temp` (temp directory). Only enabled areas are cleaned.

**New in v1.3.0 — Cache sub-options:** When `Clean Cache` is enabled, these additional areas can be individually toggled:

| Sub-option / Sub-Option | Path / Pfad | What is deleted / Was wird gelöscht |
|---|---|---|
| **Clean HTTP/Image cache** | `special://userdata/cache/`, `special://userdata/Thumbnails/cache/` | Kodi's internal HTTP response cache and thumbnail cache directory |
| **Clean Weather addon caches** | `special://userdata/addon_data/weather.*/cache/`, `special://userdata/addon_data/weather.*/temp/` | Cached weather data for all weather.* addons |
| **Clean Downloads** | `special://userdata/Downloads/` | Completed/incomplete Kodi download manager files |
| **Clean Search History** | `special://userdata/guisettings.xml` | Recent search entries removed from XML (file is preserved) |

Cleans the following base areas:

| Area / Bereich | Path / Pfad | What is deleted / Was wird gelöscht |
|---|---|---|
| Temp directory / Temp-Verzeichnis | `special://temp/` | All files and subdirectories (except kodi.log, kodi.old.log, xbmc.log, xbmc.old.log) |
| Addon caches / Addon-Caches | `special://userdata/addon_data/<addon>/cache/` | Entire `cache/` subdirectory per addon |
| Addon temps / Addon-Temps | `special://userdata/addon_data/<addon>/temp/` | Entire `temp/` subdirectory per addon |
| Shared addons temp / Geteilter Addons-Temp | `special://home/addons/temp/` | Entire directory |

**Excluded addons:** script.xscleaner, script.module.requests, script.module.urllib3, script.module.chardet, script.module.idna, script.module.certifi

##
Gesteuert durch die Einstellungen: `Cache bereinigen` (Hauptschalter) mit Sub-Optionen, und `Temp bereinigen` (Temp-Verzeichnis). Es werden nur aktivierte Bereiche gereinigt.

**Neu in v1.3.0 — Cache Sub-Optionen:** Wenn `Cache bereinigen` aktiviert ist, können diese zusätzlichen Bereiche einzeln geschaltet werden:

| Sub-Option | Pfad | Was wird gelöscht |
|---|---|---|
| **HTTP-/Bild-Cache bereinigen** | `special://userdata/cache/`, `special://userdata/Thumbnails/cache/` | Kodis interner HTTP-Response-Cache und Thumbnail-Cache-Verzeichnis |
| **Wetter-Addon-Caches bereinigen** | `special://userdata/addon_data/weather.*/cache/`, `special://userdata/addon_data/weather.*/temp/` | Gecachte Wetterdaten aller weather.*-Addons |
| **Downloads bereinigen** | `special://userdata/Downloads/` | Abgeschlossene/abgebrochene Kodi-Download-Manager-Dateien |
| **Suchverlauf bereinigen** | `special://userdata/guisettings.xml` | Suchverlaufseinträge aus der XML entfernt (Datei bleibt erhalten) |

Bereinigt folgende Basisbereiche:

| Bereich | Pfad | Was wird gelöscht |
|---|---|---|
| Temp-Verzeichnis | `special://temp/` | Alle Dateien und Unterverzeichnisse (außer kodi.log, kodi.old.log, xbmc.log, xbmc.old.log) |
| Addon-Caches | `special://userdata/addon_data/<addon>/cache/` | Gesamtes `cache/` Unterverzeichnis pro Addon |
| Addon-Temps | `special://userdata/addon_data/<addon>/temp/` | Gesamtes `temp/` Unterverzeichnis pro Addon |
| Geteilter Addons-Temp | `special://home/addons/temp/` | Gesamtes Verzeichnis |

**Ausgeschlossene Addons:** script.xscleaner, script.module.requests, script.module.urllib3, script.module.chardet, script.module.idna, script.module.certifi

---

### Thumbnail Cleanup / Thumbnail-Bereinigung

Controlled by settings: `Clean Unused Thumbnails` and `Clean Old Thumbnails`. Only enabled modes are shown in the sub-dialog. The Thumbnail Age setting controls how many days for old thumbnails.

Four cleaning modes are available:

##
Gesteuert durch die Einstellungen: `Ungenutzte Thumbnails bereinigen` und `Alte Thumbnails bereinigen`. Nur aktivierte Modi werden im Unter-Dialog angezeigt. Die Thumbnail-Alter-Einstellung bestimmt die Anzahl Tage für alte Thumbnails.

Vier Bereinigungsmodi sind verfügbar:

| Mode / Modus | Description / Beschreibung |
|---|---|
| **Unused Thumbnails / Ungenutzte Thumbnails** | Compares thumbnails in `special://userdata/Thumbnails/` against `special://database/Textures13.db`. Deletes files whose texture ID is not referenced in the database. Vergleicht Thumbnails in `special://userdata/Thumbnails/` mit `special://database/Textures13.db`. Löscht Dateien deren Texture-ID nicht in der Datenbank referenziert wird. |
| **Old Thumbnails / Alte Thumbnails** | Deletes thumbnails older than X days (configurable: 1-365 days, default 30). Also removes the corresponding database entry. Löscht Thumbnails älter als X Tage (einstellbar: 1-365 Tage, Standard 30). Entfernt auch den entsprechenden Datenbank-Eintrag. |
| **Orphan Artwork / Waisen-Grafiken** | Cross-references the `url` column in `Textures13.db` against actual source files on disk. Deletes thumbnails whose original source file no longer exists. Remote URLs (`image://`, `http(s)://`) and `special://` paths are always preserved. Kreuzreferenziert die `url`-Spalte in `Textures13.db` mit den tatsächlichen Quelldateien auf der Festplatte. Löscht Thumbnails deren Quelldatei nicht mehr existiert. Remote-URLs (`image://`, `http(s)://`) und `special://`-Pfade bleiben immer erhalten. |
| **All Thumbnails / Alle Thumbnails** | Deletes ALL files in `special://userdata/Thumbnails/` and deletes `Textures13.db` entirely. Kodi rebuilds everything on next start. Löscht ALLE Dateien in `special://userdata/Thumbnails/` und löscht `Textures13.db` komplett. Kodi baut alles beim nächsten Start neu auf. |

---

### Addon Leftovers Cleanup / Addon-Überreste-Bereinigung

Controlled by setting: `Clean Addon Leftovers`. Disabled in settings hides the menu item and prevents execution.

Two-phase cleanup:

##
Gesteuert durch die Einstellung: `Addon-Überreste bereinigen`. Deaktiviert blendet den Menüpunkt aus und verhindert die Ausführung.

Zweiphasen-Bereinigung:

1. **Orphan addon data / Verwaiste Addon-Daten:** Compares directories in `special://userdata/addon_data/` against installed addons in `special://home/addons/` **and** `special://xbmc/addons/` (system addons). Prevents deletion of `peripheral.*`, `skin.*`, `game.controller.*` etc.
Vergleicht Verzeichnisse in `special://userdata/addon_data/` mit installierten Addons in `special://home/addons/` **und** `special://xbmc/addons/` (System-Addons). Verhindert Löschung von `peripheral.*`, `skin.*`, `game.controller.*` etc.

2. **Invalid addons / Ungültige Addons:** Scans `special://home/addons/` for addon directories missing an `addon.xml` file. Deletes them as broken/invalid.
Scant `special://home/addons/` nach Addon-Verzeichnissen ohne `addon.xml` Datei. Löscht diese als defekt/ungültig.

**Excluded / Ausgeschlossen:** script.xscleaner, script.module.* addons

---

### Addon Storage / Addon-Speicherplatz

New in v1.3.6 — a read-only submenu that shows the disk usage of every installed addon as a Kodi list, sorted by size (largest first). It answers questions like "which addon is eating my 2.1 GB?". Select an entry to see its ID and size in a details dialog — nothing is deleted from this view.

Two views are available:

| View / Ansicht | Scanned path / Gescannter Pfad | Notes / Hinweise |
|---|---|---|
| **Addons** | `special://home/addons/`, `special://xbmc/addons/` | Folders of the same addon (home + system) are merged into one entry; `packages/` and `temp/` are excluded |
| **Addon Data / Addon-Daten** | `special://userdata/addon_data/` | Per-addon data folders, names resolved from `addon.xml` where possible |

Each list starts with a **Total** row showing the combined size of all entries. Sizes are measured fresh on every open (progress dialog shown), so the displayed values are always current; a leftover `xscleaner_addon_sizes.json` from older versions is removed automatically.

##

Neu in v1.3.6 — ein schreibgeschütztes Untermenü, das den Speicherverbrauch jedes installierten Addons als Kodi-Liste anzeigt, sortiert nach Größe (größte zuerst). Es beantwortet Fragen wie "welches Addon belegt meine 2,1 GB?". Ein Eintrag zeigt seine ID und Größe in einem Details-Dialog — in dieser Ansicht wird nichts gelöscht.

Zwei Ansichten sind verfügbar:

| Ansicht | Gescannter Pfad | Hinweise |
|---|---|---|
| **Addons** | `special://home/addons/`, `special://xbmc/addons/` | Ordner desselben Addons (Home + System) werden zu einem Eintrag zusammengefasst; `packages/` und `temp/` sind ausgenommen |
| **Addon-Daten** | `special://userdata/addon_data/` | Datenordner der Addons, Namen soweit möglich aus `addon.xml` aufgelöst |

Jede Liste beginnt mit einer **Gesamt**-Zeile mit dem kombinierten Speicher aller Einträge. Die Größen werden bei jedem Öffnen frisch gemessen (Fortschrittsdialog), sodass die angezeigten Werte immer aktuell sind; eine übriggebliebene `xscleaner_addon_sizes.json` aus älteren Versionen wird automatisch entfernt.

---

### Package Cleanup / Paket-Bereinigung

Controlled by setting: `Clean Packages`. Disabled in settings hides the menu item and prevents execution.

Deletes the entire contents of `special://home/addons/packages/`. These are downloaded addon installation files that are no longer needed after installation.

When **Clean Unused Languages / Unbenutzte Sprachen bereinigen** is additionally enabled, all `resources/language/resource.language.*` directories except `en_gb` and `de_de` are removed from every addon in `special://home/addons/`. Frees space by keeping only the two supported languages. This option depends on `Clean Packages` and is shown directly beneath it in the settings.

##

Löscht den gesamten Inhalt von `special://home/addons/packages/`. Dieses sind heruntergeladene Addon-Installationsdateien die nach der Installation nicht mehr benötigt werden.

Wenn zusätzlich **Unbenutzte Sprachen bereinigen** aktiviert ist, werden alle `resources/language/resource.language.*` Verzeichnisse außer `en_gb` und `de_de` aus jedem Addon in `special://home/addons/` entfernt. Spart Speicher durch Behalten nur der zwei unterstützten Sprachen. Diese Option hängt von `Pakete bereinigen` ab und steht in den Einstellungen direkt darunter.

---

### Crash Log Cleanup / Absturzprotokoll-Bereinigung

Controlled by setting: `Clean Crash Logs`. Disabled in settings hides the menu item and prevents execution.

Cleans crash-related files from two locations:

##
Gesteuert durch die Einstellung: `Crash-Logs bereinigen`. Deaktiviert blendet den Menüpunkt aus und verhindert die Ausführung.

Bereinigt absturzbezogene Dateien an zwei Orten:

| Location / Ort | Files deleted / Gelöschte Dateien |
|---|---|
| `special://userdata/crashlogs/` | All `.dmp` and `.crash` files, all subdirectories |
| `special://userdata/` (root) | Any `.dmp` and `.crash` files in the userdata root |

---

### Database Optimization / Datenbankoptimierung

Controlled by settings: `DB Backup Before Optimize`, `Run VACUUM`, `Integrity Check`, `Cleanup Orphaned DB Entries`, `Clean TMDBHelper caches`, `Clean Celebrity/Artist Data`, `Rebuild Textures13.db`. Each sub-operation is individually enabled/disabled. The sub-dialog is built dynamically — only options whose settings are enabled appear in the menu.

Finds all Kodi database files in `special://database/` and `special://userdata/addon_data/*/`. Optimization modes:

##
Gesteuert durch die Einstellungen: `DB Backup vor Optimierung`, `VACUUM ausführen`, `Integritätsprüfung ausführen`, `Verwaiste DB-Einträge bereinigen`, `TMDBHelper-Caches bereinigen`, `Celebrity/Artist-Daten bereinigen`, `Textures13.db neu aufbauen`. Jede Unter-Operation ist einzeln aktivierbar/deaktivierbar. Der Unter-Dialog wird dynamisch aufgebaut – nur Optionen deren Einstellungen aktiviert sind werden angezeigt.

Findet alle Kodi-Datenbankdateien in `special://database/` und `special://userdata/addon_data/*/`. Optimierungsmodi:

| Mode / Modus | Description / Beschreibung |
|---|---|
| **VACUUM + Check** | Creates a full database backup via Backup & Restore system, then runs `VACUUM` (reclaims unused space) and `PRAGMA quick_check` (verifies integrity). Erstellt ein vollständiges Backup über das Backup- & Wiederherstellungssystem, führt dann `VACUUM` durch (reklamiert ungenutzten Platz) und `PRAGMA quick_check` (verifiziert Integrität). |
| **VACUUM only / Nur VACUUM** | Creates a full database backup, then runs `VACUUM` only. Erstellt ein vollständiges Datenbank-Backup und führt dann nur `VACUUM` durch. |
| **Integrity Check / Integritätsprüfung** | Runs `PRAGMA quick_check` on each database. Führt `PRAGMA quick_check` für jede Datenbank durch. |
| **Orphan Cleanup / Waisen-Bereinigung** | Removes duplicate/orphaned rows from video (`MyVideos*.db`) and music (`MyMusic*.db`) databases. Entfernt doppelte/verwaiste Zeilen aus Video- (`MyVideos*.db`)- und Musik- (`MyMusic*.db`)-Datenbanken. |
| **TMDBHelper Cache Cleanup** | Deletes `itemdetails.db` and `itemdetails.db-wal` files in `special://userdata/addon_data/themoviedb.helper/` and subdirectories. These are cached metadata databases from TMDBHelper that are safely regenerated. Löscht `itemdetails.db` und `itemdetails.db-wal` Dateien in `special://userdata/addon_data/themoviedb.helper/` und Unterordnern. Dabei handelt es sich um gecachte Metadaten-Datenbanken von TMDBHelper die sicher neu generiert werden. |
| **Celebrity/Artist Cache** | Clears celebrity, actor links and artist tables from `MyVideos*.db`. These are safely regenerated by Kodi. Leert Celebrity-, Schauspielerlink- und Artist-Tabellen aus `MyVideos*.db`. Werden von Kodi sicher neu generiert. |
| **Rebuild Textures13.db** | Creates a full database backup, then deletes `Textures13.db` to force Kodi to rebuild the texture database from scratch on next start. Erstellt ein vollständiges Datenbank-Backup und löscht dann `Textures13.db`, um Kodi zum kompletten Neubau der Texturdatenbank beim nächsten Start zu zwingen. |

**Backups** are now created using the Backup & Restore system. When enabled (`DB Backup Before Optimize`), a full database backup is saved to the configured **backup path** as `xscleaner_databases_<timestamp>.zip`. This backup is fully restorable via **Backup & Restore → Restore**. The addon aborts optimization if no backup path is set — a backup is mandatory for all modifying operations. Database backups are also subject to the **Backup Retention** setting (`Max Backups to Keep`).

**Backups** werden jetzt über das Backup- & Wiederherstellungssystem erstellt. Wenn aktiviert (`DB Backup vor Optimierung`), wird ein vollständiges Datenbank-Backup unter dem konfigurierten **Backup-Pfad** als `xscleaner_databases_<timestamp>.zip` gespeichert. Dieses Backup ist vollständig über **Backup/Wiederherstellen → Wiederherstellen** restaurierbar. Das Addon bricht die Optimierung ab, wenn kein Backup-Pfad gesetzt ist — ein Backup ist für alle schreibenden Operationen zwingend erforderlich. Datenbank-Backups unterliegen ebenfalls der **Backup-Aufbewahrung** (`Maximale Anzahl Backups`).

---

### Broken Sources Checker / Defekte Quellen Prüfer

Reads `special://userdata/sources.xml` and checks if each configured source path actually exists on disk. **Remote URLs (http://, https://, smb://, nfs://, ftp://)** are automatically recognised and skipped — only local filesystem paths are validated. Displays a list of broken/missing sources and offers to remove them from the XML file.

##
Liest `special://userdata/sources.xml` und prüft ob jeder konfigurierte Quellenpfad tatsächlich auf der Festplatte existiert. **Remote-URLs (http://, https://, smb://, nfs://, ftp://)** werden automatisch erkannt und übersprungen — nur lokale Dateisystempfade werden validiert. Zeigt eine Liste defekter/fehlender Quellen an und bietet an diese aus der XML-Datei zu entfernen.

---

### Favorites Manager / Favorites-Manager

Reads `special://userdata/favourites.xml`, parses all `<favourite>` entries, and checks whether their target paths still exist. Remote URLs and Kodi built-in commands (`ActivateWindow(...)`, `RunAddon(...)`) are evaluated — broken entries (pointing to deleted files, missing addons, or invalid paths) are listed and can be removed with one click.

##
Liest `special://userdata/favourites.xml`, parst alle `<favourite>`-Einträge und prüft ob deren Zielpfade noch existieren. Remote-URLs und Kodi-interne Befehle (`ActivateWindow(...)`, `RunAddon(...)`) werden ausgewertet — defekte Einträge (zeigen auf gelöschte Dateien, fehlende Addons oder ungültige Pfade) werden aufgelistet und können mit einem Klick entfernt werden.

---

### Advanced Settings Editor / Advanced Settings Editor

Creates, edits, or removes `special://userdata/advancedsettings.xml`. Version-aware: detects Kodi version and shows cache settings only for Kodi 19-20 (cache/buffer moved to GUI in Kodi 21+). Single-page menu with current values, help texts, and edit dialogs. RAM-based cache recommendations.

##
Erstellt, bearbeitet oder entfernt `special://userdata/advancedsettings.xml`. Versionssensitiv: Erkennt Kodi-Version und zeigt Cache-Einstellungen nur für Kodi 19-20 (Cache/Buffer sind ab Kodi 21+ in der GUI). Einseitiges Menü mit aktuellen Werten, Hilfetexten und Bearbeitungsdialogen. RAM-basierte Cache-Empfehlungen.

**Version-aware cache settings:**
- Kodi 19-20: Full cache/buffer editor with RAM-based recommendations
- Kodi 21+: Info notice — cache settings now in Settings > Services > Caching

**Available settings:**

#### Cache & Buffer (Kodi 19-20) / Cache & Buffer (Kodi 19-20)

For smoother video playback by buffering streamed content in RAM. Only shown on Kodi 19-20; from Kodi 21+ these values are configured under **Settings > Services > Caching**.

| Setting / Einstellung | Default / Standard | Description / Beschreibung |
|---|---|---|
| **buffermode** (Buffer Mode / Buffer-Modus) | On (All) / Ein (Alle) | Controls for which sources the cache is active: **Off** (no caching), **On (Filesystem)** (only local/file sources), **On (Internet)** (only remote sources), **On (All)** (everything). Steuert für welche Quellen der Cache aktiv ist: **Aus** (kein Caching), **Ein (Dateisystem)** (nur lokale/Datei-Quellen), **Ein (Internet)** (nur Remote-Quellen), **Ein (Alle)** (alles). |
| **memorysize** (Memory Size / Speichergröße) | RAM-dependent / RAM-abhängig | Size in bytes of the in-memory buffer used for stream caching. **0** = use disk instead of RAM. The recommended value is derived from detected system RAM. Größe des Speicher-Puffers für Stream-Caching in Bytes. **0** = Festplatte statt RAM verwenden. Der empfohlene Wert wird aus dem erkannten System-RAM abgeleitet. |
| **readfactor** (Read Factor / Read-Faktor) | 4 | Maximum read-rate multiplier. Values above 1 read the file faster than real time, reducing stutter on slow connections. Maximaler Leserate-Multiplikator. Werte über 1 lesen die Datei schneller als in Echtzeit und reduzieren Ruckeln bei langsamen Verbindungen. |

In the cache dialog you can **Apply recommended** values (based on detected RAM) or **Edit values** manually.
Im Cache-Dialog kannst du die **empfohlenen Werte übernehmen** (basierend auf dem erkannten RAM) oder die Werte **manuell bearbeiten**.

#### Network / Netzwerk

Configure connection timeouts and options for HTTP/FTP/NFS access.

| Setting / Einstellung | Default / Standard | Description / Beschreibung |
|---|---|---|
| **curlclienttimeout** | 10 s | Timeout for HTTP/FTP connections in seconds before an operation is aborted. Timeout für HTTP/FTP-Verbindungen in Sekunden, bevor ein Vorgang abgebrochen wird. |
| **curllowspeedtime** | 20 s | Seconds before a slow connection is considered stalled and aborted. Sekunden, bis eine langsame Verbindung als festgefahren gilt und abgebrochen wird. |
| **curlretries** | 2 | Number of retries for failed HTTP/FTP operations. Anzahl der Wiederholungen bei fehlgeschlagenen HTTP/FTP-Operationen. |
| **disableipv6** | Off / Aus | Disables IPv6. Enable if you experience IPv6 network issues. Deaktiviert IPv6. Bei IPv6-Netzwerkproblemen aktivieren. |
| **disablehttp2** | Off / Aus | Disables HTTP/2. Enable if you experience issues with HTTP/2 servers. Deaktiviert HTTP/2. Bei HTTP/2-Serverproblemen aktivieren. |
| **nfstimeout** | 30 s | Timeout for NFS access in seconds. Timeout für NFS-Zugriffe in Sekunden. |
| **nfsretries** | 0 | Number of NFS retries. **0** = disabled. Anzahl der NFS-Wiederholungen. **0** = deaktiviert. |

#### Video / Video

Fine-tune playback behavior and resume (watched) tracking.

| Setting / Einstellung | Default / Standard | Description / Beschreibung |
|---|---|---|
| **skiploopfilter** | 0 | H.264 loop filter skip. Lower values = less CPU usage but worse quality, higher values = better quality but more CPU. H.264 Loop-Filter-Skip. Niedrigere Werte = weniger CPU, aber schlechtere Qualität; höhere Werte = bessere Qualität, aber mehr CPU. |
| **playcountminimumpercent** | 90 % | Minimum percentage of a video that must be played before it is marked as watched. **101** = never mark as watched. Mindestprozent der Wiedergabe eines Videos, bis es als gesehen markiert wird. **101** = nie als gesehen markieren. |
| **ignoresecondsatstart** | 180 s | Seconds at the start of a video that are ignored for the resume point (skips past intro/credits). Sekunden am Videoanfang, die für den Fortsetzen-Punkt ignoriert werden (überspringt Intro/Vorspann). |
| **ignorepercentatend** | 8 % | Percentage at the end of a video that is ignored for the resume point (video is considered finished near the end). Prozentsatz am Videoende, der für den Fortsetzen-Punkt ignoriert wird (Video gilt nahe dem Ende als beendet). |
| **maxtempo** | 1.6 | Maximum playback speed multiplier (range 1.6-2.0) allowed for audio-pitch-corrected fast playback. Maximale Wiedergabegeschwindigkeit (Bereich 1.6-2.0) für tonhöhenkorrigierte Schnellwiedergabe. |

#### Samba / Samba

| Setting / Einstellung | Default / Standard | Description / Beschreibung |
|---|---|---|
| **clienttimeout** | 30 s | Timeout for Samba/SMB network share access in seconds. Timeout für den Zugriff auf Samba/SMB-Netzwerkfreigaben in Sekunden. |

**Operations / Aktionen:** View current advancedsettings.xml (`View advancedsettings.xml` / `Aktuelle advancedsettings.xml anzeigen`), Reset to default (`Reset to default` / `Auf Standard zurücksetzen`), Delete (`Delete advancedsettings.xml` / `advancedsettings.xml löschen`).

---

### Backup & Restore / Sicherung & Wiederherstellung

Creates timestamped backups of Kodi data to a user-configured path.

##
Erstellt zeitgestempelte Sicherungen von Kodi-Daten an einem benutzerkonfigurierten Pfad.

The backup destination is configured in the addon settings under **Settings > Backup** — the **Backup folder (SMB/NFS/FTP)…** button opens a folder browser that lists the local filesystem, your configured Kodi sources (including network sources from the file manager), browsable SMB/NFS/FTP network locations, and a manual path entry. Network shares (`smb://`, `nfs://`, `ftp://`), WebDAV targets (`dav://`, `davs://`) and `special://` paths are fully supported as backup destination.

Das Backup-Ziel wird in den Addon-Einstellungen unter **Einstellungen > Backup** konfiguriert — der Button **Backup-Ordner (SMB/NFS/FTP)…** öffnet einen Ordner-Browser, der das lokale Dateisystem, deine konfigurierten Kodi-Quellen (inkl. Netzwerkquellen aus dem Dateimanager), durchsuchbare SMB/NFS/FTP-Netzwerkadressen und eine manuelle Pfadeingabe auflistet. Netzwerk-Shares (`smb://`, `nfs://`, `ftp://`), WebDAV-Ziele (`dav://`, `davs://`) und `special://`-Pfade werden als Backup-Ziel voll unterstützt.

For WebDAV targets (`dav://`, `davs://`) the credentials are stored in the addon settings under **Backup > WebDAV** (server URL, user name, password — each with a help text) and injected into the paths automatically at run time, so no credentials need to be embedded in the backup path URL. The backup folder browser gained a **WebDAV (Nextcloud/ownCloud)…** entry that starts at the configured server URL, and the settings offer a **Test WebDAV connection** button. Existing `davs://user:pass@…` paths keep working unchanged.

Für WebDAV-Ziele (`dav://`, `davs://`) werden die Zugangsdaten in den Addon-Einstellungen unter **Backup > WebDAV** gespeichert (Server-URL, Benutzername, Passwort — jeweils mit Hilfetext) und zur Laufzeit automatisch in die Pfade eingefügt, sodass keine Zugangsdaten in der Backup-Pfad-URL stehen müssen. Der Backup-Ordner-Browser hat einen neuen Eintrag **WebDAV (Nextcloud/ownCloud)…**, der an der konfigurierten Server-URL startet, und die Einstellungen bieten einen Button **WebDAV-Verbindung testen**. Bestehende `davs://benutzer:passwort@…`-Pfade funktionieren unverändert weiter.

**Backup types / Backup-Typen:**

| Type / Typ | Contents / Inhalt |
|---|---|
| **Full / Vollständig** | Addons, Addon Data, Databases, sources.xml, advancedsettings.xml, guisettings.xml, profiles.xml, keymaps, playlists |
| **Addons** | `special://home/addons` |
| **Addon Data / Addon-Daten** | `special://userdata/addon_data` |
| **Addons + Data / Addons + Daten** | `special://home/addons`, `special://userdata/addon_data` |
| **Databases / Datenbanken** | `special://database/` |
| **Settings / Einstellungen** | sources.xml, advancedsettings.xml, guisettings.xml |
| **Profiles / Profile** | profiles.xml |
| **Keymaps** | `special://userdata/keymaps/` |
| **Playlists** | `special://userdata/playlists/` |

**Restore** downloads and verifies the selected ZIP archive, extracts it to a staging folder, and then swaps the restored data back into the original Kodi locations. A failed or cancelled restore leaves the original data untouched.

**Wiederherstellung** lädt das ausgewählte ZIP-Archiv herunter und verifiziert es, entpackt es in einen Staging-Ordner und tauscht die wiederhergestellten Daten anschließend atomar an den ursprünglichen Kodi-Orten ein. Eine fehlgeschlagene oder abgebrochene Wiederherstellung lässt die ursprünglichen Daten unangetastet.

**Retention / Aufbewahrung:** With `Max Backups to Keep (0 = off)` you can limit the number of backups per type. When the limit is reached, the oldest backups of that type are removed after a new backup was created successfully. Default: 10 (1-30, 0 disables deletion).

**Aufbewahrung:** Mit `Maximale Anzahl Backups (0 = aus)` lässt sich die Anzahl der Backups pro Typ begrenzen. Wird die Grenze erreicht, werden die ältesten Backups dieses Typs gelöscht, nachdem ein neues Backup erfolgreich erstellt wurde. Standard: 10 (1-30, 0 deaktiviert das Löschen).

---

### Dropbox Backup / Dropbox-Backup

New in v1.3.9 — Dropbox is an optional backup destination. A **"Dropbox"** entry in the backup folder browser selects the backup path `dropbox://`; backups are then stored in your Dropbox **app folder** (the free 2 GB plan is supported). Authentication uses a **never-expiring refresh token**, so the connection never needs to be re-authorized; the short-lived access token is fetched and refreshed automatically (5-minute safety margin) and cached in `addon_data/script.xscleaner/dropbox_state.json`.

##

Neu in v1.3.9 — Dropbox ist ein optionales Backup-Ziel. Ein Eintrag **"Dropbox"** im Backup-Ordner-Browser wählt den Backup-Pfad `dropbox://`; die Backups landen dann in deinem Dropbox-**App-Ordner** (der kostenlose 2-GB-Plan wird unterstützt). Die Anmeldung nutzt einen **nicht ablaufenden Refresh-Token**, sodass die Verbindung nie neu autorisiert werden muss; der kurzlebige Access-Token wird automatisch geholt und erneuert (5-Minuten-Sicherheitspuffer) und in `addon_data/script.xscleaner/dropbox_state.json` zwischengespeichert.

**Setting up / Einrichtung:**

1. Create a Dropbox app at <https://www.dropbox.com/developers/apps> → **Create app** → **Scoped access** → **App folder** (e.g. `xscleaner-backups`). Note the **App Key** and **App Secret**.
2. In the app settings, add the **files.content.read**, **files.content.write**, **files.metadata.read** and **files.metadata.write** permissions.
3. Generate the **Refresh Token** by running the included helper once on any PC with Python 3: `python dropbox_token.py` (enter the App Key/App Secret when asked). It writes the token to `~/Downloads/xscleaner_dropbox_tokens.txt`.
4. In Kodi open **Settings > Backup** and fill in the new **Dropbox** group: App Key, App Secret and Refresh Token. Optionally set the **Dropbox folder** (subfolder inside the app folder, default `xscleaner`).
5. Press **Test Dropbox connection** — it uploads, reads back and deletes a probe file and confirms the connection.
6. Open **Backup & Restore → Select backup folder**, choose **Dropbox** as the backup path.

##

1. Erstelle eine Dropbox-App unter <https://www.dropbox.com/developers/apps> → **Create app** → **Scoped access** → **App folder** (z. B. `xscleaner-backups`). Notiere **App Key** und **App Secret**.
2. Füge in den App-Einstellungen die Berechtigungen **files.content.read**, **files.content.write**, **files.metadata.read** und **files.metadata.write** hinzu.
3. Erzeuge den **Refresh-Token**, indem du das mitgelieferte Hilfsprogramm einmal auf einem beliebigen PC mit Python 3 ausführst: `python dropbox_token.py` (App Key/App Secret eingeben). Es schreibt den Token nach `~/Downloads/xscleaner_dropbox_tokens.txt`.
4. Öffne in Kodi **Einstellungen > Backup** und fülle die neue Gruppe **Dropbox** aus: App Key, App Secret und Refresh-Token. Optional kannst du den **Dropbox-Ordner** setzen (Unterordner im App-Ordner, Standard `xscleaner`).
5. Drücke **Dropbox-Verbindung testen** — es lädt eine Prüfdatei hoch, liest sie zurück und löscht sie und bestätigt die Verbindung.
6. Öffne **Backup & Restore → Backup-Ordner auswählen** und wähle **Dropbox** als Backup-Pfad.

Backups larger than 140 MB (the Dropbox single-upload limit) are uploaded in 4 MB **upload sessions**; downloads stream in chunks. Both honour the backup progress dialog and can be cancelled. Because the app folder is used, no folder linking or extra authorisation is ever needed.

##

Backups größer als 140 MB (das Dropbox-Einzel-Upload-Limit) werden in 4-MB-**Upload-Sessions** hochgeladen; Downloads werden in Blöcken gestreamt. Beides läuft über den Backup-Fortschrittsdialog und ist abbrechbar. Da der App-Ordner verwendet wird, ist kein Ordner-Linking oder eine weitere Autorisierung jemals nötig.

---

### WebDAV Backup / WebDAV-Backup

New in v1.3.9 — WebDAV targets (`dav://`, `davs://`, e.g. Nextcloud or ownCloud) are fully supported as backup destination. The credentials are stored in the addon settings under **Backup > WebDAV** (server URL, user name, password) and injected into `dav://`/`davs://` paths at run time — backups, restores and scheduled auto-backups no longer need credentials in the backup path URL. The backup folder browser gained a **WebDAV (Nextcloud/ownCloud)…** entry that starts at the configured server URL, and the settings offer a **Test WebDAV connection** button. Existing `davs://user:pass@…` paths keep working unchanged.

##

Neu in v1.3.9 — WebDAV-Ziele (`dav://`, `davs://`, z. B. Nextcloud oder ownCloud) werden als Backup-Ziel voll unterstützt. Die Zugangsdaten werden in den Addon-Einstellungen unter **Backup > WebDAV** gespeichert (Server-URL, Benutzername, Passwort) und zur Laufzeit in `dav://`-/`davs://`-Pfade eingefügt — Backups, Wiederherstellungen und geplante Auto-Backups brauchen keine Zugangsdaten mehr in der Backup-Pfad-URL. Der Backup-Ordner-Browser hat einen neuen Eintrag **WebDAV (Nextcloud/ownCloud)…**, der an der konfigurierten Server-URL startet, und die Einstellungen bieten einen Button **WebDAV-Verbindung testen**. Bestehende `davs://benutzer:passwort@…`-Pfade funktionieren unverändert weiter.

**Setting up / Einrichtung:**

1. In Kodi open **Settings > Backup** and fill in the new **WebDAV** group: server URL (e.g. `https://cloud.example.com/remote.php/dav/files/user` for Nextcloud/ownCloud), user name (usually the account name, not the e-mail) and password (use an app password when 2FA is on).
2. Press **Test WebDAV connection** — it verifies the configured connection.
3. Open **Backup & Restore → Select backup folder**, choose **WebDAV (Nextcloud/ownCloud)…** and pick the folder.

##

1. Öffne in Kodi **Einstellungen > Backup** und fülle die neue Gruppe **WebDAV** aus: Server-URL (z. B. `https://cloud.example.com/remote.php/dav/files/user` für Nextcloud/ownCloud), Benutzername (meist der Kontoname, nicht die E-Mail) und Passwort (bei 2FA ein App-Passwort verwenden).
2. Drücke **WebDAV-Verbindung testen** — es prüft die konfigurierte Verbindung.
3. Öffne **Backup & Restore → Backup-Ordner auswählen**, wähle **WebDAV (Nextcloud/ownCloud)…** und wähle den Ordner.

All WebDAV file operations run over plain HTTP(S) with Basic auth using a **native WebDAV client** instead of Kodi's curl-based file access — on some servers (e.g. Nextcloud) Kodi reported a successful PUT without the file actually being persisted, so the write test failed and backup uploads/downloads were silently broken. Uploads and downloads (with progress and cancel), the write test (PUT + read-back + DELETE), reliable folder creation (MKCOL), folder listing (PROPFIND), file size and delete all run natively; the write test verifies the probe by reading it back (GET) instead of Kodi's unreliable `CFile::Exists`/`CFile::Stat`, so a folder is no longer falsely reported as "not writable". Failed write probes are deleted from the share. WebDAV folders appear in the backup folder browser navigation (".." works there too). The URL options `|verifypeer=false|` and `|verifyhost=false|` are honoured for servers with self-signed certificates.

##

Alle WebDAV-Dateioperationen laufen über direktes HTTP(S) mit Basic-Auth und einem **nativen WebDAV-Client** statt über Kodis curl-basierten Dateizugriff — auf manchen Servern (z. B. Nextcloud) meldete Kodi einen erfolgreichen PUT, ohne die Datei tatsächlich zu speichern, sodass der Schreibtest fehlschlug und Backup-Uploads/-Downloads still brachen. Uploads und Downloads (mit Fortschritt und Abbruch), der Schreibtest (PUT + Zurücklesen + DELETE), die zuverlässige Ordnererstellung (MKCOL), die Ordnerliste (PROPFIND), Dateigröße und Löschen laufen alle nativ; der Schreibtest verifiziert die Testdatei durch Zurücklesen (GET) statt über Kodis unzuverlässiges `CFile::Exists`/`CFile::Stat`, sodass ein Ordner nicht mehr fälschlich als "nicht beschreibbar" gemeldet wird. Fehlgeschlagene Schreibtestsdateien werden von der Freigabe gelöscht. WebDAV-Ordner erscheinen in der Browser-Navigation des Backup-Ordners (".." funktioniert dort ebenfalls). Die URL-Optionen `|verifypeer=false|` und `|verifyhost=false|` werden für Server mit selbstsignierten Zertifikaten beachtet.

---

### Automatic Scheduled Backup / Automatisches geplantes Backup

New in v1.3.7 — controlled by the new **Automatic backup** group in the Backup settings. When enabled, the addon service stays active and runs a **full backup** at a configurable interval and time:

| Setting / Einstellung | Description / Beschreibung | Default / Standard |
|---|---|---|
| **Automatic backup / Automatisches Backup** | Master toggle — enables the scheduled full backup | Off / Aus |
| **Backup interval (days) / Backup-Intervall (Tage)** | Days between scheduled full backups (1-30) | 7 |
| **Backup hour (0-23) / Backup-Stunde (0-23)** | Hour of day at which the backup runs | 3 |

The next run is scheduled from the last successful backup at the configured hour. A **banner notification** announces when an automatic backup starts and finishes — no popup or confirmation is needed. The scheduled time is tracked in `addon_data/script.xscleaner/backup_state.json`.

**Missed-backup catch-up:** If the scheduled backup did not run — because Kodi was not running at the configured hour or the run failed — the next Kodi start shows a yes/no dialog asking whether to run a full backup now. Confirming runs the backup immediately in the background (banner notification, Kodi stays usable); declining skips this slot until the next interval. The schedule is independent of manual backups.

##

Neu in v1.3.7 — gesteuert durch die neue Gruppe **Automatisches Backup** in den Backup-Einstellungen. Wenn aktiviert, bleibt der Addon-Dienst aktiv und führt in einem konfigurierbaren Intervall und zu einer festgelegten Uhrzeit ein **Voll-Backup** aus:

| Einstellung | Beschreibung | Standard |
|---|---|---|
| **Automatisches Backup** | Hauptschalter — aktiviert das geplante Voll-Backup | Aus |
| **Backup-Intervall (Tage)** | Tage zwischen den geplanten Voll-Backups (1-30) | 7 |
| **Backup-Stunde (0-23)** | Uhrzeit, zu der das Backup läuft | 3 |

Der nächste Lauf wird ab dem letzten erfolgreichen Backup zur konfigurierten Stunde eingeplant. Eine **Banner-Benachrichtigung** kündigt den Start und das Ende eines automatischen Backups an — kein Popup oder Bestätigungsdialog nötig. Der geplante Zeitpunkt wird in `addon_data/script.xscleaner/backup_state.json` gespeichert.

**Nachholen verpasster Backups:** Wenn das geplante Backup nicht ausgeführt wurde — weil Kodi zur konfigurierten Stunde nicht lief oder der Lauf fehlschlug — zeigt der nächste Kodi-Start einen Ja/Nein-Dialog mit der Frage, ob jetzt ein Voll-Backup ausgeführt werden soll. Bestätigen führt das Backup sofort im Hintergrund aus (Banner-Benachrichtigung, Kodi bleibt bedienbar); Ablehnen überspringt diesen Slot bis zum nächsten Intervall. Der Zeitplan ist unabhängig von manuellen Backups.

---

### Kodi Factory Reset / Kodi auf Werkseinstellungen zurücksetzen

Controlled by setting: `Enable Kodi factory reset` (disabled by default). Only when enabled does the menu item appear.

##

Gesteuert durch die Einstellung: `Kodi-Werkseinstellung aktivieren` (standardmäßig deaktiviert). Nur wenn aktiviert erscheint der Menüpunkt.

**WARNING: This will reset Kodi completely, except XSCleaner and its dependencies!**

**WARNUNG: Kodi wird komplett zurückgesetzt, mit Ausnahme von XSCleaner und dessen Abhängigkeiten!**

Walks the entire `special://home/` directory and deletes all files and directories, except:
- script.xscleaner and script.module.* addons (preserved for re-installation)
- kodi.log and kodi.old.log

After cleanup, reloads the Kodi master profile.

##
Durchsucht das gesamte `special://home/` Verzeichnis und löscht alle Dateien und Verzeichnisse, außer:
- script.xscleaner und script.module.* Addons (bleiben für Neuinstallation erhalten)
- kodi.log und kodi.old.log

Nach der Bereinigung wird das Kodi-Masterprofil neu geladen.

---

### Startup Manager / Startup Manager

Lists all installed service addons (those with `<extension point="xbmc.service">` in their addon.xml). Shows enabled/disabled status and lets you toggle each one.

##
Listet alle installierten Service-Addons auf (solche mit `<extension point="xbmc.service">` in ihrer addon.xml). Zeigt Aktiviert/Deaktiviert-Status an und ermöglicht das Umschalten.

---

### Log File Viewer / Logdatei-Betrachter

Lists all `.log` files in `special://logpath/` and displays the selected file in a text viewer (read-only).

##
Listet alle `.log` Dateien in `special://logpath/` auf und zeigt die ausgewählte Datei in einem Textbetrachter an (schreibgeschützt).

---

### Activity Log / Aktivitätsprotokoll

Every cleaning, backup, or system action is recorded in a local SQLite database (`activitylog.db`). Each entry shows timestamp, action name, summary, items cleaned, and space freed. Selecting an entry reveals the individual file paths and sizes that were affected.

##
Jede Bereinigungs-, Backup- oder Systemaktion wird in einer lokalen SQLite-Datenbank (`activitylog.db`) aufgezeichnet. Jeder Eintrag zeigt Zeitstempel, Aktionsname, Zusammenfassung, bereinigte Elemente und freigegebenen Speicherplatz. Die Auswahl eines Eintrags zeigt die betroffenen einzelnen Dateipfade und Größen.

---

### Settings / Einstellungen

Access via the main menu. Configurable options:

##
Zugriff über das Hauptmenü. Konfigurierbare Optionen:

| Setting / Einstellung | Description / Beschreibung | Default / Standard |
|---|---|---|---|
| Clean Cache / Cache bereinigen | Master toggle for cache cleaning | On / An |
| Clean HTTP/Image cache | Clean Kodi HTTP response and image cache (requires Clean Cache) | On / An |
| Clean Weather addon caches | Clean cached weather data (requires Clean Cache) | On / An |
| Clean Downloads | Clean Kodi download manager files (requires Clean Cache) | On / An |
| Clean Search History | Clear recent searches from guisettings.xml (requires Clean Cache) | On / An |
| Clean Temp / Temp bereinigen | Enable temp cleaning | On / An |
| Clean Unused Thumbnails | Enable unused thumbnail removal | On / An |
| Clean Old Thumbnails / Alte Thumbnails | Enable old thumbnail removal | On / An |
| Thumbnail Age / Thumbnail-Alter | Max age in days for old thumbnails | 30 |
| Clean Packages / Pakete bereinigen | Enable package cleanup | On / An |
| Clean Unused Languages | Remove non-English/German language files (part of Package Cleanup) | Off / Aus |
| Enable Kodi factory reset | Show the "Reset Kodi to factory defaults" menu item | Off / Aus |
| Clean Crash Logs | Enable crash log cleanup | On / An |
| Clean Addon Leftovers | Enable addon leftover removal | On / An |
| DB Backup Before Optimize | Backup databases before VACUUM | On / An |
| Run VACUUM | Run VACUUM during DB optimize | On / An |
| Integrity Check / Integritätsprüfung | Run quick_check during DB optimize | On / An |
| Cleanup Orphaned DB Entries | Remove orphaned DB rows | Off / Aus |
| Clean TMDBHelper Caches / TMDBHelper-Caches | Delete TMDBHelper cache databases (itemdetails.db, .db-wal) | On / An |
| Clean Celebrity/Artist Data | Clear celebrity/actor/artist tables from MyVideos*.db | Off / Aus |
| Rebuild Textures13.db | Backup and delete Textures13.db to force full rebuild | Off / Aus |
| Backup Path / Pfad | Directory for backups — set it via the "Backup-Ordner (SMB/NFS/FTP)… / Backup folder (SMB/NFS/FTP)…" button in the Backup settings to also pick network shares | Empty / Leer |
| Max Backups to Keep / Maximale Anzahl Backups | Max backups kept per type before oldest are removed (0 = off) | 10 |
| Dropbox App Key / Dropbox App-Key | Dropbox app key for the backup app (see Dropbox Backup) | Empty / Leer |
| Dropbox App Secret / Dropbox App-Secret | Dropbox app secret for the backup app | Empty / Leer |
| Dropbox Refresh Token / Dropbox Refresh-Token | Never-expiring refresh token, generated with dropbox_token.py | Empty / Leer |
| Dropbox Folder / Dropbox-Ordner | Subfolder inside the Dropbox app folder for backups | xscleaner |
| Dropbox connection test / Dropbox-Verbindung testen | Button: verifies upload, read-back and delete on Dropbox | — |
| WebDAV server URL / WebDAV-Server-URL | Base URL of the WebDAV target, e.g. `https://cloud.example.com/remote.php/dav/files/user` (Nextcloud/ownCloud) — injected into dav:///davs:// paths | Empty / Leer |
| WebDAV user name / WebDAV-Benutzername | Cloud login name (usually the account name, not the e-mail) | Empty / Leer |
| WebDAV password / WebDAV-Passwort | Cloud password (use an app password when 2FA is on) | Empty / Leer |
| WebDAV connection test / WebDAV-Verbindung testen | Button: verifies the configured WebDAV connection | — |
| Automatic backup / Automatisches Backup | Enable scheduled automatic full backups | Off / Aus |
| Backup interval (days) / Backup-Intervall (Tage) | Days between scheduled full backups (1-30) | 7 |
| Backup hour (0-23) / Backup-Stunde (0-23) | Hour of day at which the automatic backup runs | 3 |
| Auto Cleanup at Startup | Enable automatic cleanup on Kodi start | Off / Aus |
| Startup Delay / Startverzögerung | Seconds to wait before auto cleanup | 30 |
| Cleanup Interval / Bereinigungsintervall | Min days between auto cleanups (0=every start) | 0 |
| Auto Update Check | Check for addon updates automatically | On / An |
| Update Interval / Update-Intervall | Hours between update checks | 24 |

---

## Auto Cleanup Service / Automatischer Bereinigungsservice

When enabled in settings, XSCleaner runs a background service at Kodi startup that automatically cleans enabled cleanup categories (cache with all sub-options, thumbnails, packages, crash logs, addon leftovers, unused languages) after a configurable delay (default 30 seconds). Each category can be individually enabled/disabled in settings.

The service also respects the **Cleanup Interval** setting: when set to 0 (default), cleanup runs on every Kodi start. When set to 1-30 days, the service skips execution if the last run was more recent than the configured interval, preventing unnecessary cleanup on frequent restarts. The last run timestamp is stored in `addon_data/script.xscleaner/last_auto_cleanup.txt`.

When **Automatic backup** is enabled in the Backup settings, the same service additionally stays active after the cleanup to act as a scheduler: it waits for the next scheduled full-backup time (interval + hour), runs the backup silently with a banner notification, and — if a scheduled backup was missed — asks on the next Kodi start whether to run it now (see [Automatic Scheduled Backup](#automatic-scheduled-backup--automatisches-geplantes-backup)).

##
Wenn in den Einstellungen aktiviert, führt XSCleaner einen Hintergrunddienst beim Kodi-Start aus der automatisch alle aktivierten Bereinigungskategorien (Cache mit allen Sub-Optionen, Thumbnails, Pakete, Crash-Logs, Addon-Überreste, unbenutzte Sprachen) nach einer konfigurierbaren Verzögerung (Standard 30 Sekunden) bereinigt. Jede Kategorie kann einzeln in den Einstellungen aktiviert/deaktiviert werden.

Der Dienst respektiert auch die **Bereinigungsintervall**-Einstellung: bei 0 (Standard) wird bei jedem Kodi-Start gereinigt. Bei 1-30 Tagen überspringt der Dienst die Ausführung wenn der letzte Lauf kürzer zurückliegt als das eingestellte Intervall, um unnötige Bereinigungen bei häufigen Neustarts zu vermeiden. Der Zeitstempel des letzten Laufs wird in `addon_data/script.xscleaner/last_auto_cleanup.txt` gespeichert.

Wenn **Automatisches Backup** in den Backup-Einstellungen aktiviert ist, bleibt derselbe Dienst nach der Bereinigung zusätzlich als Scheduler aktiv: Er wartet auf den nächsten geplanten Voll-Backup-Zeitpunkt (Intervall + Uhrzeit), führt das Backup still mit einer Banner-Benachrichtigung aus und fragt bei einem verpassten geplanten Backup beim nächsten Kodi-Start, ob es jetzt ausgeführt werden soll (siehe [Automatisches geplantes Backup](#automatic-scheduled-backup--automatisches-geplantes-backup)).

---

## License / Lizenz

This project is licensed under the GNU General Public License v3.0. See [LICENSE](LICENSE) for details.

##
Dieses Projekt steht unter der GNU General Public License v3.0. Siehe [LICENSE](LICENSE) für Details.
