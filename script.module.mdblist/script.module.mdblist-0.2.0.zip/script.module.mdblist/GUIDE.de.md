# MDBList Addon – Anleitung (Deutsch)

[English guide](GUIDE.md) · [English README](README.md) · [Deutsches README](README.de.md)

`script.module.mdblist` verbindet Kodi mit [MDBList.com](https://mdblist.com):
Scrobbling der Wiedergabe, Synchronisierung zwischen Kodi-Bibliothek und
MDBList-Konto sowie ein Python-Modul für andere Addons.

## Voraussetzungen

- Kodi 19 (Matrix) oder neuer
- Kostenloser MDBList-Account mit API-Key:
  auf mdblist.com einloggen → *Preferences* → *API key* kopieren
- Den Key im Addon eintragen: *Addons → Meine Addons → MDBList → Einstellungen
  → Allgemein → API-Key*

## Scrobbling

Solange der Hintergrunddienst läuft, wird jede Film-/Serienwiedergabe an
MDBList gemeldet:

| Ereignis | Wird gesendet | Kodi-Benachrichtigung |
|---|---|---|
| Wiedergabestart | `start` | ja |
| **Pause** | `pause` | **nein (bewusst)** |
| Fortsetzen | `start` (mit aktuellem Fortschritt) | ja |
| Stopp / Ende | `stop` | ja |

> **Hinweis zu Pause:** Pausieren wird vollständig ausgewertet und an MDBList
> übertragen – es erscheint nur absichtlich keine Benachrichtigung, damit
> häufiges Pausieren keine Notify-Flut erzeugt. Auf mdblist.com ist der Titel
> trotzdem korrekt als „pausiert" markiert. Wer das prüfen möchte: Debug-Log
> aktivieren, beim Pausieren erscheint `SCROBBLE [pause] …`.

Einstellungen:

- **Scrobbling aktivieren** (Standard: an)
- **Mindestfortschritt in %**: Stopps unterhalb dieses Wertes werden nicht als
  „gesehen" gewertet (Standard 5 %)

### Bewertungs-Popup nach der Wiedergabe

Optional (Standard: aus): Nach Ende einer Film-/Serienepisode – oder wenn
jenseits der Schwelle manuell gestoppt wird – öffnet das Addon einen
Auswahldialog (*Keine Bewertung, 1 ★ … 10 ★*) und überträgt die Wahl an
MDBList.

- **Nach Wiedergabe nach Bewertung fragen**: Feature einschalten
- **Mindestfortschritt für Bewertungsfrage (%)**: Slider, Minimum 75 %
  (Standard 85 %)
- **Bewertungsfrage für**: Filme und Serien / Nur Filme / Nur Serien

Hinweise:

- Das Popup setzt aktives Scrobbling voraus (die Identifikation hängt daran)
  und erscheint nur bei erfolgreich identifizierten Inhalten.
- Episoden werden auf mdblist.com auf **Episoden-Ebene** bewertet. Der
  Ratings-Pull liest derzeit nur Filme zurück nach Kodi – Episoden-Bewertungen
  kommen also (noch) nicht zurück.
- Derselbe Sterne-Picker ersetzt beim Bewerten über das Kontextmenü das alte
  Zahlenfeld.

### Erkennung von Inhalten

Das Addon identifiziert abgespielte Inhalte in dieser Reihenfolge:

1. TMDB-/IMDB-ID des Kodi-ListItems (Bibliotheksinhalte)
2. Rückwärtssuche über den Dateipfad in der Kodi-Bibliothek (z. B. für
   strm-Dateien von xStream ohne eigene IDs)
3. Titel-/Jahres-Suche über die MDBList-API (nicht in der Bibliothek),
   Ergebnis wird 30 Tage zwischengespeichert

## Synchronisierung

Jede Richtung ist einzeln abschaltbar (*Einstellungen → Sync*):

- **Gesehen-Status**: Push und Pull für Filme und Episoden. Es zählen die
  Abspielanzahl (plays); bei Gleichstand gewinnt der neuere Zeitstempel.
  MDBList ist beim Pull **führend**, aber nur für Einträge, die MDBList
  tatsächlich kennt:
  - Als gesehen geführte Einträge → in Kodi als gesehen markiert.
  - Als **explizit ungesehen** geführte Einträge (aus dem MDBList-Sync-Journal)
    → in Kodi als ungesehen markiert (`playcount` 0, Gesehen-Datum geleert).
    Hat ein solcher Eintrag in Kodi aktuell einen Fortsetzungspunkt (als
    „teilweise angesehen" angezeigt), wird dieser ebenfalls entfernt, sodass
    er nicht mehr als angespielt erscheint.
  - Einträge, die MDBList unbekannt sind, bleiben in Kodi unangetastet.
  Um eine Endlosschleife zu vermeiden, überspringt der **Push** alles, was
  MDBList aktuell als explizit ungesehen führt: Ein auf MDBList als ungesehen
  markierter Titel wird vom nächsten Push nie still heimlich wieder als
  gesehen gemeldet, selbst wenn Kodi ihn noch als gesehen zählt.
  Serien werden ausschließlich auf **Episodenebene** synchronisiert: Episoden
  werden mit ihrer eigenen Episoden-ID gepusht (der dokumentierte flache
  `episodes`-Bucket), und der Pull zieht nach, was auf MDBList als einzelne
  Episode als gesehen (oder als ungesehen markiert) geführt ist.
  Staffel-Kennzeichen („ganze Staffel gesehen") von MDBList werden ignoriert,
  da MDBList sie inkonsistent setzen kann; Kodi leitet eine gesehene Staffel
  selbst aus ihren gesehenen Episoden ab.
- **Bewertungen**: Kodi-*userrating* ↔ MDBList-Rating (Filme; Serien folgen).
- **Bibliothek → Sammlung** (Standard: aus): Gleicht die gesamte
  Kodi-Bibliothek mit der MDBList-Collection ab – Filme **und einzelne
  Episoden**. Es wird nur hinzugefügt: Löschen aus der Kodi-Bibliothek
  entfernt nichts aus der Collection. Erst mit dieser Option erscheinen auch
  **ungesehene** Filme/Serien auf mdblist.com.

Wichtig zum Verständnis der Log-/Zusammenfassungsangaben: Die Zahlen bedeuten
immer „in diesem Lauf **neu** übertragen". Steht dort `movies: 0`, heißt das
„nichts Neues" – nicht „Sammlung leer".

Weitere Einstellungen:

- **Startverzögerung**: Wartezeit nach Kodi-Start vor dem ersten Sync
  (Standard 120 s)
- **Intervall**: periodischer Sync in Minuten, 0 = aus
- **Sync nach Bibliotheksaktualisierung**: Sync nach jedem Scan/Clean. Ein
  Rescan kann bedeuten, dass eine Serie gelöscht und neu hinzugefügt wurde
  (Kodi setzt dabei die Gesehen-Zähler zurück), daher läuft dieser Sync
  erzwungen: Der Remote-Gesehen-Status wird erneut angewendet, selbst wenn
  sich das MDBList-Aktivitäts-Watermark nicht geändert hat.

### Manueller Sync

Kontextmenü im Addon → **Jetzt synchronisieren**, oder
`RunScript(script.module.mdblist, action=sync)`.

Der manuelle Sync wartet bis zu 45 Sekunden, falls gerade ein
Dienst-Sync läuft, statt sofort abzubrechen. Erscheint die Meldung
„Es läuft bereits eine Synchronisierung", war innerhalb dieser Zeit kein
Slot frei – einfach erneut versuchen. Nach echtem Abschluss folgt eine
Bestätigung.

## Aktionen (RunScript)

```text
RunScript(script.module.mdblist, action=sync)              # Sync erzwingen
RunScript(script.module.mdblist, action=rate, id=tmdb:769, rating=9)
RunScript(script.module.mdblist, action=watchlist,
          operation=add, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=list,
          list_id=123, operation=add, id=tmdb:769)
RunScript(script.module.mdblist, action=auth_info)         # Key-Status zeigen
RunScript(script.module.mdblist, action=contextmenu)       # Dialog öffnen
```

`id` akzeptiert `tmdb:`, `imdb:`, `trakt:`, `tvdb:` oder eine nackte Zahl.
Ohne `id`/`type` wird der aktuell abgespielte Titel verwendet.

## Fehlerbehebung

1. *Debug-Logging* in den Addon-Einstellungen aktivieren
2. Kodi-Neustart bzw. manuellen Sync auslösen
3. Log prüfen (`kodi.log`), relevante Zeilen beginnen mit
   `[script.module.mdblist]`

Typische Zeilen:

```text
SCROBBLE [start] (id: library) tmdb:1399 "Serie X" at 3%
SCROBBLE [pause] …            ← Pause wurde gesendet (keine Notify dazu)
Remote watched snapshot: movies=3 shows=0 seasons=1 episodes=3 total=7 complete=True
Watched pull: {'movies': 0, 'episodes': 3, 'unwatched_movies': 0, 'unwatched_episodes': 0, 'resume_reset': 0}
Watched push: 3 entries (movies=1 episodes=2)
Watched push response: {'updated': 2, 'not_found': 0, 'errors': 0, 'plays': 0}
              (raw: ['{"updated":{"episodes":[{"tvdb":123}]},"not_found":{"episodes":[]},"errors":[],"plays":[]}'])
Collection remote snapshot: movies=12 shows=2
Collection diff: movies=0 show payloads=1 episodes=14 unresolved=0
Collection push: {'status': 'ok', 'movies': 0, 'episodes': 14}
Sync finished in 16.4s: {…}
```

Häufige Fälle:

- **In Kodi gesehene Episoden/Serien erreichen mdblist.com nicht**: Vor 0.1.8
  nutzte der Episoden-Sync das verschachtelte Payload
  `shows[].seasons[].episodes[].number`, das MDBList zwar annimmt, aber
  stillschweigend ignoriert. Seit 0.1.8 wird der dokumentierte flache
  `episodes`-Bucket mit der eigenen Provider-ID der Episode gepusht. Eine
  Serie muss in der Bibliothek gescrapet sein, damit ihre Episoden
  `uniqueid`s tragen – andernfalls kann kein Eintrag identifiziert werden;
  das Sync-Log warnt dann mit der Anzahl übersprungener Episoden.
- **Inhalte fehlen in der Sammlung**: `unresolved=` > 0 bedeutet, dass eine
  Serie weder IDs noch per Titelsuche aufgelöst werden konnte. Serien mit
  TVDB-only-IDs werden direkt als solche übertragen (MDBList akzeptiert
  tmdb/tvdb/imdb/trakt).
- **Rate-Limit**: Der kostenlose API-Tarif erlaubt 1000 Requests/Tag; die
  Caches (Remote-Snapshots 6 h, ID-Auflösungen 30 Tage) halten das Aufkommen
  niedrig.
- **Alles zurücksetzen**: Im Profilordner des Addons die `cache.db` löschen
  und Kodi neu starten.
