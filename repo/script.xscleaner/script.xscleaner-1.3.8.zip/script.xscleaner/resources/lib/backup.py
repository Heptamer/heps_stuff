from datetime import datetime
import glob
import os
import shutil
import time
import xml.etree.ElementTree as ET
import zipfile
from . import vfs
from .constants import (
    HOME, HOME_ADDONS, ADDON_DATA, TEMP,
    DATABASE, SOURCES_XML, ADVSETTINGS_XML,
    GUISETTINGS_XML, PROFILES_XML, KEYMAP_DIR,
    PLAYLISTS_DIR, translate
)
from .utils import (
    log, notify, yesno_dialog, ok_dialog,
    progress_create, progress_update, progress_close,
    get_setting, set_setting, ADDON_NAME,
    get_localized_string
)
from .logger import log_action


BACKUP_TYPES = {
    'full': 32340,
    'addons': 32341,
    'addon_data': 32342,
    'addons_data': 32343,
    'databases': 32236,
    'settings': 32344,
    'profiles': 32346,
    'keymaps': 32347,
    'playlists': 32348
}


class _OperationCancelled(Exception):
    pass


def backup_restore_menu():
    options = [
        get_localized_string(32349),
        get_localized_string(32350)
    ]
    selection = __import__('xbmcgui').Dialog().select(ADDON_NAME, options)

    if selection == 0:
        _backup_menu()
    elif selection == 1:
        _restore_menu()


_SCHEME_ROOTS = ('smb://', 'nfs://', 'ftp://', 'http://', 'https://')


def _is_scheme_root(path):
    return path in _SCHEME_ROOTS or path == '/'


def _display_path(path):
    # strip credentials (user:pass@) from remote URLs for display only
    if '://' in path and '@' in path:
        scheme, rest = path.split('://', 1)
        return f'{scheme}://{rest.rsplit("@", 1)[-1]}'
    return path


def _browser_parent(path):
    path = str(path)
    if not path.rstrip('/'):
        return None
    for scheme in _SCHEME_ROOTS:
        if path == scheme:
            return None
        if path.startswith(scheme):
            rest = path[len(scheme):].strip('/')
            if not rest:
                return None
            if '/' in rest:
                return scheme + rest.rsplit('/', 1)[0]
            return scheme
    parent = os.path.dirname(path.rstrip('/') or path)
    if parent == path.rstrip('/'):
        return None
    return parent


def _get_sources():
    sources = []
    try:
        root = ET.parse(SOURCES_XML).getroot()
    except Exception:
        return sources
    for source in root.findall('.//source'):
        name_el = source.find('name')
        path_el = source.find('path')
        if path_el is None or not path_el.text:
            continue
        p = path_el.text
        if p.startswith('special://'):
            resolved = translate(p)
            if not resolved:
                continue
            p = resolved
        label = f'{name_el.text} ({p})' if name_el is not None and name_el.text else p
        sources.append({'label': label, 'path': p})
    return sources


def _manual_path(current=None):
    result = __import__('xbmcgui').Dialog().input(get_localized_string(32399), current or '')
    result = result.strip() if result else ''
    return result or None


def _browser_entries(current):
    entries = []

    if not current:
        entries.append({'label': get_localized_string(32377), 'action': 'open', 'path': '/'})
        for source in _get_sources():
            entries.append({'label': source['label'], 'action': 'open', 'path': source['path']})
        entries.append({'label': get_localized_string(32378), 'action': 'open', 'path': 'smb://'})
        entries.append({'label': get_localized_string(32379), 'action': 'open', 'path': 'nfs://'})
        entries.append({'label': get_localized_string(32388), 'action': 'open', 'path': 'ftp://'})
        entries.append({'label': get_localized_string(32389), 'action': 'manual'})
        return entries

    parent = _browser_parent(current)
    if not _is_scheme_root(current):
        entries.append({'label': '[B]' + get_localized_string(32369) + '[/B]', 'action': 'choose'})
    if parent is not None:
        entries.append({'label': '[B]' + get_localized_string(32580) + '[/B]', 'action': 'manual'})
        entries.append({'label': '..', 'action': 'open', 'path': parent})
    else:
        entries.append({'label': '..', 'action': 'open', 'path': ''})

    remote = '://' in current
    if remote:
        progress_create(ADDON_NAME, get_localized_string(32581))
    start = time.time()
    try:
        dirs = [d for d in vfs.listdir_dirs(current) if not d.startswith('@')]
    finally:
        if remote:
            remaining = 300 - (time.time() - start) * 1000
            if remaining > 0:
                __import__('xbmc').sleep(int(remaining))
            progress_close()

    for name in dirs:
        entries.append({'label': name, 'action': 'open', 'path': vfs.join(current, name)})

    return entries


def _browse_vfs():
    current = _resolve_path(get_setting('backup_path')) or ''
    dialog = __import__('xbmcgui').Dialog()

    while True:
        current = _resolve_path(current)
        entries = _browser_entries(current)
        if not entries:
            ok_dialog(ADDON_NAME, get_localized_string(32398))
            return None

        options = [e['label'] for e in entries]
        display = _display_path(current)
        heading = display or get_localized_string(32366)
        selection = dialog.select(heading, options)
        if selection == -1:
            return None

        entry = entries[selection]

        if entry['action'] == 'choose':
            remote = '://' in current
            if remote:
                progress_create(ADDON_NAME, get_localized_string(32581))
            start = time.time()
            try:
                ok = vfs.mkdirs(current) and vfs.writable(current)
            finally:
                if remote:
                    remaining = 300 - (time.time() - start) * 1000
                    if remaining > 0:
                        __import__('xbmc').sleep(int(remaining))
                    progress_close()
            if not ok:
                ok_dialog(ADDON_NAME, get_localized_string(32368))
                continue
            return current

        if entry['action'] == 'manual':
            current_backup_path = get_setting('backup_path') if current == '' else current
            entered = _manual_path(current_backup_path)
            if entered is None:
                continue
            current = entered
            continue

        current = entry['path']


def _select_backup_path():
    selected = _browse_vfs()
    if not selected:
        return
    set_setting('backup_path', selected)


def _resolve_path(path):
    if not path:
        return ''
    if path.startswith('special://'):
        return translate(path) or ''
    return path


def _backup_menu():
    backup_path = _resolve_path(get_setting('backup_path'))
    if not backup_path:
        ok_dialog(ADDON_NAME, get_localized_string(32351))
        return

    options = [get_localized_string(sid) for sid in BACKUP_TYPES.values()]
    selection = __import__('xbmcgui').Dialog().select(ADDON_NAME, options)

    if selection == -1:
        return

    backup_type = list(BACKUP_TYPES.keys())[selection]

    if not yesno_dialog(ADDON_NAME, get_localized_string(32352).format(get_localized_string(BACKUP_TYPES[backup_type]))):
        return

    create_backup(backup_path, backup_type)


def _restore_menu():
    backup_path = _resolve_path(get_setting('backup_path'))
    if not backup_path or not vfs.exists(backup_path):
        ok_dialog(ADDON_NAME, get_localized_string(32353))
        return

    backups = _list_backups(backup_path)
    if not backups:
        ok_dialog(ADDON_NAME, get_localized_string(32354))
        return

    options = [b['name'] for b in backups]
    selection = __import__('xbmcgui').Dialog().select(ADDON_NAME, options)

    if selection == -1:
        return

    if not yesno_dialog(ADDON_NAME, get_localized_string(32355), get_localized_string(32356)):
        return

    _restore_backup(backups[selection]['path'])


def _backup_include(name):
    if name == '__pycache__':
        return False
    if name.endswith('.pyc'):
        return False
    return True


def _measure_items(items):
    total_bytes = 0
    total_files = 0
    for _name, src in items:
        if os.path.isfile(src):
            total_files += 1
            try:
                total_bytes += os.path.getsize(src)
            except OSError:
                pass
        elif os.path.isdir(src):
            for root, dirs, files in os.walk(src):
                dirs[:] = [d for d in dirs if _backup_include(d)]
                for f in files:
                    if not _backup_include(f):
                        continue
                    total_files += 1
                    try:
                        total_bytes += os.path.getsize(os.path.join(root, f))
                    except OSError:
                        pass
    return total_bytes, total_files


def _ensure_temp_space(needed):
    try:
        free = shutil.disk_usage(TEMP).free
    except Exception:
        return True
    return free > needed


def _zip_add_tree(zf, src, arc_base, on_file, item_name):
    """Adds a directory tree (local) to the zip. Returns (files_added, ok)."""
    files_added = 0
    ok = True
    for root, dirs, files in os.walk(src):
        dirs[:] = sorted(d for d in dirs if _backup_include(d))
        files = sorted(f for f in files if _backup_include(f))
        rel = os.path.relpath(root, src)
        arc_dir = arc_base if rel == '.' else f'{arc_base}/{rel}'.replace(os.sep, '/')
        if not files and not dirs:
            zf.writestr(f'{arc_dir}/', b'')
        for f in files:
            arc = f'{arc_dir}/{f}'
            try:
                zf.write(os.path.join(root, f), arc)
                files_added += 1
                if on_file:
                    on_file(arc[len(arc_base) + 1:], item_name)
            except _OperationCancelled:
                raise
            except Exception as e:
                ok = False
                log(f'Backup failed: could not add {os.path.join(root, f)} to archive: {e}')
    return files_added, ok


def _remove_tmp_zip(tmp_zip):
    try:
        if os.path.exists(tmp_zip):
            os.remove(tmp_zip)
    except OSError:
        pass


def create_backup(backup_path, backup_type, silent=False):
    backup_path = _resolve_path(backup_path)
    if not backup_path:
        log(f'Backup aborted: no valid backup path')
        return False

    if not silent:
        progress_create(ADDON_NAME, get_localized_string(32357))

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_name = f'xscleaner_{backup_type}_{timestamp}'
    share_zip = vfs.join(backup_path, backup_name + '.zip')
    tmp_zip = os.path.join(TEMP, backup_name + '.zip')

    try:
        if not vfs.mkdirs(backup_path):
            if not silent:
                progress_close()
                ok_dialog(ADDON_NAME, get_localized_string(32368))
            log(f'Backup failed: cannot create directory {backup_path}')
            return False
        if not vfs.writable(backup_path):
            if not silent:
                progress_close()
                ok_dialog(ADDON_NAME, get_localized_string(32368))
            log(f'Backup failed: backup path is not writable: {backup_path}')
            return False

        items = _get_backup_items(backup_type)
        log(f'Backup started: {backup_name} from {backup_path}, {len(items)} item(s): '
            + ', '.join(name for name, _ in items) or 'none')

        total_bytes, total_files = _measure_items(items)
        if not _ensure_temp_space(total_bytes):
            if not silent:
                progress_close()
                ok_dialog(ADDON_NAME, get_localized_string(32368))
            log(f'Backup failed: not enough free space in {TEMP} for {total_bytes} bytes')
            return False

        detail_paths = []
        failed = 0
        files_done = [0]

        def _on_file(rel, item_name):
            files_done[0] += 1
            if silent:
                return
            display = f'{item_name}/{rel}' if rel else item_name
            pct = int(files_done[0] / total_files * 100) if total_files else 0
            if not progress_update(pct, get_localized_string(32401).format(display)):
                raise _OperationCancelled()

        def _on_upload(written):
            if silent:
                return
            pct = int(min(100, written / total_bytes * 100)) if total_bytes else 0
            if not progress_update(pct, get_localized_string(32401).format(backup_name + '.zip')):
                raise _OperationCancelled()

        with zipfile.ZipFile(tmp_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
            for name, src in items:
                try:
                    kind = vfs.mode_type(src)
                    log(f'Backup item {name}: src={src}, type={kind}')
                    if kind is None:
                        if not vfs.exists(src):
                            log(f'Backup skipped missing item {name}: {src}')
                            continue
                        failed += 1
                        log(f'Backup failed: cannot determine type of {src}')
                        continue
                    if kind == 'file':
                        zf.write(src, name)
                        _on_file('', name)
                        detail_paths.append((src, vfs.getsize(src)))
                        log(f'Added {name} to archive')
                    elif kind == 'dir':
                        _added, item_ok = _zip_add_tree(zf, src, name, _on_file, name)
                        if not item_ok:
                            failed += 1
                            log(f'Backup failed: could not add directory {name} to the archive')
                        else:
                            detail_paths.append((src, vfs.get_dir_size(src)))
                            log(f'Added directory {name} ({_added} files) to archive')
                except _OperationCancelled:
                    raise
                except Exception as e:
                    failed += 1
                    log(f'Error backing up {name}: {e}')

        bad = zipfile.ZipFile(tmp_zip).testzip()
        if bad is not None:
            failed += 1
            log(f'Backup failed: built archive is corrupt ({bad})')
        elif total_files == 0:
            failed += 1
            log(f'Backup failed: no files found to back up')
        else:
            if vfs.copy(tmp_zip, share_zip, on_progress=_on_upload if not silent else None):
                remote_size = vfs.getsize(share_zip)
                local_size = os.path.getsize(tmp_zip)
                if remote_size and remote_size != local_size:
                    failed += 1
                    log(f'Backup failed: size mismatch for {share_zip} ({remote_size} != {local_size})')
                    vfs.delete(share_zip)
                else:
                    if not remote_size:
                        log(f'Backup uploaded: {share_zip} (size could not be verified)')
                    else:
                        log(f'Backup uploaded: {share_zip}')
            else:
                failed += 1
                log(f'Backup failed: could not upload {backup_name}.zip to {share_zip}')
                vfs.delete(share_zip)
    except _OperationCancelled:
        if not silent:
            progress_close()
        log('Backup cancelled by user')
        return False
    except Exception as e:
        failed += 1
        log(f'Backup aborted by unexpected error: {e}')
        if not silent:
            progress_close()
            notify(ADDON_NAME, get_localized_string(32391).format(failed))
        return False
    finally:
        _remove_tmp_zip(tmp_zip)

    if not silent:
        progress_close()
        if failed > 0:
            notify(ADDON_NAME, get_localized_string(32391).format(failed))
        else:
            notify(ADDON_NAME, get_localized_string(32359).format(backup_name + '.zip'))

    pruned = _prune_backups(backup_path, backup_type, _get_retention_limit())
    if pruned > 0 and not silent:
        notify(ADDON_NAME, get_localized_string(32364).format(pruned))

    log(f'Backup created: {backup_name}.zip ({len(detail_paths)} item(s), {failed} failure(s))')
    log_action('Backup Created', backup_name + '.zip', detail_paths=detail_paths)
    return failed == 0


def _cleanup_path(path):
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        elif os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


def _clean_stale_stage_dirs():
    try:
        for p in glob.glob(os.path.join(HOME, '.xsc_restore_stage_*')):
            shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass


def _top_level_entries(infos):
    tops = []
    for info in infos:
        name = info.filename
        top = name.split('/')[0] if '/' in name else name
        if top in ('', '.', '..') or top in tops:
            continue
        tops.append(top)
    return tops


def _dir_size_local(path):
    total = 0
    try:
        for root, _dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
    except Exception:
        pass
    return total


def _merge_dir(src_dir, dst_dir):
    """Moves the children of src_dir into dst_dir, replacing existing items.
    Both paths are local (staging lives under HOME), so each child is an
    atomic rename; only the staging copy is touched until then."""
    try:
        for child in sorted(os.listdir(src_dir)):
            child_src = os.path.join(src_dir, child)
            child_dst = vfs.join(dst_dir, child)
            if os.path.isdir(child_src):
                _cleanup_path(child_dst)
                try:
                    os.rename(child_src, child_dst)
                except OSError:
                    if not vfs.copytree(child_src, child_dst):
                        log(f'Restore failed: could not restore {child_dst}')
                        return False
                    _cleanup_path(child_src)
            else:
                _cleanup_path(child_dst)
                try:
                    os.replace(child_src, child_dst)
                except OSError:
                    if not vfs.copy(child_src, child_dst):
                        log(f'Restore failed: could not restore {child_dst}')
                        return False
                    _cleanup_path(child_src)
        return True
    except Exception as e:
        log(f'Restore failed: merge error: {e}')
        return False


def _restore_backup(backup_path):
    progress_create(ADDON_NAME, get_localized_string(32360))

    token = str(int(time.time() * 1000))
    tmp_zip = os.path.join(TEMP, os.path.basename(str(backup_path).rstrip('/')) + f'.{token}')
    stage_root = os.path.join(HOME, f'.xsc_restore_stage_{token}')
    detail_paths = []
    failed = 0
    zf = None

    try:
        _clean_stale_stage_dirs()
        total_size = vfs.getsize(backup_path)

        def _on_download(downloaded):
            if not total_size:
                return
            pct = int(min(100, downloaded / total_size * 100))
            if not progress_update(pct, get_localized_string(32400).format(os.path.basename(str(backup_path)))):
                raise _OperationCancelled()

        log(f'Restore started: downloading {backup_path}')
        if not vfs.copy(backup_path, tmp_zip, on_progress=_on_download):
            failed += 1
            log(f'Restore failed: could not download {backup_path}')
            progress_close()
            notify(ADDON_NAME, get_localized_string(32403).format(failed))
            return

        try:
            zf = zipfile.ZipFile(tmp_zip)
        except Exception as e:
            failed += 1
            log(f'Restore failed: {backup_path} is not a valid ZIP archive: {e}')
            progress_close()
            notify(ADDON_NAME, get_localized_string(32403).format(failed))
            return

        bad = zf.testzip()
        if bad is not None:
            failed += 1
            log(f'Restore failed: corrupt entry in archive: {bad}')
            progress_close()
            notify(ADDON_NAME, get_localized_string(32403).format(failed))
            return

        infos = zf.infolist()
        total_entries = len(infos)
        if not infos:
            failed += 1
            log(f'Restore failed: archive is empty: {backup_path}')
            progress_close()
            notify(ADDON_NAME, get_localized_string(32403).format(failed))
            return
        if total_size and os.path.getsize(tmp_zip) != total_size:
            failed += 1
            log(f'Restore failed: size mismatch for {backup_path} ({os.path.getsize(tmp_zip)} != {total_size})')
            progress_close()
            notify(ADDON_NAME, get_localized_string(32403).format(failed))
            return

        log(f'Restore: extracting {total_entries} entries locally')
        _cleanup_path(stage_root)
        os.makedirs(stage_root, exist_ok=True)
        done = 0
        extract_ok = True
        for info in infos:
            done += 1
            name = info.filename
            pct = int(done / total_entries * 100)
            if not progress_update(pct, get_localized_string(32400).format(name)):
                raise _OperationCancelled()
            target = os.path.normpath(os.path.join(stage_root, name))
            if not (target == stage_root or target.startswith(stage_root + os.sep)):
                log(f'Restore skipped unsafe entry: {name}')
                continue
            try:
                if name.endswith('/'):
                    os.makedirs(target, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with zf.open(info) as src_f, open(target, 'wb') as dst_f:
                    shutil.copyfileobj(src_f, dst_f)
            except _OperationCancelled:
                raise
            except Exception as e:
                extract_ok = False
                failed += 1
                log(f'Restore failed: could not extract {name}: {e}')
        zf.close()
        zf = None

        if extract_ok:
            for top in _top_level_entries(infos):
                src_stage = os.path.join(stage_root, top)
                final = _restore_dst(top)
                try:
                    if os.path.isdir(src_stage):
                        if not vfs.mkdirs(final):
                            failed += 1
                            log(f'Restore failed: cannot ensure {final} exists')
                            continue
                        if not _merge_dir(src_stage, final):
                            failed += 1
                            log(f'Restore failed: could not finalize {top} at {final}')
                            continue
                        _cleanup_path(src_stage)
                    else:
                        try:
                            os.replace(src_stage, final)
                        except OSError:
                            if not vfs.copy(src_stage, final):
                                failed += 1
                                log(f'Restore failed: could not finalize {top} at {final}')
                                continue
                            _cleanup_path(src_stage)
                    detail_paths.append((final, _dir_size_local(final)))
                    log(f'Restored {top} -> {final}')
                except _OperationCancelled:
                    raise
                except Exception as e:
                    failed += 1
                    log(f'Error finalizing {top}: {e}')
    except _OperationCancelled:
        progress_close()
        notify(ADDON_NAME, get_localized_string(32402))
        log('Restore cancelled by user')
        return
    except Exception as e:
        failed += 1
        log(f'Restore aborted by unexpected error: {e}')
        progress_close()
        notify(ADDON_NAME, get_localized_string(32403).format(failed))
        return
    finally:
        if zf is not None:
            try:
                zf.close()
            except Exception:
                pass
        _cleanup_path(tmp_zip)
        _cleanup_path(stage_root)

    progress_close()
    if failed > 0:
        notify(ADDON_NAME, get_localized_string(32403).format(failed))
    else:
        notify(ADDON_NAME, get_localized_string(32362))
    log(f'Backup restored from: {backup_path}')
    log_action('Backup Restored', backup_path, detail_paths=detail_paths)


def _restore_dst(name):
    if name == 'addons':
        return HOME_ADDONS
    if name.startswith('userdata/'):
        return vfs.join(HOME, name[len('userdata/'):])
    return vfs.join(HOME, name)


def _get_backup_items(backup_type):
    items = []

    if backup_type in ['full', 'addons', 'addons_data']:
        items.append(('addons', HOME_ADDONS))

    if backup_type in ['full', 'addon_data', 'addons_data']:
        items.append(('userdata/addon_data', ADDON_DATA))

    if backup_type in ['full', 'databases']:
        items.append(('userdata/Database', DATABASE))

    if backup_type in ['full', 'settings']:
        items.append(('userdata/sources.xml', SOURCES_XML))
        items.append(('userdata/advancedsettings.xml', ADVSETTINGS_XML))
        items.append(('userdata/guisettings.xml', GUISETTINGS_XML))

    if backup_type in ['full', 'profiles']:
        items.append(('userdata/profiles.xml', PROFILES_XML))

    if backup_type in ['full', 'keymaps']:
        items.append(('userdata/keymaps', KEYMAP_DIR))

    if backup_type in ['full', 'playlists']:
        items.append(('userdata/playlists', PLAYLISTS_DIR))

    return items


def _list_backups(backup_path, backup_type=None):
    backups = []
    prefix = f'xscleaner_{backup_type}_' if backup_type else 'xscleaner_'
    try:
        for item in vfs.listdir(backup_path):
            item_path = vfs.join(backup_path, item)
            if item.endswith('.zip') and vfs.isfile(item_path) and item.startswith(prefix):
                backups.append({
                    'name': item,
                    'path': item_path
                })
    except Exception:
        pass

    backups.sort(key=lambda x: x['name'], reverse=True)
    return backups


def _get_retention_limit():
    try:
        return max(0, int(get_setting('backup_retention') or 10))
    except (ValueError, TypeError):
        return 10


def _prune_backups(backup_path, backup_type, limit):
    if limit <= 0:
        return 0

    backups = _list_backups(backup_path, backup_type)
    excess = len(backups) - limit
    if excess <= 0:
        return 0

    removed = 0
    detail_paths = []
    for backup in backups[limit:]:
        try:
            size = vfs.getsize(backup['path'])
            if not vfs.delete(backup['path']):
                log(f'Error removing old backup {backup["name"]}: delete returned False')
                continue
            removed += 1
            detail_paths.append((backup['path'], size))
            log(f'Removed old {backup_type} backup: {backup["name"]}')
        except Exception as e:
            log(f'Error removing old backup {backup["name"]}: {e}')

    if removed > 0:
        log_action('Backup Retention', f'{removed} old {backup_type} backups removed', items_cleaned=removed, detail_paths=detail_paths)

    return removed
