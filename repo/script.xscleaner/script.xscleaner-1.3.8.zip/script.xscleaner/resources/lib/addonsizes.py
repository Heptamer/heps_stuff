import json
import os
import time
import xml.etree.ElementTree as ET
import xbmcplugin

from .constants import HOME_ADDONS, XBMC_ADDONS, ADDON_DATA, USERDATA
from .utils import (
    log, human_size, get_dir_size, ok_dialog,
    progress_create, progress_update, progress_close,
    create_dir_item, ADDON_NAME, get_localized_string
)


_SKIP_ADDON_FOLDERS = {'packages', 'temp'}

_CACHE_FILE = os.path.join(USERDATA, 'xscleaner_addon_sizes.json') if USERDATA else None
_CACHE_TTL = 600


def show_addon_sizes(handle):
    create_dir_item(
        get_localized_string(32552),
        'addons', 'addon_sizes_list', description=get_localized_string(32554),
        is_folder=True
    )
    create_dir_item(
        get_localized_string(32553),
        'addon_data', 'addon_sizes_list', description=get_localized_string(32555),
        is_folder=True
    )
    _end(handle)


def show_addon_sizes_list(source, handle):
    if source not in ('addons', 'addon_data'):
        source = 'addons'

    entries = _load_cache(source)
    if entries is None:
        collected = _collect(source)
        measured = _measure(collected)
        entries = [[e['id'], e['name'], e['size']] for e in measured]
        _save_cache(source, entries)

    if not entries:
        notify_text = get_localized_string(32557) if source == 'addons' else get_localized_string(32558)
        ok_dialog(ADDON_NAME, notify_text)
        _end(handle)
        return

    total = sum(e[2] for e in entries)
    create_dir_item(
        get_localized_string(32556).format(human_size(total)),
        f'__total__\x1f{total}', 'addon_sizes_show',
        description=get_localized_string(32556).format(human_size(total))
    )

    for addon_id, name, size in entries:
        label = f'{name} — {human_size(size)}'
        create_dir_item(
            label,
            f'{addon_id}\x1f{size}', 'addon_sizes_show',
            description=addon_id, icon_image='DefaultAddon.png'
        )

    _end(handle)


def show_addon_size_info(payload):
    try:
        addon_id, raw_size = payload.split('\x1f', 1)
        size = int(raw_size)
    except (ValueError, AttributeError):
        return

    if addon_id == '__total__':
        ok_dialog(get_localized_string(32560), get_localized_string(32556).format(human_size(size)))
        return

    ok_dialog(get_localized_string(32560), get_localized_string(32561).format(addon_id, human_size(size)))


def invalidate_addon_sizes_cache():
    if not _CACHE_FILE:
        return
    try:
        if os.path.exists(_CACHE_FILE):
            os.remove(_CACHE_FILE)
    except OSError:
        pass


def _collect(source):
    if source == 'addon_data':
        entries = []
        if ADDON_DATA and os.path.isdir(ADDON_DATA):
            for item in sorted(os.listdir(ADDON_DATA)):
                data_path = os.path.join(ADDON_DATA, item)
                if os.path.isdir(data_path):
                    entries.append({
                        'id': item,
                        'name': _get_addon_name(item),
                        'paths': [data_path]
                    })
        return entries

    merged = {}
    for addons_path in (HOME_ADDONS, XBMC_ADDONS):
        if not addons_path or not os.path.isdir(addons_path):
            continue
        for item in sorted(os.listdir(addons_path)):
            if item in _SKIP_ADDON_FOLDERS:
                continue
            addon_path = os.path.join(addons_path, item)
            if not os.path.isdir(addon_path):
                continue
            entry = merged.setdefault(item, {
                'id': item,
                'name': _get_addon_name(item),
                'paths': []
            })
            entry['paths'].append(addon_path)
    return list(merged.values())


def _measure(entries):
    progress_create(ADDON_NAME, get_localized_string(32559))
    total = len(entries)
    measured = []
    for idx, entry in enumerate(entries, 1):
        size = 0
        for path in entry['paths']:
            size += get_dir_size(path)
        measured.append({'id': entry['id'], 'name': entry['name'], 'size': size})
        if total:
            progress_update(int(idx * 100 / total), entry['name'])
    progress_close()

    measured.sort(key=lambda e: e['size'], reverse=True)
    return measured


def _get_addon_name(addon_id):
    for addons_path in (HOME_ADDONS, XBMC_ADDONS):
        if not addons_path:
            continue
        addon_xml = os.path.join(addons_path, addon_id, 'addon.xml')
        try:
            root = ET.parse(addon_xml).getroot()
            name = root.get('name')
            if name:
                return name
        except Exception:
            pass
    return addon_id


def _load_cache(source):
    if not _CACHE_FILE or not os.path.exists(_CACHE_FILE):
        return None
    try:
        with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if time.time() - data.get('timestamp', 0) > _CACHE_TTL:
            return None
        cached = data.get(source)
        if cached is None:
            return None
        return [[str(item[0]), str(item[1]), int(item[2])] for item in cached]
    except Exception as e:
        log(f'Error loading addon size cache: {e}')
        return None


def _save_cache(source, entries):
    if not _CACHE_FILE:
        return
    try:
        os.makedirs(os.path.dirname(_CACHE_FILE), exist_ok=True)
        data = {}
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
        data['timestamp'] = time.time()
        data[source] = entries
        with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception as e:
        log(f'Error saving addon size cache: {e}')


def _end(handle):
    if handle != -1:
        xbmcplugin.endOfDirectory(handle)
