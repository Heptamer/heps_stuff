import os
import shutil
import xml.etree.ElementTree as ET

from .constants import (
    TEMP, ADDON_DATA, ADDONS_TEMP,
    ADDON_NAME, EXCLUDES, USERDATA, GUISETTINGS_XML, THUMBNAILS
)
from .utils import (
    log, notify, human_size, get_dir_size,
    yesno_dialog, progress_create, progress_update,
    progress_close, get_localized_string, is_setting_enabled,
    remove_empty_folders
)
from .logger import log_action

_TEMP_PRESERVED = ['kodi.log', 'kodi.old.log', 'xbmc.log', 'xbmc.old.log']


def clean_cache(silent=False):
    do_temp = is_setting_enabled('clean_temp')
    do_cache = is_setting_enabled('clean_cache')
    do_http = is_setting_enabled('clean_http_cache')
    do_weather = is_setting_enabled('clean_weather_cache')
    do_downloads = is_setting_enabled('clean_downloads')
    do_search = is_setting_enabled('clean_search_history')

    if not do_temp and not do_cache and not do_http and not do_weather and not do_downloads and not do_search:
        return 0

    if not silent:
        if not yesno_dialog(
            ADDON_NAME,
            get_localized_string(32150),
            get_localized_string(32170)
        ):
            return

    progress_create(ADDON_NAME, get_localized_string(32100))
    total_freed = 0
    all_details = []
    steps = int(do_temp) + int(do_cache) * 3 + int(do_http) + int(do_weather) + int(do_downloads) + int(do_search)
    if steps == 0:
        progress_close()
        return 0
    step = 0

    if do_temp:
        progress_update(int(step / steps * 100), get_localized_string(32171))
        size, paths = _clean_temp()
        total_freed += size
        all_details.extend(paths)
        remove_empty_folders(TEMP)
        step += 1

    if do_cache:
        progress_update(int(step / steps * 100), get_localized_string(32172))
        size, paths = _clean_addon_caches()
        total_freed += size
        all_details.extend(paths)
        step += 1

        progress_update(int(step / steps * 100), get_localized_string(32173))
        size, paths = _clean_addon_temps()
        total_freed += size
        all_details.extend(paths)
        step += 1

        progress_update(int(step / steps * 100), get_localized_string(32174))
        size, paths = _clean_addons_temp()
        total_freed += size
        all_details.extend(paths)
        step += 1

    if do_http:
        progress_update(int(step / steps * 100), get_localized_string(32176))
        size, paths = _clean_http_cache()
        total_freed += size
        all_details.extend(paths)
        remove_empty_folders(os.path.join(USERDATA, 'cache'))
        step += 1

    if do_weather:
        progress_update(int(step / steps * 100), get_localized_string(32177))
        size, paths = _clean_weather_caches()
        total_freed += size
        all_details.extend(paths)
        step += 1

    if do_downloads:
        progress_update(int(step / steps * 100), get_localized_string(32178))
        size, paths = _clean_downloads()
        total_freed += size
        all_details.extend(paths)
        remove_empty_folders(os.path.join(USERDATA, 'Downloads'))
        step += 1

    if do_search:
        progress_update(int(step / steps * 100), get_localized_string(32179))
        size, paths = _clean_search_history()
        total_freed += size
        all_details.extend(paths)
        step += 1

    progress_update(100, get_localized_string(32175))
    progress_close()

    if not silent:
        notify(ADDON_NAME, f'{get_localized_string(32201)}: {human_size(total_freed)}')

    log(f'Cache cleanup completed, freed {human_size(total_freed)}')
    log_action(
        'Cache Cleanup',
        'Temp, addon caches, addon temps, http, weather, downloads, search',
        space_freed=total_freed,
        detail_paths=all_details
    )
    return total_freed


def get_cache_size():
    total = 0
    total += get_temp_size()
    total += _get_addon_caches_size()
    total += _get_addon_temps_size()
    total += _get_addons_temp_size()
    total += _get_http_cache_size()
    total += _get_weather_cache_size()
    total += _get_downloads_size()
    return total


def _clean_temp():
    cleaned = 0
    paths = []
    if not os.path.exists(TEMP):
        return 0, paths

    try:
        for item in os.listdir(TEMP):
            if item in _TEMP_PRESERVED:
                continue

            item_path = os.path.join(TEMP, item)
            try:
                if os.path.isfile(item_path):
                    size = os.path.getsize(item_path)
                    os.remove(item_path)
                    cleaned += size
                    paths.append((item_path, size))
                elif os.path.isdir(item_path):
                    size = get_dir_size(item_path)
                    shutil.rmtree(item_path, ignore_errors=True)
                    cleaned += size
                    paths.append((item_path, size))
            except OSError:
                pass
    except Exception as e:
        log(f'Error cleaning temp: {e}')

    return cleaned, paths


def _clean_addon_caches():
    cleaned = 0
    paths = []
    if not os.path.exists(ADDON_DATA):
        return 0, paths

    for addon_name in os.listdir(ADDON_DATA):
        if addon_name in EXCLUDES:
            continue

        cache_dir = os.path.join(ADDON_DATA, addon_name, 'cache')
        if os.path.exists(cache_dir):
            try:
                size = get_dir_size(cache_dir)
                shutil.rmtree(cache_dir, ignore_errors=True)
                cleaned += size
                paths.append((cache_dir, size))
            except Exception:
                pass

    return cleaned, paths


def _clean_addon_temps():
    cleaned = 0
    paths = []
    if not os.path.exists(ADDON_DATA):
        return 0, paths

    for addon_name in os.listdir(ADDON_DATA):
        if addon_name in EXCLUDES:
            continue

        temp_dir = os.path.join(ADDON_DATA, addon_name, 'temp')
        if os.path.exists(temp_dir):
            try:
                size = get_dir_size(temp_dir)
                shutil.rmtree(temp_dir, ignore_errors=True)
                cleaned += size
                paths.append((temp_dir, size))
            except Exception:
                pass

    return cleaned, paths


def _clean_addons_temp():
    cleaned = 0
    paths = []
    if not os.path.exists(ADDONS_TEMP):
        return 0, paths

    try:
        size = get_dir_size(ADDONS_TEMP)
        shutil.rmtree(ADDONS_TEMP, ignore_errors=True)
        cleaned = size
        paths.append((ADDONS_TEMP, size))
    except Exception as e:
        log(f'Error cleaning addons temp: {e}')

    return cleaned, paths


def get_temp_size():
    if not os.path.exists(TEMP):
        return 0
    total = 0
    try:
        for item in os.listdir(TEMP):
            if item in _TEMP_PRESERVED:
                continue
            item_path = os.path.join(TEMP, item)
            try:
                if os.path.isfile(item_path):
                    total += os.path.getsize(item_path)
                elif os.path.isdir(item_path):
                    total += get_dir_size(item_path)
            except OSError:
                pass
    except Exception:
        pass
    return total


def _get_addon_caches_size():
    total = 0
    if not os.path.exists(ADDON_DATA):
        return 0
    for addon_name in os.listdir(ADDON_DATA):
        cache_dir = os.path.join(ADDON_DATA, addon_name, 'cache')
        if os.path.exists(cache_dir):
            total += get_dir_size(cache_dir)
    return total


def _get_addon_temps_size():
    total = 0
    if not os.path.exists(ADDON_DATA):
        return 0
    for addon_name in os.listdir(ADDON_DATA):
        temp_dir = os.path.join(ADDON_DATA, addon_name, 'temp')
        if os.path.exists(temp_dir):
            total += get_dir_size(temp_dir)
    return total


def _get_addons_temp_size():
    return get_dir_size(ADDONS_TEMP) if os.path.exists(ADDONS_TEMP) else 0


def _clean_http_cache():
    cleaned = 0
    paths = []
    kodi_cache = os.path.join(USERDATA, 'cache')
    thumb_cache = os.path.join(THUMBNAILS, 'cache')
    for d in (kodi_cache, thumb_cache):
        if os.path.exists(d):
            try:
                size = get_dir_size(d)
                shutil.rmtree(d, ignore_errors=True)
                cleaned += size
                paths.append((d, size))
            except Exception as e:
                log(f'Error cleaning http cache {d}: {e}')
    return cleaned, paths


def _clean_weather_caches():
    cleaned = 0
    paths = []
    if not os.path.exists(ADDON_DATA):
        return 0, paths
    for addon_name in os.listdir(ADDON_DATA):
        if addon_name.startswith('weather.'):
            for sub in ('cache', 'temp'):
                d = os.path.join(ADDON_DATA, addon_name, sub)
                if os.path.exists(d):
                    try:
                        size = get_dir_size(d)
                        shutil.rmtree(d, ignore_errors=True)
                        cleaned += size
                        paths.append((d, size))
                    except Exception:
                        pass
    return cleaned, paths


def _clean_downloads():
    cleaned = 0
    paths = []
    downloads = os.path.join(USERDATA, 'Downloads')
    if not os.path.exists(downloads):
        return 0, paths
    try:
        for item in os.listdir(downloads):
            item_path = os.path.join(downloads, item)
            try:
                if os.path.isfile(item_path):
                    size = os.path.getsize(item_path)
                    os.remove(item_path)
                    cleaned += size
                    paths.append((item_path, size))
                elif os.path.isdir(item_path):
                    size = get_dir_size(item_path)
                    shutil.rmtree(item_path, ignore_errors=True)
                    cleaned += size
                    paths.append((item_path, size))
            except OSError:
                pass
    except Exception as e:
        log(f'Error cleaning downloads: {e}')
    return cleaned, paths


def _clean_search_history():
    cleaned = 0
    paths = []
    if not os.path.exists(GUISETTINGS_XML):
        return 0, paths
    try:
        tree = ET.parse(GUISETTINGS_XML)
        root = tree.getroot()

        remove = []
        for parent in root.iter():
            for child in list(parent):
                if child.tag.lower() == 'recent':
                    remove.append((parent, child))

        if not remove:
            return 0, paths

        for parent, child in remove:
            parent.remove(child)

        empty = []
        for parent in root.iter():
            for child in list(parent):
                if child.tag.lower() == 'searches' and len(child) == 0:
                    empty.append((parent, child))
        for parent, child in empty:
            parent.remove(child)

        size_before = os.path.getsize(GUISETTINGS_XML)
        tree.write(GUISETTINGS_XML, encoding='utf-8', xml_declaration=True)
        size_after = os.path.getsize(GUISETTINGS_XML)
        freed = size_before - size_after if size_after < size_before else 0
        cleaned += freed
        paths.append((GUISETTINGS_XML, freed))
        log(f'Search history cleaned, freed {human_size(freed)}')
    except Exception as e:
        log(f'Error cleaning search history: {e}')
    return cleaned, paths


def _get_http_cache_size():
    total = 0
    kodi_cache = os.path.join(USERDATA, 'cache')
    thumb_cache = os.path.join(THUMBNAILS, 'cache')
    for d in (kodi_cache, thumb_cache):
        if os.path.exists(d):
            total += get_dir_size(d)
    return total


def _get_weather_cache_size():
    total = 0
    if not os.path.exists(ADDON_DATA):
        return 0
    for addon_name in os.listdir(ADDON_DATA):
        if addon_name.startswith('weather.'):
            for sub in ('cache', 'temp'):
                d = os.path.join(ADDON_DATA, addon_name, sub)
                if os.path.exists(d):
                    total += get_dir_size(d)
    return total


def _get_downloads_size():
    downloads = os.path.join(USERDATA, 'Downloads')
    return get_dir_size(downloads) if os.path.exists(downloads) else 0
