import os
import sys
import xbmcgui
import xbmcaddon
import xbmcplugin

from .constants import (
    ADDON_ID, ADDON_NAME, ADDON_ICON, ADDON_FANART
)

_addon = None
_dialog = None
_progress_dialog = None


def _get_addon():
    global _addon
    if _addon is None:
        _addon = xbmcaddon.Addon(id=ADDON_ID)
    return _addon


def _get_dialog():
    global _dialog
    if _dialog is None:
        _dialog = xbmcgui.Dialog()
    return _dialog


def _get_progress_dialog():
    global _progress_dialog
    if _progress_dialog is None:
        _progress_dialog = xbmcgui.DialogProgress()
    return _progress_dialog


def get_setting(setting_id):
    return _get_addon().getSetting(setting_id)


def set_setting(setting_id, value):
    _get_addon().setSetting(setting_id, value)


def is_setting_enabled(setting_id):
    return _get_addon().getSetting(setting_id) == 'true'


def get_localized_string(string_id):
    return _get_addon().getLocalizedString(string_id)


def open_settings():
    _get_addon().openSettings()


def log(message, level=None):
    try:
        import xbmc
        if level is None:
            level = xbmc.LOGINFO
        xbmc.log(f'{ADDON_NAME}: {message}', level=level)
    except Exception:
        pass


def notify(title, message, icon=ADDON_ICON, time=3000):
    _get_dialog().notification(title, message, icon=icon, time=time)


def human_size(size_bytes):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f'{size_bytes:.1f} {unit}'
        size_bytes /= 1024.0
    return f'{size_bytes:.1f} PB'


def get_dir_size(path):
    total = 0
    try:
        for root, dirs, files in os.walk(path):
            for f in files:
                fp = os.path.join(root, f)
                try:
                    total += os.path.getsize(fp)
                except OSError:
                    pass
    except Exception:
        pass
    return total


def remove_empty_folders(path, exclude=None):
    if exclude is None:
        exclude = []
    for _ in range(5):
        removed = 0
        for root, dirs, files in os.walk(path, topdown=False):
            if not dirs and not files:
                if not any(ex in root for ex in exclude):
                    try:
                        os.rmdir(root)
                        removed += 1
                    except OSError:
                        pass
        if removed == 0:
            break


def create_dir_item(name, url, action, icon=None, fanart=None,
                    description='', is_folder=False,
                    icon_image='DefaultFolder.png'):
    if icon is None:
        icon = ADDON_ICON
    if fanart is None:
        fanart = ADDON_FANART

    from urllib.parse import quote_plus
    script_url = sys.argv[0] if len(sys.argv) > 0 else ''
    u = (f'{script_url}?url={quote_plus(url)}&action={quote_plus(action)}'
         f'&name={quote_plus(name)}&icon={quote_plus(icon)}'
         f'&fanart={quote_plus(fanart)}'
         f'&description={quote_plus(description)}')

    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': icon_image, 'thumb': icon, 'fanart': fanart})
    liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
    liz.setProperty('Fanart_Image', fanart)

    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    return xbmcplugin.addDirectoryItem(
        handle=handle, url=u, listitem=liz, isFolder=is_folder
    )


def yesno_dialog(title, line1, line2='', yeslabel=None, nolabel=None):
    if yeslabel is None:
        yeslabel = get_localized_string(32219)
    if nolabel is None:
        nolabel = get_localized_string(32220)
    if line2:
        line1 = f'{line1}\n{line2}'
    return _get_dialog().yesno(title, line1, yeslabel=yeslabel, nolabel=nolabel)


def ok_dialog(title, line1, line2=''):
    if line2:
        line1 = f'{line1}\n{line2}'
    _get_dialog().ok(title, line1)


def progress_create(title, line1):
    _get_progress_dialog().create(title, line1)


def progress_update(percent, line1=''):
    progress = _get_progress_dialog()
    if progress.iscanceled():
        return False
    progress.update(percent, line1)
    return True


def progress_close():
    _get_progress_dialog().close()


def indent_xml(elem):
    try:
        import xml.etree.ElementTree as ET
        ET.indent(elem, space='  ')
    except AttributeError:
        pass
