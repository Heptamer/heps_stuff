import os
import xml.etree.ElementTree as ET
from .constants import SOURCES_XML, translate
from .utils import (
    log, yesno_dialog, ok_dialog,
    progress_create, progress_close,
    ADDON_NAME, get_localized_string, indent_xml
)
from .logger import log_action


def check_sources():
    if not os.path.exists(SOURCES_XML):
        ok_dialog(ADDON_NAME, get_localized_string(32300))
        return

    try:
        tree = ET.parse(SOURCES_XML)
        root = tree.getroot()
    except Exception as e:
        log(f'Error parsing sources.xml: {e}')
        ok_dialog(ADDON_NAME, get_localized_string(32301).format(e))
        return

    progress_create(ADDON_NAME, get_localized_string(32302))

    broken_sources = []
    valid_sources = 0

    for source_type in root.findall('.//source'):
        name = source_type.find('name')
        path = source_type.find('path')

        if name is not None and path is not None:
            source_path = path.text

            if source_path:
                if _is_remote(source_path):
                    valid_sources += 1
                    continue

                if source_path.startswith('special://'):
                    full_path = _translate_special(source_path)
                else:
                    full_path = source_path

                if full_path is not None and not os.path.exists(full_path):
                    broken_sources.append({
                        'name': name.text,
                        'path': source_path
                    })
                elif full_path is not None:
                    valid_sources += 1

    progress_close()

    if broken_sources:
        _show_broken_sources(broken_sources, root, tree)
    else:
        ok_dialog(ADDON_NAME, get_localized_string(32303).format(valid_sources))


def _show_broken_sources(broken_sources, root, tree):
    lines = [f'{s["name"]}: {s["path"]}' for s in broken_sources]
    message = get_localized_string(32304).format(len(broken_sources)) + ':\n\n' + '\n'.join(lines)

    if yesno_dialog(ADDON_NAME, message, get_localized_string(32305)):
        _remove_broken_sources(broken_sources, root, tree)
    else:
        ok_dialog(ADDON_NAME, message)


def _remove_broken_sources(broken_sources, root, tree):
    try:
        broken_names = {s['name'] for s in broken_sources}

        for source_type in root.findall('.//source'):
            name_elem = source_type.find('name')
            if name_elem is not None and name_elem.text in broken_names:
                parent = _find_parent(root, source_type)
                if parent is not None:
                    parent.remove(source_type)

        indent_xml(tree)
        tree.write(SOURCES_XML, encoding='utf-8', xml_declaration=True)

        ok_dialog(ADDON_NAME, get_localized_string(32306).format(len(broken_sources)))
        log(f'Removed {len(broken_sources)} broken sources')
        detail_paths = [(SOURCES_XML, os.path.getsize(SOURCES_XML))]
        log_action('Sources Cleanup', f'{len(broken_sources)} broken sources removed', items_cleaned=len(broken_sources), detail_paths=detail_paths)

    except Exception as e:
        log(f'Error removing broken sources: {e}')
        ok_dialog(ADDON_NAME, get_localized_string(32222).format(e))


def _find_parent(root, element):
    for parent in root.iter():
        for child in parent:
            if child is element:
                return parent
    return None


def _is_remote(path):
    return '://' in path


def _translate_special(path):
    return translate(path)
