import xbmcgui
from .logger import (
    get_log_entries, get_log_details, clear_log,
    format_entry_short, format_entry_details
)
from .utils import (
    yesno_dialog, notify, ADDON_NAME,
    get_localized_string
)

ACTION_DETAILS = 'details'
ACTION_CLEAR = 'clear'


def show_activity_log():
    entries = get_log_entries(100)

    options = []
    actions = []

    options.append(f'--- {get_localized_string(32442)} ---')
    actions.append(ACTION_CLEAR)

    for e in entries:
        options.append(format_entry_short(e))
        actions.append(ACTION_DETAILS)

    if len(actions) == 1:
        options.append(f'--- {get_localized_string(32444)} ---')
        actions.append(None)

    selection = xbmcgui.Dialog().select(get_localized_string(32440), options)

    if selection == -1:
        return

    action = actions[selection]

    if action == ACTION_DETAILS:
        entry = entries[selection - 1]
        log_id = entry[0]
        details = get_log_details(log_id)
        content = format_entry_details(entry, details)
        xbmcgui.Dialog().textviewer(get_localized_string(32440), content)

    elif action == ACTION_CLEAR:
        if yesno_dialog(ADDON_NAME, get_localized_string(32442)):
            if clear_log():
                notify(ADDON_NAME, get_localized_string(32443))
