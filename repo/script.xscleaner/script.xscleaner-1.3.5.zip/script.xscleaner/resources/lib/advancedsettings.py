import os
import xbmc
import xbmcgui
import xml.etree.ElementTree as ET
from .constants import ADVSETTINGS_XML
from .utils import (
    log, yesno_dialog, ok_dialog,
    ADDON_NAME, get_localized_string, indent_xml, human_size
)
from .logger import log_action

BUFFER_MODE_OPTIONS = [
    get_localized_string(32394),
    get_localized_string(32395),
    get_localized_string(32396),
    get_localized_string(32397),
]

RAM_CACHE_PRESETS = [
    (1024, 20971520, 2),
    (2048, 52428800, 2),
    (4096, 139460602, 4),
    (8192, 268435456, 4),
    (99999, 536870912, 4),
]


def _h(text):
    return f'[COLOR gray]{text}[/COLOR]'


def _first_sentence(text):
    return text.split('. ')[0].strip().rstrip('.')


def edit_advanced_settings():
    while True:
        kodi_version = _get_kodi_version()
        ram_mb = _get_total_ram_mb()
        root = _load_or_create_root()

        items = []
        actions = []

        if kodi_version <= 20:
            items.append(f'[B]{get_localized_string(32456)}[/B]')
            actions.append(None)
            items.append(_h(get_localized_string(32487)))
            actions.append('cache_settings')
            if ram_mb > 0:
                items.append(f'  {get_localized_string(32478).format(ram_mb)}')
                actions.append(None)
        else:
            items.append(f'[B]{get_localized_string(32456)}[/B]')
            actions.append(None)
            items.append(_h(get_localized_string(32476)))
            actions.append('cache_info')
            if ram_mb > 0:
                items.append(f'  {get_localized_string(32478).format(ram_mb)}')
                actions.append(None)

        items.append('')
        actions.append(None)
        items.append(f'[B]{get_localized_string(32450)}[/B]')
        actions.append(None)
        items.append(_h(get_localized_string(32488)))
        actions.append(None)

        network = root.find('network')
        items.append(f'  curl {_first_sentence(get_localized_string(32463))}: {_read_int(network, "curlclienttimeout", 10)}s')
        actions.append(('network', 'curlclienttimeout', 10, 1, 1000, 32463))

        items.append(f'  curl {_first_sentence(get_localized_string(32464))}: {_read_int(network, "curllowspeedtime", 20)}s')
        actions.append(('network', 'curllowspeedtime', 20, 1, 1000, 32464))

        items.append(f'  curl {_first_sentence(get_localized_string(32465))}: {_read_int(network, "curlretries", 2)}')
        actions.append(('network', 'curlretries', 2, 0, 10, 32465))

        items.append(f'  {_first_sentence(get_localized_string(32466))}: {_format_bool(_read_bool(network, "disableipv6", False))}')
        actions.append(('network_bool', 'disableipv6', False, 32466))

        items.append(f'  {_first_sentence(get_localized_string(32467))}: {_format_bool(_read_bool(network, "disablehttp2", False))}')
        actions.append(('network_bool', 'disablehttp2', False, 32467))

        items.append(f'  NFS {_first_sentence(get_localized_string(32468))}: {_read_int(network, "nfstimeout", 30)}s')
        actions.append(('network', 'nfstimeout', 30, 0, 3600, 32468))

        items.append(f'  NFS {_first_sentence(get_localized_string(32469))}: {_read_int(network, "nfsretries", 0)}')
        actions.append(('network', 'nfsretries', 0, -1, 30, 32469))

        items.append('')
        actions.append(None)
        items.append(f'[B]{get_localized_string(32451)}[/B]')
        actions.append(None)
        items.append(_h(get_localized_string(32489)))
        actions.append(None)

        items.append(f'  {_first_sentence(get_localized_string(32470))}: {_read_int(root.find("video"), "skiploopfilter", 0)}')
        actions.append(('video', 'skiploopfilter', 0, -16, 48, 32470))

        items.append(f'  {_first_sentence(get_localized_string(32471))}: {_read_int(root.find("video"), "playcountminimumpercent", 90)}%')
        actions.append(('video', 'playcountminimumpercent', 90, 0, 101, 32471))

        items.append(f'  {_first_sentence(get_localized_string(32472))}: {_read_int(root.find("video"), "ignoresecondsatstart", 180)}s')
        actions.append(('video', 'ignoresecondsatstart', 180, 0, 3600, 32472))

        items.append(f'  {_first_sentence(get_localized_string(32473))}: {_read_int(root.find("video"), "ignorepercentatend", 8)}%')
        actions.append(('video', 'ignorepercentatend', 8, 0, 101, 32473))

        items.append(f'  {_first_sentence(get_localized_string(32474))}: {_read_float(root.find("video"), "maxtempo", 1.6)}')
        actions.append(('video_float', 'maxtempo', 1.6, 1.6, 2.0, 32474))

        items.append('')
        actions.append(None)
        items.append(f'[B]{get_localized_string(32452)}[/B]')
        actions.append(None)
        items.append(_h(get_localized_string(32490)))
        actions.append(None)

        samba = root.find('samba')
        items.append(f'  {_first_sentence(get_localized_string(32475))}: {_read_int(samba, "clienttimeout", 30)}s')
        actions.append(('samba', 'clienttimeout', 30, 5, 100, 32475))

        items.append('')
        actions.append(None)
        items.append(f'[B]{get_localized_string(32320)}[/B]')
        actions.append('view')
        items.append(f'[B]{get_localized_string(32454)}[/B]')
        actions.append('reset')
        items.append(f'[B]{get_localized_string(32455)}[/B]')
        actions.append('delete')

        selection = xbmcgui.Dialog().select(ADDON_NAME, items, preselect=-1)

        if selection == -1:
            break

        action = actions[selection]

        if action is None:
            continue

        if action == 'cache_settings':
            _edit_cache_dialog(root, ram_mb)
            continue

        if action == 'cache_info':
            ram_str = get_localized_string(32478).format(ram_mb) if ram_mb > 0 else ''
            ok_dialog(ADDON_NAME, f'{get_localized_string(32476)}\n\n{ram_str}')
            continue

        if action == 'view':
            _view_advanced_settings()
            continue

        if action == 'reset':
            _reset_advanced_settings()
            continue

        if action == 'delete':
            _delete_advanced_settings()
            continue

        if isinstance(action, tuple) and len(action) >= 2:
            _edit_setting_by_type(root, action)


def _edit_cache_dialog(root, ram_mb):
    while True:
        memorysize, readfactor, buffermode = _get_cache_recommendation(ram_mb)

        mode_label = BUFFER_MODE_OPTIONS[buffermode] if 0 <= buffermode < len(BUFFER_MODE_OPTIONS) else BUFFER_MODE_OPTIONS[1]
        size_label = human_size(memorysize)

        summary_lines = [
            _h(get_localized_string(32487)),
            '',
            get_localized_string(32479),
        ]

        if ram_mb > 0:
            summary_lines.append(get_localized_string(32478).format(ram_mb))
            summary_lines.append('')

        summary_lines.extend([
            f'  {get_localized_string(32484).format(str(memorysize), size_label)}',
            f'  {get_localized_string(32485).format(str(readfactor))}',
            f'  {get_localized_string(32483).format(mode_label)}',
        ])

        options = [
            get_localized_string(32480),
            get_localized_string(32481),
        ]

        selection = xbmcgui.Dialog().select(
            get_localized_string(32482),
            summary_lines + ['', '---'] + options,
        )

        if selection == -1:
            break

        total_lines = len(summary_lines) + 1
        if selection >= total_lines:
            option_index = selection - total_lines - 1
            if option_index == 0:
                _apply_cache_preset(root, memorysize, readfactor, buffermode)
                continue
            elif option_index == 1:
                _edit_cache_values(root, memorysize, readfactor, buffermode)
                continue


def _get_cache_recommendation(ram_mb):
    if ram_mb <= 0:
        return 20971520, 4, 3

    for threshold, size, factor in RAM_CACHE_PRESETS:
        if ram_mb <= threshold:
            return size, factor, 3

    return RAM_CACHE_PRESETS[-1][1], RAM_CACHE_PRESETS[-1][2], 3


def _apply_cache_preset(root, memorysize, readfactor, buffermode):
    cache = root.find('cache')
    if cache is None:
        cache = ET.SubElement(root, 'cache')

    _set_elem(cache, 'memorysize', str(memorysize))
    _set_elem(cache, 'readfactor', str(readfactor))
    _set_elem(cache, 'buffermode', str(buffermode))

    _save_root(root)
    ok_dialog(ADDON_NAME, get_localized_string(32330))
    log_action('Advanced Settings', 'Cache settings applied (recommended)', detail_paths=[(ADVSETTINGS_XML, 0)])


def _edit_cache_values(root, default_memory, default_factor, default_mode):
    cache = root.find('cache')

    memory_str = xbmcgui.Dialog().input(
        get_localized_string(32462),
        str(_read_int(cache, 'memorysize', default_memory)),
        type=xbmcgui.INPUT_NUMERIC
    )
    if not memory_str:
        return

    mode_index = xbmcgui.Dialog().select(
        get_localized_string(32458),
        BUFFER_MODE_OPTIONS,
        preselect=min(max(_read_int(cache, 'buffermode', default_mode), 0), len(BUFFER_MODE_OPTIONS) - 1)
    )
    if mode_index == -1:
        return

    factor_str = xbmcgui.Dialog().input(
        get_localized_string(32461),
        str(_read_int(cache, 'readfactor', default_factor)),
        type=xbmcgui.INPUT_NUMERIC
    )
    if not factor_str:
        return

    try:
        memorysize = int(memory_str)
        readfactor = int(factor_str)
    except ValueError:
        ok_dialog(ADDON_NAME, get_localized_string(32390))
        return

    if memorysize < 0 or readfactor < 1:
        ok_dialog(ADDON_NAME, get_localized_string(32390))
        return

    if cache is None:
        cache = ET.SubElement(root, 'cache')

    _set_elem(cache, 'memorysize', str(memorysize))
    _set_elem(cache, 'readfactor', str(readfactor))
    _set_elem(cache, 'buffermode', str(mode_index))

    _save_root(root)
    ok_dialog(ADDON_NAME, get_localized_string(32330))
    log_action('Advanced Settings', 'Cache settings edited', detail_paths=[(ADVSETTINGS_XML, 0)])


_EDIT_TYPES = {
    'network': ('network', 'int'),
    'network_bool': ('network', 'bool'),
    'video': ('video', 'int'),
    'video_float': ('video', 'float'),
    'samba': ('samba', 'int'),
}


def _edit_setting_by_type(root, action):
    parent_tag, kind = _EDIT_TYPES[action[0]]

    parent = root.find(parent_tag)
    if parent is None:
        parent = ET.SubElement(root, parent_tag)

    if kind == 'bool':
        tag, default, help_id = action[1], action[2], action[3]
        new_val = not _read_bool(parent, tag, default)
        _set_elem(parent, tag, str(new_val).lower())
        _save_root(root)
        ok_dialog(ADDON_NAME, f'{tag} = {_format_bool(new_val)}')
        log_action('Advanced Settings', f'{tag} = {_format_bool(new_val)}', detail_paths=[(ADVSETTINGS_XML, 0)])
        return

    tag, default, min_val, max_val, help_id = action[1], action[2], action[3], action[4], action[5]
    current = _read_float(parent, tag, default) if kind == 'float' else _read_int(parent, tag, default)
    value = xbmcgui.Dialog().input(
        get_localized_string(help_id),
        str(current),
        type=xbmcgui.INPUT_NUMERIC
    )
    if not value:
        return
    try:
        val = float(value) if kind == 'float' else int(value)
        if val < min_val or val > max_val:
            raise ValueError
    except ValueError:
        ok_dialog(ADDON_NAME, get_localized_string(32390))
        return
    _set_elem(parent, tag, str(val))
    _save_root(root)
    ok_dialog(ADDON_NAME, f'{tag} = {val}')
    log_action('Advanced Settings', f'{tag} = {val}', detail_paths=[(ADVSETTINGS_XML, 0)])


def _view_advanced_settings():
    if os.path.exists(ADVSETTINGS_XML):
        try:
            with open(ADVSETTINGS_XML, 'r') as f:
                content = f.read()
            xbmcgui.Dialog().textviewer(get_localized_string(32453), content)
        except Exception as e:
            log(f'Error reading advancedsettings.xml: {e}')
            ok_dialog(ADDON_NAME, get_localized_string(32327).format(e))
    else:
        ok_dialog(ADDON_NAME, get_localized_string(32328))


def _reset_advanced_settings():
    if not yesno_dialog(ADDON_NAME, get_localized_string(32332)):
        return
    root = _create_default_root()
    _save_root(root)
    ok_dialog(ADDON_NAME, get_localized_string(32333))
    log_action('Advanced Settings', 'Reset to default', detail_paths=[(ADVSETTINGS_XML, 0)])


def _delete_advanced_settings():
    if not os.path.exists(ADVSETTINGS_XML):
        ok_dialog(ADDON_NAME, get_localized_string(32334))
        return
    if not yesno_dialog(ADDON_NAME, get_localized_string(32335)):
        return
    try:
        size = os.path.getsize(ADVSETTINGS_XML)
        os.remove(ADVSETTINGS_XML)
        ok_dialog(ADDON_NAME, get_localized_string(32336))
        log_action('Advanced Settings', 'Deleted', space_freed=size, detail_paths=[(ADVSETTINGS_XML, size)])
    except Exception as e:
        log(f'Error deleting advancedsettings.xml: {e}')
        ok_dialog(ADDON_NAME, get_localized_string(32222).format(e))


def _get_kodi_version():
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except (ValueError, TypeError, AttributeError, IndexError):
        return 21


def _get_total_ram_mb():
    try:
        raw = xbmc.getInfoLabel('System.Memory(total)')
        if not raw:
            return 0
        raw = raw.strip().lower().replace('mb', '').replace(' ', '')
        return int(float(raw))
    except (ValueError, TypeError):
        return 0


def _load_or_create_root():
    if os.path.exists(ADVSETTINGS_XML):
        try:
            tree = ET.parse(ADVSETTINGS_XML)
            return tree.getroot()
        except Exception:
            pass
    return _create_default_root()


def _create_default_root():
    return ET.Element('advancedsettings')


def _read_int(parent, tag, default):
    if parent is None:
        return default
    elem = parent.find(tag)
    if elem is None or not elem.text:
        return default
    try:
        return int(elem.text)
    except (ValueError, TypeError):
        return default


def _read_float(parent, tag, default):
    if parent is None:
        return default
    elem = parent.find(tag)
    if elem is None or not elem.text:
        return default
    try:
        return float(elem.text)
    except (ValueError, TypeError):
        return default


def _read_bool(parent, tag, default):
    if parent is None:
        return default
    elem = parent.find(tag)
    if elem is None or not elem.text:
        return default
    return elem.text.strip().lower() == 'true'


def _set_elem(parent, tag, text):
    elem = parent.find(tag)
    if elem is None:
        elem = ET.SubElement(parent, tag)
    elem.text = text
    return elem


def _format_bool(val):
    return get_localized_string(32219) if val else get_localized_string(32220)


def _save_root(root):
    try:
        tree = ET.ElementTree(root)
        indent_xml(tree)
        tree.write(ADVSETTINGS_XML, encoding='utf-8', xml_declaration=True)
        log('advancedsettings.xml saved')
        return True
    except Exception as e:
        log(f'Error saving advancedsettings.xml: {e}')
        return False
