import os
import json
import time
import xbmcgui
from .constants import (
    HOME, HOME_ADDONS, ADDON_DATA, THUMBNAILS,
    PACKAGES_PATH, TEMP, DATABASE, USERDATA,
    ADDON_VERSION
)
from .utils import (
    human_size, get_dir_size, get_localized_string, log
)

_STORAGE_ITEMS = [
    (32230, HOME),
    (32231, HOME_ADDONS),
    (32232, ADDON_DATA),
    (32233, THUMBNAILS),
    (32234, PACKAGES_PATH),
    (32235, TEMP),
    (32236, DATABASE),
]

_TIP_ITEMS = [
    (32233, 500 * 1024 * 1024, 32541),
    (32234, 200 * 1024 * 1024, 32542),
    (32237, 200 * 1024 * 1024, 32543),
    (32236, 500 * 1024 * 1024, 32544),
    (32235, 100 * 1024 * 1024, 32545),
]

_SIZES_CACHE_FILE = os.path.join(USERDATA, 'xscleaner_sizes.json') if USERDATA else None
_SIZES_TTL = 600


def show_system_info():
    storage = _get_storage_info()
    total = storage[0][1]

    lines = []
    for sid, size in storage:
        lines.append(f'{get_localized_string(sid)}: {human_size(size)}')
    lines.append('')
    lines.append(f'{get_localized_string(32238)}: {human_size(total)}')

    lines.append('')
    lines.append(f'XSCleaner v{ADDON_VERSION}')

    import sys
    lines.append(f'Python {sys.version.split()[0]}')

    try:
        import xbmc
        kodi_ver = xbmc.getInfoLabel('System.BuildVersion')
        lines.append(f'Kodi {kodi_ver}')
    except Exception:
        pass

    tips = _get_performance_tips(storage)
    if tips:
        lines.append('')
        lines.append(f'[COLOR yellow]--- {get_localized_string(32540)} ---[/COLOR]')
        for tip in tips:
            lines.append(f'[COLOR gray]* {tip}[/COLOR]')

    content = '\n'.join(lines)
    xbmcgui.Dialog().textviewer(get_localized_string(32420), content)


def get_storage_info():
    return [(get_localized_string(sid), size) for sid, size in _get_storage_info()]


def get_total_size():
    return _get_storage_info()[0][1]


def _get_storage_info():
    cached = _load_sizes_cache()
    if cached is not None:
        return cached

    from .cache import get_cache_size, get_temp_size

    result = []
    for sid, path in _STORAGE_ITEMS:
        if path == TEMP:
            size = get_temp_size()
        else:
            size = get_dir_size(path) if os.path.exists(path) else 0
        result.append((sid, size))

    result.append((32237, get_cache_size()))

    _save_sizes_cache(result)
    return result


def invalidate_storage_cache():
    if not _SIZES_CACHE_FILE:
        return
    try:
        if os.path.exists(_SIZES_CACHE_FILE):
            os.remove(_SIZES_CACHE_FILE)
    except OSError:
        pass


def _load_sizes_cache():
    if not _SIZES_CACHE_FILE or not os.path.exists(_SIZES_CACHE_FILE):
        return None
    try:
        with open(_SIZES_CACHE_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if time.time() - data.get('timestamp', 0) > _SIZES_TTL:
            return None
        sizes = [[int(sid), int(size)] for sid, size in data.get('sizes', [])]
        if len(sizes) != len(_STORAGE_ITEMS) + 1:
            return None
        return sizes
    except Exception as e:
        log(f'Error loading size cache: {e}')
        return None


def _save_sizes_cache(result):
    if not _SIZES_CACHE_FILE:
        return
    try:
        os.makedirs(os.path.dirname(_SIZES_CACHE_FILE), exist_ok=True)
        with open(_SIZES_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump({'timestamp': time.time(), 'sizes': result}, f)
    except Exception as e:
        log(f'Error saving size cache: {e}')


def _get_performance_tips(storage):
    storage_dict = dict(storage)
    tips = []

    for sid, threshold, msg_id in _TIP_ITEMS:
        if storage_dict.get(sid, 0) > threshold:
            tips.append(get_localized_string(msg_id))

    try:
        import xbmc
        raw = xbmc.getInfoLabel('System.Memory(total)')
        if raw:
            raw = raw.strip().lower().replace('mb', '').replace(' ', '')
            ram_mb = int(float(raw))
            if ram_mb < 2048:
                tips.append(get_localized_string(32546))
    except Exception:
        pass

    return tips
