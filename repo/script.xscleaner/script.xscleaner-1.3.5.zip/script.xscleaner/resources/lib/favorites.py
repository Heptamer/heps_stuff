import os
import xml.etree.ElementTree as ET
from .constants import FAVORITES_XML, HOME_ADDONS, XBMC_ADDONS, translate
from .utils import (
    log, yesno_dialog, ok_dialog,
    progress_create, progress_update, progress_close,
    ADDON_NAME, get_localized_string
)
from .logger import log_action


def clean_favorites():
    if not os.path.exists(FAVORITES_XML):
        ok_dialog(ADDON_NAME, get_localized_string(32530))
        return

    try:
        tree = ET.parse(FAVORITES_XML)
        root = tree.getroot()
    except Exception as e:
        log(f'Error parsing favourites.xml: {e}')
        ok_dialog(ADDON_NAME, get_localized_string(32531).format(e))
        return

    progress_create(ADDON_NAME, get_localized_string(32532))

    broken = []
    valid = 0
    favorites = root.findall('.//favourite')

    for i, fav in enumerate(favorites):
        progress_update(int(i / len(favorites) * 100) if favorites else 100)
        name = fav.get('name', '').strip()
        onclick = (fav.text or '').strip()
        if not onclick:
            continue
        target = _extract_target(onclick)
        if target and not _is_valid_target(target):
            broken.append((name, onclick))
        else:
            valid += 1

    progress_close()

    if broken:
        _show_broken_favorites(broken, root, tree)
    else:
        ok_dialog(ADDON_NAME, get_localized_string(32533).format(valid))


def _extract_target(onclick):
    for prefix in ('ActivateWindow(', 'RunAddon(', 'PlayMedia('):
        if not onclick.startswith(prefix):
            continue
        inner = onclick[len(prefix):]
        paren_count = 1
        i = 0
        while i < len(inner) and paren_count > 0:
            if inner[i] == '(':
                paren_count += 1
            elif inner[i] == ')':
                paren_count -= 1
            i += 1
        args = _split_args(inner[:i - 1])
        if not args:
            return None

        if prefix == 'RunAddon(':
            return ('addon', args[0])
        if prefix == 'PlayMedia(':
            return ('path', args[-1])

        if len(args) >= 2 and args[1]:
            if args[1].lower() not in ('return', 'noop', 'none', 'restore'):
                return ('path', args[1])
        return None

    return None


def _split_args(s):
    args = []
    current = []
    in_quote = False
    quote_char = ''
    for c in s:
        if c in ('"', "'"):
            if not in_quote:
                in_quote = True
                quote_char = c
            elif c == quote_char:
                in_quote = False
            current.append(c)
        elif c == ',' and not in_quote:
            args.append(''.join(current).strip())
            current = []
        else:
            current.append(c)
    args.append(''.join(current).strip())
    return [a.strip().strip('"').strip("'") for a in args]


def _is_valid_target(target):
    kind, value = target
    if not value:
        return True
    if kind == 'addon':
        for addons_path in (HOME_ADDONS, XBMC_ADDONS):
            if os.path.exists(os.path.join(addons_path, value)):
                return True
        return False
    return _path_exists(value)


def _path_exists(path):
    if path.startswith('special://'):
        translated = translate(path)
        return True if translated is None else os.path.exists(translated)
    if '://' in path:
        return True
    return os.path.exists(path)


def _show_broken_favorites(broken, root, tree):
    lines = [f'{name}: {onclick[:60]}...' if len(onclick) > 60 else f'{name}: {onclick}' for name, onclick in broken]
    message = get_localized_string(32534).format(len(broken)) + ':\n\n' + '\n'.join(lines)

    if yesno_dialog(ADDON_NAME, message, get_localized_string(32535)):
        _remove_broken_favorites(broken, root, tree)
    else:
        ok_dialog(ADDON_NAME, message)


def _remove_broken_favorites(broken, root, tree):
    broken_onclicks = {onclick for _, onclick in broken}
    removed = 0
    for fav in list(root.findall('.//favourite')):
        if (fav.text or '').strip() in broken_onclicks:
            root.remove(fav)
            removed += 1

    try:
        tree.write(FAVORITES_XML, encoding='utf-8')
        ok_dialog(ADDON_NAME, get_localized_string(32536).format(removed))
        log(f'Removed {removed} broken favorites')
        log_action('Favorites Cleanup', f'{removed} broken favorites removed', items_cleaned=removed, detail_paths=[(FAVORITES_XML, os.path.getsize(FAVORITES_XML))])
    except Exception as e:
        log(f'Error saving favourites.xml: {e}')
        ok_dialog(ADDON_NAME, get_localized_string(32222).format(e))
