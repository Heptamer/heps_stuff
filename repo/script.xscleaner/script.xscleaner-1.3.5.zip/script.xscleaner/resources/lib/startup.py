import json
import os
import xbmcgui
from .constants import HOME_ADDONS, ADDON_ID
from .utils import log, notify, yesno_dialog, ok_dialog, ADDON_NAME, get_localized_string
from .logger import log_action


def manage_startup():
    service_addons = _get_service_addons()

    if not service_addons:
        ok_dialog(ADDON_NAME, get_localized_string(32380))
        return

    options = []
    for addon in service_addons:
        status = f'[COLOR green]{get_localized_string(32381)}[/COLOR]' if addon['enabled'] else f'[COLOR red]{get_localized_string(32382)}[/COLOR]'
        options.append(f'{addon["name"]} - {status}')

    selection = xbmcgui.Dialog().select(ADDON_NAME, options)

    if selection == -1:
        return

    addon = service_addons[selection]

    if addon['id'] == ADDON_ID:
        ok_dialog(ADDON_NAME, get_localized_string(32383))
        return

    if addon['enabled']:
        if yesno_dialog(ADDON_NAME, get_localized_string(32384).format(addon["name"])):
            _set_addon_enabled(addon['id'], False)
            notify(ADDON_NAME, get_localized_string(32385).format(addon["name"]))
            log_action('Startup Manager', f'Disabled: {addon["name"]}', detail_paths=[(addon['id'], 0)])
    else:
        if yesno_dialog(ADDON_NAME, get_localized_string(32386).format(addon["name"])):
            _set_addon_enabled(addon['id'], True)
            notify(ADDON_NAME, get_localized_string(32387).format(addon["name"]))
            log_action('Startup Manager', f'Enabled: {addon["name"]}', detail_paths=[(addon['id'], 0)])


def _get_service_addons():
    addons = []

    if not os.path.exists(HOME_ADDONS):
        return addons

    for addon_id in os.listdir(HOME_ADDONS):
        addon_path = os.path.join(HOME_ADDONS, addon_id)
        if not os.path.isdir(addon_path):
            continue

        addon_xml = os.path.join(addon_path, 'addon.xml')
        if not os.path.exists(addon_xml):
            continue

        try:
            import xml.etree.ElementTree as ET
            tree = ET.parse(addon_xml)
            root = tree.getroot()

            for ext in root.findall('.//extension'):
                if ext.get('point') == 'xbmc.service':
                    name = root.get('name', addon_id)
                    enabled = _is_addon_enabled(addon_id)

                    addons.append({
                        'id': addon_id,
                        'name': name,
                        'enabled': enabled
                    })
                    break

        except Exception:
            pass

    addons.sort(key=lambda x: x['name'])
    return addons


def _is_addon_enabled(addon_id):
    try:
        query = json.dumps({
            'jsonrpc': '2.0',
            'method': 'Addons.GetAddonDetails',
            'params': {'addonid': addon_id, 'properties': ['enabled']},
            'id': 1,
        })
        import xbmc
        result = xbmc.executeJSONRPC(query)

        data = json.loads(result)
        return bool(data.get('result', {}).get('addon', {}).get('enabled', False))

    except Exception:
        return False


def _set_addon_enabled(addon_id, enabled):
    try:
        query = json.dumps({
            'jsonrpc': '2.0',
            'method': 'Addons.SetAddonEnabled',
            'params': {'addonid': addon_id, 'enabled': enabled},
            'id': 1,
        })
        import xbmc
        xbmc.executeJSONRPC(query)
        return True

    except Exception as e:
        log(f'Error setting addon state: {e}')
        return False
