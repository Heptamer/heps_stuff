import os
import shutil
from .constants import HOME, HOME_ADDONS, EXCLUDES
from .utils import (
    log, notify, yesno_dialog, ok_dialog,
    progress_create, progress_close,
    ADDON_NAME, get_localized_string, remove_empty_folders
)
from .logger import log_action


def fresh_start(mode='normal'):
    if mode == 'normal':
        if not yesno_dialog(
            ADDON_NAME,
            get_localized_string(32370),
            get_localized_string(32371)
        ):
            return

        if not yesno_dialog(
            ADDON_NAME,
            get_localized_string(32372),
            get_localized_string(32373)
        ):
            return

    progress_create(ADDON_NAME, get_localized_string(32374))

    try:
        cleaned = 0
        detail_paths = []
        preserved = set(EXCLUDES)
        addons_dir = os.path.normpath(HOME_ADDONS)

        for root, dirs, files in os.walk(HOME, topdown=True):
            dirs[:] = [d for d in dirs if d not in preserved]

            for name in files:
                if name in ['kodi.log', 'kodi.old.log']:
                    continue

                fp = os.path.join(root, name)
                try:
                    os.remove(fp)
                    cleaned += 1
                except OSError:
                    pass

            for name in dirs:
                if name in preserved:
                    continue
                dp = os.path.normpath(os.path.join(root, name))
                if dp == addons_dir:
                    continue
                try:
                    shutil.rmtree(dp, ignore_errors=True)
                    cleaned += 1
                    detail_paths.append((dp, 0))
                except OSError:
                    pass

        remove_empty_folders(HOME, EXCLUDES)

        progress_close()

        if mode == 'normal':
            notify(ADDON_NAME, get_localized_string(32375).format(cleaned))

        log(f'Kodi factory reset completed, {cleaned} items removed')
        log_action('Kodi Factory Reset', f'{cleaned} items removed', items_cleaned=cleaned, detail_paths=detail_paths)

        if mode == 'normal':
            _reload_profile()

    except Exception as e:
        progress_close()
        log(f'Kodi factory reset error: {e}')
        if mode == 'normal':
            ok_dialog(ADDON_NAME, get_localized_string(32376).format(e))


def _reload_profile():
    try:
        import xbmc
        xbmc.executebuiltin('LoadProfile(Master user)')
    except Exception:
        pass
