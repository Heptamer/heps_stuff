import os
import sqlite3
import time
from .constants import DATABASE, DATABASE_FILES, ADDON_DATA, TEXTURES_DB
from .backup import create_backup
from .utils import (
    log, notify, human_size,
    yesno_dialog, ok_dialog, progress_create, progress_update,
    progress_close, ADDON_NAME, get_setting, is_setting_enabled,
    get_localized_string
)
from .logger import log_action


def optimize_databases(silent=False):
    do_backup = is_setting_enabled('db_backup')
    do_vacuum = is_setting_enabled('db_vacuum')
    do_check = is_setting_enabled('db_quick_check')
    do_orphans = is_setting_enabled('db_cleanup_orphans')
    do_tmdbhelper = is_setting_enabled('db_clean_tmdbhelper')
    do_celeb = is_setting_enabled('db_clean_celeb_cache')
    do_textures = is_setting_enabled('db_rebuild_textures')

    if not do_backup and not do_vacuum and not do_check and not do_orphans and not do_tmdbhelper and not do_celeb and not do_textures:
        return

    if do_backup or do_vacuum or do_orphans or do_tmdbhelper or do_celeb or do_textures:
        backup_path = get_setting('backup_path')
        if not backup_path:
            if not silent:
                ok_dialog(ADDON_NAME, get_localized_string(32351))
            log('Database optimization aborted: backup_path not configured')
            return

    action_labels = []
    action_keys = []

    if do_vacuum and do_check and do_backup:
        action_labels.append(get_localized_string(32280))
        action_keys.append('full')

    if do_vacuum:
        action_labels.append(get_localized_string(32281))
        action_keys.append('vacuum')

    if do_check:
        action_labels.append(get_localized_string(32282))
        action_keys.append('check')

    if do_orphans:
        action_labels.append(get_localized_string(32283))
        action_keys.append('orphans')

    if do_tmdbhelper:
        action_labels.append(get_localized_string(32289))
        action_keys.append('tmdbhelper')

    if do_celeb:
        action_labels.append(get_localized_string(32290))
        action_keys.append('celeb')

    if do_textures:
        action_labels.append(get_localized_string(32291))
        action_keys.append('textures')

    if not action_labels:
        return

    if not silent:
        selection = __import__('xbmcgui').Dialog().select(ADDON_NAME, action_labels)
        if selection == -1:
            return
        action = action_keys[selection]
    else:
        action = action_keys[0]

    if not silent:
        if not yesno_dialog(
            ADDON_NAME,
            get_localized_string(32284),
            get_localized_string(32285)
        ):
            return

    progress_create(ADDON_NAME, get_localized_string(32286))

    if (action in ('full', 'vacuum') and do_backup) or action == 'textures':
        create_backup(backup_path, 'databases', silent=True)

    optimized = 0
    total_freed = 0
    detail_paths = []

    if action == 'tmdbhelper':
        freed, paths = _clean_tmdbhelper()
        total_freed += freed
        detail_paths.extend(paths)
        if freed > 0:
            optimized += 1
        progress_update(100, get_localized_string(32287).format('TMDBHelper'))

    elif action == 'celeb':
        freed, paths = _clean_celeb_cache()
        total_freed += freed
        detail_paths.extend(paths)
        if freed > 0:
            optimized += 1
        progress_update(100, get_localized_string(32287).format('Celebrity/Artist'))

    elif action == 'textures':
        freed, paths = _rebuild_textures_db()
        total_freed += freed
        detail_paths.extend(paths)
        if freed > 0:
            optimized += 1
        progress_update(100, get_localized_string(32287).format('Textures13.db'))

    else:
        db_files = _find_all_databases()
        for i, db_path in enumerate(db_files):
            if not os.path.exists(db_path):
                continue

            percent = int((i / len(db_files)) * 100)
            db_name = os.path.basename(db_path)
            progress_update(percent, get_localized_string(32287).format(db_name))

            size_before = os.path.getsize(db_path)

            if action in ('full', 'vacuum'):
                if do_vacuum:
                    _vacuum_database(db_path)
                optimized += 1

            if action in ('full', 'check'):
                if do_check:
                    _check_database(db_path)

            if action == 'orphans':
                if do_orphans:
                    _cleanup_orphans(db_path)
                optimized += 1

            size_after = os.path.getsize(db_path)
            detail_paths.append((db_path, size_before - size_after if size_after < size_before else 0))

    progress_close()

    if not silent:
        if optimized > 0 or total_freed > 0:
            msg = get_localized_string(32288).format(optimized)
            if total_freed > 0:
                msg += f' (+{human_size(total_freed)})'
            notify(ADDON_NAME, msg)
        else:
            notify(ADDON_NAME, get_localized_string(32223))

    action_names = {
        'full': 'VACUUM + Check',
        'vacuum': 'VACUUM',
        'check': 'Integrity Check',
        'orphans': 'Orphan Cleanup',
        'tmdbhelper': 'TMDBHelper Cache Cleanup',
        'celeb': 'Celebrity/Artist Cache Cleanup',
        'textures': 'Textures13.db Rebuild',
    }
    log(f'Database optimization completed: {action_names[action]}, {optimized} databases processed, freed {human_size(total_freed)}')
    log_action('Database Optimize', action_names[action], items_cleaned=optimized, space_freed=total_freed, detail_paths=detail_paths)


def _find_all_databases():
    db_files = []

    if os.path.exists(DATABASE):
        for name in DATABASE_FILES:
            path = os.path.join(DATABASE, name)
            if os.path.exists(path):
                db_files.append(path)

        for item in os.listdir(DATABASE):
            if item.endswith('.db') and item not in DATABASE_FILES:
                db_files.append(os.path.join(DATABASE, item))

    if os.path.exists(ADDON_DATA):
        for addon_name in os.listdir(ADDON_DATA):
            addon_data_path = os.path.join(ADDON_DATA, addon_name)
            if os.path.isdir(addon_data_path):
                for item in os.listdir(addon_data_path):
                    if item.endswith('.db'):
                        db_files.append(os.path.join(addon_data_path, item))

    return db_files


def _clean_tmdbhelper():
    cleaned = 0
    paths = []
    tmdb_path = os.path.join(ADDON_DATA, 'themoviedb.helper')
    if not os.path.exists(tmdb_path):
        log('TMDBHelper addon data not found, skipping')
        return cleaned, paths

    for root, dirs, files in os.walk(tmdb_path):
        for f in files:
            if f in ('itemdetails.db', 'itemdetails.db-wal'):
                fp = os.path.join(root, f)
                try:
                    size = os.path.getsize(fp)
                    os.remove(fp)
                    cleaned += size
                    paths.append((fp, size))
                    log(f'Removed TMDBHelper cache: {fp} ({human_size(size)})')
                except OSError as e:
                    log(f'Error removing {fp}: {e}')

    if cleaned > 0:
        log(f'TMDBHelper cache cleanup completed, freed {human_size(cleaned)}')
    else:
        log('No TMDBHelper cache files found')

    return cleaned, paths


def _vacuum_database(db_path):
    try:
        conn = sqlite3.connect(db_path)
        conn.execute('VACUUM')
        conn.close()
        log(f'VACUUM completed: {os.path.basename(db_path)}')
        return True
    except Exception as e:
        log(f'Error vacuuming {db_path}: {e}')
        return False


def _check_database(db_path):
    try:
        conn = sqlite3.connect(db_path)
        result = conn.execute('PRAGMA quick_check').fetchone()
        conn.close()

        if result[0] == 'ok':
            log(f'Integrity check OK: {os.path.basename(db_path)}')
        else:
            log(f'Integrity check FAILED: {os.path.basename(db_path)} - {result[0]}')

        return result[0] == 'ok'
    except Exception as e:
        log(f'Error checking {db_path}: {e}')
        return False


def _cleanup_orphans(db_path):
    db_name = os.path.basename(db_path)

    if db_name.startswith('MyVideos') or db_name.startswith('MyMusic'):
        return _cleanup_db_orphans(db_path)

    return False


def _cleanup_db_orphans(db_path):
    start = time.time()
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        tables = [row[0] for row in cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()]

        cleaned = 0
        for table in tables:
            try:
                count = cursor.execute(
                    f'SELECT COUNT(*) FROM "{table}"'
                ).fetchone()[0]
                if count > 500000:
                    log(f'Skipping duplicate cleanup in "{table}" ({count} rows, too large)')
                    continue
            except Exception:
                pass

            try:
                columns = [row[1] for row in cursor.execute(
                    f'PRAGMA table_info("{table}")'
                )]
                if not columns:
                    continue
                group_cols = ', '.join(f'"{c}"' for c in columns)
                cursor.execute(
                    f'DELETE FROM "{table}" WHERE rowid NOT IN '
                    f'(SELECT MIN(rowid) FROM "{table}" GROUP BY {group_cols})'
                )
                cleaned += cursor.rowcount
            except Exception:
                pass

        conn.commit()
        conn.close()

        if cleaned > 0:
            log(f'Removed {cleaned} duplicate rows from {os.path.basename(db_path)} ({time.time() - start:.1f}s)')

        return cleaned > 0

    except Exception as e:
        log(f'Error cleaning duplicates in {db_path}: {e}')
        return False


def _clean_celeb_cache():
    cleaned = 0
    paths = []
    db_path = os.path.join(DATABASE, 'MyVideos116.db')
    if not os.path.exists(db_path):
        db_path = os.path.join(DATABASE, 'MyVideos131.db')
    if not os.path.exists(db_path):
        db_path = os.path.join(DATABASE, 'MyVideos203.db')
    if not os.path.exists(db_path):
        log('No MyVideos database found for celeb cache cleanup')
        return 0, paths

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        tables = [row[0] for row in cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()]
        celeb_tables = [t for t in tables if any(
            kw in t.lower() for kw in ('celebrity', 'artist')
        )]
        for table in celeb_tables:
            try:
                cursor.execute(f'DELETE FROM "{table}"')
                count = cursor.rowcount
                if count > 0:
                    cleaned += count
                    log(f'Cleared {count} rows from "{table}"')
            except Exception:
                pass
        conn.commit()
        conn.close()
        if cleaned > 0:
            log(f'Celebrity/Artist cache cleaned: {cleaned} rows removed')
    except Exception as e:
        log(f'Error cleaning celeb cache: {e}')
    return cleaned, paths


def _rebuild_textures_db():
    cleaned = 0
    paths = []
    if not os.path.exists(TEXTURES_DB):
        log('Textures13.db not found, nothing to rebuild')
        return 0, paths
    try:
        size = os.path.getsize(TEXTURES_DB)
        os.remove(TEXTURES_DB)
        cleaned = size
        paths.append((TEXTURES_DB, size))
        log(f'Textures13.db deleted ({human_size(size)}), backup created')
    except Exception as e:
        log(f'Error rebuilding Textures13.db: {e}')
    return cleaned, paths
