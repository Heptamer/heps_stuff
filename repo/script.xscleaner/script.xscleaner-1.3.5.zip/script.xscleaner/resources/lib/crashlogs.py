import os
import shutil
from .constants import CRASH_PATH, USERDATA, HOME, TEMP
from .utils import (
    log, notify, human_size, get_dir_size,
    yesno_dialog, ADDON_NAME, get_localized_string, is_setting_enabled
)
from .logger import log_action


def clean_crashlogs(silent=False):
    if not is_setting_enabled('clean_crashlogs'):
        return 0

    if not silent:
        if not yesno_dialog(
            ADDON_NAME,
            get_localized_string(32270),
            get_localized_string(32271)
        ):
            return

    cleaned = 0
    detail_paths = []

    if os.path.exists(CRASH_PATH):
        size, paths = _clean_directory(CRASH_PATH)
        cleaned += size
        detail_paths.extend(paths)

    size, paths = _clean_userdata_crashlogs()
    cleaned += size
    detail_paths.extend(paths)

    for path in (HOME, TEMP):
        if path and os.path.isdir(path):
            size, paths = _clean_crashlog_files(path)
            cleaned += size
            detail_paths.extend(paths)

    if not silent:
        if cleaned > 0:
            notify(ADDON_NAME, get_localized_string(32272).format(human_size(cleaned)))
        else:
            notify(ADDON_NAME, get_localized_string(32215))

    log(f'Crash logs cleanup completed, freed {human_size(cleaned)}')
    log_action('Crash Logs Cleanup', space_freed=cleaned, detail_paths=detail_paths)
    return cleaned


def _clean_directory(path):
    cleaned = 0
    paths = []
    try:
        for item in os.listdir(path):
            item_path = os.path.join(path, item)
            try:
                if item.endswith(('.dmp', '.crash')) or item.startswith('kodi_crash'):
                    size = os.path.getsize(item_path)
                    os.remove(item_path)
                    cleaned += size
                    paths.append((item_path, size))
                elif os.path.isdir(item_path) and _contains_crash_files(item_path):
                    dir_size = get_dir_size(item_path)
                    shutil.rmtree(item_path, ignore_errors=True)
                    cleaned += dir_size
                    paths.append((item_path, dir_size))
            except OSError:
                pass
    except Exception as e:
        log(f'Error cleaning crash logs in {path}: {e}')

    return cleaned, paths


def _contains_crash_files(path):
    for root, dirs, files in os.walk(path):
        for f in files:
            if f.endswith(('.dmp', '.crash')):
                return True
    return False


def _clean_crashlog_files(path):
    cleaned = 0
    paths = []
    try:
        for item in os.listdir(path):
            if not item.startswith('kodi_crash'):
                continue
            item_path = os.path.join(path, item)
            try:
                if os.path.isfile(item_path):
                    size = os.path.getsize(item_path)
                    os.remove(item_path)
                    cleaned += size
                    paths.append((item_path, size))
            except OSError:
                pass
    except Exception as e:
        log(f'Error cleaning crash logs in {path}: {e}')

    return cleaned, paths


def _clean_userdata_crashlogs():
    cleaned = 0
    paths = []
    try:
        for item in os.listdir(USERDATA):
            if item.endswith(('.dmp', '.crash')) or item.startswith('kodi_crash'):
                item_path = os.path.join(USERDATA, item)
                try:
                    size = os.path.getsize(item_path)
                    os.remove(item_path)
                    cleaned += size
                    paths.append((item_path, size))
                except OSError:
                    pass
    except Exception:
        pass

    return cleaned, paths
