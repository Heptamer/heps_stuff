import os
import time
import sqlite3
import xbmcgui

from .constants import (
    THUMBNAILS, TEXTURES_DB, translate
)
from .utils import (
    log, notify, human_size,
    yesno_dialog, progress_create, progress_close,
    get_localized_string, is_setting_enabled, get_setting, ADDON_NAME
)
from .logger import log_action


def clean_thumbnails(silent=False):
    all_options = [
        get_localized_string(32240),
        get_localized_string(32241),
        get_localized_string(32242),
        get_localized_string(32243)
    ]

    enabled = [
        is_setting_enabled('clean_thumbnails_unused'),
        is_setting_enabled('clean_thumbnails_old'),
        True,
        True
    ]

    if not any(enabled):
        return 0

    if not silent:
        options = [all_options[i] for i in range(4) if enabled[i]]
        if not options:
            return 0
        selection = xbmcgui.Dialog().select(ADDON_NAME, options)
        if selection == -1:
            return
        real_index = [i for i in range(4) if enabled[i]][selection]
    else:
        if enabled[0]:
            real_index = 0
        elif enabled[1]:
            real_index = 1
        elif enabled[2]:
            real_index = 2
        elif enabled[3]:
            real_index = 3
        else:
            return 0

    if not silent:
        if not yesno_dialog(
            ADDON_NAME,
            all_options[real_index],
            get_localized_string(32221)
        ):
            return

    progress_create(ADDON_NAME, get_localized_string(32244))

    max_age = 30
    if real_index == 1:
        try:
            max_age = int(get_setting('clean_thumbnails_days') or '30')
        except (ValueError, TypeError):
            max_age = 30

    if real_index == 0:
        cleaned, paths = _clean_unused_thumbnails()
    elif real_index == 1:
        cleaned, paths = _clean_old_thumbnails(max_age)
    elif real_index == 2:
        cleaned, paths = _clean_orphan_artwork()
    elif real_index == 3:
        cleaned, paths = _clean_all_thumbnails()

    progress_close()

    if not silent:
        if cleaned > 0:
            notify(ADDON_NAME, get_localized_string(32245).format(human_size(cleaned)))
        else:
            notify(ADDON_NAME, get_localized_string(32218))

    log(f'Thumbnail cleanup completed, freed {human_size(cleaned)}')
    action_names = ['Unused', 'Old', 'Orphan', 'ALL']
    log_action('Thumbnails Cleanup', action_names[real_index], space_freed=cleaned, detail_paths=paths)
    return cleaned


def _clean_unused_thumbnails():
    cleaned = 0
    paths = []

    if not os.path.exists(TEXTURES_DB):
        return 0, paths

    try:
        conn = sqlite3.connect(TEXTURES_DB)
        cursor = conn.cursor()
        cursor.execute('SELECT textureid, url FROM texture')
        rows = cursor.fetchall()
        conn.close()

        existing_textures = {row[0] for row in rows}

        for root, dirs, files in os.walk(THUMBNAILS):
            for name in files:
                try:
                    name_no_ext = os.path.splitext(name)[0]
                    tex_id = int(name_no_ext) if name_no_ext.isdigit() else -1

                    if tex_id not in existing_textures:
                        fp = os.path.join(root, name)
                        size = os.path.getsize(fp)
                        os.remove(fp)
                        cleaned += size
                        paths.append((fp, size))
                except (ValueError, OSError):
                    pass

    except Exception as e:
        log(f'Error cleaning unused thumbnails: {e}')

    return cleaned, paths


def _clean_old_thumbnails(max_age_days=30):
    cleaned = 0
    paths = []
    now = time.time()
    max_age = max_age_days * 86400
    ids_to_delete = []

    if not os.path.exists(TEXTURES_DB):
        return 0, paths

    try:
        conn = sqlite3.connect(TEXTURES_DB)
        cursor = conn.cursor()

        for root, dirs, files in os.walk(THUMBNAILS):
            for name in files:
                fp = os.path.join(root, name)
                try:
                    file_age = now - os.path.getmtime(fp)
                    if file_age > max_age:
                        size = os.path.getsize(fp)
                        os.remove(fp)

                        name_no_ext = os.path.splitext(name)[0]
                        if name_no_ext.isdigit():
                            ids_to_delete.append(int(name_no_ext))

                        cleaned += size
                        paths.append((fp, size))
                except OSError:
                    pass

        _delete_texture_ids(cursor, ids_to_delete)
        conn.commit()
        conn.close()

    except Exception as e:
        log(f'Error cleaning old thumbnails: {e}')

    return cleaned, paths


def _clean_orphan_artwork():
    cleaned = 0
    paths = []
    ids_to_delete = []

    if not os.path.exists(TEXTURES_DB):
        return 0, paths

    try:
        conn = sqlite3.connect(TEXTURES_DB)
        cursor = conn.cursor()
        cursor.execute('SELECT textureid, url FROM texture')
        rows = cursor.fetchall()

        valid_ids = set()
        for tex_id, url in rows:
            if _source_exists(url):
                valid_ids.add(tex_id)

        for root, dirs, files in os.walk(THUMBNAILS):
            for name in files:
                try:
                    name_no_ext = os.path.splitext(name)[0]
                    if name_no_ext.isdigit():
                        tex_id = int(name_no_ext)
                        if tex_id not in valid_ids:
                            fp = os.path.join(root, name)
                            size = os.path.getsize(fp)
                            os.remove(fp)
                            ids_to_delete.append(tex_id)
                            cleaned += size
                            paths.append((fp, size))
                except (ValueError, OSError):
                    pass

        _delete_texture_ids(cursor, ids_to_delete)
        conn.commit()
        conn.close()

    except Exception as e:
        log(f'Error cleaning orphan artwork: {e}')

    return cleaned, paths


def _delete_texture_ids(cursor, ids):
    ids = list(ids)
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        placeholders = ','.join('?' * len(chunk))
        cursor.execute(
            f'DELETE FROM texture WHERE textureid IN ({placeholders})',
            chunk
        )


def _source_exists(url):
    if not url:
        return True
    if url.startswith('special://'):
        translated = translate(url)
        return True if translated is None else os.path.exists(translated)
    if '://' in url:
        return True
    return os.path.exists(url)


def _clean_all_thumbnails():
    cleaned = 0
    paths = []

    if os.path.exists(THUMBNAILS):
        for root, dirs, files in os.walk(THUMBNAILS, topdown=False):
            for name in files:
                fp = os.path.join(root, name)
                try:
                    size = os.path.getsize(fp)
                    os.remove(fp)
                    cleaned += size
                    paths.append((fp, size))
                except OSError:
                    pass

            for name in dirs:
                dp = os.path.join(root, name)
                try:
                    os.rmdir(dp)
                    paths.append((dp, 0))
                except OSError:
                    pass

    if os.path.exists(TEXTURES_DB):
        try:
            os.remove(TEXTURES_DB)
            paths.append((TEXTURES_DB, 0))
        except OSError:
            pass

    return cleaned, paths
