import os
import shutil
import stat
import threading
import time

try:
    import xbmcvfs
except ImportError:
    xbmcvfs = None

from .utils import log

_OP_TIMEOUT = 15   # metadata operations: stat, listdir, exists, mkdirs, delete, rmdir
_IO_TIMEOUT = 30   # single read/write call inside _copy_stream


def _run_with_timeout(fn, timeout=_OP_TIMEOUT, default=None):
    """Runs fn() in a daemon thread. Returns (value, timed_out).

    A hung xbmcvfs call can no longer block the caller for longer than
    timeout seconds; the daemon thread keeps waiting in the background until
    Kodi's own connection timeout resolves it.
    """
    result = [default]
    exc = [None]

    def _target():
        try:
            result[0] = fn()
        except Exception as e:
            exc[0] = e

    t = threading.Thread(target=_target, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        log(f'Network operation timed out after {timeout}s')
        return default, True
    if exc[0] is not None:
        raise exc[0]
    return result[0], False


def _is_remote(path):
    return '://' in str(path)


def _stat(path):
    if xbmcvfs is None:
        return None
    if _is_remote(path):
        try:
            result, timed_out = _run_with_timeout(lambda: xbmcvfs.Stat(path), timeout=_OP_TIMEOUT, default=None)
        except Exception:
            return None
        if timed_out:
            log(f'stat timed out: {path}')
            return None
        return result
    try:
        return xbmcvfs.Stat(path)
    except Exception:
        return None


def _get_mode(path):
    # Local paths: os.path is authoritative. xbmcvfs.Stat() can return a
    # bogus non-zero mode for missing local files (which would make them
    # look like regular files and break the "skip missing optional items"
    # logic in backups), so it is never consulted for type checks here.
    if not _is_remote(path):
        try:
            return os.stat(path).st_mode
        except (OSError, TypeError):
            return 0
    mode = 0
    if xbmcvfs is not None:
        st = _stat(path)
        if st is not None:
            try:
                mode = st.st_mode()
            except TypeError:
                mode = st.st_mode
            if not isinstance(mode, int):
                mode = 0
    return mode


def exists(path):
    if xbmcvfs is not None:
        if _is_remote(path):
            try:
                result, timed_out = _run_with_timeout(lambda: bool(xbmcvfs.exists(path)), timeout=_OP_TIMEOUT, default=False)
            except Exception:
                result = False
                timed_out = False
            if timed_out:
                log(f'exists timed out: {path}')
                return False
            return result
        try:
            result = bool(xbmcvfs.exists(path))
        except Exception:
            result = False
        if result:
            return True
        if not _is_remote(path):
            try:
                return os.path.exists(path)
            except Exception:
                return False
        return result
    return os.path.exists(path)


def isfile(path):
    mode = _get_mode(path)
    return bool(mode) and stat.S_ISREG(mode)


def isdir(path):
    mode = _get_mode(path)
    return bool(mode) and stat.S_ISDIR(mode)


def mode_type(path):
    mode = _get_mode(path)
    if mode and stat.S_ISDIR(mode):
        return 'dir'
    if mode and stat.S_ISREG(mode):
        return 'file'
    return None


def _listdir_checked(path):
    """Returns (names, timed_out). copytree uses this to detect timeouts,
    which would otherwise be indistinguishable from an empty directory."""
    if xbmcvfs is not None:
        if _is_remote(path):
            def _remote():
                files, dirs = xbmcvfs.listdir(path)
                return sorted(list(files) + list(dirs))
            try:
                result, timed_out = _run_with_timeout(_remote, timeout=_OP_TIMEOUT, default=None)
            except Exception:
                return [], False
            if timed_out:
                log(f'listdir timed out: {path}')
                return [], True
            return result or [], False
        try:
            files, dirs = xbmcvfs.listdir(path)
            names = sorted(list(files) + list(dirs))
            if names:
                return names, False
        except Exception:
            pass
    try:
        return sorted(os.listdir(path)), False
    except OSError:
        return [], False


def listdir(path):
    names, _ = _listdir_checked(path)
    return names


def listdir_dirs(path):
    if xbmcvfs is not None:
        if _is_remote(path):
            def _remote():
                _, dirs = xbmcvfs.listdir(path)
                return sorted(list(dirs))
            try:
                result, timed_out = _run_with_timeout(_remote, timeout=_OP_TIMEOUT, default=None)
            except Exception:
                return []
            if timed_out:
                log(f'listdir_dirs timed out: {path}')
                return []
            return result or []
        try:
            _, dirs = xbmcvfs.listdir(path)
            dirs = sorted(list(dirs))
            if dirs:
                return dirs
        except Exception:
            pass
    try:
        return sorted(d for d in os.listdir(path) if os.path.isdir(join(path, d)))
    except OSError:
        return []


def _basename(path):
    return str(path).rstrip('/').split('/')[-1]


def _should_include(name):
    if name == '__pycache__':
        return False
    if name.endswith('.pyc'):
        return False
    return True


def _listdir_names(path):
    names = listdir(path)
    if not names:
        log(f'listdir returned nothing for {path}')
    return set(names)


def _probe_write(base):
    probe = join(base, '.xscleaner_write_test')
    try:
        if xbmcvfs is None:
            with open(probe, 'w') as f:
                f.write('ok')
            os.remove(probe)
            return True
        f = xbmcvfs.File(probe, 'w')
        if _is_remote(base):
            ok, _ = _run_with_timeout(lambda: bool(f.write(b'ok')), timeout=_IO_TIMEOUT, default=False)
        else:
            ok = bool(f.write(b'ok'))
        try:
            f.close()
        except Exception:
            pass
        # Kodi caches SMB/NFS directory listings; xbmcvfs.listdir() can return
        # a stale snapshot without the freshly written probe file even though
        # the write succeeded. Verify the file directly (xbmcvfs.exists/bypassed
        # via os.path.stat fallback) and retry in case the listing is delayed.
        visible = False
        for _ in range(4):
            if exists(probe):
                visible = True
                break
            if _basename(probe) in _listdir_names(base):
                visible = True
                break
            time.sleep(0.3)
        size = getsize(probe)
        if not ok or not visible or size <= 0:
            log(f'Write probe failed for {base}: write={ok}, listed={visible}, size={size}')
            return False
        try:
            xbmcvfs.delete(probe)
        except Exception:
            pass
        return True
    except Exception as e:
        log(f'Write probe error for {base}: {e}')
        return False


def writable(path):
    if not mkdirs(path):
        log(f'Write test failed for {path}: cannot create the folder')
        return False
    if _probe_write(path):
        return True
    sub = join(path, '.xscleaner_write_probe')
    log(f'Write test: file write failed in {path}, retrying in subfolder {sub}')
    if mkdirs(sub) and _probe_write(sub):
        try:
            if xbmcvfs is not None:
                xbmcvfs.rmdir(sub)
            else:
                os.rmdir(sub)
        except Exception:
            pass
        return True
    log(f'Write test failed for {path}: file write failed in the folder and in a subfolder')
    return False


def mkdirs(path):
    if xbmcvfs is None:
        try:
            os.makedirs(path, exist_ok=True)
            return True
        except OSError:
            return False
    if not _is_remote(path):
        try:
            if xbmcvfs.mkdirs(path):
                return True
        except Exception:
            pass
        try:
            os.makedirs(path, exist_ok=True)
            return True
        except OSError:
            return False
    if _is_remote(path):
        try:
            created, timed_out = _run_with_timeout(lambda: bool(xbmcvfs.mkdirs(path)), timeout=_OP_TIMEOUT, default=False)
        except Exception:
            created, timed_out = False, False
        if created and not timed_out:
            return True
        if timed_out:
            log(f'mkdirs timed out: {path}')
        return _remote_dir_created(path)


def _remote_dir_created(path):
    # xbmcvfs.mkdirs() maps to CUtil::CreateDirectoryEx(), which creates the
    # directory but returns CDirectory::Exists() - that check uses Kodi's
    # directory cache and can report False for a just-created SMB directory.
    # Verify directly (xbmcvfs.exists bypasses the cache) and retry in case
    # the SMB directory listing is delayed.
    try:
        for _ in range(4):
            if exists(path):
                return True
            if _basename(path) in _listdir_names(dirname(path)):
                return True
            time.sleep(0.3)
    except Exception:
        pass
    return False


def join(*parts):
    parts = [p for p in parts if p]
    if not parts:
        return ''
    if _is_remote(parts[0]):
        orig = str(parts[0])
        base = orig.rstrip('/')
        scheme_end = orig.find('://')
        if scheme_end != -1 and len(base) <= scheme_end + 3:
            base = orig[:scheme_end + 3]
        result = base
        for p in parts[1:]:
            if not result.endswith('/'):
                result = result + '/'
            result = result + str(p).strip('/')
        return result
    return os.path.join(*parts)


def dirname(path):
    if _is_remote(path):
        idx = str(path).rfind('/')
        if idx <= 0:
            return str(path)
        return str(path)[:idx]
    return os.path.dirname(path)


def getsize(path):
    if not _is_remote(path):
        try:
            return os.path.getsize(path)
        except OSError:
            return 0
    if xbmcvfs is not None:
        st = _stat(path)
        if st is not None:
            try:
                size = int(st.st_size())
            except Exception:
                size = -1
            if size == -1:
                return 0
            return size
    return 0


def _restore_mtime(src, dst):
    try:
        mtime = _stat(src).st_mtime()
        os.utime(dst, (mtime, mtime))
    except Exception:
        pass


def _copy_stream(src, dst, on_progress=None):
    local_src = not _is_remote(src)
    local_dst = not _is_remote(dst)
    if local_src:
        try:
            fsrc = open(src, 'rb')
        except (OSError, IOError) as e:
            log(f'Copy failed: cannot open source {src}: {e}')
            return False
        read_chunk = fsrc.read
    else:
        try:
            fsrc = xbmcvfs.File(src, 'r')
        except Exception as e:
            log(f'Copy failed: cannot open source {src}: {e}')
            return False
        read_chunk = fsrc.readBytes
    try:
        if local_dst:
            fdst = open(dst, 'wb')
        else:
            fdst = xbmcvfs.File(dst, 'w')
    except Exception as e:
        log(f'Copy failed: cannot open destination {dst}: {e}')
        try:
            fsrc.close()
        except Exception:
            pass
        return False
    try:
        while True:
            try:
                if _is_remote(src):
                    chunk, timed_out = _run_with_timeout(read_chunk, timeout=_IO_TIMEOUT, default=b'')
                else:
                    chunk = read_chunk(64 * 1024)
                    timed_out = False
                if timed_out:
                    log(f'Copy failed: read timed out from {src}')
                    return False
                if not chunk:
                    break
                if _is_remote(dst):
                    ok, timed_out = _run_with_timeout(lambda: fdst.write(chunk), timeout=_IO_TIMEOUT, default=False)
                    if timed_out or not ok:
                        log(f'Copy failed: write error/timeout to {dst}')
                        return False
                elif not fdst.write(chunk):
                    log(f'Copy failed: write error to {dst}')
                    return False
            except Exception as e:
                log(f'Copy failed: {src} -> {dst}: {e}')
                return False
            if on_progress:
                on_progress(len(chunk))
    finally:
        try:
            fsrc.close()
        except Exception:
            pass
        try:
            fdst.close()
        except Exception:
            pass
    ok = bool(exists(dst))
    if not ok:
        log(f'Copy failed: destination missing after write {dst}')
    return ok


def copy(src, dst, on_progress=None):
    if xbmcvfs is not None and (_is_remote(src) or _is_remote(dst)):
        return _copy_stream(src, dst, on_progress=on_progress)
    if xbmcvfs is not None:
        try:
            ok = bool(xbmcvfs.copy(src, dst))
        except Exception:
            ok = False
        if ok and not _is_remote(dst):
            _restore_mtime(src, dst)
        return ok
    try:
        shutil.copy2(src, dst)
        return True
    except (OSError, shutil.Error):
        return False


def count_files(path):
    if xbmcvfs is not None:
        try:
            files, dirs = xbmcvfs.listdir(path)
            files = [f for f in files if _should_include(f)]
            dirs = [d for d in dirs if _should_include(d)]
            total = len(files)
            ok = True
            for name in dirs:
                sub_total, sub_ok = count_files(join(path, name))
                total += sub_total
                ok = ok and sub_ok
            return total, ok
        except Exception:
            if _is_remote(path):
                return 0, False
    try:
        total = 0
        ok = True
        for name in os.listdir(path):
            if not _should_include(name):
                continue
            item = join(path, name)
            if os.path.isdir(item):
                sub_total, sub_ok = count_files(item)
                total += sub_total
                ok = ok and sub_ok
            elif os.path.isfile(item):
                total += 1
        return total, ok
    except OSError:
        return 0, False


def copytree(src, dst, on_file=None, _rel=''):
    if not mkdirs(dst):
        return False
    names, timed_out = _listdir_checked(src)
    if timed_out:
        log(f'Copy failed: listing {src} timed out')
        return False
    ok = True
    for name in names:
        if not _should_include(name):
            continue
        item = join(src, name)
        target = join(dst, name)
        child_rel = _rel + name
        kind = mode_type(item)
        if kind == 'dir':
            if not copytree(item, target, on_file, child_rel + '/'):
                ok = False
        elif kind == 'file':
            if not copy(item, target):
                ok = False
            if on_file:
                on_file(child_rel)
        else:
            ok = False
            log(f'Copy skipped: cannot determine type of {item}')
    return ok


def delete(path):
    if xbmcvfs is not None:
        if _is_remote(path):
            ok, _ = _run_with_timeout(lambda: bool(xbmcvfs.delete(path)), timeout=_OP_TIMEOUT, default=False)
            return ok
        try:
            return bool(xbmcvfs.delete(path))
        except Exception:
            pass
    try:
        os.remove(path)
        return True
    except OSError:
        return False


def rmtree(path):
    if xbmcvfs is not None:
        try:
            for name in listdir(path):
                item = join(path, name)
                if isdir(item):
                    rmtree(item)
                else:
                    if _is_remote(item):
                        _, timed_out = _run_with_timeout(lambda: xbmcvfs.delete(item), timeout=_OP_TIMEOUT, default=False)
                        if timed_out:
                            log(f'rmtree aborted: deleting {item} timed out')
                            return False
                    else:
                        xbmcvfs.delete(item)
            if _is_remote(path):
                ok, _ = _run_with_timeout(lambda: bool(xbmcvfs.rmdir(path)), timeout=_OP_TIMEOUT, default=False)
                return ok
            return bool(xbmcvfs.rmdir(path))
        except Exception:
            return False
    try:
        shutil.rmtree(path, ignore_errors=True)
        return True
    except Exception:
        return False


def get_dir_size(path):
    total = 0
    for name in listdir(path):
        item = join(path, name)
        if isdir(item):
            total += get_dir_size(item)
        elif isfile(item):
            total += getsize(item)
    return total
