import os
import xbmcgui
from .constants import LOG_PATH
from .utils import log, ok_dialog, ADDON_NAME, get_localized_string


def view_logs():
    if not os.path.exists(LOG_PATH):
        ok_dialog(ADDON_NAME, get_localized_string(32400))
        return

    log_files = []
    for item in os.listdir(LOG_PATH):
        if item.endswith('.log'):
            log_files.append({
                'name': item,
                'path': os.path.join(LOG_PATH, item)
            })

    if not log_files:
        ok_dialog(ADDON_NAME, get_localized_string(32401))
        return

    log_files.sort(key=lambda x: x['name'])

    options = [f['name'] for f in log_files]
    selection = xbmcgui.Dialog().select(ADDON_NAME, options)

    if selection == -1:
        return

    _view_log(log_files[selection]['path'])


def _view_log(log_path):
    try:
        size = os.path.getsize(log_path)
        read_size = min(size, 50000)
        with open(log_path, 'rb') as f:
            f.seek(size - read_size)
            content = f.read().decode('utf-8', errors='replace')

        if size > 50000:
            content = get_localized_string(32402) + '\n\n' + content

        xbmcgui.Dialog().textviewer(get_localized_string(32403), content)

    except Exception as e:
        log(f'Error reading log: {e}')
        ok_dialog(ADDON_NAME, get_localized_string(32404).format(e))
