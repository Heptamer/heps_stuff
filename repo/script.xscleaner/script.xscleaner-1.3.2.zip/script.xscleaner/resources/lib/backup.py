import os
import shutil
from datetime import datetime
from .constants import (
    HOME, HOME_ADDONS, ADDON_DATA,
    DATABASE, SOURCES_XML, ADVSETTINGS_XML,
    GUISETTINGS_XML, PROFILES_XML, KEYMAP_DIR,
    PLAYLISTS_DIR
)
from .utils import (
    log, notify, yesno_dialog, ok_dialog,
    progress_create, progress_update, progress_close,
    get_setting, ADDON_NAME, get_dir_size,
    get_localized_string
)
from .logger import log_action


BACKUP_TYPES = {
    'full': 32340,
    'addons': 32341,
    'addon_data': 32342,
    'addons_data': 32343,
    'databases': 32236,
    'settings': 32344,
    'profiles': 32346,
    'keymaps': 32347,
    'playlists': 32348
}


def backup_restore_menu():
    options = [get_localized_string(32349), get_localized_string(32350)]
    selection = __import__('xbmcgui').Dialog().select(ADDON_NAME, options)

    if selection == 0:
        _backup_menu()
    elif selection == 1:
        _restore_menu()


def _backup_menu():
    backup_path = get_setting('backup_path')
    if not backup_path:
        ok_dialog(ADDON_NAME, get_localized_string(32351))
        return

    options = [get_localized_string(sid) for sid in BACKUP_TYPES.values()]
    selection = __import__('xbmcgui').Dialog().select(ADDON_NAME, options)

    if selection == -1:
        return

    backup_type = list(BACKUP_TYPES.keys())[selection]

    if not yesno_dialog(ADDON_NAME, get_localized_string(32352).format(get_localized_string(BACKUP_TYPES[backup_type]))):
        return

    create_backup(backup_path, backup_type)


def _restore_menu():
    backup_path = get_setting('backup_path')
    if not backup_path or not os.path.exists(backup_path):
        ok_dialog(ADDON_NAME, get_localized_string(32353))
        return

    backups = _list_backups(backup_path)
    if not backups:
        ok_dialog(ADDON_NAME, get_localized_string(32354))
        return

    options = [b['name'] for b in backups]
    selection = __import__('xbmcgui').Dialog().select(ADDON_NAME, options)

    if selection == -1:
        return

    if not yesno_dialog(ADDON_NAME, get_localized_string(32355), get_localized_string(32356)):
        return

    _restore_backup(backups[selection]['path'])


def create_backup(backup_path, backup_type, silent=False):
    if not silent:
        progress_create(ADDON_NAME, get_localized_string(32357))

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_name = f'xscleaner_{backup_type}_{timestamp}'
    backup_dir = os.path.join(backup_path, backup_name)
    os.makedirs(backup_dir, exist_ok=True)

    items_to_backup = _get_backup_items(backup_type)
    detail_paths = []

    for i, (name, src) in enumerate(items_to_backup):
        if not os.path.exists(src):
            continue

        if not silent:
            percent = int((i / len(items_to_backup)) * 100)
            progress_update(percent, get_localized_string(32358).format(name))

        try:
            dst = os.path.join(backup_dir, name)
            if os.path.isfile(src):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
                detail_paths.append((src, os.path.getsize(src)))
            elif os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
                detail_paths.append((src, get_dir_size(src)))
        except Exception as e:
            log(f'Error backing up {name}: {e}')

    if not silent:
        progress_close()
        notify(ADDON_NAME, get_localized_string(32359).format(backup_name))

    log(f'Backup created: {backup_name}')
    log_action('Backup Created', backup_name, detail_paths=detail_paths)


def _restore_backup(backup_path):
    progress_create(ADDON_NAME, get_localized_string(32360))

    items = os.listdir(backup_path)
    detail_paths = []

    for i, name in enumerate(items):
        percent = int((i / len(items)) * 100)
        progress_update(percent, get_localized_string(32361).format(name))

        src = os.path.join(backup_path, name)
        dst = _restore_dst(name)

        try:
            if os.path.isfile(src):
                shutil.copy2(src, dst)
                detail_paths.append((dst, os.path.getsize(src)))
            elif os.path.isdir(src):
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
                detail_paths.append((dst, get_dir_size(src)))
        except Exception as e:
            log(f'Error restoring {name}: {e}')

    progress_close()
    notify(ADDON_NAME, get_localized_string(32362))
    log(f'Backup restored from: {backup_path}')
    log_action('Backup Restored', backup_path, detail_paths=detail_paths)


def _restore_dst(name):
    if name == 'addons':
        return HOME_ADDONS
    if name.startswith('userdata/'):
        return os.path.join(HOME, name[len('userdata/'):])
    return os.path.join(HOME, name)


def _get_backup_items(backup_type):
    items = []

    if backup_type in ['full', 'addons', 'addons_data']:
        items.append(('addons', HOME_ADDONS))

    if backup_type in ['full', 'addon_data', 'addons_data']:
        items.append(('userdata/addon_data', ADDON_DATA))

    if backup_type in ['full', 'databases']:
        items.append(('userdata/Database', DATABASE))

    if backup_type in ['full', 'settings']:
        items.append(('userdata/sources.xml', SOURCES_XML))
        items.append(('userdata/advancedsettings.xml', ADVSETTINGS_XML))
        items.append(('userdata/guisettings.xml', GUISETTINGS_XML))

    if backup_type in ['full', 'profiles']:
        items.append(('userdata/profiles.xml', PROFILES_XML))

    if backup_type in ['full', 'keymaps']:
        items.append(('userdata/keymaps', KEYMAP_DIR))

    if backup_type in ['full', 'playlists']:
        items.append(('userdata/playlists', PLAYLISTS_DIR))

    return items


def _list_backups(backup_path):
    backups = []
    try:
        for item in os.listdir(backup_path):
            item_path = os.path.join(backup_path, item)
            if os.path.isdir(item_path) and item.startswith('xscleaner_'):
                backups.append({
                    'name': item,
                    'path': item_path
                })
    except Exception:
        pass

    backups.sort(key=lambda x: x['name'], reverse=True)
    return backups
