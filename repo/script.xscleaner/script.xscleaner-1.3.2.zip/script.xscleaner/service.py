import os
import time
import xbmcaddon

from resources.lib.constants import ADDON_ID, ADDON_DATA
from resources.lib.utils import log

LAST_RUN_FILE = os.path.join(ADDON_DATA, ADDON_ID, 'last_auto_cleanup.txt') if ADDON_DATA else None


def run_service():
    addon = xbmcaddon.Addon(id=ADDON_ID)
    auto_clean = addon.getSetting('auto_cleanup_enabled')
    delay = _get_int_setting(addon, 'auto_cleanup_delay', 30)
    interval_days = _get_int_setting(addon, 'auto_cleanup_interval_days', 0)

    if auto_clean != 'true':
        return

    interval_seconds = interval_days * 86400
    if interval_seconds > 0:
        last_run = _read_last_run()
        if last_run > 0:
            elapsed = time.time() - last_run
            if elapsed < interval_seconds:
                remaining_hours = int((interval_seconds - elapsed) / 3600)
                log(f'Auto cleanup skipped, {remaining_hours}h remaining until next run')
                return

    has_work = (
        addon.getSetting('clean_cache') == 'true' or
        addon.getSetting('clean_temp') == 'true' or
        addon.getSetting('clean_thumbnails_unused') == 'true' or
        addon.getSetting('clean_thumbnails_old') == 'true' or
        addon.getSetting('clean_packages') == 'true' or
        addon.getSetting('clean_crashlogs') == 'true' or
        addon.getSetting('clean_addon_leftovers') == 'true'
    )

    if not has_work:
        return

    log(f'Service started, waiting {delay}s')

    if _wait_for_abort(delay):
        log('Service aborted during delay, skipping cleanup')
        return

    try:
        from resources.lib.cache import clean_cache
        from resources.lib.thumbnails import clean_thumbnails
        from resources.lib.packages import clean_packages
        from resources.lib.crashlogs import clean_crashlogs
        from resources.lib.addons import clean_addon_leftovers

        clean_cache(silent=True)
        clean_thumbnails(silent=True)
        clean_packages(silent=True)
        clean_crashlogs(silent=True)
        clean_addon_leftovers(silent=True)
        _write_last_run()
        log('Auto cleanup completed')

        try:
            from resources.lib.dashboard import invalidate_storage_cache
            invalidate_storage_cache()
        except Exception:
            pass

        try:
            from resources.lib.updater import check_for_updates
            check_for_updates(silent=True)
        except Exception:
            pass
    except Exception as e:
        log(f'Auto cleanup failed: {e}', level=4)


def _get_int_setting(addon, key, default):
    try:
        return int(addon.getSetting(key) or default)
    except (ValueError, TypeError):
        return default


def _wait_for_abort(seconds):
    try:
        import xbmc
        return xbmc.Monitor().waitForAbort(seconds)
    except Exception:
        time.sleep(seconds)
        return False


def _read_last_run():
    try:
        if LAST_RUN_FILE and os.path.exists(LAST_RUN_FILE):
            with open(LAST_RUN_FILE, 'r') as f:
                return float(f.read().strip())
    except (ValueError, OSError):
        pass
    return 0


def _write_last_run():
    try:
        if not LAST_RUN_FILE:
            return
        os.makedirs(os.path.dirname(LAST_RUN_FILE), exist_ok=True)
        with open(LAST_RUN_FILE, 'w') as f:
            f.write(str(time.time()))
    except OSError as e:
        log(f'Failed to write last run time: {e}', level=4)


if __name__ == '__main__':
    run_service()
