[![Kodi Version](https://img.shields.io/badge/kodi-19%2B-blue)](https://kodi.tv/)
[![License: GPLv3](https://img.shields.io/badge/License-GPLv3-yellow.svg)](https://opensource.org/licenses/GPL-3.0)
![Python application](https://img.shields.io/badge/Build_with-Pycharm-green)

# XSCleaner Kodi Add-on
**script.xscleaner** is a [Kodi](https://kodi.tv/) maintenance add-on that cleans cache, thumbnails, addon leftovers, packages, crash logs, optimizes databases, manages backup/restore, and more. Fully localized in German and English.

##
**script.xscleaner** ist ein [Kodi](https://kodi.tv/) Wartungs-Add-on das Cache, Thumbnails, Addon-Overlaps, Pakete, Absturzprotokolle bereinigt, Datenbanken optimiert, Backup/Restore verwaltet und vieles mehr. Vollständig auf Deutsch und Englisch lokalisiert.

---

## Features
- Dashboard with storage overview and performance tips
- Cache & temp file cleanup (with HTTP, weather, downloads, search history sub-options)
- Thumbnail cleanup (unused, old, orphan, all)
- Addon leftover & orphan data removal
- Package cleanup (with unused language cleanup)
- Crash log cleanup
- Database optimization (VACUUM, integrity check, orphan cleanup, TMDBHelper cache, celebrity/artist cache, textures rebuild)
- Broken sources detection & removal (supports remote URLs)
- Favorites Manager (detect and remove broken favorites)
- Advanced settings editor (version-aware, RAM detection, network/video/samba)
- Full backup & restore system
- Kodi factory reset (off by default in settings)
- Startup service manager
- Log file viewer
- Activity log with detailed path tracking
- Automatic cleanup at Kodi startup (optional)
- User-friendly interface in German and English

##
- Dashboard mit Speicherübersicht und Leistungstipps
- Cache- & Temporärdateien-Bereinigung (mit HTTP-, Wetter-, Downloads-, Suchverlauf-Sub-Optionen)
- Thumbnail-Bereinigung (ungenutzt, alt, Waisen, alle)
- Addon-Überreste & verwaiste Daten entfernen (mit Sprachdateien-Bereinigung)
- Paket-Cache bereinigen
- Absturzprotokolle bereinigen
- Datenbankoptimierung (VACUUM, Integritätsprüfung, Waisen-Bereinigung, TMDBHelper-Cache, Celebrity/Artist-Cache, Textures-Neubau)
- Defekte Quellen erkennen & entfernen (unterstützt Remote-URLs)
- Favorites-Manager (defekte Favoriten erkennen und entfernen)
- Advanced Settings Editor (Buffer, Cache, Netzwerk, Video, Samba)
- Vollständiges Backup & Wiederherstellung
- Kodi auf Werkseinstellungen zurücksetzen (in den Einstellungen standardmäßig deaktiviert)
- Startup Service Manager
- Logdatei-Betrachter
- Aktivitätsprotokoll mit detaillierter Pfadverfolgung
- Automatische Bereinigung beim Kodi-Start (optional)
- Benutzerfreundliche Oberfläche auf Deutsch und Englisch

---

## Requirements
- Kodi 19 (Matrix) or higher
- Python 3

##
- Kodi 19 (Matrix) oder höher
- Python 3

---

## Installation

### From Repository
Coming soon.

### Manual Installation
1. Download the latest release ZIP file
2. In Kodi go to **Settings > Add-ons > Install from ZIP file**
3. Select the downloaded ZIP file

##
### Aus dem Repository
In Kürze verfügbar.

### Manuelle Installation
1. Die neueste Release-ZIP-Datei herunterladen
2. In Kodi zu **Einstellungen > Add-ons > Aus ZIP-Datei installieren** gehen
3. Die heruntergeladene ZIP-Datei auswählen

---

## Usage / Benutzung

Open XSCleaner from the Kodi main menu under **Add-ons**. The add-on appears as a plugin with a clickable dashboard and a list of all available tools.

##
Öffne XSCleaner über das Kodi-Hauptmenü unter **Add-ons**. Das Add-on erscheint als Plugin mit einem klickbaren Dashboard und einer Liste aller verfügbaren Werkzeuge.

---

## Features in Detail / Funktionen im Detail

### Dashboard
Displays the current size of key Kodi directories: Home, Addons, Addon Data, Thumbnails, Packages, Temp, Databases, and total cache. Click on it to see detailed system info (Kodi version, Python version, build) with **performance tips** — actionable hints when directories exceed recommended sizes (e.g., thumbnails >500MB, low RAM detected).

##
Zeigt die aktuelle Größe wichtiger Kodi-Verzeichnisse an: Home, Addons, Addon Data, Thumbnails, Packages, Temp, Datenbanken und Gesamtcache. Klicke darauf für detaillierte Systeminfos (Kodi-Version, Python-Version, Build) mit **Leistungstipps** — Hinweise wenn Verzeichnisse empfohlene Größen überschreiten (z.B. Thumbnails >500MB, wenig RAM erkannt).

---

### Cache & Temp Cleanup / Cache- & Temp-Bereinigung

Controlled by settings: `Clean Cache` (master toggle) with sub-options, and `Clean Temp` (temp directory). Only enabled areas are cleaned.

**New in v1.3.0 — Cache sub-options:** When `Clean Cache` is enabled, these additional areas can be individually toggled:

| Sub-option / Sub-Option | Path / Pfad | What is deleted / Was wird gelöscht |
|---|---|---|
| **Clean HTTP/Image cache** | `special://userdata/cache/`, `special://userdata/Thumbnails/cache/` | Kodi's internal HTTP response cache and thumbnail cache directory |
| **Clean Weather addon caches** | `special://userdata/addon_data/weather.*/cache/`, `special://userdata/addon_data/weather.*/temp/` | Cached weather data for all weather.* addons |
| **Clean Downloads** | `special://userdata/Downloads/` | Completed/incomplete Kodi download manager files |
| **Clean Search History** | `special://userdata/guisettings.xml` | Recent search entries removed from XML (file is preserved) |

Cleans the following base areas:

| Area / Bereich | Path / Pfad | What is deleted / Was wird gelöscht |
|---|---|---|
| Temp directory / Temp-Verzeichnis | `special://temp/` | All files and subdirectories (except kodi.log, kodi.old.log, xbmc.log, xbmc.old.log) |
| Addon caches / Addon-Caches | `special://userdata/addon_data/<addon>/cache/` | Entire `cache/` subdirectory per addon |
| Addon temps / Addon-Temps | `special://userdata/addon_data/<addon>/temp/` | Entire `temp/` subdirectory per addon |
| Shared addons temp / Geteilter Addons-Temp | `special://home/addons/temp/` | Entire directory |

**Excluded addons:** script.xscleaner, script.module.requests, script.module.urllib3, script.module.chardet, script.module.idna, script.module.certifi

##
Gesteuert durch die Einstellungen: `Cache bereinigen` (Hauptschalter) mit Sub-Optionen, und `Temp bereinigen` (Temp-Verzeichnis). Es werden nur aktivierte Bereiche gereinigt.

**Neu in v1.3.0 — Cache Sub-Optionen:** Wenn `Cache bereinigen` aktiviert ist, können diese zusätzlichen Bereiche einzeln geschaltet werden:

| Sub-Option | Pfad | Was wird gelöscht |
|---|---|---|
| **HTTP-/Bild-Cache bereinigen** | `special://userdata/cache/`, `special://userdata/Thumbnails/cache/` | Kodis interner HTTP-Response-Cache und Thumbnail-Cache-Verzeichnis |
| **Wetter-Addon-Caches bereinigen** | `special://userdata/addon_data/weather.*/cache/`, `special://userdata/addon_data/weather.*/temp/` | Gecachte Wetterdaten aller weather.*-Addons |
| **Downloads bereinigen** | `special://userdata/Downloads/` | Abgeschlossene/abgebrochene Kodi-Download-Manager-Dateien |
| **Suchverlauf bereinigen** | `special://userdata/guisettings.xml` | Suchverlaufseinträge aus der XML entfernt (Datei bleibt erhalten) |

Bereinigt folgende Basisbereiche:

| Bereich | Pfad | Was wird gelöscht |
|---|---|---|
| Temp-Verzeichnis | `special://temp/` | Alle Dateien und Unterverzeichnisse (außer kodi.log, kodi.old.log, xbmc.log, xbmc.old.log) |
| Addon-Caches | `special://userdata/addon_data/<addon>/cache/` | Gesamtes `cache/` Unterverzeichnis pro Addon |
| Addon-Temps | `special://userdata/addon_data/<addon>/temp/` | Gesamtes `temp/` Unterverzeichnis pro Addon |
| Geteilter Addons-Temp | `special://home/addons/temp/` | Gesamtes Verzeichnis |

**Ausgeschlossene Addons:** script.xscleaner, script.module.requests, script.module.urllib3, script.module.chardet, script.module.idna, script.module.certifi

---

### Thumbnail Cleanup / Thumbnail-Bereinigung

Controlled by settings: `Clean Unused Thumbnails` and `Clean Old Thumbnails`. Only enabled modes are shown in the sub-dialog. The Thumbnail Age setting controls how many days for old thumbnails.

Four cleaning modes are available:

##
Gesteuert durch die Einstellungen: `Ungenutzte Thumbnails bereinigen` und `Alte Thumbnails bereinigen`. Nur aktivierte Modi werden im Unter-Dialog angezeigt. Die Thumbnail-Alter-Einstellung bestimmt die Anzahl Tage für alte Thumbnails.

Vier Bereinigungsmodi sind verfügbar:

| Mode / Modus | Description / Beschreibung |
|---|---|
| **Unused Thumbnails / Ungenutzte Thumbnails** | Compares thumbnails in `special://userdata/Thumbnails/` against `special://database/Textures13.db`. Deletes files whose texture ID is not referenced in the database. Vergleicht Thumbnails in `special://userdata/Thumbnails/` mit `special://database/Textures13.db`. Löscht Dateien deren Texture-ID nicht in der Datenbank referenziert wird. |
| **Old Thumbnails / Alte Thumbnails** | Deletes thumbnails older than X days (configurable: 1-365 days, default 30). Also removes the corresponding database entry. Löscht Thumbnails älter als X Tage (einstellbar: 1-365 Tage, Standard 30). Entfernt auch den entsprechenden Datenbank-Eintrag. |
| **Orphan Artwork / Waisen-Grafiken** | Cross-references the `url` column in `Textures13.db` against actual source files on disk. Deletes thumbnails whose original source file no longer exists. Remote URLs (`image://`, `http(s)://`) and `special://` paths are always preserved. Kreuzreferenziert die `url`-Spalte in `Textures13.db` mit den tatsächlichen Quelldateien auf der Festplatte. Löscht Thumbnails deren Quelldatei nicht mehr existiert. Remote-URLs (`image://`, `http(s)://`) und `special://`-Pfade bleiben immer erhalten. |
| **All Thumbnails / Alle Thumbnails** | Deletes ALL files in `special://userdata/Thumbnails/` and deletes `Textures13.db` entirely. Kodi rebuilds everything on next start. Löscht ALLE Dateien in `special://userdata/Thumbnails/` und löscht `Textures13.db` komplett. Kodi baut alles beim nächsten Start neu auf. |

---

### Addon Leftovers Cleanup / Addon-Überreste-Bereinigung

Controlled by setting: `Clean Addon Leftovers`. Disabled in settings hides the menu item and prevents execution.

Two-phase cleanup:

##
Gesteuert durch die Einstellung: `Addon-Überreste bereinigen`. Deaktiviert blendet den Menüpunkt aus und verhindert die Ausführung.

Zweiphasen-Bereinigung:

1. **Orphan addon data / Verwaiste Addon-Daten:** Compares directories in `special://userdata/addon_data/` against installed addons in `special://home/addons/` **and** `special://xbmc/addons/` (system addons). Prevents deletion of `peripheral.*`, `skin.*`, `game.controller.*` etc.
Vergleicht Verzeichnisse in `special://userdata/addon_data/` mit installierten Addons in `special://home/addons/` **und** `special://xbmc/addons/` (System-Addons). Verhindert Löschung von `peripheral.*`, `skin.*`, `game.controller.*` etc.

2. **Invalid addons / Ungültige Addons:** Scans `special://home/addons/` for addon directories missing an `addon.xml` file. Deletes them as broken/invalid.
Scant `special://home/addons/` nach Addon-Verzeichnissen ohne `addon.xml` Datei. Löscht diese als defekt/ungültig.

**Excluded / Ausgeschlossen:** script.xscleaner, script.module.* addons

---

### Package Cleanup / Paket-Bereinigung

Controlled by setting: `Clean Packages`. Disabled in settings hides the menu item and prevents execution.

Deletes the entire contents of `special://home/addons/packages/`. These are downloaded addon installation files that are no longer needed after installation.

When **Clean Unused Languages / Unbenutzte Sprachen bereinigen** is additionally enabled, all `resources/language/resource.language.*` directories except `en_gb` and `de_de` are removed from every addon in `special://home/addons/`. Frees space by keeping only the two supported languages. This option depends on `Clean Packages` and is shown directly beneath it in the settings.

##

Löscht den gesamten Inhalt von `special://home/addons/packages/`. Dieses sind heruntergeladene Addon-Installationsdateien die nach der Installation nicht mehr benötigt werden.

Wenn zusätzlich **Unbenutzte Sprachen bereinigen** aktiviert ist, werden alle `resources/language/resource.language.*` Verzeichnisse außer `en_gb` und `de_de` aus jedem Addon in `special://home/addons/` entfernt. Spart Speicher durch Behalten nur der zwei unterstützten Sprachen. Diese Option hängt von `Pakete bereinigen` ab und steht in den Einstellungen direkt darunter.

---

### Crash Log Cleanup / Absturzprotokoll-Bereinigung

Controlled by setting: `Clean Crash Logs`. Disabled in settings hides the menu item and prevents execution.

Cleans crash-related files from two locations:

##
Gesteuert durch die Einstellung: `Crash-Logs bereinigen`. Deaktiviert blendet den Menüpunkt aus und verhindert die Ausführung.

Bereinigt absturzbezogene Dateien an zwei Orten:

| Location / Ort | Files deleted / Gelöschte Dateien |
|---|---|
| `special://userdata/crashlogs/` | All `.dmp` and `.crash` files, all subdirectories |
| `special://userdata/` (root) | Any `.dmp` and `.crash` files in the userdata root |

---

### Database Optimization / Datenbankoptimierung

Controlled by settings: `DB Backup Before Optimize`, `Run VACUUM`, `Integrity Check`, `Cleanup Orphaned DB Entries`, `Clean TMDBHelper caches`, `Clean Celebrity/Artist Data`, `Rebuild Textures13.db`. Each sub-operation is individually enabled/disabled. The sub-dialog is built dynamically — only options whose settings are enabled appear in the menu.

Finds all Kodi database files in `special://database/` and `special://userdata/addon_data/*/`. Optimization modes:

##
Gesteuert durch die Einstellungen: `DB Backup vor Optimierung`, `VACUUM ausführen`, `Integritätsprüfung ausführen`, `Verwaiste DB-Einträge bereinigen`, `TMDBHelper-Caches bereinigen`, `Celebrity/Artist-Daten bereinigen`, `Textures13.db neu aufbauen`. Jede Unter-Operation ist einzeln aktivierbar/deaktivierbar. Der Unter-Dialog wird dynamisch aufgebaut – nur Optionen deren Einstellungen aktiviert sind werden angezeigt.

Findet alle Kodi-Datenbankdateien in `special://database/` und `special://userdata/addon_data/*/`. Optimierungsmodi:

| Mode / Modus | Description / Beschreibung |
|---|---|
| **VACUUM + Check** | Creates a full database backup via Backup & Restore system, then runs `VACUUM` (reclaims unused space) and `PRAGMA quick_check` (verifies integrity). Erstellt ein vollständiges Backup über das Backup- & Wiederherstellungssystem, führt dann `VACUUM` durch (reklamiert ungenutzten Platz) und `PRAGMA quick_check` (verifiziert Integrität). |
| **VACUUM only / Nur VACUUM** | Creates a full database backup, then runs `VACUUM` only. Erstellt ein vollständiges Datenbank-Backup und führt dann nur `VACUUM` durch. |
| **Integrity Check / Integritätsprüfung** | Runs `PRAGMA quick_check` on each database. Führt `PRAGMA quick_check` für jede Datenbank durch. |
| **Orphan Cleanup / Waisen-Bereinigung** | Removes duplicate/orphaned rows from video (`MyVideos*.db`) and music (`MyMusic*.db`) databases. Entfernt doppelte/verwaiste Zeilen aus Video- (`MyVideos*.db`)- und Musik- (`MyMusic*.db`)-Datenbanken. |
| **TMDBHelper Cache Cleanup** | Deletes `itemdetails.db` and `itemdetails.db-wal` files in `special://userdata/addon_data/themoviedb.helper/` and subdirectories. These are cached metadata databases from TMDBHelper that are safely regenerated. Löscht `itemdetails.db` und `itemdetails.db-wal` Dateien in `special://userdata/addon_data/themoviedb.helper/` und Unterordnern. Dabei handelt es sich um gecachte Metadaten-Datenbanken von TMDBHelper die sicher neu generiert werden. |
| **Celebrity/Artist Cache** | Clears celebrity, actor links and artist tables from `MyVideos*.db`. These are safely regenerated by Kodi. Leert Celebrity-, Schauspielerlink- und Artist-Tabellen aus `MyVideos*.db`. Werden von Kodi sicher neu generiert. |
| **Rebuild Textures13.db** | Creates a full database backup, then deletes `Textures13.db` to force Kodi to rebuild the texture database from scratch on next start. Erstellt ein vollständiges Datenbank-Backup und löscht dann `Textures13.db`, um Kodi zum kompletten Neubau der Texturdatenbank beim nächsten Start zu zwingen. |

**Backups** are now created using the Backup & Restore system. When enabled (`DB Backup Before Optimize`), a full database backup is saved to the configured **backup path** as `xscleaner_databases_<timestamp>/userdata/Database/`. This backup is fully restorable via **Backup & Restore → Restore**. The addon aborts optimization if no backup path is set — a backup is mandatory for all modifying operations.

**Backups** werden jetzt über das Backup- & Wiederherstellungssystem erstellt. Wenn aktiviert (`DB Backup vor Optimierung`), wird ein vollständiges Datenbank-Backup unter dem konfigurierten **Backup-Pfad** als `xscleaner_databases_<timestamp>/userdata/Database/` gespeichert. Dieses Backup ist vollständig über **Backup/Wiederherstellen → Wiederherstellen** restaurierbar. Das Addon bricht die Optimierung ab, wenn kein Backup-Pfad gesetzt ist — ein Backup ist für alle schreibenden Operationen zwingend erforderlich.

---

### Broken Sources Checker / Defekte Quellen Prüfer

Reads `special://userdata/sources.xml` and checks if each configured source path actually exists on disk. **Remote URLs (http://, https://, smb://, nfs://, ftp://)** are automatically recognised and skipped — only local filesystem paths are validated. Displays a list of broken/missing sources and offers to remove them from the XML file.

##
Liest `special://userdata/sources.xml` und prüft ob jeder konfigurierte Quellenpfad tatsächlich auf der Festplatte existiert. **Remote-URLs (http://, https://, smb://, nfs://, ftp://)** werden automatisch erkannt und übersprungen — nur lokale Dateisystempfade werden validiert. Zeigt eine Liste defekter/fehlender Quellen an und bietet an diese aus der XML-Datei zu entfernen.

---

### Favorites Manager / Favorites-Manager

Reads `special://userdata/favorites.xml`, parses all `<favourite>` entries, and checks whether their target paths still exist. Remote URLs and Kodi built-in commands (`ActivateWindow(...)`, `RunAddon(...)`) are evaluated — broken entries (pointing to deleted files, missing addons, or invalid paths) are listed and can be removed with one click.

##
Liest `special://userdata/favorites.xml`, parst alle `<favourite>`-Einträge und prüft ob deren Zielpfade noch existieren. Remote-URLs und Kodi-interne Befehle (`ActivateWindow(...)`, `RunAddon(...)`) werden ausgewertet — defekte Einträge (zeigen auf gelöschte Dateien, fehlende Addons oder ungültige Pfade) werden aufgelistet und können mit einem Klick entfernt werden.

---

### Advanced Settings Editor / Advanced Settings Editor

Creates, edits, or removes `special://userdata/advancedsettings.xml`. Version-aware: detects Kodi version and shows cache settings only for Kodi 19-20 (cache/buffer moved to GUI in Kodi 21+). Single-page menu with current values, help texts, and edit dialogs. RAM-based cache recommendations.

##
Erstellt, bearbeitet oder entfernt `special://userdata/advancedsettings.xml`. Versionssensitiv: Erkennt Kodi-Version und zeigt Cache-Einstellungen nur für Kodi 19-20 (Cache/Buffer sind ab Kodi 21+ in der GUI). Einseitiges Menü mit aktuellen Werten, Hilfetexten und Bearbeitungsdialogen. RAM-basierte Cache-Empfehlungen.

**Version-aware cache settings:**
- Kodi 19-20: Full cache/buffer editor with RAM-based recommendations
- Kodi 21+: Info notice — cache settings now in Settings > Services > Caching

**Available settings:**

#### Cache & Buffer (Kodi 19-20) / Cache & Buffer (Kodi 19-20)

For smoother video playback by buffering streamed content in RAM. Only shown on Kodi 19-20; from Kodi 21+ these values are configured under **Settings > Services > Caching**.

| Setting / Einstellung | Default / Standard | Description / Beschreibung |
|---|---|---|
| **buffermode** (Buffer Mode / Buffer-Modus) | On (All) / Ein (Alle) | Controls for which sources the cache is active: **Off** (no caching), **On (Filesystem)** (only local/file sources), **On (Internet)** (only remote sources), **On (All)** (everything). Steuert für welche Quellen der Cache aktiv ist: **Aus** (kein Caching), **Ein (Dateisystem)** (nur lokale/Datei-Quellen), **Ein (Internet)** (nur Remote-Quellen), **Ein (Alle)** (alles). |
| **memorysize** (Memory Size / Speichergröße) | RAM-dependent / RAM-abhängig | Size in bytes of the in-memory buffer used for stream caching. **0** = use disk instead of RAM. The recommended value is derived from detected system RAM. Größe des Speicher-Puffers für Stream-Caching in Bytes. **0** = Festplatte statt RAM verwenden. Der empfohlene Wert wird aus dem erkannten System-RAM abgeleitet. |
| **readfactor** (Read Factor / Read-Faktor) | 4 | Maximum read-rate multiplier. Values above 1 read the file faster than real time, reducing stutter on slow connections. Maximaler Leserate-Multiplikator. Werte über 1 lesen die Datei schneller als in Echtzeit und reduzieren Ruckeln bei langsamen Verbindungen. |

In the cache dialog you can **Apply recommended** values (based on detected RAM) or **Edit values** manually.
Im Cache-Dialog kannst du die **empfohlenen Werte übernehmen** (basierend auf dem erkannten RAM) oder die Werte **manuell bearbeiten**.

#### Network / Netzwerk

Configure connection timeouts and options for HTTP/FTP/NFS access.

| Setting / Einstellung | Default / Standard | Description / Beschreibung |
|---|---|---|
| **curlclienttimeout** | 10 s | Timeout for HTTP/FTP connections in seconds before an operation is aborted. Timeout für HTTP/FTP-Verbindungen in Sekunden, bevor ein Vorgang abgebrochen wird. |
| **curllowspeedtime** | 20 s | Seconds before a slow connection is considered stalled and aborted. Sekunden, bis eine langsame Verbindung als festgefahren gilt und abgebrochen wird. |
| **curlretries** | 2 | Number of retries for failed HTTP/FTP operations. Anzahl der Wiederholungen bei fehlgeschlagenen HTTP/FTP-Operationen. |
| **disableipv6** | Off / Aus | Disables IPv6. Enable if you experience IPv6 network issues. Deaktiviert IPv6. Bei IPv6-Netzwerkproblemen aktivieren. |
| **disablehttp2** | Off / Aus | Disables HTTP/2. Enable if you experience issues with HTTP/2 servers. Deaktiviert HTTP/2. Bei HTTP/2-Serverproblemen aktivieren. |
| **nfstimeout** | 30 s | Timeout for NFS access in seconds. Timeout für NFS-Zugriffe in Sekunden. |
| **nfsretries** | 0 | Number of NFS retries. **0** = disabled. Anzahl der NFS-Wiederholungen. **0** = deaktiviert. |

#### Video / Video

Fine-tune playback behavior and resume (watched) tracking.

| Setting / Einstellung | Default / Standard | Description / Beschreibung |
|---|---|---|
| **skiploopfilter** | 0 | H.264 loop filter skip. Lower values = less CPU usage but worse quality, higher values = better quality but more CPU. H.264 Loop-Filter-Skip. Niedrigere Werte = weniger CPU, aber schlechtere Qualität; höhere Werte = bessere Qualität, aber mehr CPU. |
| **playcountminimumpercent** | 90 % | Minimum percentage of a video that must be played before it is marked as watched. **101** = never mark as watched. Mindestprozent der Wiedergabe eines Videos, bis es als gesehen markiert wird. **101** = nie als gesehen markieren. |
| **ignoresecondsatstart** | 180 s | Seconds at the start of a video that are ignored for the resume point (skips past intro/credits). Sekunden am Videoanfang, die für den Fortsetzen-Punkt ignoriert werden (überspringt Intro/Vorspann). |
| **ignorepercentatend** | 8 % | Percentage at the end of a video that is ignored for the resume point (video is considered finished near the end). Prozentsatz am Videoende, der für den Fortsetzen-Punkt ignoriert wird (Video gilt nahe dem Ende als beendet). |
| **maxtempo** | 1.6 | Maximum playback speed multiplier (range 1.6-2.0) allowed for audio-pitch-corrected fast playback. Maximale Wiedergabegeschwindigkeit (Bereich 1.6-2.0) für tonhöhenkorrigierte Schnellwiedergabe. |

#### Samba / Samba

| Setting / Einstellung | Default / Standard | Description / Beschreibung |
|---|---|---|
| **clienttimeout** | 30 s | Timeout for Samba/SMB network share access in seconds. Timeout für den Zugriff auf Samba/SMB-Netzwerkfreigaben in Sekunden. |

**Operations / Aktionen:** View current advancedsettings.xml (`View advancedsettings.xml` / `Aktuelle advancedsettings.xml anzeigen`), Reset to default (`Reset to default` / `Auf Standard zurücksetzen`), Delete (`Delete advancedsettings.xml` / `advancedsettings.xml löschen`).

---

### Backup & Restore / Sicherung & Wiederherstellung

Creates timestamped backups of Kodi data to a user-configured path.

##
Erstellt zeitgestempelte Sicherungen von Kodi-Daten an einem benutzerkonfigurierten Pfad.

**Backup types / Backup-Typen:**

| Type / Typ | Contents / Inhalt |
|---|---|
| **Full / Vollständig** | Addons, Addon Data, Databases, sources.xml, advancedsettings.xml, guisettings.xml, profiles.xml, keymaps, playlists |
| **Addons** | `special://home/addons` |
| **Addon Data / Addon-Daten** | `special://userdata/addon_data` |
| **Addons + Data / Addons + Daten** | `special://home/addons`, `special://userdata/addon_data` |
| **Databases / Datenbanken** | `special://database/` |
| **Settings / Einstellungen** | sources.xml, advancedsettings.xml, guisettings.xml |
| **Profiles / Profile** | profiles.xml |
| **Keymaps** | `special://userdata/keymaps/` |
| **Playlists** | `special://userdata/playlists/` |

**Restore** copies selected backup contents back to the original Kodi locations. Existing files and directories are overwritten.

**Wiederherstellung** kopiert den ausgewählten Backup-Inhalt zurück an die ursprünglichen Kodi-Orte. Vorhandene Dateien und Verzeichnisse werden überschrieben.

---

### Kodi Factory Reset / Kodi auf Werkseinstellungen zurücksetzen

Controlled by setting: `Enable Kodi factory reset` (disabled by default). Only when enabled does the menu item appear.

##

Gesteuert durch die Einstellung: `Kodi-Werkseinstellung aktivieren` (standardmäßig deaktiviert). Nur wenn aktiviert erscheint der Menüpunkt.

**WARNING: This will reset Kodi completely, except XSCleaner and its dependencies!**

**WARNUNG: Kodi wird komplett zurückgesetzt, mit Ausnahme von XSCleaner und dessen Abhängigkeiten!**

Walks the entire `special://home/` directory and deletes all files and directories, except:
- script.xscleaner and script.module.* addons (preserved for re-installation)
- kodi.log and kodi.old.log

After cleanup, reloads the Kodi master profile.

##
Durchsucht das gesamte `special://home/` Verzeichnis und löscht alle Dateien und Verzeichnisse, außer:
- script.xscleaner und script.module.* Addons (bleiben für Neuinstallation erhalten)
- kodi.log und kodi.old.log

Nach der Bereinigung wird das Kodi-Masterprofil neu geladen.

---

### Startup Manager / Startup Manager

Lists all installed service addons (those with `<extension point="xbmc.service">` in their addon.xml). Shows enabled/disabled status and lets you toggle each one.

##
Listet alle installierten Service-Addons auf (solche mit `<extension point="xbmc.service">` in ihrer addon.xml). Zeigt Aktiviert/Deaktiviert-Status an und ermöglicht das Umschalten.

---

### Log File Viewer / Logdatei-Betrachter

Lists all `.log` files in `special://logpath/` and displays the selected file in a text viewer (read-only).

##
Listet alle `.log` Dateien in `special://logpath/` auf und zeigt die ausgewählte Datei in einem Textbetrachter an (schreibgeschützt).

---

### Activity Log / Aktivitätsprotokoll

Every cleaning, backup, or system action is recorded in a local SQLite database (`activitylog.db`). Each entry shows timestamp, action name, summary, items cleaned, and space freed. Selecting an entry reveals the individual file paths and sizes that were affected.

##
Jede Bereinigungs-, Backup- oder Systemaktion wird in einer lokalen SQLite-Datenbank (`activitylog.db`) aufgezeichnet. Jeder Eintrag zeigt Zeitstempel, Aktionsname, Zusammenfassung, bereinigte Elemente und freigegebenen Speicherplatz. Die Auswahl eines Eintrags zeigt die betroffenen einzelnen Dateipfade und Größen.

---

### Settings / Einstellungen

Access via the main menu. Configurable options:

##
Zugriff über das Hauptmenü. Konfigurierbare Optionen:

| Setting / Einstellung | Description / Beschreibung | Default / Standard |
|---|---|---|---|
| Clean Cache / Cache bereinigen | Master toggle for cache cleaning | On / An |
| Clean HTTP/Image cache | Clean Kodi HTTP response and image cache (requires Clean Cache) | On / An |
| Clean Weather addon caches | Clean cached weather data (requires Clean Cache) | On / An |
| Clean Downloads | Clean Kodi download manager files (requires Clean Cache) | On / An |
| Clean Search History | Clear recent searches from guisettings.xml (requires Clean Cache) | On / An |
| Clean Temp / Temp bereinigen | Enable temp cleaning | On / An |
| Clean Unused Thumbnails | Enable unused thumbnail removal | On / An |
| Clean Old Thumbnails / Alte Thumbnails | Enable old thumbnail removal | On / An |
| Thumbnail Age / Thumbnail-Alter | Max age in days for old thumbnails | 30 |
| Clean Packages / Pakete bereinigen | Enable package cleanup | On / An |
| Clean Unused Languages | Remove non-English/German language files (part of Package Cleanup) | Off / Aus |
| Enable Kodi factory reset | Show the "Reset Kodi to factory defaults" menu item | Off / Aus |
| Clean Crash Logs | Enable crash log cleanup | On / An |
| Clean Addon Leftovers | Enable addon leftover removal | On / An |
| DB Backup Before Optimize | Backup databases before VACUUM | On / An |
| Run VACUUM | Run VACUUM during DB optimize | On / An |
| Integrity Check / Integritätsprüfung | Run quick_check during DB optimize | On / An |
| Cleanup Orphaned DB Entries | Remove orphaned DB rows | Off / Aus |
| Clean TMDBHelper Caches / TMDBHelper-Caches | Delete TMDBHelper cache databases (itemdetails.db, .db-wal) | On / An |
| Clean Celebrity/Artist Data | Clear celebrity/actor/artist tables from MyVideos*.db | Off / Aus |
| Rebuild Textures13.db | Backup and delete Textures13.db to force full rebuild | Off / Aus |
| Backup Path / Pfad | Directory for backups | Empty / Leer |
| Auto Cleanup at Startup | Enable automatic cleanup on Kodi start | Off / Aus |
| Startup Delay / Startverzögerung | Seconds to wait before auto cleanup | 30 |
| Cleanup Interval / Bereinigungsintervall | Min days between auto cleanups (0=every start) | 0 |
| Auto Update Check | Check for addon updates automatically | On / An |
| Update Interval / Update-Intervall | Hours between update checks | 24 |

---

## Auto Cleanup Service / Automatischer Bereinigungsservice

When enabled in settings, XSCleaner runs a background service at Kodi startup that automatically cleans enabled cleanup categories (cache with all sub-options, thumbnails, packages, crash logs, addon leftovers, unused languages) after a configurable delay (default 30 seconds). Each category can be individually enabled/disabled in settings.

The service also respects the **Cleanup Interval** setting: when set to 0 (default), cleanup runs on every Kodi start. When set to 1-30 days, the service skips execution if the last run was more recent than the configured interval, preventing unnecessary cleanup on frequent restarts. The last run timestamp is stored in `addon_data/script.xscleaner/last_auto_cleanup.txt`.

##
Wenn in den Einstellungen aktiviert, führt XSCleaner einen Hintergrunddienst beim Kodi-Start aus der automatisch alle aktivierten Bereinigungskategorien (Cache mit allen Sub-Optionen, Thumbnails, Pakete, Crash-Logs, Addon-Überreste, unbenutzte Sprachen) nach einer konfigurierbaren Verzögerung (Standard 30 Sekunden) bereinigt. Jede Kategorie kann einzeln in den Einstellungen aktiviert/deaktiviert werden.

Der Dienst respektiert auch die **Bereinigungsintervall**-Einstellung: bei 0 (Standard) wird bei jedem Kodi-Start gereinigt. Bei 1-30 Tagen überspringt der Dienst die Ausführung wenn der letzte Lauf kürzer zurückliegt als das eingestellte Intervall, um unnötige Bereinigungen bei häufigen Neustarts zu vermeiden. Der Zeitstempel des letzten Laufs wird in `addon_data/script.xscleaner/last_auto_cleanup.txt` gespeichert.

---

## License / Lizenz

This project is licensed under the GNU General Public License v3.0. See [LICENSE](LICENSE) for details.

##
Dieses Projekt steht unter der GNU General Public License v3.0. Siehe [LICENSE](LICENSE) für Details.
