import os
import xbmcgui
from .constants import (
    HOME, HOME_ADDONS, ADDON_DATA, THUMBNAILS,
    PACKAGES_PATH, TEMP, DATABASE,
    ADDON_VERSION, TEMP_PRESERVED
)
from .utils import (
    human_size, get_dir_size, get_localized_string
)

_STORAGE_ITEMS = [
    (32230, HOME),
    (32231, HOME_ADDONS),
    (32232, ADDON_DATA),
    (32233, THUMBNAILS),
    (32234, PACKAGES_PATH),
    (32235, TEMP),
    (32236, DATABASE),
]

_TIP_ITEMS = [
    (32233, 500 * 1024 * 1024, 32541),
    (32234, 200 * 1024 * 1024, 32542),
    (32237, 200 * 1024 * 1024, 32543),
    (32236, 500 * 1024 * 1024, 32544),
    (32235, 100 * 1024 * 1024, 32545),
]

def show_system_info():
    storage = _get_storage_info()
    total = storage[0][1]

    lines = []
    for sid, size in storage:
        lines.append(f'{get_localized_string(sid)}: {human_size(size)}')
    lines.append('')
    lines.append(f'{get_localized_string(32238)}: {human_size(total)}')

    lines.append('')
    lines.append(f'XSCleaner v{ADDON_VERSION}')

    import sys
    lines.append(f'Python {sys.version.split()[0]}')

    try:
        import xbmc
        kodi_ver = xbmc.getInfoLabel('System.BuildVersion')
        lines.append(f'Kodi {kodi_ver}')
    except Exception:
        pass

    tips = _get_performance_tips(storage)
    if tips:
        lines.append('')
        lines.append(f'[COLOR yellow]--- {get_localized_string(32540)} ---[/COLOR]')
        for tip in tips:
            lines.append(f'[COLOR gray]* {tip}[/COLOR]')

    content = '\n'.join(lines)
    xbmcgui.Dialog().textviewer(get_localized_string(32420), content)


def get_storage_info():
    return [(get_localized_string(sid), size) for sid, size in _get_storage_info()]


def _under(base, root):
    try:
        return os.path.commonpath([base, root]) == root
    except (ValueError, OSError):
        return False


def _get_storage_info():
    from .cache import cache_dirs, get_temp_size

    cache_roots, temp_roots = cache_dirs()
    bucket_roots = [p for _sid, p in _STORAGE_ITEMS if p and p != HOME and _under(p, HOME)]

    sizes = {}
    cache_total = 0
    if HOME:
        for root, dirs, files in os.walk(HOME):
            for f in files:
                if root in temp_roots and f in TEMP_PRESERVED:
                    continue
                fp = os.path.join(root, f)
                try:
                    size = os.path.getsize(fp)
                except OSError:
                    continue
                sizes[HOME] = sizes.get(HOME, 0) + size
                for p in bucket_roots:
                    if _under(fp, p):
                        sizes[p] = sizes.get(p, 0) + size
                if any(_under(fp, cr) for cr in cache_roots):
                    cache_total += size

    result = []
    for sid, path in _STORAGE_ITEMS:
        if not path:
            size = 0
        elif _under(path, HOME):
            size = sizes.get(path, 0)
        elif path == TEMP:
            size = get_temp_size()
        else:
            size = get_dir_size(path)
        result.append((sid, size))

    for cr in cache_roots:
        if not _under(cr, HOME):
            cache_total += get_temp_size() if cr in temp_roots else get_dir_size(cr)
    result.append((32237, cache_total))
    return result


def _get_performance_tips(storage):
    storage_dict = dict(storage)
    tips = []

    for sid, threshold, msg_id in _TIP_ITEMS:
        if storage_dict.get(sid, 0) > threshold:
            tips.append(get_localized_string(msg_id))

    try:
        import xbmc
        raw = xbmc.getInfoLabel('System.Memory(total)')
        if raw:
            raw = raw.strip().lower().replace('mb', '').replace(' ', '')
            ram_mb = int(float(raw))
            if ram_mb < 2048:
                tips.append(get_localized_string(32546))
    except Exception:
        pass

    return tips
