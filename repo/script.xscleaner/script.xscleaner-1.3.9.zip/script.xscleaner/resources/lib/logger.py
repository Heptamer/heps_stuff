import os
import sqlite3
import time
import xbmc
from datetime import datetime
from .constants import ADDON_DATA, ADDON_ID
from .utils import log, human_size

LOG_DB_PATH = os.path.join(ADDON_DATA, ADDON_ID, 'activitylog.db') if ADDON_DATA else None
_db_ready = False


def _log_error(message):
    log(message, level=xbmc.LOGERROR)


def _log_info(message):
    log(message)


def _ensure_db():
    global _db_ready
    if _db_ready:
        return True
    if not LOG_DB_PATH:
        _log_error('Activity log DB disabled (userdata path not resolved)')
        return False
    if 'special://' in LOG_DB_PATH:
        _log_error(f'Activity log DB disabled (unresolved special path): {LOG_DB_PATH}')
        return False
    try:
        db_dir = os.path.dirname(LOG_DB_PATH)
        os.makedirs(db_dir, exist_ok=True)
        conn = sqlite3.connect(LOG_DB_PATH)
        _migrate_schema(conn)
        conn.execute('''
            CREATE TABLE IF NOT EXISTS activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL,
                action TEXT,
                summary TEXT,
                items_cleaned INTEGER DEFAULT 0,
                space_freed INTEGER DEFAULT 0
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS activity_details (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                log_id INTEGER,
                path TEXT,
                size INTEGER DEFAULT 0,
                FOREIGN KEY (log_id) REFERENCES activity_log(id)
            )
        ''')
        conn.commit()
        conn.close()
        _db_ready = True
        _log_info(f'Activity log DB ready: {LOG_DB_PATH}')
        return True
    except Exception as e:
        _log_error(f'_ensure_db failed: {e} (path={LOG_DB_PATH})')
        return False


def _migrate_schema(conn):
    try:
        cursor = conn.execute("PRAGMA table_info(activity_log)")
        columns = {row[1] for row in cursor.fetchall()}
        if columns and 'summary' not in columns:
            _log_info('Migrating activity_log table: adding summary column')
            conn.execute('ALTER TABLE activity_log ADD COLUMN summary TEXT DEFAULT ""')
            conn.commit()
    except Exception:
        pass


def log_action(action, summary='', items_cleaned=0, space_freed=0, detail_paths=None):
    if not _ensure_db():
        _log_error(f'log_action skipped (DB not ready): {action}')
        return
    try:
        conn = sqlite3.connect(LOG_DB_PATH)
        cursor = conn.execute(
            'INSERT INTO activity_log (timestamp, action, summary, items_cleaned, space_freed) VALUES (?, ?, ?, ?, ?)',
            (time.time(), action, summary, items_cleaned, space_freed)
        )
        log_id = cursor.lastrowid

        if detail_paths:
            for path, size in detail_paths:
                conn.execute(
                    'INSERT INTO activity_details (log_id, path, size) VALUES (?, ?, ?)',
                    (log_id, path, size)
                )

        _prune_details(conn)
        conn.commit()
        conn.close()
        detail_count = len(detail_paths) if detail_paths else 0
        _log_info(f'Logged: {action} (id={log_id}, details={detail_count})')
    except Exception as e:
        _log_error(f'log_action failed: {e} (action={action})')


def _prune_details(conn):
    try:
        conn.execute('''
            DELETE FROM activity_details WHERE log_id NOT IN (
                SELECT id FROM activity_log ORDER BY timestamp DESC LIMIT 200
            )
        ''')
    except Exception:
        pass


def get_log_entries(limit=100):
    if not _ensure_db():
        return []
    try:
        conn = sqlite3.connect(LOG_DB_PATH)
        cursor = conn.execute(
            'SELECT id, timestamp, action, summary, items_cleaned, space_freed FROM activity_log ORDER BY timestamp DESC LIMIT ?',
            (limit,)
        )
        entries = cursor.fetchall()
        conn.close()
        _log_info(f'get_log_entries: {len(entries)} entries')
        return entries
    except Exception as e:
        _log_error(f'get_log_entries failed: {e}')
        return []


def get_log_details(log_id):
    if not _ensure_db():
        return []
    try:
        conn = sqlite3.connect(LOG_DB_PATH)
        cursor = conn.execute(
            'SELECT path, size FROM activity_details WHERE log_id = ? ORDER BY id',
            (log_id,)
        )
        items = cursor.fetchall()
        conn.close()
        return items
    except Exception as e:
        _log_error(f'get_log_details failed: {e}')
        return []


def clear_log():
    if not _ensure_db():
        return False
    try:
        conn = sqlite3.connect(LOG_DB_PATH)
        conn.execute('DELETE FROM activity_details')
        conn.execute('DELETE FROM activity_log')
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        _log_error(f'clear_log failed: {e}')
        return False


def format_entry_short(entry):
    log_id, ts, action, summary, items, freed = entry
    dt = datetime.fromtimestamp(ts).strftime('%d.%m.%Y %H:%M')
    parts = [f'[{dt}] {action}']
    if summary:
        parts.append(f'  {summary}')
    if items > 0 or freed > 0:
        info = []
        if items > 0:
            info.append(f'{items}')
        if freed > 0:
            info.append(human_size(freed))
        parts.append(f'  ({", ".join(info)})')
    return '\n'.join(parts)


def format_entry_details(entry, details):
    log_id, ts, action, summary, items, freed = entry
    dt = datetime.fromtimestamp(ts).strftime('%d.%m.%Y %H:%M')

    lines = [
        f'=== {action} ===',
        f'{dt}',
        ''
    ]

    if summary:
        lines.append(f'{summary}')
        lines.append('')

    if items > 0 or freed > 0:
        info = []
        if items > 0:
            info.append(f'{items} items')
        if freed > 0:
            info.append(human_size(freed))
        lines.append(f'Total: {", ".join(info)}')
        lines.append('')

    if details:
        lines.append('--- Details ---')
        for path, size in details:
            if size > 0:
                lines.append(f'  {path} ({human_size(size)})')
            else:
                lines.append(f'  {path}')
    else:
        lines.append('No detailed paths recorded.')

    return '\n'.join(lines)
