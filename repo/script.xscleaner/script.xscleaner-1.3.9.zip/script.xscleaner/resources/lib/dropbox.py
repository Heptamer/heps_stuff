import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from .constants import ADDON_ID, ADDON_DATA
from .utils import get_setting, log

# OAuth2 / API endpoints
TOKEN_URL = 'https://api.dropboxapi.com/oauth2/token'
API_BASE = 'https://api.dropboxapi.com'
CONTENT_BASE = 'https://content.dropboxapi.com'

# The Dropbox simple upload endpoint accepts files up to 150 MB. Larger
# files go through upload sessions in 4 MB chunks.
SIMPLE_UPLOAD_LIMIT = 140 * 1024 * 1024
CHUNK_SIZE = 4 * 1024 * 1024
DEFAULT_FOLDER = 'xscleaner'

STATE_FILE = os.path.join(ADDON_DATA, ADDON_ID, 'dropbox_state.json')


def is_dropbox_path(path):
    return isinstance(path, str) and path.lower().startswith('dropbox://')


def configured():
    return bool(
        get_setting('dropbox_app_key') and
        get_setting('dropbox_app_secret') and
        get_setting('dropbox_refresh_token')
    )


def _folder():
    folder = (get_setting('dropbox_folder') or '').strip().strip('/')
    return folder or DEFAULT_FOLDER


def _api_path(path):
    """Converts an internal 'dropbox://...' path to the Dropbox API path."""
    p = str(path)
    if is_dropbox_path(p):
        rest = p[len('dropbox://'):].strip('/')
        if not rest:
            return '/' + _folder()
        return '/' + rest
    return p


def join(base, name):
    """Builds an internal dropbox path. The configured folder is injected
    when base is only 'dropbox://'."""
    base = str(base)
    name = str(name).strip('/')
    sub = base[len('dropbox://'):].strip('/') if is_dropbox_path(base) else ''
    if not sub:
        sub = _folder()

    # Verhindert doppeltes Anhängen des Ordnernamens
    if name and name == sub:
        return f'dropbox://{sub}'

    if name:
        return f'dropbox://{sub}/{name}'
    return f'dropbox://{sub}'


def _open(req, timeout):
    try:
        return urllib.request.urlopen(req, timeout=timeout), None
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode('utf-8', 'replace')
        except Exception:
            body = ''
        return None, (e.code, body)
    except Exception as e:
        return None, (0, str(e))


def _load_token_state():
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, 'r') as f:
                state = json.load(f)
            return state.get('access_token', ''), float(state.get('expires_at', 0.0))
    except Exception as e:
        log(f'Dropbox: could not read token state: {e}')
    return '', 0.0


def _save_token_state(token, expires_at):
    try:
        os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
        with open(STATE_FILE, 'w') as f:
            json.dump({'access_token': token, 'expires_at': expires_at}, f)
    except OSError as e:
        log(f'Dropbox: could not save token state: {e}')


def _refresh_access_token():
    key = get_setting('dropbox_app_key')
    secret = get_setting('dropbox_app_secret')
    refresh = get_setting('dropbox_refresh_token')
    if not key or not secret or not refresh:
        log('Dropbox: credentials missing for token refresh')
        return None
    data = urllib.parse.urlencode({
        'refresh_token': refresh,
        'grant_type': 'refresh_token',
        'client_id': key,
        'client_secret': secret,
    }).encode('utf-8')
    req = urllib.request.Request(TOKEN_URL, data=data, method='POST')
    req.add_header('Content-Type', 'application/x-www-form-urlencoded')
    resp, err = _open(req, 15)
    if err is not None:
        log(f'Dropbox: token refresh failed: {err[0]} {err[1][:200]}')
        return None
    try:
        result = json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        log(f'Dropbox: bad token response: {e}')
        return None
    token = result.get('access_token')
    if not token:
        log('Dropbox: no access_token in token response')
        return None
    try:
        expires_in = int(result.get('expires_in', 14400))
    except (TypeError, ValueError):
        expires_in = 14400
    _save_token_state(token, time.time() + expires_in)
    return token


def get_access_token():
    """Returns a valid access token, refreshing the short-lived token from
    the never-expiring refresh token when needed (with a 5 minute margin)."""
    token, expires = _load_token_state()
    if token and expires and expires > time.time() + 300:
        return token
    return _refresh_access_token()


def _rpc(data, endpoint, timeout=30):
    """JSON API call with bearer auth and a single 401 retry after refresh."""
    token = get_access_token()
    if not token:
        return None
    url = API_BASE + endpoint
    body = json.dumps(data).encode('utf-8')

    def _make_req(access_token):
        req = urllib.request.Request(url, data=body, method='POST')
        req.add_header('Authorization', f'Bearer {access_token}')
        req.add_header('Content-Type', 'application/json')
        return req

    resp, err = _open(_make_req(token), timeout)
    if err is not None and err[0] == 401:
        token = _refresh_access_token()
        if token:
            resp, err = _open(_make_req(token), timeout)
    if err is not None:
        log(f'Dropbox: {endpoint} failed: {err[0]} {err[1][:300]}')
        return None
    try:
        return json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        log(f'Dropbox: bad JSON from {endpoint}: {e}')
        return None


def _content_open(endpoint, api_arg, body=None, timeout=120):
    """Opens a content API request for upload/download. Returns
    (response, error). Handles a single 401 retry after token refresh."""
    token = get_access_token()
    if not token:
        return None, (401, 'no access token')
    url = CONTENT_BASE + endpoint
    data = body if body is not None else b''

    def _make_req(access_token):
        req = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Authorization', f'Bearer {access_token}')
        req.add_header('Dropbox-API-Arg', json.dumps(api_arg))
        if body is not None:
            req.add_header('Content-Type', 'application/octet-stream')
        return req

    resp, err = _open(_make_req(token), timeout)
    if err is not None and err[0] == 401:
        token = _refresh_access_token()
        if token:
            resp, err = _open(_make_req(token), timeout)
    return resp, err


def _metadata(path):
    data = json.dumps({'path': _api_path(path)}).encode('utf-8')
    url = API_BASE + '/2/files/get_metadata'
    token = get_access_token()
    if not token:
        return None

    def _make_req(access_token):
        req = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Authorization', f'Bearer {access_token}')
        req.add_header('Content-Type', 'application/json')
        return req

    resp, err = _open(_make_req(token), 15)
    if err is not None and err[0] == 401:
        token = _refresh_access_token()
        if token:
            resp, err = _open(_make_req(token), 15)
    if err is not None:
        if err[0] != 409:
            log(f'Dropbox: get_metadata failed: {err[0]} {err[1][:300]}')
        return None
    try:
        return json.loads(resp.read().decode('utf-8'))
    except Exception:
        return None


def listdir(path):
    folder = _api_path(path)
    entries = []
    cursor = None
    for _ in range(100):
        if cursor:
            result = _rpc({'cursor': cursor}, '/2/files/list_folder/continue')
        else:
            result = _rpc({
                'path': folder,
                'recursive': False,
                'include_deleted': False,
                'include_mounted_folders': True,
                'limit': 1000,
            }, '/2/files/list_folder')
        if result is None:
            return entries
        for entry in result.get('entries', []):
            if entry.get('.tag') == 'file':
                entries.append(entry.get('name', ''))
        if not result.get('has_more'):
            break
        cursor = result.get('cursor')
    return entries


def mkdirs(path):
    folder = _api_path(path)
    if folder == '/':
        return get_access_token() is not None
    if _rpc({'path': folder}, '/2/files/create_folder_v2') is not None:
        return True
    return exists(path)


def exists(path):
    return _metadata(path) is not None


def isfile(path):
    meta = _metadata(path)
    return meta is not None and meta.get('.tag') == 'file'


def getsize(path):
    meta = _metadata(path)
    if meta is None or meta.get('.tag') != 'file':
        return 0
    try:
        return int(meta.get('size', 0))
    except (TypeError, ValueError):
        return 0


def delete(path):
    return _rpc({'path': _api_path(path)}, '/2/files/delete_v2') is not None


def writable(path):
    token = get_access_token()
    if not token:
        log('Dropbox: write check failed, no access token')
        return False
    probe = join(path, '.xscleaner_write_test')
    if not _upload_bytes(b'ok', probe):
        log(f'Dropbox: write probe failed for {path}')
        return False
    verified = False
    for _ in range(3):
        if getsize(probe) > 0:
            verified = True
            break
        time.sleep(0.3)
    delete(probe)
    if not verified:
        log(f'Dropbox: write probe not verified for {path}')
    return verified


def _upload_bytes(data, dropbox_dst):
    resp, err = _content_open(
        '/2/files/upload',
        {'path': _api_path(dropbox_dst), 'mode': 'overwrite'},
        body=data,
        timeout=30,
    )
    if err is not None:
        log(f'Dropbox: upload failed for {dropbox_dst}: {err[0]} {err[1][:200]}')
        return False
    resp.read()
    return True


def copy(src, dst, on_progress=None):
    src_db = is_dropbox_path(src)
    dst_db = is_dropbox_path(dst)
    if src_db and not dst_db:
        return _download(src, dst, on_progress)
    if dst_db and not src_db:
        return _upload(src, dst, on_progress)
    log(f'Dropbox: copy only supports local <-> dropbox ({src} -> {dst})')
    return False


def _upload(local_src, dropbox_dst, on_progress=None):
    try:
        size = os.path.getsize(local_src)
    except OSError as e:
        log(f'Dropbox: cannot stat {local_src}: {e}')
        return False
    if size <= SIMPLE_UPLOAD_LIMIT:
        try:
            with open(local_src, 'rb') as f:
                data = f.read()
        except OSError as e:
            log(f'Dropbox: cannot read {local_src}: {e}')
            return False
        if not _upload_bytes(data, dropbox_dst):
            return False
        if on_progress:
            on_progress(size)
        return True
    return _upload_session(local_src, dropbox_dst, size, on_progress)


def _upload_session(local_src, dropbox_dst, size, on_progress=None):
    resp, err = _content_open(
        '/2/files/upload_session/start', {'close': False}, body=b'', timeout=30
    )
    if err is not None:
        log(f'Dropbox: upload session start failed: {err[0]} {err[1][:200]}')
        return False
    try:
        session_id = json.loads(resp.read().decode('utf-8')).get('session_id')
    except Exception as e:
        log(f'Dropbox: bad session start response: {e}')
        return False
    if not session_id:
        log('Dropbox: no session_id in session start response')
        return False

    written = 0
    try:
        f = open(local_src, 'rb')
    except OSError as e:
        log(f'Dropbox: cannot read {local_src}: {e}')
        return False
    try:
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break
            written += len(chunk)
            if written >= size:
                resp, err = _content_open(
                    '/2/files/upload_session/finish',
                    {
                        'cursor': {'session_id': session_id, 'offset': written},
                        'commit': {'path': _api_path(dropbox_dst), 'mode': 'overwrite', 'mute': True},
                    },
                    body=chunk,
                )
                if err is not None:
                    log(f'Dropbox: upload session finish failed: {err[0]} {err[1][:200]}')
                    return False
                resp.read()
                break
            resp, err = _content_open(
                '/2/files/upload_session/append_v2',
                {'cursor': {'session_id': session_id, 'offset': written - len(chunk)}, 'close': False},
                body=chunk,
            )
            if err is not None:
                log(f'Dropbox: upload session append failed: {err[0]} {err[1][:200]}')
                return False
            resp.read()
            if on_progress:
                on_progress(written)
    finally:
        try:
            f.close()
        except Exception:
            pass
    if on_progress:
        on_progress(size)
    return True


def _download(dropbox_src, local_dst, on_progress=None):
    resp, err = _content_open('/2/files/download', {'path': _api_path(dropbox_src)})
    if err is not None:
        log(f'Dropbox: download failed for {dropbox_src}: {err[0]} {err[1][:200]}')
        return False
    written = 0
    try:
        with open(local_dst, 'wb') as f:
            while True:
                chunk = resp.read(64 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                written += len(chunk)
                if on_progress:
                    on_progress(written)
    except OSError as e:
        log(f'Dropbox: cannot write {local_dst}: {e}')
        return False
    return True
