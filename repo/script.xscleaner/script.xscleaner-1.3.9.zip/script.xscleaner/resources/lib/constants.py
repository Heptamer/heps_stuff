import os

ADDON_ID = 'script.xscleaner'
ADDON_NAME = 'XSCleaner'
ADDON_VERSION = '1.3.9'

try:
    import xbmcvfs
    _TRANSLATE = xbmcvfs.translatePath
except ImportError:
    import xbmc
    _TRANSLATE = xbmc.translatePath


def translate(path):
    try:
        result = _TRANSLATE(path)
    except Exception:
        return None
    if not result or 'special://' in str(result):
        return None
    return result


def _join(*parts):
    if any(p is None for p in parts):
        return None
    return os.path.join(*parts)


HOME = translate('special://home/')
XBMC = translate('special://xbmc/')
XBMC_ADDONS = _join(XBMC, 'addons')
HOME_ADDONS = _join(HOME, 'addons')
ADDON_DATA = _join(translate('special://userdata/'), 'addon_data')
USERDATA = translate('special://userdata/')
DATABASE = translate('special://database/')
TEMP = translate('special://temp/')
THUMBNAILS = _join(USERDATA, 'Thumbnails')
TEXTURES_DB = _join(DATABASE, 'Textures13.db')

ADDONS_TEMP = _join(HOME_ADDONS, 'temp')
PACKAGES_PATH = _join(HOME_ADDONS, 'packages')

ADDON_PATH = _join(HOME_ADDONS, ADDON_ID)
ADDON_ICON = _join(ADDON_PATH, 'resources', 'icon.png')
ADDON_FANART = _join(ADDON_PATH, 'resources', 'fanart.jpg')

LOG_PATH = translate('special://logpath/')
CRASH_PATH = _join(USERDATA, 'crashlogs')

SOURCES_XML = _join(USERDATA, 'sources.xml')
FAVORITES_XML = _join(USERDATA, 'favourites.xml')
GUISETTINGS_XML = _join(USERDATA, 'guisettings.xml')
ADVSETTINGS_XML = _join(USERDATA, 'advancedsettings.xml')
PROFILES_XML = _join(USERDATA, 'profiles.xml')
KEYMAP_DIR = _join(USERDATA, 'keymaps')
PLAYLISTS_DIR = _join(USERDATA, 'playlists')

EXCLUDES = [
    ADDON_ID,
    'script.module.requests',
    'script.module.urllib3',
    'script.module.chardet',
    'script.module.idna',
    'script.module.certifi',
]

DATABASE_FILES = [
    'MyMusic7.db',
    'MyVideos116.db',
    'MyVideos119.db',
    'MyVideos121.db',
    'MyVideos131.db',
    'MyVideos203.db',
    'Epg7.db',
    'Textures13.db',
    'Addons27.db',
    'Addons33.db',
    'Sizes7.db',
    'ViewModes6.db',
    'MyMusic82.db',
]

TEMP_PRESERVED = ['kodi.log', 'kodi.old.log', 'xbmc.log', 'xbmc.old.log']
