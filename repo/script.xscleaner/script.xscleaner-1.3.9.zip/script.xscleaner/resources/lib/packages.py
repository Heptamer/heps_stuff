import os
import shutil
from .constants import PACKAGES_PATH, HOME_ADDONS
from .utils import (
    log, notify, human_size, get_dir_size,
    yesno_dialog, progress_create, progress_close,
    ADDON_NAME, get_localized_string, is_setting_enabled
)
from .logger import log_action


def clean_packages(silent=False):
    if not is_setting_enabled('clean_packages'):
        return 0

    do_languages = is_setting_enabled('clean_unused_languages')
    has_packages = os.path.exists(PACKAGES_PATH)

    if not silent and not has_packages and not do_languages:
        notify(ADDON_NAME, get_localized_string(32216))
        return 0

    if not silent:
        dialog_text = get_localized_string(32261)
        if do_languages:
            dialog_text = f'{dialog_text}\n{get_localized_string(32264)}'
        if not yesno_dialog(
            ADDON_NAME,
            get_localized_string(32260),
            dialog_text
        ):
            return

    if not silent:
        progress_create(ADDON_NAME, get_localized_string(32262))

    cleaned = 0
    detail_paths = []

    if has_packages:
        try:
            for root, dirs, files in os.walk(PACKAGES_PATH):
                for name in files:
                    fp = os.path.join(root, name)
                    try:
                        size = os.path.getsize(fp)
                        os.remove(fp)
                        cleaned += size
                        detail_paths.append((fp, size))
                    except OSError:
                        pass

                for name in dirs:
                    dp = os.path.join(root, name)
                    try:
                        shutil.rmtree(dp, ignore_errors=True)
                        detail_paths.append((dp, 0))
                    except OSError:
                        pass
        except Exception as e:
            log(f'Error cleaning packages: {e}')

    if do_languages:
        lang_size, lang_paths = _clean_unused_languages()
        cleaned += lang_size
        detail_paths.extend(lang_paths)

    progress_close()

    if not silent:
        if cleaned > 0:
            notify(ADDON_NAME, get_localized_string(32263).format(human_size(cleaned)))
        else:
            notify(ADDON_NAME, get_localized_string(32216))

    log(f'Package cleanup completed, freed {human_size(cleaned)}')
    log_action('Packages Cleanup', space_freed=cleaned, detail_paths=detail_paths)
    return cleaned


def _clean_unused_languages():
    cleaned = 0
    paths = []
    keep = {'resource.language.en_gb', 'resource.language.de_de'}
    if not os.path.exists(HOME_ADDONS):
        return 0, paths
    for addon_name in os.listdir(HOME_ADDONS):
        lang_dir = os.path.join(HOME_ADDONS, addon_name, 'resources', 'language')
        if not os.path.exists(lang_dir):
            continue
        try:
            for item in os.listdir(lang_dir):
                item_path = os.path.join(lang_dir, item)
                if os.path.isdir(item_path) and item not in keep:
                    size = get_dir_size(item_path)
                    shutil.rmtree(item_path, ignore_errors=True)
                    cleaned += size
                    paths.append((item_path, size))
                    log(f'Removed language: {addon_name}/{item}')
        except Exception as e:
            log(f'Error cleaning languages for {addon_name}: {e}')
    return cleaned, paths
