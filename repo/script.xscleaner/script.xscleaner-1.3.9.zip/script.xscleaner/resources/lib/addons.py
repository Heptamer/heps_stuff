import os
import shutil
from .constants import HOME_ADDONS, XBMC_ADDONS, ADDON_DATA, EXCLUDES
from .utils import (
    log, notify, human_size, get_dir_size,
    yesno_dialog, progress_create, progress_close,
    ADDON_NAME, ADDON_ID,
    get_localized_string, is_setting_enabled, remove_empty_folders
)
from .logger import log_action


def clean_addon_leftovers(silent=False):
    if not is_setting_enabled('clean_addon_leftovers'):
        return 0

    if not silent:
        if not yesno_dialog(
            ADDON_NAME,
            get_localized_string(32250),
            get_localized_string(32251)
        ):
            return

    if not silent:
        progress_create(ADDON_NAME, get_localized_string(32252))

    cleaned = 0
    removed_count = 0
    detail_paths = []

    installed_addons = set()
    for addons_path in (HOME_ADDONS, XBMC_ADDONS):
        if os.path.exists(addons_path):
            for item in os.listdir(addons_path):
                if os.path.isdir(os.path.join(addons_path, item)):
                    installed_addons.add(item)

    addon_data_dirs = set()
    if os.path.exists(ADDON_DATA):
        for item in os.listdir(ADDON_DATA):
            data_path = os.path.join(ADDON_DATA, item)
            if os.path.isdir(data_path):
                addon_data_dirs.add(item)

    orphan_data = addon_data_dirs - installed_addons - set(EXCLUDES) - {ADDON_ID}

    for addon_name in orphan_data:
        data_path = os.path.join(ADDON_DATA, addon_name)
        try:
            size = get_dir_size(data_path)
            shutil.rmtree(data_path, ignore_errors=True)
            cleaned += size
            removed_count += 1
            detail_paths.append((data_path, size))
            log(f'Removed orphan data: {addon_name}')
        except Exception as e:
            log(f'Error removing {addon_name}: {e}')

    if os.path.exists(HOME_ADDONS):
        for item in os.listdir(HOME_ADDONS):
            if item in EXCLUDES or item == ADDON_ID:
                continue

            addon_path = os.path.join(HOME_ADDONS, item)
            if not os.path.isdir(addon_path):
                continue

            addon_xml = os.path.join(addon_path, 'addon.xml')
            if not os.path.exists(addon_xml):
                try:
                    size = get_dir_size(addon_path)
                    shutil.rmtree(addon_path, ignore_errors=True)
                    cleaned += size
                    removed_count += 1
                    detail_paths.append((addon_path, size))
                    log(f'Removed invalid addon: {item}')
                except Exception as e:
                    log(f'Error removing invalid addon {item}: {e}')

    remove_empty_folders(HOME_ADDONS, EXCLUDES)
    remove_empty_folders(ADDON_DATA, EXCLUDES)

    progress_close()

    if not silent:
        if removed_count > 0:
            notify(
                ADDON_NAME,
                get_localized_string(32253).format(removed_count, human_size(cleaned))
            )
        else:
            notify(ADDON_NAME, get_localized_string(32217))

    log(f'Addon leftovers cleanup completed, removed {removed_count} items, freed {human_size(cleaned)}')
    log_action('Addon Leftovers Cleanup', f'{removed_count} addons', items_cleaned=removed_count, space_freed=cleaned, detail_paths=detail_paths)
    return cleaned
