import os
import xml.etree.ElementTree as ET
import xbmcplugin

from .constants import HOME_ADDONS, XBMC_ADDONS, ADDON_DATA, USERDATA
from .utils import (
    human_size, get_dir_size, ok_dialog,
    progress_create, progress_update, progress_close,
    create_dir_item, ADDON_NAME, get_localized_string
)


_SKIP_ADDON_FOLDERS = {'packages', 'temp'}

_STALE_CACHE_FILE = os.path.join(USERDATA, 'xscleaner_addon_sizes.json') if USERDATA else None


def show_addon_sizes(handle):
    create_dir_item(
        get_localized_string(32552),
        'addons', 'addon_sizes_list', description=get_localized_string(32554),
        is_folder=True
    )
    create_dir_item(
        get_localized_string(32553),
        'addon_data', 'addon_sizes_list', description=get_localized_string(32555),
        is_folder=True
    )
    _end(handle)


def show_addon_sizes_list(source, handle):
    if source not in ('addons', 'addon_data'):
        source = 'addons'

    _remove_stale_cache_file()

    collected = _collect(source)
    measured = _measure(collected)
    entries = [[e['id'], e['name'], e['size']] for e in measured]

    if not entries:
        notify_text = get_localized_string(32557) if source == 'addons' else get_localized_string(32558)
        ok_dialog(ADDON_NAME, notify_text)
        _end(handle)
        return

    total = sum(e[2] for e in entries)
    create_dir_item(
        get_localized_string(32556).format(human_size(total)),
        f'__total__\x1f{total}', 'addon_sizes_show',
        description=get_localized_string(32556).format(human_size(total))
    )

    for addon_id, name, size in entries:
        label = f'{name} — {human_size(size)}'
        create_dir_item(
            label,
            f'{addon_id}\x1f{size}', 'addon_sizes_show',
            description=addon_id, icon_image='DefaultAddon.png'
        )

    _end(handle)


def show_addon_size_info(payload):
    try:
        addon_id, raw_size = payload.split('\x1f', 1)
        size = int(raw_size)
    except (ValueError, AttributeError):
        return

    if addon_id == '__total__':
        ok_dialog(get_localized_string(32560), get_localized_string(32556).format(human_size(size)))
        return

    ok_dialog(get_localized_string(32560), get_localized_string(32561).format(addon_id, human_size(size)))


def _remove_stale_cache_file():
    if not _STALE_CACHE_FILE:
        return
    try:
        if os.path.exists(_STALE_CACHE_FILE):
            os.remove(_STALE_CACHE_FILE)
    except OSError:
        pass


def _collect(source):
    if source == 'addon_data':
        entries = []
        if ADDON_DATA and os.path.isdir(ADDON_DATA):
            for item in sorted(os.listdir(ADDON_DATA)):
                data_path = os.path.join(ADDON_DATA, item)
                if os.path.isdir(data_path):
                    entries.append({
                        'id': item,
                        'name': _get_addon_name(item),
                        'paths': [data_path]
                    })
        return entries

    merged = {}
    for addons_path in (HOME_ADDONS, XBMC_ADDONS):
        if not addons_path or not os.path.isdir(addons_path):
            continue
        for item in sorted(os.listdir(addons_path)):
            if item in _SKIP_ADDON_FOLDERS:
                continue
            addon_path = os.path.join(addons_path, item)
            if not os.path.isdir(addon_path):
                continue
            entry = merged.setdefault(item, {
                'id': item,
                'name': _get_addon_name(item),
                'paths': []
            })
            entry['paths'].append(addon_path)
    return list(merged.values())


def _measure(entries):
    progress_create(ADDON_NAME, get_localized_string(32559))
    total = len(entries)
    measured = []
    for idx, entry in enumerate(entries, 1):
        size = 0
        for path in entry['paths']:
            size += get_dir_size(path)
        measured.append({'id': entry['id'], 'name': entry['name'], 'size': size})
        if total:
            progress_update(int(idx * 100 / total), entry['name'])
    progress_close()

    measured.sort(key=lambda e: e['size'], reverse=True)
    return measured


def _get_addon_name(addon_id):
    for addons_path in (HOME_ADDONS, XBMC_ADDONS):
        if not addons_path:
            continue
        addon_xml = os.path.join(addons_path, addon_id, 'addon.xml')
        try:
            root = ET.parse(addon_xml).getroot()
            name = root.get('name')
            if name:
                return name
        except Exception:
            pass
    return addon_id


def _end(handle):
    if handle != -1:
        xbmcplugin.endOfDirectory(handle)
