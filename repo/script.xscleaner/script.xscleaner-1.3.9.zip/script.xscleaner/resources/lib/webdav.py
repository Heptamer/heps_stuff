import base64
import os
import ssl
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

from .utils import log

# Kodi's curl-based WebDAV file access is unreliable: xbmcvfs.File
# reports a successful PUT on some servers (e.g. Nextcloud) without the
# file actually being persisted, which broke the write test and backups.
# This module implements the dav:// / davs:// operations natively over
# plain HTTP(S) with Basic auth, mirroring the dropbox.py API surface.
_DAV_NS = '{DAV:}'
_PROPFIND_BODY = (
    b'<?xml version="1.0" encoding="utf-8"?>'
    b'<d:propfind xmlns:d="DAV:"><d:allprop/></d:propfind>'
)
_CHUNK = 64 * 1024

try:
    import certifi
    _CA_BUNDLE = certifi.where()
except Exception:
    _CA_BUNDLE = None


class _Parsed(object):
    __slots__ = ('scheme', 'host', 'port', 'username', 'password', 'path')

    def __init__(self, scheme, host, port, username, password, path):
        self.scheme = scheme
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.path = path


class _ProgressReader(object):
    """File-like body for streaming uploads. http.client reads it in
    blocksize chunks and derives Content-Length from __len__()."""

    def __init__(self, f, size, on_progress):
        self._f = f
        self._size = size
        self._done = 0
        self._on_progress = on_progress

    def __len__(self):
        return self._size

    def read(self, size=-1):
        chunk = self._f.read(size)
        if chunk:
            self._done += len(chunk)
            if self._on_progress:
                self._on_progress(self._done)
        return chunk


class _MethodPreservingRedirect(urllib.request.HTTPRedirectHandler):
    """Follows redirects without downgrading PUT/PROPFIND/DELETE to GET.
    Credentials are dropped when the target host changes."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        from urllib.parse import urlsplit
        old = urlsplit(req.full_url)
        new = urlsplit(newurl)
        newheaders = {}
        for key, value in req.header_items():
            if key.lower() == 'authorization' and (
                    (old.hostname, old.port) != (new.hostname, new.port)):
                continue
            newheaders[key] = value
        newreq = urllib.request.Request(
            newurl.replace(' ', '%20'),
            headers=newheaders,
            origin_req_host=req.origin_req_host,
            unverifiable=True,
            method=req.get_method(),
        )
        newreq.data = req.data
        return newreq


def is_webdav_path(path):
    return isinstance(path, str) and path.lower().startswith(('dav://', 'davs://'))


def _split_options(raw):
    """Splits off Kodi-style URL options appended after '|', e.g.
    davs://host/path|verifypeer=false|verifyhost=false."""
    if '|' not in raw:
        return raw, {}
    url_part, _, opts = raw.partition('|')
    flags = {}
    for item in opts.split('|'):
        if '=' in item:
            key, _, value = item.partition('=')
            flags[key.strip().lower()] = value.strip().lower()
    return url_part, flags


def _parse_url(path):
    raw, flags = _split_options(str(path))
    parts = urllib.parse.urlsplit(raw)
    scheme = parts.scheme.lower()
    if scheme == 'dav':
        http_scheme = 'http'
    elif scheme == 'davs':
        http_scheme = 'https'
    elif scheme in ('http', 'https'):
        http_scheme = scheme
    else:
        raise ValueError(f'unsupported scheme: {scheme}')
    try:
        port = parts.port
    except ValueError:
        port = None
    username = urllib.parse.unquote(parts.username or '')
    password = urllib.parse.unquote(parts.password or '')
    path = parts.path or '/'
    if not path.startswith('/'):
        path = '/' + path
    return _Parsed(http_scheme, parts.hostname or '', port,
                   username or None, password, path), flags


def has_credentials(path):
    raw, _ = _split_options(str(path))
    parts = urllib.parse.urlsplit(raw)
    return bool(parts.username)


def _scheme_for(raw_scheme):
    scheme = (raw_scheme or '').lower()
    if scheme == 'dav':
        return 'dav'
    if scheme == 'davs':
        return 'davs'
    if scheme == 'http':
        return 'dav'
    if scheme == 'https':
        return 'davs'
    return 'davs'


def _with_options(url, flags):
    for key, value in flags.items():
        url += '|' + key + '=' + value
    return url


def normalize_base(server_url):
    """Normalizes a user-entered WebDAV base URL into a dav:// / davs://
    URL without credentials. The scheme is optional (http -> dav,
    https -> davs); |verifypeer=...| style options are preserved."""
    raw, flags = _split_options(str(server_url).strip())
    if not raw:
        return None
    if '://' not in raw:
        raw = 'https://' + raw
    parts = urllib.parse.urlsplit(raw)
    host = parts.hostname or ''
    if not host:
        return None
    try:
        port = parts.port
    except ValueError:
        port = None
    netloc = host
    if port:
        netloc += ':%d' % port
    path = parts.path or '/'
    if not path.startswith('/'):
        path = '/' + path
    url = f'{_scheme_for(parts.scheme)}://{netloc}{path}'
    return _with_options(url, flags)


def add_credentials(path, username, password):
    """Returns the dav/davs path with username/password embedded. Paths that
    already carry credentials are returned unchanged."""
    raw, flags = _split_options(str(path))
    parts = urllib.parse.urlsplit(raw)
    if parts.username:
        return str(path)
    try:
        port = parts.port
    except ValueError:
        port = None
    netloc = urllib.parse.quote(username or '', safe='')
    netloc += ':' + urllib.parse.quote(password or '', safe='')
    netloc += '@' + (parts.hostname or '')
    if port:
        netloc += ':%d' % port
    query = ('?' + parts.query) if parts.query else ''
    url = f'{_scheme_for(parts.scheme)}://{netloc}{parts.path or "/"}{query}'
    return _with_options(url, flags)


def _encode_path(path):
    return '/'.join(
        urllib.parse.quote(urllib.parse.unquote(segment), safe='')
        for segment in path.split('/')
    )


def _http_url_for(parsed, flags, relpath):
    netloc = parsed.host
    if parsed.port:
        netloc += ':%d' % parsed.port
    return f'{parsed.scheme}://{netloc}{_encode_path(relpath)}'


def _http_url(parsed, flags):
    return _http_url_for(parsed, flags, parsed.path)


def _display(path):
    s = str(path)
    if '@' in s and '://' in s:
        scheme, rest = s.split('://', 1)
        return f'{scheme}://{rest.rsplit("@", 1)[-1]}'
    return s


def _brief(body):
    if isinstance(body, bytes):
        body = body.decode('utf-8', 'replace')
    return (body or '')[:200]


def _tls_context(flags):
    verify_peer = flags.get('verifypeer', 'true') != 'false'
    verify_host = flags.get('verifyhost', 'true') != 'false'
    context = ssl.create_default_context(cafile=_CA_BUNDLE)
    if not verify_peer:
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    elif not verify_host:
        context.check_hostname = False
    return context


def _verify_disabled(flags):
    return flags.get('verifypeer', 'true') == 'false'


def _is_ssl_verify_error(err):
    code, detail = err
    if code != 0:
        return False
    text = str(detail)
    return ('CERTIFICATE_VERIFY_FAILED' in text or
            'certificate verify failed' in text or
            'self-signed certificate' in text)


def _open_once(method, http_url, username, password, flags, body, headers, timeout):
    req = urllib.request.Request(http_url, data=body, method=method)
    for key, value in (headers or {}).items():
        req.add_header(key, value)
    if username is not None:
        token = (urllib.parse.quote(username, safe='') + ':'
                 + urllib.parse.quote(password or '', safe=''))
        req.add_header('Authorization',
                       'Basic ' + base64.b64encode(token.encode('utf-8')).decode('ascii'))
    handlers = [_MethodPreservingRedirect()]
    if http_url.lower().startswith('https://'):
        handlers.append(urllib.request.HTTPSHandler(context=_tls_context(flags)))
    opener = urllib.request.build_opener(*handlers)
    try:
        return opener.open(req, timeout=timeout), None
    except urllib.error.HTTPError as e:
        try:
            body_bytes = e.read()
        except Exception:
            body_bytes = b''
        return None, (e.code, body_bytes)
    except urllib.error.URLError as e:
        return None, (0, str(e.reason))
    except (OSError, TimeoutError) as e:
        return None, (0, str(e))


def _request(method, url, flags=None, username=None, password=None,
             body=None, headers=None, timeout=30):
    """Performs a WebDAV/HTTP request against url (already an http(s) URL
    without credentials). Returns (resp_or_None, err). err is (code, detail)
    on failure, None on success (resp must be closed by the caller). On
    Android the default CA store is often empty; if the certificate cannot
    be verified and no CA bundle is importable, the request is retried once
    with verification disabled (loudly logged) so public-CA servers still
    work."""
    flags = flags or {}
    while True:
        resp, err = _open_once(method, url, username, password,
                               flags, body, headers, timeout)
        if (err is not None and _is_ssl_verify_error(err)
                and _CA_BUNDLE is None and not _verify_disabled(flags)):
            log('WebDAV: TLS certificate could not be verified (no CA bundle available '
                'on this device); retrying with certificate verification disabled. Append '
                '|verifypeer=false|verifyhost=false to the path to control this explicitly.')
            flags = dict(flags)
            flags['verifypeer'] = 'false'
            flags['verifyhost'] = 'false'
            continue
        if err is not None:
            return None, err
        return resp, None


def _propfind_url(url, flags, depth, username=None, password=None):
    resp, err = _request(
        'PROPFIND', url, flags=flags, username=username, password=password,
        body=_PROPFIND_BODY,
        headers={'Depth': depth, 'Content-Type': 'text/xml; charset=utf-8'},
        timeout=30,
    )
    if err is not None:
        return None, err
    try:
        data = resp.read()
    except Exception as e:
        resp.close()
        return None, (0, str(e))
    resp.close()
    return data, None


def _propfind(path, depth):
    parsed, flags = _parse_url(path)
    data, err = _propfind_url(_http_url(parsed, flags), flags, depth,
                              parsed.username, parsed.password)
    return data, parsed, err


def _dir_exists_url(url, flags, username=None, password=None):
    data, err = _propfind_url(url, flags, '0', username, password)
    return err is None and data is not None


def _mkcol(url, flags, username=None, password=None):
    resp, err = _request('MKCOL', url, flags=flags,
                         username=username, password=password, timeout=30)
    if err is not None:
        return False
    resp.close()
    return resp.status in (200, 201, 204)


def _prop_stat(data):
    try:
        root = ET.fromstring(data)
    except Exception:
        return {}
    stats = {}
    for node in root.findall(f'{_DAV_NS}response'):
        href_el = node.find(f'{_DAV_NS}href')
        if href_el is None or not href_el.text:
            continue
        href = urllib.parse.unquote(href_el.text)
        is_collection = False
        size = 0
        for ps in node.findall(f'{_DAV_NS}propstat'):
            status_el = ps.find(f'{_DAV_NS}status')
            if status_el is not None and '404' in (status_el.text or ''):
                continue
            prop = ps.find(f'{_DAV_NS}prop')
            if prop is None:
                continue
            rt = prop.find(f'{_DAV_NS}resourcetype')
            if rt is not None and rt.find(f'{_DAV_NS}collection') is not None:
                is_collection = True
            size_el = prop.find(f'{_DAV_NS}getcontentlength')
            if size_el is not None and size_el.text:
                try:
                    size = int(size_el.text)
                except (TypeError, ValueError):
                    size = 0
        stats[href] = {'collection': is_collection, 'size': size}
    return stats


def _basename(path):
    return str(path).rstrip('/').split('/')[-1]


def _match_stat(stats, path):
    if not stats:
        return None
    if len(stats) == 1:
        return next(iter(stats.values()))
    base = _basename(path)
    for href, st in stats.items():
        if href.rstrip('/').rsplit('/', 1)[-1] == base:
            return st
    return None


def join(base, name):
    base = str(base)
    name = str(name).strip('/')
    if not name:
        return base.rstrip('/')
    if base.endswith('/') or base.endswith('://'):
        return base + name
    return base + '/' + name


def exists(path):
    data, parsed, err = _propfind(path, '0')
    if err is not None:
        if err[0] != 404:
            log(f'WebDAV: PROPFIND failed for {_display(path)}: {err[0]} {_brief(err[1])}')
        return False
    return True


def check(path):
    """Returns (ok, http_code) for a single PROPFIND on path, so the caller
    can distinguish a reachable folder from an authentication error."""
    data, parsed, err = _propfind(path, '0')
    if err is not None:
        return False, err[0]
    return True, 200


def isfile(path):
    data, parsed, err = _propfind(path, '0')
    if err is not None:
        return False
    st = _match_stat(_prop_stat(data), path)
    return st is not None and not st['collection']


def getsize(path):
    data, parsed, err = _propfind(path, '0')
    if err is not None:
        return 0
    st = _match_stat(_prop_stat(data), path)
    return st['size'] if st else 0


def _listdir(path, dirs_only):
    data, parsed, err = _propfind(path, '1')
    if err is not None:
        if err[0] != 404:
            log(f'WebDAV: PROPFIND failed for {_display(path)}: {err[0]} {_brief(err[1])}')
        return []
    target = urllib.parse.unquote(parsed.path)
    if not target.endswith('/'):
        target += '/'
    names = []
    for href, st in _prop_stat(data).items():
        if not href.startswith(target):
            continue
        rest = href[len(target):].strip('/')
        if not rest or '/' in rest:
            continue
        if dirs_only and not st['collection']:
            continue
        names.append(rest)
    return names


def listdir(path):
    return _listdir(path, dirs_only=False)


def listdir_dirs(path):
    return _listdir(path, dirs_only=True)


def mkdirs(path):
    parsed, flags = _parse_url(path)
    user = parsed.username
    pw = parsed.password
    if _dir_exists_url(_http_url(parsed, flags), flags, user, pw):
        return True
    rel = parsed.path.rstrip('/')
    ancestor = rel
    while ancestor != '/' and not _dir_exists_url(
            _http_url_for(parsed, flags, ancestor), flags, user, pw):
        ancestor = ancestor.rsplit('/', 1)[0] or '/'
    if ancestor == '/' and not _dir_exists_url(
            _http_url_for(parsed, flags, ancestor), flags, user, pw):
        log(f'WebDAV: mkdirs failed, no existing base: {_display(path)}')
        return False
    missing = rel[len(ancestor):].strip('/')
    for segment in (missing.split('/') if missing else []):
        ancestor = ancestor.rstrip('/') + '/' + segment
        if _dir_exists_url(_http_url_for(parsed, flags, ancestor), flags, user, pw):
            continue
        if not _mkcol(_http_url_for(parsed, flags, ancestor), flags, user, pw) \
                and not _dir_exists_url(_http_url_for(parsed, flags, ancestor), flags, user, pw):
            log(f'WebDAV: MKCOL failed for {_display(path)}')
            return False
    return _dir_exists_url(_http_url_for(parsed, flags, parsed.path), flags, user, pw)


def delete(path):
    parsed, flags = _parse_url(path)
    resp, err = _request('DELETE', _http_url(parsed, flags), flags=flags,
                         username=parsed.username, password=parsed.password, timeout=30)
    if err is not None:
        if err[0] == 404:
            return True
        log(f'WebDAV: DELETE failed for {_display(path)}: {err[0]} {_brief(err[1])}')
        return False
    resp.close()
    return resp.status in (200, 202, 204)


def _put_bytes(path, data):
    parsed, flags = _parse_url(path)
    resp, err = _request('PUT', _http_url(parsed, flags), flags=flags,
                         username=parsed.username, password=parsed.password, body=data,
                         headers={'Content-Type': 'application/octet-stream'},
                         timeout=30)
    if err is not None:
        log(f'WebDAV: PUT failed for {_display(path)}: {err[0]} {_brief(err[1])}')
        return False
    resp.close()
    return resp.status in (200, 201, 204)


def _read(path):
    parsed, flags = _parse_url(path)
    resp, err = _request('GET', _http_url(parsed, flags), flags=flags,
                         username=parsed.username, password=parsed.password, timeout=30)
    if err is not None:
        if err[0] != 404:
            log(f'WebDAV: GET failed for {_display(path)}: {err[0]} {_brief(err[1])}')
        return None
    try:
        return resp.read()
    except Exception:
        return None
    finally:
        try:
            resp.close()
        except Exception:
            pass


def writable(path):
    if not mkdirs(path):
        log(f'WebDAV: write test failed for {_display(path)}: cannot create the folder')
        return False
    probe = join(path, '.xscleaner_write_test')
    data = b'xscleaner-write-test'
    if not _put_bytes(probe, data):
        log(f'WebDAV: write probe failed for {_display(path)}')
        return False
    verified = False
    try:
        read_back = _read(probe)
        verified = read_back == data
    finally:
        delete(probe)
    if not verified:
        log(f'WebDAV: write probe not verified for {_display(path)}')
    return verified


def check(path):
    """Probes the WebDAV connection with a depth-0 PROPFIND.
    Returns (True, 0) when the server answers, (False, http_code) otherwise."""
    try:
        parsed, flags = _parse_url(path)
        data, err = _propfind_url(_http_url(parsed, flags), flags, '0',
                                  parsed.username, parsed.password)
    except Exception as e:
        return False, 0
    if err is not None:
        return False, err[0]
    return True, 0


def copy(src, dst, on_progress=None):
    src_dav = is_webdav_path(src)
    dst_dav = is_webdav_path(dst)
    if src_dav and not dst_dav:
        return _download(src, dst, on_progress)
    if dst_dav and not src_dav:
        return _upload(src, dst, on_progress)
    log(f'WebDAV: copy only supports local <-> webdav ({src} -> {dst})')
    return False


def _upload(local_src, dav_dst, on_progress=None):
    try:
        size = os.path.getsize(local_src)
    except OSError as e:
        log(f'WebDAV: cannot stat {local_src}: {e}')
        return False
    try:
        f = open(local_src, 'rb')
    except OSError as e:
        log(f'WebDAV: cannot read {local_src}: {e}')
        return False
    parsed, flags = _parse_url(dav_dst)
    body = _ProgressReader(f, size, on_progress)
    try:
        resp, err = _request('PUT', _http_url(parsed, flags), flags=flags,
                             username=parsed.username, password=parsed.password, body=body,
                             headers={'Content-Type': 'application/octet-stream'},
                             timeout=120)
    finally:
        try:
            f.close()
        except Exception:
            pass
    if err is not None:
        log(f'WebDAV: upload failed for {_display(dav_dst)}: {err[0]} {_brief(err[1])}')
        return False
    resp.close()
    return True


def _download(dav_src, local_dst, on_progress=None):
    parsed, flags = _parse_url(dav_src)
    resp, err = _request('GET', _http_url(parsed, flags), flags=flags,
                         username=parsed.username, password=parsed.password, timeout=120)
    if err is not None:
        log(f'WebDAV: download failed for {_display(dav_src)}: {err[0]} {_brief(err[1])}')
        return False
    written = 0
    try:
        with open(local_dst, 'wb') as f:
            while True:
                chunk = resp.read(_CHUNK)
                if not chunk:
                    break
                f.write(chunk)
                written += len(chunk)
                if on_progress:
                    on_progress(written)
    except OSError as e:
        log(f'WebDAV: cannot write {local_dst}: {e}')
        return False
    finally:
        try:
            resp.close()
        except Exception:
            pass
    return True
