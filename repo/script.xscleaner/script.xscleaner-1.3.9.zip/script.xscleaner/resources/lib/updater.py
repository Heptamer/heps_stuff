import os
import time
import json
from .constants import ADDON_ID, ADDON_VERSION
from .utils import log, notify, ADDON_NAME, get_setting, get_localized_string


REPO_URL = 'https://raw.githubusercontent.com/xscleaner/script.xscleaner/main/repository'


def check_for_updates(silent=False):
    try:
        auto_update = get_setting('auto_update_check')

        if auto_update != 'true':
            return False

        last_check = _get_last_check_time()
        interval = _get_int_setting('auto_update_interval', 24)
        if time.time() - last_check < interval * 3600:
            return False

        latest_version = _fetch_latest_version()
        if latest_version is None:
            return False

        _set_last_check_time()

        if _is_newer_version(latest_version, ADDON_VERSION):
            if not silent:
                notify(ADDON_NAME, get_localized_string(32410).format(latest_version))
            log(f'Update available: v{latest_version}')
            return True

        return False

    except Exception as e:
        log(f'Error checking for updates: {e}')
        return False


def _get_int_setting(setting_id, default):
    try:
        return int(get_setting(setting_id) or default)
    except (ValueError, TypeError):
        return default


def _fetch_latest_version():
    try:
        url = f'{REPO_URL}/addons.xml'

        import urllib.request
        response = urllib.request.urlopen(url, timeout=10)
        content = response.read().decode('utf-8')

        import xml.etree.ElementTree as ET
        root = ET.fromstring(content)

        for addon in root.findall('.//addon'):
            if addon.get('id') == ADDON_ID:
                return addon.get('version')

        return None

    except Exception as e:
        log(f'Error fetching latest version: {e}')
        return None


def _is_newer_version(new_version, current_version):
    new_parts = _parse_version(new_version)
    current_parts = _parse_version(current_version)

    for i in range(max(len(new_parts), len(current_parts))):
        new_val = new_parts[i] if i < len(new_parts) else 0
        current_val = current_parts[i] if i < len(current_parts) else 0

        if new_val > current_val:
            return True
        elif new_val < current_val:
            return False

    return False


def _parse_version(version):
    parts = []
    for chunk in str(version).split('.'):
        digits = ''
        for ch in chunk:
            if ch.isdigit():
                digits += ch
            else:
                break
        parts.append(int(digits) if digits else 0)
    return parts


def _get_last_check_time():
    try:
        from .constants import USERDATA
        state_file = os.path.join(USERDATA, 'xscleaner_update_state.json')

        if os.path.exists(state_file):
            with open(state_file, 'r') as f:
                state = json.load(f)
                return state.get('last_check', 0)

    except Exception:
        pass

    return 0


def _set_last_check_time():
    try:
        from .constants import USERDATA
        state_file = os.path.join(USERDATA, 'xscleaner_update_state.json')

        state = {'last_check': time.time()}

        with open(state_file, 'w') as f:
            json.dump(state, f)

    except Exception as e:
        log(f'Error saving update state: {e}')
