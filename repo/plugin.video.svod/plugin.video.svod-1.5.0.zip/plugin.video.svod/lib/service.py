# -*- coding: utf-8 -*-
""" Background service code """

from __future__ import absolute_import, division, unicode_literals

from urllib.parse import urlsplit, parse_qsl, urlencode
import os
import time as time_module
import datetime
import xml.etree.ElementTree as ET
from xml.dom import minidom

import xbmc
import xbmcvfs
from xbmc import Monitor, Player, getInfoLabel
import xbmcaddon
from .loggers import Logger
from .utils import get_int_value, get_next_info_and_send_signal
from .globals import G
from .api import Api


class StalkerService:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self._pvr_loaded_portal = None

    def _get_pvr_paths(self):
        custom = (self.addon.getSetting('pvr_output_path') or '').strip()
        if custom:
            base = xbmcvfs.translatePath(custom)
        else:
            base = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        m3u_path = os.path.join(base, 'pvr_channels.m3u')
        xmltv_path = os.path.join(base, 'pvr_epg.xml')
        return m3u_path, xmltv_path

    @staticmethod
    def _format_xmltv_time(ts_val, offset_hours=0):
        if not ts_val:
            return ''
        try:
            ts_str = str(ts_val).strip()
            if not ts_str:
                return ''
            # Fall 1: Unix-Timestamp (nur Ziffern)
            if ts_str.isdigit():
                ts = int(ts_str)
                if ts <= 0:
                    return ''
                dt = datetime.datetime.fromtimestamp(ts + offset_hours * 3600)
            # Fall 2: Datum-Zeit-String z.B. "2026-05-25 12:45:00"
            elif ' ' in ts_str and ':' in ts_str:
                dt = datetime.datetime.strptime(ts_str, '%Y-%m-%d %H:%M:%S') + datetime.timedelta(hours=offset_hours)
            else:
                return ''
            tz_str = dt.strftime('%z')
            if not tz_str:
                tz_str = '+0000'
            return dt.strftime('%Y%m%d%H%M%S') + ' ' + tz_str
        except (ValueError, OSError):
            return ''

    def _update_pvr_data(self):
        if self.addon.getSetting('pvr_enabled') != 'true':
            return

        output_path = (self.addon.getSetting('pvr_output_path') or '').strip()
        if not output_path:
            Logger.warn("PVR: no output path set, skipping (enable needs a folder)")
            return

        portal_id = int(self.addon.getSetting('pvr_portal_id') or '0')
        if portal_id < 1 or portal_id > 10:
            Logger.debug("PVR: portal_id not set, skipping")
            return

        Logger.info(f"PVR: Generating data for Portal {portal_id}")

        old = G.active_portal
        try:
            G.init_globals(portal_id)
            old_limit = G.addon_config.max_page_limit
            G.addon_config.max_page_limit = 20

            # 1) Kategorie-Filter auslesen und Genres durchgehen
            category_filter = G.portal_config.category_filter or ''
            genres = Api.get_tv_genres()
            all_channels = []
            seen_ids = set()

            if isinstance(genres, list):
                for genre in genres:
                    if not isinstance(genre, dict) or 'id' not in genre:
                        continue

                    # Kategorie-Filter: Genre-Titel muss mind. einen Filterbegriff enthalten
                    if category_filter:
                        title_lower = genre.get('title', '').lower()
                        filters = [f.strip().lower() for f in category_filter.split(',') if f.strip()]
                        if filters and not any(f in title_lower for f in filters):
                            continue

                    genre_title = genre.get('title', '')
                    try:
                        result = Api.get_tv_channels(genre['id'], 1, "", 0)
                        if result and isinstance(result, dict) and 'data' in result:
                            for ch in result['data']:
                                ch_id = str(ch.get('id', ''))
                                if ch_id and ch_id not in seen_ids:
                                    seen_ids.add(ch_id)
                                    all_channels.append((ch, genre_title))
                    except Exception as e:
                        Logger.error(f"PVR channel fetch failed for genre {genre.get('id')}: {e}")

            G.addon_config.max_page_limit = old_limit

            if not all_channels:
                Logger.warn("PVR: No channels found")
                return

            # 2) M3U generieren (plugin:// URLs mit group-title)
            m3u_lines = ['#EXTM3U']
            for ch, genre_title in all_channels:
                name = ch.get('name', '').replace(',', '')
                logo = ch.get('logo', '')
                cmd = ch.get('cmd', '')
                ch_id = ch.get('id', '')

                pvr_params = {
                    'action': 'tv_play',
                    'cmd': cmd,
                    'use_http_tmp_link': ch.get('use_http_tmp_link', '1'),
                    'use_load_balancing': ch.get('use_load_balancing', '0'),
                    'portal_id': portal_id
                }
                plugin_url = 'plugin://plugin.video.svod/?' + urlencode(pvr_params)

                extinf = f'#EXTINF:-1 tvg-id="{ch_id}" tvg-name="{name}" group-title="{genre_title}" tvg-logo="{logo}",{name}'
                m3u_lines.append(extinf)
                m3u_lines.append(plugin_url)

            m3u_path, _ = self._get_pvr_paths()
            m3u_dir = os.path.dirname(m3u_path)
            if not xbmcvfs.exists(m3u_dir):
                xbmcvfs.mkdirs(m3u_dir)
            with xbmcvfs.File(m3u_path, 'w') as f:
                f.write('\n'.join(m3u_lines))
            Logger.info(f"PVR M3U: {len(all_channels)} channels → {m3u_path}")

            # 3) EPG in 50er-Batches vorladen
            channel_ids = [str(ch['id']) for ch, _ in all_channels if 'id' in ch]
            now_date = datetime.datetime.now().strftime('%Y-%m-%d')
            p_id = G.active_portal
            if p_id not in G.cache_epg:
                G.cache_epg[p_id] = {}
            if p_id not in G.cache_short_epg:
                G.cache_short_epg[p_id] = {}

            # Diagnose: Teste einen einzelnen Kanal mit roher Antwort
            if channel_ids:
                test_id = channel_ids[0]
                try:
                    raw = Api._Api__call_stalker_portal_return_response(
                        {'type': 'itv', 'action': 'get_epg_info', 'ch_id': test_id, 'date': now_date}
                    )
                    Logger.info(f"PVR EPG diagnostic - status: {raw.status_code}, body[:500]: {raw.text[:500]}")
                except Exception as diag_e:
                    Logger.error(f"PVR EPG diagnostic failed: {diag_e}")

            for i in range(0, len(channel_ids), 50):
                batch = channel_ids[i:i + 50]
                params = {'type': 'itv', 'action': 'get_epg_info', 'ch_id': ','.join(batch), 'date': now_date}
                try:
                    response = Api._Api__call_stalker_portal(params)
                    if response and isinstance(response, dict) and 'js' in response:
                        js_data = response['js']
                        epg_dict = {}
                        if isinstance(js_data, dict):
                            epg_dict = js_data.get('data', {})
                            if not isinstance(epg_dict, dict):
                                epg_dict = js_data
                        for ch_id_str in batch:
                            if ch_id_str in epg_dict:
                                data = epg_dict[ch_id_str]
                                if isinstance(data, list):
                                    G.cache_epg[p_id][ch_id_str] = data
                                    G.cache_short_epg[p_id][ch_id_str] = {
                                        'data': data,
                                        'timestamp': time_module.time()
                                    }
                    else:
                        # Batch fehlgeschlagen → Fallback: get_short_epg pro Einzelkanal
                        Logger.warn(f"PVR EPG batch {i}: empty/invalid response, trying single-channel fallback...")
                        for ch_id_str in batch:
                            if ch_id_str in G.cache_epg.get(p_id, {}):
                                continue
                            try:
                                single_params = {
                                    'type': 'itv',
                                    'action': 'get_short_epg',
                                    'ch_id': ch_id_str
                                }
                                single_resp = Api._Api__call_stalker_portal(single_params)
                                if single_resp and isinstance(single_resp, dict) and 'js' in single_resp:
                                    js_single = single_resp['js']
                                    data = js_single if isinstance(js_single, list) else []
                                    if data:
                                        G.cache_epg[p_id][ch_id_str] = data
                                        G.cache_short_epg[p_id][ch_id_str] = {
                                            'data': data,
                                            'timestamp': time_module.time()
                                        }
                            except Exception as e_single:
                                Logger.error(f"PVR EPG single request for {ch_id_str} failed: {e_single}")
                except Exception as e:
                    Logger.error(f"PVR EPG batch {i} failed: {e}")

            # 4) XMLTV generieren
            tv_elem = ET.Element('tv', {'generator-info-name': 'xStalkerVoD PVR'})

            for ch, _ in all_channels:
                ch_id = str(ch.get('id', ''))
                ch_name = ch.get('name', '')
                ch_logo = ch.get('logo', '')

                ch_el = ET.SubElement(tv_elem, 'channel', {'id': ch_id})
                dn = ET.SubElement(ch_el, 'display-name', {'lang': 'de'})
                dn.text = ch_name
                if ch_logo:
                    ET.SubElement(ch_el, 'icon', {'src': ch_logo})

                # NUR aus Cache lesen – KEINE neuen API-Calls!
                epg = G.cache_epg.get(p_id, {}).get(ch_id)
                if not epg:
                    cached_short = G.cache_short_epg.get(p_id, {}).get(ch_id)
                    if isinstance(cached_short, dict):
                        epg = cached_short.get('data')

                if epg and isinstance(epg, list):
                    epg_offset = G.portal_config.epg_offset
                    for entry in epg:
                        if not isinstance(entry, dict):
                            continue

                        raw_start = (entry.get('time') or entry.get('t_time')
                                     or entry.get('t_start_show') or entry.get('t_start')
                                     or entry.get('start') or '')
                        start_str = StalkerService._format_xmltv_time(raw_start, epg_offset)
                        if not start_str:
                            continue

                        title = entry.get('name') or entry.get('title') or ''
                        desc = entry.get('descr') or entry.get('description') or ''

                        raw_duration = entry.get('duration') or entry.get('len') or entry.get('length') or ''
                        raw_stop = (entry.get('time_to') or entry.get('t_stop') or entry.get('t_end')
                                    or entry.get('stop') or entry.get('end') or '')

                        if raw_stop:
                            stop_str = StalkerService._format_xmltv_time(raw_stop, epg_offset)
                        elif raw_duration and str(raw_duration).isdigit() and str(raw_start).isdigit():
                            stop_ts = int(raw_start) + int(raw_duration)
                            stop_str = StalkerService._format_xmltv_time(stop_ts, epg_offset)
                        elif str(raw_start).isdigit():
                            stop_ts = int(raw_start) + 1800
                            stop_str = StalkerService._format_xmltv_time(stop_ts, epg_offset)
                        else:
                            stop_str = ''

                        prog = ET.SubElement(tv_elem, 'programme', {
                            'start': start_str,
                            'stop': stop_str or start_str,
                            'channel': ch_id
                        })
                        t_el = ET.SubElement(prog, 'title', {'lang': 'de'})
                        t_el.text = title
                        if desc:
                            d_el = ET.SubElement(prog, 'desc', {'lang': 'de'})
                            d_el.text = desc

            rough = ET.tostring(tv_elem, encoding='unicode')
            dom = minidom.parseString(rough)
            xml_content = dom.toprettyxml(indent='  ', encoding='UTF-8')

            _, xmltv_path = self._get_pvr_paths()
            xmltv_dir = os.path.dirname(xmltv_path)
            if not xbmcvfs.exists(xmltv_dir):
                xbmcvfs.mkdirs(xmltv_dir)
            with xbmcvfs.File(xmltv_path, 'wb') as f:
                f.write(xml_content)
            Logger.info(f"PVR XMLTV: {len(all_channels)} channels → {xmltv_path}")

        except Exception as e:
            Logger.error(f"PVR update failed: {e}")
        finally:
            try:
                G.init_globals(old)
            except Exception:
                pass

    def _early_pvr_load(self):
        """
        PVR früh laden (vor precheck/preload):
        - Prüft ob PVR aktiviert und konfiguriert
        - Prüft PVR-Portal auf Erreichbarkeit
        - Lädt M3U + XMLTV für das PVR-Portal
        """
        if self.addon.getSetting('pvr_enabled') != 'true':
            return
        portal_id = int(self.addon.getSetting('pvr_portal_id') or '0')
        if portal_id < 1 or portal_id > 10:
            return
        output_path = (self.addon.getSetting('pvr_output_path') or '').strip()
        if not output_path:
            Logger.warn("PVR early: no output path set, skipping")
            return

        Logger.info(f"PVR early: checking Portal {portal_id} ...")
        if self._is_portal_reachable(portal_id):
            self._update_pvr_data()
            self._pvr_loaded_portal = portal_id
            Logger.info(f"PVR early: Portal {portal_id} loaded (M3U + XMLTV)")
        else:
            Logger.warn(f"PVR early: Portal {portal_id} not reachable, skipping")

    def run(self):
        Logger.info("Stalker Service started")

        # Warte kurz, bis Kodi stabil läuft (5 Sek)
        monitor = xbmc.Monitor()
        if monitor.waitForAbort(5):
            return

        # 1) PVR früh laden (M3U+XMLTV) bevor die anderen Checks starten
        self._early_pvr_load()

        # 2) Portal Precheck beim Start ausführen
        self.perform_portal_precheck()

        # 3) EPG Preload beim Start ausführen
        self.perform_preload()

        # Service-Loop: alle 5 Minuten PVR-Refresh prüfen
        last_pvr_refresh = time_module.time()
        while not monitor.waitForAbort(300):
            if self.addon.getSetting('pvr_enabled') == 'true':
                interval = int(self.addon.getSetting('pvr_refresh_interval') or '60')
                if time_module.time() - last_pvr_refresh >= interval * 60:
                    self._update_pvr_data()
                    last_pvr_refresh = time_module.time()

    def _is_portal_reachable(self, portal_id: int) -> bool:
        """
        Schneller Reachability-Check:
        - G.init_globals(portal_id)
        - Token holen (Handshake)
        Markiert portal_error automatisch über Api.preload_epg_for_portal / Api._set_portal_error beim späteren Preload,
        aber hier können wir bereits aussortieren.
        """
        old_portal = G.active_portal
        try:
            G.init_globals(int(portal_id))
            # Token-Handshake (kurz & schmerzlos). Wenn das Portal hängt, fliegt hier eine Exception.
            from .auth import Auth
            Auth().get_token(refresh_token=False)

            try:
                Api._set_portal_error(int(portal_id), False)
            except Exception:
                pass

            return True
        except Exception as e:
            Logger.error(f"Portal {portal_id} unreachable (precheck): {str(e)}")
            # Portal markieren
            try:
                Api._set_portal_error(int(portal_id), True, reason=f"precheck: {str(e)}")
            except Exception:
                pass
            return False
        finally:
            try:
                G.init_globals(old_portal)
            except Exception:
                pass

    def perform_portal_precheck(self):
        """
        Wird bei JEDEM Kodi-Start ausgeführt.
        Prüft alle konfigurierten Portale auf Erreichbarkeit und setzt portal_error entsprechend.
        """
        try:
            configured = []
            for i in range(1, 11):
                suffix = '' if i == 1 else f'_{i}'
                server = self.addon.getSetting(f'server_address{suffix}')
                if server and server.startswith('http'):
                    configured.append(i)

            if not configured:
                Logger.info("Portal Precheck: no portals configured")
                return

            working = []
            for pid in configured:
                if self._is_portal_reachable(pid):
                    working.append(pid)

            Logger.info(f"Portal Precheck: {len(working)}/{len(configured)} portals reachable: {working}")

        except Exception as e:
            Logger.error(f"Portal precheck failed: {str(e)}")


    def perform_preload(self):
        try:
            mode_raw = self.addon.getSetting('epg_preload_mode')
            if not mode_raw or mode_raw == '0':
                Logger.info("EPG Preload is disabled in settings")
                return

            if self.addon.getSetting('epg_enabled') != 'true':
                Logger.info("EPG is disabled globally (epg_enabled=false)")
                return

            mode = int(mode_raw)

            original_user_portal = G.active_portal
            Logger.info(f"Starting EPG Preload for all portals (Mode: {mode})")

            # 1) Portale sammeln, die konfiguriert sind
            configured = []
            for i in range(1, 11):
                suffix = '' if i == 1 else f'_{i}'
                server = self.addon.getSetting(f'server_address{suffix}')
                if server and server.startswith('http'):
                    configured.append(i)

            # 2) Vorab prüfen, welche Portale antworten
            working = []
            for pid in configured:
                if self._pvr_loaded_portal == pid:
                    Logger.debug(f"Skipping precheck for Portal {pid} (already loaded via PVR)")
                    continue
                if self._is_portal_reachable(pid):
                    working.append(pid)

            Logger.info(f"EPG Precheck: {len(working)}/{len(configured)} portals reachable: {working}")

            # 3) Preload nur für funktionierende Portale
            for pid in working:
                Logger.debug(f"Preloading EPG for Portal {pid}...")
                Api.preload_epg_for_portal(pid, mode)
                xbmc.Monitor().waitForAbort(2)

            G.init_globals(original_user_portal)

        except Exception as e:
            Logger.error(f"Service preload failed: {str(e)}")


class BackgroundService(Monitor):
    """ Background service code """

    def __init__(self):
        Monitor.__init__(self)
        self._player = PlayerMonitor()

    def run(self):
        Logger.debug('Service started - Waiting for network...')

        # Kurz warten, bis das Netzwerk sicher da ist
        if self.waitForAbort(5): return

        # EPG Preload für alle konfigurierten Portale
        addon = G._GlobalVariables__addon  # Zugriff auf das Addon-Objekt
        try:
            # Nur fortfahren wenn EPG generell aktiviert ist
            if addon.getSetting('epg_enabled') == 'true':
                # Holen als String und konvertieren zu Int
                mode = int(addon.getSetting('epg_preload_mode') or 0)

                # Wir merken uns, welches Portal der User eigentlich gerade nutzt (meistens 1 beim Start)
                original_user_portal = G.active_portal

                if mode > 0:
                    for i in range(1, 11):
                        if self.abortRequested(): break

                        suffix = '' if i == 1 else f'_{i}'
                        server = addon.getSetting(f'server_address{suffix}')

                        if server and server.startswith('http'):
                            Logger.debug(f"Preloading EPG for Portal {i}...")
                            Api.preload_epg_for_portal(i, mode)
                            # Kleine Pause zwischen den Portalen, um den Server nicht zu stressen
                            self.waitForAbort(2)
                        G.init_globals(original_user_portal)
        except Exception as e:
            Logger.error(f"Error during background preload: {str(e)}")

        while not self.abortRequested():
            # Stop when abort requested
            if self.waitForAbort(10):
                break

        Logger.debug('Service stopped')


class PlayerMonitor(Player):
    """ A custom Player object to check subtitles """

    def __init__(self):
        """ Initialises a custom Player object """
        self.__listen = False
        self.__av_started = False
        self.__path = None
        Player.__init__(self)

    def onPlayBackStarted(self):  # pylint: disable=invalid-name
        """ Will be called when Kodi player starts """
        self.__path = getInfoLabel('Player.FilenameAndPath')
        if not self.__path.startswith('plugin://plugin.video.svod/'):
            self.__listen = False
            return
        self.__listen = True
        self.__av_started = False
        Logger.debug('Stalker Player: [onPlayBackStarted] called')

    def onAVStarted(self):  # pylint: disable=invalid-name
        """ Will be called when Kodi has a video or audiostream """
        if not self.__listen:
            return
        Logger.debug('Stalker Player: [onAVStarted] called')
        self.__av_started = True
        params = dict(parse_qsl(urlsplit(self.__path).query))
        episode_no = get_int_value(params, 'series')
        total_episodes = get_int_value(params, 'total_episodes')
        if episode_no != 0 and episode_no < total_episodes:
            params.update({'series': episode_no + 1})
            next_episode_url = '{}?{}'.format('plugin://plugin.video.svod/', urlencode(params))
            get_next_info_and_send_signal(params, next_episode_url)

    def onPlayBackError(self):  # pylint: disable=invalid-name
        """ Will be called when playback stops due to an error. """
        if not self.__listen:
            return
        self.__av_started = False
        self.__listen = False
        Logger.debug('Stalker Player: [onPlayBackError] called')

    def onPlayBackEnded(self):  # pylint: disable=invalid-name
        """ Will be called when [Kodi] stops playing a file """
        if not self.__listen:
            return
        Logger.debug('Stalker Player: [onPlayBackEnded] called')
        self.__listen = False
        self.__av_started = False

    def onPlayBackStopped(self):  # pylint: disable=invalid-name
        """ Will be called when [user] stops Kodi playing a file """
        if not self.__listen:
            return
        self.__listen = False
        if not self.__av_started:
            params = dict(parse_qsl(urlsplit(self.__path).query))
            if 'cmd' in params and params.get('use_cmd', '0') == '0':
                Logger.debug('Stalker Player: [onPlayBackStopped] playback failed? retrying with cmd {}'.format(self.__path + "&use_cmd=1"))
                xbmc.executebuiltin("Dialog.Close(all, true)")
                func_str = f'PlayMedia({self.__path + "&use_cmd=1"})'
                xbmc.executebuiltin(func_str)
                return
        self.__av_started = False
        Logger.debug('Stalker Player: [onPlayBackStopped] called')


def run():
    """ Run the BackgroundService """
    BackgroundService().run()
