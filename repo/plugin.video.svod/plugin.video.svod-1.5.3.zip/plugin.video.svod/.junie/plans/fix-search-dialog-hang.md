---
sessionId: session-260919-083424-1v3z
---

# Requirements

### Overview & Goals
Fix the issue where the search dialog hangs for an extended period when users click 'Cancel' without entering any search text.

### Scope
- Fix the specific behavior in the search functionality where canceling with no input causes a delay
- Ensure proper handling of empty search terms or cancellation
- Maintain all existing search functionality and user experience

### User Stories
- As a user, I want to be able to quickly cancel a search without waiting for long delays
- As a developer, I want the search dialog to properly handle cancellations and empty inputs immediately

### Functional Requirements
- When a user cancels the input dialog (presses 'Cancel' button) with no text entered, the function should return immediately
- The search term validation should not block execution on cancellation
- No unnecessary API calls or processing should occur when cancelling without input

### Non-Functional Requirements
- Performance: Search dialogs must respond within 1 second to user actions
- Consistency: All search functions (vod_search, series_search, tv_search) should behave consistently

# Delivery Steps

### * Step 1: Analyze Current Search Implementation
Review and understand the current implementation of all search functions in addon.py that could be causing the delay when canceling.

- Examine __search_vod(), __search_series() and __search_tv() methods in lib/addon.py
- Identify how ask_for_input() is used and where delays might occur during cancellation
- Check if there are any missing early returns or incomplete handling of empty/cancelled inputs

###   Step 2: Implement Immediate Cancellation Handling
Modify the search functions to properly handle cancellation immediately without waiting for processing.

- Update __search_vod(), __search_series() and __search_tv() methods in lib/addon.py
- Ensure that when ask_for_input() returns None (user canceled), the function exits early
- Add explicit checks for empty or None return values from input dialog before proceeding with search logic