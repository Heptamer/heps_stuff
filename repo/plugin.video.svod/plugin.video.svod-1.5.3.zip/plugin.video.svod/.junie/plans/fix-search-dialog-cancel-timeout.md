---
sessionId: session-260918-181914-fl13
---

# Requirements

### Overview & Goals
When a user opens the search function (for VOD, Series, or TV channels) and cancels the input dialog or enters an empty search string, the Kodi interface takes a very long time to close the search dialog/view. The goal is to make the search dialog and directory view terminate immediately upon cancellation or empty input without any delay.

### Scope
- **In Scope**:
  - `lib/addon.py`: Fix directory completion handling in `__search_vod`, `__search_series`, and `__search_tv` when `search_term` is `None` or empty.
- **Out of Scope**:
  - Changing `changelog.txt` or addon metadata.
  - Changing API search queries or search results rendering when a valid search string is entered.

### Functional Requirements
- When the user cancels the search text input dialog (or submits an empty/whitespace-only input), the plugin must immediately close the directory loading process via `xbmcplugin.endOfDirectory(..., succeeded=False)`.
- Kodi UI must immediately return to the previous view without hanging or spinning waiting for a directory timeout.
- Applies to all search entry points: VOD search (`__search_vod`), Series search (`__search_series`), and TV search (`__search_tv`).

# Technical Design

### Current Implementation
In `lib/addon.py`, the search handlers `__search_vod` (lines 1730-1758), `__search_series` (lines 1759-1786), and `__search_tv` (lines 1787-1813) are triggered when clicking a search directory item (`isContextMenuSearch=False`) or running via context menu:
```python
search_term = ask_for_input(params['category'])
if search_term:
    params.update({'action': 'vod_listing', ...})
    ...
```
If the user cancels the category selection dialog (`ask_for_category_selection`), `xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, ...)` is already called correctly. However, if the user proceeds past category selection and then cancels `ask_for_input` or provides an empty input, `search_term` evaluates to `None` / empty string. The methods currently do nothing and simply exit without calling `xbmcplugin.endOfDirectory`. Because Kodi opened a directory handle and expects an `endOfDirectory` response, it hangs waiting until its internal directory request times out.

### Key Decisions
- **Proper Directory Finalization**: Whenever `search_term` is falsy or only whitespace after `ask_for_input`, immediately invoke `xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)` and return.
- **Consistency across all search types**: Apply identical handling to VOD, Series, and TV search methods.

### Proposed Changes
#### `lib/addon.py`
In `__search_vod`, `__search_series`, and `__search_tv`:
```python
search_term = ask_for_input(params['category'])
if not search_term or not search_term.strip():
    xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
    return

search_term = search_term.strip()
params.update({'action': '<type>_listing', 'update_listing': False, 'search_term': search_term, 'page': 1})
...
```

### Architecture & Call Flow
```mermaid
sequenceDiagram
    participant User
    participant Kodi as Kodi UI / Directory
    participant Addon as StalkerAddon (__search_*)
    participant Dialog as Input Dialog

    User->>Kodi: Click Search / Suchfunktion
    Kodi->>Addon: Invoke action (e.g. vod_search)
    Addon->>Dialog: ask_for_input(category)
    Dialog-->>User: Show Text Input
    User->>Dialog: Cancel / Empty input
    Dialog-->>Addon: Returns None / ""
    Addon->>Kodi: xbmcplugin.endOfDirectory(handle, succeeded=False)
    Kodi-->>User: Immediately close busy dialog / return to view
```

### Risks & Mitigations
- *Risk*: `G.get_handle()` being `-1` in context menu search calls (`isContextMenuSearch=True`).
- *Mitigation*: Kodi's `xbmcplugin.endOfDirectory` safely ignores `-1` handles, matching existing patterns throughout the codebase (e.g., in category selection abort).

# Testing

### Validation Approach
- Verify syntax and static analysis in `lib/addon.py`.
- Trace all execution paths in `__search_vod`, `__search_series`, and `__search_tv` to ensure `endOfDirectory` is guaranteed to be called in all exit scenarios:
  1. Category selection cancelled: calls `endOfDirectory(succeeded=False)` and returns.
  2. Input dialog cancelled / empty / whitespace: calls `endOfDirectory(succeeded=False)` and returns.
  3. Valid search term provided via directory: calls listing method which calls `endOfDirectory(succeeded=True)`.
  4. Valid search term provided via context menu: updates container.

### Key Scenarios
- User navigates to VOD > Search > cancels search input dialog -> returns immediately with no hang.
- User navigates to Series > Search > cancels search input dialog -> returns immediately with no hang.
- User navigates to TV > Search > cancels search input dialog -> returns immediately with no hang.
- User enters valid search text -> listing appears as expected.

# Delivery Steps

###   Step 1: Implement cancellation & empty input handling for VOD and Series search
VOD and Series search handlers immediately finalize Kodi directory handles when input dialog is cancelled or empty.

- Update `__search_vod` in `lib/addon.py`: check if `search_term` is falsy or blank after `ask_for_input`, call `xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)`, and return early.
- Update `__search_series` in `lib/addon.py`: check if `search_term` is falsy or blank after `ask_for_input`, call `xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)`, and return early.
- Strip leading and trailing whitespace from `search_term` before proceeding with valid search queries.

###   Step 2: Implement cancellation & empty input handling for TV channel search
TV search handler immediately finalizes Kodi directory handles when input dialog is cancelled or empty.

- Update `__search_tv` in `lib/addon.py`: check if `search_term` is falsy or blank after `ask_for_input`, call `xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)`, and return early.
- Strip leading and trailing whitespace from `search_term` before proceeding with valid TV search queries.
- Verify that all three search entry points (`vod_search`, `series_search`, `tv_search`) correctly terminate without causing Kodi UI hangs on cancel or empty input.