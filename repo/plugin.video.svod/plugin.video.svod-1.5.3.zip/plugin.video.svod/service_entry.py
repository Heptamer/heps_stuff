# -*- coding: utf-8 -*-
"""Service entry point"""

#from __future__ import absolute_import, division, unicode_literals

#if __name__ == '__main__':
#    from lib.service import run

#    run()

from lib.service import StalkerService

if __name__ == '__main__':
    service = StalkerService()
    service.run()
