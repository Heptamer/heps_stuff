# script.module.mdblist

[English](README.md) | [Deutsch](README.de.md)

Detailed guide: [English](GUIDE.md) · [Deutsch](GUIDE.de.md)

MDBList.com integration for Kodi — scrobbling, library sync and a python
module for third-party addons. Works like the Trakt addon, but for
[MDBList](https://mdblist.com).

Requires a free API key: create/login at mdblist.com → Preferences → API key,
then enter it in the addon settings.

## Features

- **Service** (`xbmc.service`): scrobble playback progress to MDBList
  (start/pause/stop), optional rating prompt after playback (episodes rated
  at episode level), scheduled and event-driven syncs (after library update,
  interval timer, startup delay). Background threads stop cleanly on Kodi
  shutdown, so the service ends within Kodi's 5-second timeout.
- **API-limit aware**: the `X-RateLimit-*` headers of every response are
  persisted, so syncs stop when the daily quota is exhausted and resume
  automatically after the reset. Pause/stop scrobbles that cannot be sent are
  buffered in a small sqlite outbox and replayed afterwards;
  `RunScript(script.module.mdblist, action=apilimit)` shows the remaining
  quota and the reset time.
- **Robust identification** for playback started by widgets/streaming addons
  (e.g. xStream, TMDbHelper): ids and titles are collected from every source
  Kodi exposes (ListItem uniqueids and properties, VideoPlayer InfoLabels
  including `VideoPlayer.UniqueID(...)`, `Player.GetItem`), then resolved via
  the Kodi library (file path, title/year, show + season/episode) and a title
  search that tries the original title first plus cleaned/transliterated
  variants and accepts any provider id. The same chain backs the context menu
  actions, so they work for plugin playback too.
- **Script actions** (`xbmc.python.script`) callable from skins, contexts menus
  or other addons:
  ```
  RunScript(script.module.mdblist, action=contextmenu)
  RunScript(script.module.mdblist, action=sync)
  RunScript(script.module.mdblist, action=repair_watched_dates[,limit=3])
  RunScript(script.module.mdblist, action=rate,type=movie,id=tmdb:769,rating=9)
  RunScript(script.module.mdblist, action=addtowatchlist,type=show,id=tmdb:1399)
  RunScript(script.module.mdblist, action=removefromwatchlist,...)
  RunScript(script.module.mdblist, action=togglewatched,...)
   RunScript(script.module.mdblist, action=markwatched|markunwatched,...)
   RunScript(script.module.mdblist, action=unrate,...)
   RunScript(script.module.mdblist, action=clearprogress[,type=...,id=...])
   RunScript(script.module.mdblist, action=auth_info)
   RunScript(script.module.mdblist, action=apilimit)
   ```
   `id` accepts `tmdb:12345`, `imdb:tt0117731`, `trakt:...`, `tvdb:...`.
   Without `id`/`type` the currently playing item is used.
- **Sync** (bidirectional, each direction switchable):
  - watched status for movies + episodes (plays aware, newest timestamp
    wins; episodes pushed via the documented flat episodes bucket,
    shows handled strictly on the episode level, "whole season watched"
    flags ignored; MDBList authoritative on the pull — items marked
    watched there are marked watched in Kodi, items marked explicitly
    unwatched there are marked unwatched (play count, watch date and any
    resume point reset), anything MDBList does not
    track is left untouched; local "mark unwatched" changes are detected
    via a watched-id baseline and reported to MDBList before the pull
    runs — a fresh install never wipes remote history, and a local
    re-watch newer than a journal removal's own timestamp is kept and
    re-uploaded instead of being stomped by that removal row)
  - continue-watching progress (pull only, on by default): the resume point
    of movies and episodes is taken from MDBList's paused playback sessions,
    so a title stopped on one device can be continued on another. Sessions
    this device pushed itself are ignored, items already watched here are
    left alone, and progress is compared in percent, so a position only
    slightly ahead of the local one is not overwritten
  - ratings (Kodi *userrating* ↔ MDBList rating)
  - optional: sync the Kodi library with the MDBList collection
    (movies + episodes, add-only; off by default)
- **Python module** for other addons:

  ```xml
  <import addon="script.module.mdblist" version="0.1.0"/>
  ```

  ```python
  import mdblist

  api = mdblist.get_api()          # uses the configured user key
  info = api.get_media_info('769', 'movie', 'tmdb')       # ratings, score, ...
  api.add_watchlist_items(movies=[{'tmdb': 769}])
  api.push_ratings([{'type': 'movie', 'ids': {'tmdb': 769}, 'rating': 9}])
  for item in api.iter_all('watchlist/items'):
      ...
  lists = api.get_top_lists() or api.search_lists('star wars')
  items = api.get_list_items(list_id, {'sort': 'score', 'order': 'desc'})
  ```

  Other helpers: `mdblist.has_api_key()` (is a key configured),
  `mdblist.parse_id('tmdb:769')` → `('tmdb', '769')` (also accepts
  `imdb:tt...`), the `mdblist.get_client` alias of `get_api`,
  `mdblist.__version__`, `api.is_authorized()` to validate the key, and
  `api.get_rate_limit()` for the current quota. Quota exhaustion raises
  `mdblist.MDbListRateLimitError`, a subclass of `MDbListError`.

## API coverage (client)

media info & batch, ratings lookup, watchprovider links, search · lists:
top/user/curated/official/liked/recommended/search/share/external + full CRUD
(create/update/delete/add/remove items/like/membership/changes) · watchlist
get/add/remove · sync: watched/collection/ratings/dropped (+seasons)/
last_activities/journal/item state/history/playback sessions · scrobble
start/pause/stop/clear + now-playing · checkin CRUD · upnext (+upcoming/
watchlist) · calendar events + notification prefs · user/profile/stats ·
genres, updates, justwatch streaming charts.

Low-level helpers for anything without a dedicated method:
`api.get_json/post_json/put_json/patch_json/delete_json(path, ...)`, and
`api.get_response(path, ...)` for the raw response (e.g. pagination headers).

Pagination helper:

```python
for item in api.iter_all('watchlist/items'):
    ...
```

## Settings

| Category | Setting |
|---|---|
| General | API key, debug logging, show notifications |
| Scrobbling | enable, minimum progress (%), count as watched from (%) (80-100, default 80), also apply to Kodi's play count threshold, rating prompt (off, minimum progress ≥ 75 %, movie/episode filter) |
| Sync | watched push/pull, ratings push/pull, import continue-watching progress, library to collection (off), startup delay, interval (0 = off), sync after library update |

## Notes on rate limits

The free MDBList account allows 1,000 requests/day (paid tiers allow more);
additionally, 1,000 reads and 300 writes per 5 minutes apply. The addon
therefore caches aggressively (sqlite), uses `/sync/last_activities` to skip
pull-syncs without remote changes and compares pushes against a cached remote
snapshot.

Every response's `X-RateLimit-Limit`, `X-RateLimit-Remaining` and
`X-RateLimit-Reset` headers are persisted. When the quota is exhausted (or a
429 includes `Retry-After`), the addon stops making requests until the reset
instead of sleeping for hours; syncs are skipped and resume automatically
afterwards. **Pause** and **stop** scrobbles that cannot be sent during that
window (or after a transient network/5xx failure) are stored in the small
`scrobbles.db` outbox and replayed automatically before the next sync.
`start`/resume events are not buffered because they only drive the live feed.
The `/scrobble` endpoint has no watch-date parameter, so a replayed stop marks
the item watched at replay time; for library items the normal library sync or
`action=repair_watched_dates` can correct the date.

`RunScript(script.module.mdblist, action=apilimit)` (also **API limit...** in
the context menu) shows used/remaining requests, the local reset time and how
many scrobbles are waiting in the outbox.

## License

GPL-2.0-only — see LICENSE.txt.
