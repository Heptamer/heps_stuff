# -*- coding: utf-8 -*-
import threading
import uuid

import xbmc

from ..identify import collect
from ..logger import log_debug
from ..scrobbler import ScrobbledItem, Scrobbler
from ..utils import get_setting


class MDbListPlayer(xbmc.Player):
    """Watches playback events and forwards them to the scrobbler.
    All API calls run in daemon threads so playback is never blocked."""

    def __init__(self, sync_callback=None):
        super().__init__()
        self.scrobbler = None
        self.current = None          # ScrobbledItem of current playback
        self.last_progress = 0.0
        self._lock = threading.Lock()
        self._sync_callback = sync_callback
        # Kodi's CPythonInvoker waits for every Python sub-thread (even
        # daemon threads) before it stops the addon. The sampler therefore
        # needs a stop signal; without it Kodi kills the service after its
        # 5 second shutdown timeout.
        self._stop_event = threading.Event()
        self._sampler = threading.Thread(
            target=self._sample_loop, name='mdblist-sampler', daemon=True)
        self._sampler.start()

    def request_stop(self):
        """Ask the background sampler to finish (non-blocking)."""
        self._stop_event.set()

    def stop(self, join_timeout=2.0):
        """Stop the sampler and wait briefly for it to finish."""
        self.request_stop()
        if self._sampler is not None and self._sampler.is_alive():
            self._sampler.join(join_timeout)
            if self._sampler.is_alive():
                log_debug('Player sampler did not stop in time')

    @property
    def enabled(self):
        return bool(get_setting('enable_scrobbling', 'bool'))

    def _get_scrobbler(self):
        if self.scrobbler is None:
            min_percent = get_setting('scrobble_min_percent', 'int') or 5
            self.scrobbler = Scrobbler(min_percent=min_percent)
        return self.scrobbler

    def _progress(self):
        try:
            total_time = self.getTotalTime()
            if not total_time or total_time <= 0:
                return 0.0
            progress = (self.getTime() / float(total_time)) * 100
            return max(0.0, min(progress, 100.0))
        except (RuntimeError, TypeError, ZeroDivisionError):
            return 0.0

    def _sample_loop(self):
        """Sample the playback position once a second while something plays.

        The position is kept fresh because on Android the player is already
        torn down when the stop event arrives; without the last sample a stop
        used to fall back to the start position and was dropped below the
        scrobble threshold. The loop ends when request_stop()/stop() is called
        (Kodi only waits 5 seconds for Python threads during shutdown)."""
        while not self._stop_event.is_set():
            try:
                with self._lock:
                    active = self.enabled and self.current is not None
                if active and self.isPlaying():
                    # a 0.0 here means the player already shut down; keep the
                    # last good sample instead of resetting it to the start
                    value = self._progress() or self.last_progress
                    with self._lock:
                        self.last_progress = value
            except Exception as exc:
                log_debug(f'Player sampler error: {exc}')
            # Event.wait() wakes immediately on stop() instead of sleeping
            # through the remaining second
            self._stop_event.wait(1)

    def _dispatch(self, method, item=None, progress=None, on_sent=None):
        target_item = item or self.current
        if not target_item:
            return
        value = self._progress() if progress is None else progress

        def _run():
            sent = self._get_scrobbler().send(
                method, target_item, round(value, 2),
                session_key=getattr(target_item, 'session_key', None))
            if on_sent is not None and sent:
                try:
                    on_sent(sent)
                except Exception as exc:
                    log_debug(f'Post-stop hook failed: {exc}')

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()

    # ------------------------------------------------------------------ #
    # player callbacks                                                   #
    # ------------------------------------------------------------------ #

    def onAVStarted(self):
        """Fired once playback actually started and duration is available."""
        with self._lock:
            try:
                listitem = self.getPlayingItem()
            except RuntimeError:
                listitem = None
            info = collect(listitem)
            if info is None:
                self.current = None
                log_debug('Player: nothing identifiable playing')
                return
            try:
                info.file_path = self.getPlayingFile()
            except RuntimeError:
                info.file_path = None
            self.current = ScrobbledItem(info, session_key=uuid.uuid4().hex)
            self.last_progress = self._progress()
        if not self.enabled:
            return
        self._dispatch('start')

    def onPlayBackResumed(self):
        if not self.enabled or not self.current:
            return
        self._dispatch('start')

    def onPlayBackPaused(self):
        if not self.enabled or not self.current:
            return
        self.last_progress = self._progress()
        self._dispatch('pause', progress=self.last_progress)

    def onPlayBackSeek(self, time_s, seek_offset):
        if self.current:
            self.last_progress = self._progress()

    def onPlayBackStopped(self):
        self._on_end()

    def onPlayBackEnded(self):
        self._on_end(completed=True)

    def _on_end(self, completed=False):
        with self._lock:
            item = self.current
            self.current = None
        if not self.enabled or not item:
            return
        # after end events getTime()/getTotalTime() raise; Kodi logs the
        # raw exception even when caught, so only ask while still playing
        progress = self.last_progress
        if self.isPlaying():
            progress = max(progress, self._progress())
        if completed:
            # the file ran to its end, but the last sample usually sits at
            # 99.x% – without this a threshold of 100% could never be met
            progress = 100.0
        if progress < (get_setting('scrobble_min_percent', 'int') or 5):
            log_debug(f'Playback ended below scrobble threshold ({progress:.1f}%)')
            self._dispatch('stop', item=item, progress=progress)
            return

        def _ask(resolved):
            from ..gui.rateprompt import prompt_rating
            prompt_rating(resolved, progress)

        self._dispatch('stop', item=item, progress=progress, on_sent=_ask)
        if self._sync_callback is not None:
            try:
                self._sync_callback()
            except Exception as exc:
                log_debug(f'Post-scrobble sync trigger failed: {exc}')
