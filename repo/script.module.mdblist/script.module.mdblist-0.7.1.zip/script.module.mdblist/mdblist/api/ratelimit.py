# -*- coding: utf-8 -*-
"""Persistent MDBList API quota tracking.

Every MDBList response carries the daily quota in its headers
(``X-RateLimit-Limit``, ``X-RateLimit-Remaining``, ``X-RateLimit-Reset``).
A 429 additionally carries ``Retry-After``.  The addon uses that data to
stop making requests until the limit resets instead of sleeping for hours
inside a sync/scrobble thread.

The state lives in the addon's sqlite cache so it also survives a Kodi
restart and is shared between the service and script processes.  It is
keyed by a fingerprint of the API key: switching keys must not inherit the
block of the previous account.
"""
import hashlib
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

from ..logger import log_debug, log_error

# cache key of the persisted state
CACHE_KEY = 'api_rate_limit'
# a 429 without Retry-After but with daily quota left is treated as the
# short read/write window (1000 reads / 300 writes per 5 minutes)
BURST_FALLBACK_SECONDS = 5 * 60
# a 429 without any usable header: back off briefly instead of hammering
DEFAULT_BLOCK_SECONDS = 60


def api_key_hash(api_key):
    """Stable, non-reversible fingerprint used to separate accounts."""
    return hashlib.sha256(str(api_key or '').encode('utf-8')).hexdigest()[:16]


def _header_int(headers, *names):
    """First integer value among the given header names, else None."""
    if not headers:
        return None
    for name in names:
        value = headers.get(name)
        if value is None:
            continue
        try:
            return int(float(str(value).strip()))
        except (TypeError, ValueError):
            continue
    return None


def _as_int(value):
    if value is None:
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _parse_reset(value):
    """Normalise a rate-limit reset header to unix epoch seconds."""
    if value is None:
        return None
    try:
        reset = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    # be tolerant about a server that sends milliseconds
    if reset > 10 ** 12:
        reset /= 1000.0
    return reset


def parse_retry_after(value):
    """Parse Retry-After as seconds (integer) or an HTTP date."""
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        return max(int(float(text)), 0)
    except (TypeError, ValueError):
        pass
    try:
        dt = parsedate_to_datetime(text)
    except (TypeError, ValueError, OverflowError):
        return None
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return max(int((dt - datetime.now(timezone.utc)).total_seconds()), 0)


def format_reset(timestamp):
    """Local-time representation of a reset timestamp for dialogs/logs."""
    if not timestamp:
        return '?'
    try:
        return datetime.fromtimestamp(float(timestamp)).strftime(
            '%Y-%m-%d %H:%M')
    except (OverflowError, OSError, TypeError, ValueError):
        return '?'


class RateLimitStore(object):
    """Read/write the quota state; falls back to memory without a cache."""

    def __init__(self, cache=None):
        self._cache = cache
        self._memory = {}
        self._memory_ttl = {}

    # ------------------------------------------------------------------ #
    # storage                                                            #
    # ------------------------------------------------------------------ #

    def _get_cache(self):
        if self._cache is not None:
            return self._cache
        try:
            from ..cache import get_cache
            return get_cache()
        except Exception as exc:  # no Kodi/profile dir available
            log_debug(f'Rate-limit cache unavailable: {exc}')
            return None

    def _load_raw(self, key_hash):
        cache = self._get_cache()
        if cache is not None:
            try:
                data = cache.get(CACHE_KEY)
            except Exception as exc:
                log_debug(f'Rate-limit cache read failed: {exc}')
                data = None
        else:
            data = self._memory.get(key_hash)
            expires = self._memory_ttl.get(key_hash) or 0
            if expires and expires <= time.time():
                data = None
        if not isinstance(data, dict):
            return None
        if data.get('api_key_hash') != key_hash:
            return None
        return data

    def _save_raw(self, key_hash, data):
        ttl = max(int((data.get('blocked_until') or 0) - time.time()), 0)
        ttl = max(ttl + 7 * 86400, 7 * 86400)
        cache = self._get_cache()
        if cache is not None:
            try:
                cache.set(CACHE_KEY, data, ttl=ttl)
                return data
            except Exception as exc:
                log_debug(f'Rate-limit cache write failed: {exc}')
        self._memory[key_hash] = data
        self._memory_ttl[key_hash] = time.time() + ttl
        return data

    # ------------------------------------------------------------------ #
    # public API                                                         #
    # ------------------------------------------------------------------ #

    def load(self, api_key):
        return self._load_raw(api_key_hash(api_key))

    def clear(self, api_key):
        key_hash = api_key_hash(api_key)
        cache = self._get_cache()
        if cache is not None:
            try:
                cache.delete(CACHE_KEY)
            except Exception as exc:
                log_debug(f'Rate-limit cache delete failed: {exc}')
        self._memory.pop(key_hash, None)
        self._memory_ttl.pop(key_hash, None)

    def observe(self, api_key, response):
        """Store the quota headers of one response and return the state.

        A response that reports ``Remaining: 0`` blocks further requests
        until the reset even though the response itself succeeded.  A 429
        sets the block from Retry-After when present; when it is missing,
        a remaining quota above zero means the short read/write window and
        gets a short fallback instead of blocking until midnight."""
        key_hash = api_key_hash(api_key)
        headers = getattr(response, 'headers', None) or {}
        status = getattr(response, 'status_code', None)
        now = time.time()

        limit = _header_int(headers, 'X-RateLimit-Limit', 'RateLimit-Limit')
        remaining = _header_int(
            headers, 'X-RateLimit-Remaining', 'RateLimit-Remaining')
        reset = _parse_reset(headers.get('X-RateLimit-Reset') or
                             headers.get('RateLimit-Reset'))
        retry_after = parse_retry_after(headers.get('Retry-After'))

        previous = self._load_raw(key_hash) or {}
        data = {
            'api_key_hash': key_hash,
            'limit': limit if limit is not None else previous.get('limit'),
            'remaining': (remaining if remaining is not None
                          else previous.get('remaining')),
            'reset': reset if reset is not None else previous.get('reset'),
            'blocked_until': previous.get('blocked_until'),
            'updated_at': now,
        }

        if status == 429:
            if retry_after is not None:
                blocked_until = now + retry_after
            elif remaining is not None and remaining > 0:
                blocked_until = now + BURST_FALLBACK_SECONDS
            elif data.get('reset') and float(data['reset']) > now:
                blocked_until = float(data['reset'])
            else:
                blocked_until = now + DEFAULT_BLOCK_SECONDS
            data['blocked_until'] = blocked_until
            if not previous.get('blocked_until') or \
                    float(previous['blocked_until']) <= now:
                message = (
                    'MDBList API limit reached; pausing requests until {}'
                    .format(format_reset(blocked_until)))
                if blocked_until - now > 60:
                    log_error(message)
                else:
                    log_debug(message)
        elif 200 <= int(status or 0) < 300:
            if remaining == 0 and data.get('reset') and \
                    float(data['reset']) > now:
                data['blocked_until'] = float(data['reset'])
                if not previous.get('blocked_until') or \
                        float(previous['blocked_until']) <= now:
                    message = (
                        'MDBList API quota exhausted; pausing requests '
                        'until {}'.format(format_reset(
                            data['blocked_until'])))
                    if data['blocked_until'] - now > 60:
                        log_error(message)
                    else:
                        log_debug(message)
            elif remaining is not None and remaining > 0:
                data['blocked_until'] = None

        self._save_raw(key_hash, data)
        return self.status(api_key)

    def merge_user(self, api_key, user):
        """Merge the /user endpoint's quota fields into the stored state."""
        if not isinstance(user, dict):
            return self.status(api_key)
        key_hash = api_key_hash(api_key)
        previous = self._load_raw(key_hash) or {}
        now = time.time()
        limit = user.get('rate_limit')
        if limit is None:
            limit = user.get('api_requests')
        used = user.get('api_requests_count')
        remaining = user.get('rate_limit_remaining')
        limit = _as_int(limit)
        used = _as_int(used)
        remaining = _as_int(remaining)
        if remaining is None and limit is not None and used is not None:
            remaining = max(limit - used, 0)
        reset = _parse_reset(user.get('rate_limit_reset'))
        data = {
            'api_key_hash': key_hash,
            'limit': limit if limit is not None else previous.get('limit'),
            'remaining': (remaining if remaining is not None
                          else previous.get('remaining')),
            'reset': reset if reset is not None else previous.get('reset'),
            'blocked_until': previous.get('blocked_until'),
            'used': used if used is not None else previous.get('used'),
            'updated_at': now,
            'source': 'user',
        }
        if remaining == 0 and data.get('reset') and \
                float(data['reset']) > now:
            data['blocked_until'] = float(data['reset'])
        elif remaining is not None and remaining > 0:
            data['blocked_until'] = None
        self._save_raw(key_hash, data)
        return self.status(api_key)

    def status(self, api_key):
        """Current quota state with a convenient ``blocked`` flag."""
        now = time.time()
        data = self._load_raw(api_key_hash(api_key)) or {}
        blocked_until = data.get('blocked_until')
        try:
            blocked_until = float(blocked_until) if blocked_until else None
        except (TypeError, ValueError):
            blocked_until = None
        blocked = bool(blocked_until and blocked_until > now)
        reset = data.get('reset')
        try:
            reset = float(reset) if reset is not None else None
        except (TypeError, ValueError):
            reset = None
        remaining = data.get('remaining')
        # a remaining count older than the reset is stale; the caller can
        # refresh it through /user when it really needs a current value
        if reset is not None and reset <= now:
            remaining = None
        return {
            'blocked': blocked,
            'blocked_until': blocked_until,
            'reset': reset,
            'limit': _as_int(data.get('limit')),
            'remaining': _as_int(remaining),
            'used': _as_int(data.get('used')),
            'updated_at': data.get('updated_at'),
            'source': data.get('source'),
        }

    def is_blocked(self, api_key):
        return bool(self.status(api_key).get('blocked'))


# shared instance used by the HTTP layer and the UI
rate_limits = RateLimitStore()
