# -*- coding: utf-8 -*-
import time

import requests

from ..logger import log_debug, log_error
from .ratelimit import format_reset, rate_limits

BASE_URL = 'https://api.mdblist.com'
# only waits this short are still slept through inside a request; a daily
# limit's Retry-After is measured in hours and must not block the caller
SHORT_RATE_LIMIT_WAIT = 10


class MDbListError(Exception):
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


class MDbListRateLimitError(MDbListError):
    """The API quota is exhausted; no request was sent."""

    def __init__(self, message, status_code=429, reset_at=None,
                 remaining=None):
        super().__init__(message, status_code)
        self.reset_at = reset_at
        self.remaining = remaining

    def __str__(self):
        text = super().__str__()
        if self.reset_at:
            return '{} (resets at {})'.format(text, format_reset(self.reset_at))
        return text


class RequestAPI(object):
    """HTTP layer for the MDBList API.
    - apikey is always appended as query parameter
    - retries with exponential backoff on connection errors / 5xx
    - reads the quota headers of every response and stops making requests
      once the daily limit is exhausted (see api/ratelimit.py)
    - only very short Retry-After values are waited out; longer blocks are
      persisted and fail fast instead of sleeping for hours"""

    def __init__(self, api_key=None, base_url=BASE_URL, timeout=15):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key or ''
        self.timeout = timeout
        self.session = requests.Session()

    def build_url(self, path):
        return '{}/{}'.format(self.base_url, str(path).lstrip('/'))

    def build_params(self, params):
        merged = dict(params or {})
        merged.setdefault('apikey', self.api_key)
        return merged

    def _raise_if_rate_limited(self):
        info = rate_limits.status(self.api_key)
        if info.get('blocked'):
            raise MDbListRateLimitError(
                'MDBList API limit reached',
                reset_at=info.get('blocked_until'),
                remaining=info.get('remaining'))

    def request(self, method, path, params=None, json_data=None, data=None,
                headers=None, retries=3):
        url = self.build_url(path)
        request_params = self.build_params(params)
        self._raise_if_rate_limited()
        attempt = 0
        while True:
            attempt += 1
            try:
                response = self.session.request(
                    method, url, params=request_params, json=json_data, data=data,
                    headers=headers, timeout=self.timeout)
            except requests.exceptions.RequestException as exc:
                if attempt > retries:
                    raise MDbListError(f'Network error: {exc}') from exc
                wait = min(2 ** attempt, 8)
                log_debug(f'Request failed ({exc}), retry {attempt}/{retries} in {wait}s')
                time.sleep(wait)
                continue
            info = rate_limits.observe(self.api_key, response)
            if response.status_code == 429:
                blocked_until = info.get('blocked_until')
                wait = (blocked_until - time.time()) if blocked_until else None
                if wait is not None and 0 < wait <= SHORT_RATE_LIMIT_WAIT \
                        and attempt <= retries:
                    log_debug(
                        f'Rate limited, waiting {wait:.0f}s '
                        f'(attempt {attempt}/{retries})')
                    time.sleep(max(wait, 1))
                    continue
                raise MDbListRateLimitError(
                    'MDBList API rate limit reached',
                    reset_at=blocked_until,
                    remaining=info.get('remaining'))
            if response.status_code >= 500 and attempt <= retries:
                wait = min(2 ** attempt, 8)
                log_debug(f'Server error {response.status_code}, retrying in {wait}s')
                time.sleep(wait)
                continue
            return response

    def get(self, path, **kwargs):
        return self.request('GET', path, **kwargs)

    def post(self, path, **kwargs):
        return self.request('POST', path, **kwargs)

    def put(self, path, **kwargs):
        return self.request('PUT', path, **kwargs)

    def patch(self, path, **kwargs):
        return self.request('PATCH', path, **kwargs)

    def delete(self, path, **kwargs):
        return self.request('DELETE', path, **kwargs)

    @staticmethod
    def parse(response):
        """Parse a Response into python data; raise MDbListError on HTTP errors."""
        if response is None:
            return None
        if not (200 <= getattr(response, 'status_code', 500) < 300):
            body = ''
            try:
                body = response.text[:200]
            except AttributeError:
                pass
            log_error(f'API error {response.status_code}: {body}')
            if getattr(response, 'status_code', None) == 429:
                raise MDbListRateLimitError(
                    'MDBList API rate limit reached', status_code=429)
            raise MDbListError(
                f'MDBList API error {response.status_code}', response.status_code)
        try:
            return response.json()
        except ValueError:
            return None
