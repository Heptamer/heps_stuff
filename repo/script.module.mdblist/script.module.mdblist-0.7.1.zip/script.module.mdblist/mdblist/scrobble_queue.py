# -*- coding: utf-8 -*-
"""Persistent outbox for scrobbles that could not be sent.

The MDBList API has a daily request quota.  When it is exhausted (or the
network is briefly down) a pause/stop scrobble must not be lost: it carries
the watched state or the resume position.  The queue stores those events in
a small sqlite database in the addon profile and the service flushes them
once requests work again.

``start`` events are deliberately not queued: they only drive the live
"now playing" feed and would be wrong after a longer outage.  The following
pause/stop carries the state that matters.

Within one playback session only the newest event is kept (a stop replaces
a pause, a pause replaces an earlier pause); different playback sessions of
the same item stay separate so two real views are not merged.
"""
import json
import sqlite3
import threading
import time

from .api.ratelimit import api_key_hash
from .logger import log_debug, log_error
from .utils import get_profile_dir

QUEUED_METHODS = ('pause', 'stop')
# keep the outbox small and finite; a daily limit normally clears within a
# day, a week is plenty even for a long network outage
MAX_AGE = 7 * 86400
MAX_ENTRIES = 1000


class ScrobbleQueue(object):

    def __init__(self, db_path=None):
        self.db_path = db_path or (get_profile_dir() + 'scrobbles.db')
        self._lock = threading.Lock()
        self._conn = None

    def _connection(self):
        if self._conn is None:
            self._conn = sqlite3.connect(
                self.db_path, timeout=10, check_same_thread=False)
            self._conn.execute(
                'CREATE TABLE IF NOT EXISTS scrobble_queue ('
                'id INTEGER PRIMARY KEY AUTOINCREMENT,'
                'api_key_hash TEXT NOT NULL,'
                'session_key TEXT NOT NULL,'
                'media_key TEXT NOT NULL,'
                'method TEXT NOT NULL,'
                'payload TEXT,'
                'info TEXT,'
                'progress REAL NOT NULL,'
                'event_at REAL NOT NULL,'
                'attempts INTEGER NOT NULL DEFAULT 0,'
                'last_error TEXT)')
            self._conn.execute(
                'CREATE INDEX IF NOT EXISTS scrobble_queue_event '
                'ON scrobble_queue (event_at, id)')
            self._conn.commit()
        return self._conn

    # ------------------------------------------------------------------ #
    # write side                                                         #
    # ------------------------------------------------------------------ #

    def enqueue(self, api_key, session_key, media_key, method, payload=None,
                info=None, progress=0, event_at=None):
        """Add one pause/stop event; newer events of the session replace it."""
        if method not in QUEUED_METHODS:
            return None
        event_at = float(event_at or time.time())
        key_hash = api_key_hash(api_key)
        try:
            payload_text = (json.dumps(payload, ensure_ascii=False)
                            if payload else None)
            info_text = (json.dumps(info, ensure_ascii=False)
                         if info else None)
        except (TypeError, ValueError) as exc:
            log_error(f'Scrobble queue serialization failed: {exc}')
            return None
        row = (
            key_hash,
            str(session_key or media_key or ''),
            str(media_key or ''),
            method,
            payload_text,
            info_text,
            round(float(progress or 0), 2),
            event_at,
        )
        with self._lock:
            conn = self._connection()
            try:
                with conn:
                    # one session keeps only its latest state: stop supersedes
                    # pause, a later pause supersedes an earlier one
                    conn.execute(
                        'DELETE FROM scrobble_queue WHERE api_key_hash = ? '
                        'AND session_key = ?', (key_hash, row[1]))
                    cursor = conn.execute(
                        'INSERT INTO scrobble_queue '
                        '(api_key_hash, session_key, media_key, method, '
                        'payload, info, progress, event_at) '
                        'VALUES (?, ?, ?, ?, ?, ?, ?, ?)', row)
                    entry_id = cursor.lastrowid
                self._purge(conn)
                return entry_id
            except sqlite3.Error as exc:
                log_error(f'Scrobble queue write failed: {exc}')
                return None

    def _purge(self, conn):
        """Drop expired and excess entries (oldest first)."""
        now = time.time()
        try:
            with conn:
                conn.execute(
                    'DELETE FROM scrobble_queue WHERE event_at < ?',
                    (now - MAX_AGE,))
                count = conn.execute(
                    'SELECT COUNT(*) FROM scrobble_queue').fetchone()[0]
                excess = int(count or 0) - MAX_ENTRIES
                if excess > 0:
                    conn.execute(
                        'DELETE FROM scrobble_queue WHERE id IN ('
                        'SELECT id FROM scrobble_queue '
                        'ORDER BY event_at, id LIMIT ?)', (excess,))
                    log_debug(f'Scrobble queue: dropped {excess} oldest '
                              f'entries (limit {MAX_ENTRIES})')
        except sqlite3.Error as exc:
            log_debug(f'Scrobble queue purge failed: {exc}')

    def delete(self, entry_id):
        with self._lock:
            try:
                with self._connection() as conn:
                    conn.execute(
                        'DELETE FROM scrobble_queue WHERE id = ?', (entry_id,))
            except sqlite3.Error as exc:
                log_error(f'Scrobble queue delete failed: {exc}')

    def delete_session(self, api_key, session_key, before=None):
        """Drop buffered events that a live send has superseded."""
        if not session_key:
            return
        with self._lock:
            try:
                with self._connection() as conn:
                    if before is None:
                        conn.execute(
                            'DELETE FROM scrobble_queue WHERE api_key_hash = ? '
                            'AND session_key = ?',
                            (api_key_hash(api_key), str(session_key)))
                    else:
                        conn.execute(
                            'DELETE FROM scrobble_queue WHERE api_key_hash = ? '
                            'AND session_key = ? AND event_at <= ?',
                            (api_key_hash(api_key), str(session_key),
                             float(before)))
            except sqlite3.Error as exc:
                log_error(f'Scrobble queue session delete failed: {exc}')

    def mark_attempt(self, entry_id, error=None):
        """Count one failed attempt and return the new count."""
        with self._lock:
            try:
                with self._connection() as conn:
                    conn.execute(
                        'UPDATE scrobble_queue SET attempts = attempts + 1, '
                        'last_error = ? WHERE id = ?',
                        (str(error)[:500] if error else None, entry_id))
                    row = conn.execute(
                        'SELECT attempts FROM scrobble_queue WHERE id = ?',
                        (entry_id,)).fetchone()
                return int(row[0]) if row else 0
            except sqlite3.Error as exc:
                log_error(f'Scrobble queue update failed: {exc}')
                return 0

    # ------------------------------------------------------------------ #
    # read side                                                          #
    # ------------------------------------------------------------------ #

    def pending(self, api_key, limit=50):
        key_hash = api_key_hash(api_key)
        oldest = time.time() - MAX_AGE
        with self._lock:
            try:
                rows = self._connection().execute(
                    'SELECT id, session_key, media_key, method, payload, info, '
                    'progress, event_at, attempts FROM scrobble_queue '
                    'WHERE api_key_hash = ? AND event_at >= ? '
                    'ORDER BY event_at, id LIMIT ?',
                    (key_hash, oldest, int(limit))).fetchall()
            except sqlite3.Error as exc:
                log_error(f'Scrobble queue read failed: {exc}')
                return []
        entries = []
        for row in rows:
            entries.append({
                'id': row[0],
                'session_key': row[1],
                'media_key': row[2],
                'method': row[3],
                'payload': _json_load(row[4]),
                'info': _json_load(row[5]),
                'progress': float(row[6] or 0),
                'event_at': float(row[7] or 0),
                'attempts': int(row[8] or 0),
            })
        return entries

    def count(self, api_key=None):
        oldest = time.time() - MAX_AGE
        with self._lock:
            try:
                if api_key is None:
                    row = self._connection().execute(
                        'SELECT COUNT(*) FROM scrobble_queue '
                        'WHERE event_at >= ?', (oldest,)).fetchone()
                else:
                    row = self._connection().execute(
                        'SELECT COUNT(*) FROM scrobble_queue '
                        'WHERE api_key_hash = ? AND event_at >= ?',
                        (api_key_hash(api_key), oldest)).fetchone()
                return int(row[0]) if row else 0
            except sqlite3.Error as exc:
                log_error(f'Scrobble queue count failed: {exc}')
                return 0

    def clear(self):
        with self._lock:
            try:
                with self._connection() as conn:
                    conn.execute('DELETE FROM scrobble_queue')
            except sqlite3.Error as exc:
                log_error(f'Scrobble queue clear failed: {exc}')

    def close(self):
        with self._lock:
            if self._conn is not None:
                try:
                    self._conn.close()
                except sqlite3.Error:
                    pass
                self._conn = None


def _json_load(value):
    if not value:
        return None
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return None


_queue = None


def get_queue():
    global _queue
    if _queue is None:
        _queue = ScrobbleQueue()
    return _queue
