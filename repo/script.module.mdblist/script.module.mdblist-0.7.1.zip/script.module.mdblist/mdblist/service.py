# -*- coding: utf-8 -*-
"""Background service: player monitoring (scrobbling) + scheduled syncs."""
import threading
import time
import traceback

import xbmc
import xbmcgui

from .cache import get_cache
from .api.ratelimit import format_reset, rate_limits
from .logger import log_debug, log_error
from .monitor.player import MDbListPlayer
from .sync.engine import SyncEngine
from .utils import (get_kodi_setting, get_setting, has_api_key, localized,
                    notify, set_kodi_setting)

# Kodi's own watched threshold; it drives playcount, which in turn drives
# what the library sync pushes
KODI_PLAYCOUNT_SETTING = 'videolibrary.playcountminimumpercent'
# how long a scan/clean stamp stays readable for the watched sync
LIBRARY_EVENT_TTL = 30 * 86400


class MDbListService(xbmc.Monitor):

    def __init__(self):
        super().__init__()
        self.player = MDbListPlayer(sync_callback=self.do_sync)
        self._pending_sync = False
        self._last_interval_sync = time.time()
        self._last_queue_flush = time.time()
        self._rate_limit_notified_until = None
        self._rate_limit_logged_until = None
        self._stop_event = threading.Event()
        self._startup_timer = None

    # ------------------------------------------------------------------ #
    # monitor callbacks                                                  #
    # ------------------------------------------------------------------ #

    def onNotification(self, sender, method, data):
        if method in ('VideoLibrary.OnScanFinished',
                      'VideoLibrary.OnCleanFinished'):
            # Stamp the event unconditionally: the watched sync compares it
            # against its local watched baseline, so a rescan (which can wipe
            # the playcounts of a deleted and re-added item) is never
            # mistaken for a deliberate local "mark unwatched".
            get_cache().set('library_event', time.time(),
                            ttl=LIBRARY_EVENT_TTL)
            if get_setting('sync_on_update', 'bool'):
                log_debug(f'Library event ({method}), scheduling sync')
                self._pending_sync = True

    def onSettingsChanged(self):
        log_debug('Settings changed')
        self._align_watched_threshold()

    def onAbortRequested(self):
        """Kodi is shutting down; wake the sampler and pending timer now."""
        log_debug('Abort requested')
        self._stop_event.set()
        self.player.request_stop()
        self._cancel_startup_timer()

    def _cancel_startup_timer(self):
        timer = self._startup_timer
        self._startup_timer = None
        if timer is not None:
            try:
                timer.cancel()
            except Exception as exc:
                log_debug(f'Startup timer cancel failed: {exc}')

    def _stopping(self):
        return self._stop_event.is_set()

    def _shutdown(self):
        """Release every long-lived thread before Kodi's 5s timeout."""
        self._stop_event.set()
        self._cancel_startup_timer()
        self.player.stop()
        log_debug('Service stopped')

    # ------------------------------------------------------------------ #
    # watched threshold                                                  #
    # ------------------------------------------------------------------ #

    def _align_watched_threshold(self):
        """Keep Kodi's playcount threshold in step with our own.

        The scrobbler honours 'watched_min_percent' on its own, but the
        library sync pushes whatever Kodi counted as watched. If Kodi's
        threshold is the lower one, it would mark items watched below our
        threshold and the next sync would push them anyway."""
        own = int(get_setting('watched_min_percent', 'int') or 80)
        kodi = get_kodi_setting(KODI_PLAYCOUNT_SETTING)
        if kodi is None:
            log_debug(f'Kodi setting {KODI_PLAYCOUNT_SETTING} unavailable, '
                      'watched threshold not compared')
            return
        try:
            kodi = int(kodi)
        except (TypeError, ValueError):
            return
        if not get_setting('watched_apply_to_kodi', 'bool'):
            if own > kodi:
                log_debug(f'Watched threshold is {own}% but Kodi counts from '
                          f'{kodi}%, so the library sync can still report '
                          'items as watched below the threshold – enable '
                          '"apply to Kodi" to align both')
            return
        if kodi == own:
            return
        if set_kodi_setting(KODI_PLAYCOUNT_SETTING, own):
            log_debug(f'Kodi playcount threshold aligned: {kodi}% -> {own}%')
        else:
            log_error(f'Could not set {KODI_PLAYCOUNT_SETTING} to {own}%')

    # ------------------------------------------------------------------ #
    # sync execution                                                     #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _api_key():
        return get_setting('api_key', 'str') or ''

    def _rate_limit_info(self):
        return rate_limits.status(self._api_key())

    def _notify_rate_limited(self, info):
        until = (info or {}).get('blocked_until') or (info or {}).get(
            'reset_at')
        if not until or self._rate_limit_notified_until == until:
            return
        self._rate_limit_notified_until = until
        if not get_setting('show_notifications', 'bool'):
            return
        message = localized(32151)
        if message:
            notify(message.format(format_reset(until)),
                   icon=xbmcgui.NOTIFICATION_WARNING)

    def _flush_scrobbles(self):
        """Replay buffered scrobbles; safe to call while another flush runs."""
        if self._stopping():
            return {'status': 'stopped', 'pending': 0}
        if not has_api_key():
            return {'status': 'no_key', 'pending': 0}
        try:
            from .scrobbler import Scrobbler
            result = Scrobbler().flush_pending(
                should_abort=self._stopping)
        except Exception as exc:
            log_error(f'Scrobble queue flush failed: {exc}')
            return {'status': 'error', 'pending': 0}
        self._last_queue_flush = time.time()
        return result

    def do_sync(self, force=False, silent=True):
        if self._stopping():
            log_debug('Sync skipped: service stopping')
            return
        if not has_api_key():
            log_debug('Sync skipped: no API key')
            return
        info = self._rate_limit_info()
        if info.get('blocked'):
            self._notify_rate_limited(info)
            log_debug(
                'Sync skipped: API limit reached until {}'.format(
                    format_reset(info.get('blocked_until'))))
            return

        def _worker():
            started = time.time()
            try:
                flush = self._flush_scrobbles()
                summary = SyncEngine().run(
                    force=force, should_abort=self._stopping)
                if flush:
                    summary['scrobble_flush'] = flush
                log_debug(f'Sync finished in {time.time() - started:.1f}s: {summary}')
                if summary.get('rate_limited'):
                    # a request hit the limit while this run was executing
                    self._notify_rate_limited(summary['rate_limited'])
                    if not silent:
                        notify(localized(32151).format(format_reset(
                            summary['rate_limited'].get('reset_at'))) or
                               'API limit reached',
                               icon=xbmcgui.NOTIFICATION_WARNING)
                elif not silent:
                    notify(localized(32112) or 'Sync finished')
            except Exception as exc:
                log_error(f'Sync failed: {exc}\n{traceback.format_exc()}')
                if not silent:
                    notify(localized(32125) or 'Sync failed')

        threading.Thread(target=_worker, daemon=True).start()

    def startup_sync(self):
        delay = int(get_setting('sync_startup_delay', 'int') or 0)
        if not has_api_key():
            log_debug('No API key configured yet')
            return
        log_debug(f'Startup sync in {delay}s')
        timer = threading.Timer(delay, self.do_sync)
        timer.daemon = True
        self._startup_timer = timer
        timer.start()

    # ------------------------------------------------------------------ #
    # main loop                                                          #
    # ------------------------------------------------------------------ #

    def run(self):
        log_debug('Service starting')
        try:
            self._align_watched_threshold()
            if has_api_key() and not self._stopping():
                # an outbox left over from the last session should not wait
                # for the configured startup sync delay
                threading.Thread(target=self._flush_scrobbles,
                                 daemon=True).start()
            self.startup_sync()
            while not self.waitForAbort(30):
                if self._stopping():
                    break
                now = time.time()
                info = self._rate_limit_info()
                if info.get('blocked'):
                    if self._rate_limit_logged_until != info.get(
                            'blocked_until'):
                        self._rate_limit_logged_until = info.get(
                            'blocked_until')
                        log_debug(
                            'Sync paused: API limit reached until {}'.format(
                                format_reset(info.get('blocked_until'))))
                        self._notify_rate_limited(info)
                    # keep pending library events for after the reset
                    continue
                if self._rate_limit_logged_until is not None:
                    log_debug('API limit reset, resuming sync')
                    self._rate_limit_logged_until = None
                    self._rate_limit_notified_until = None
                    self._pending_sync = True
                if self._pending_sync:
                    self._pending_sync = False
                    # A rescan can mean a show was deleted and re-added,
                    # wiping its local playcounts. Without remote activity
                    # changes the pulls would be skipped entirely, so a
                    # library event forces them to re-apply the remote
                    # watched state.
                    self.do_sync(force=True)
                    self._last_interval_sync = now
                    continue
                if now - self._last_queue_flush >= 300:
                    self._last_queue_flush = now
                    threading.Thread(target=self._flush_scrobbles,
                                     daemon=True).start()
                interval_minutes = int(
                    get_setting('sync_interval', 'int') or 0)
                if interval_minutes > 0 and \
                        now - self._last_interval_sync >= \
                        interval_minutes * 60:
                    log_debug('Interval sync due')
                    self._last_interval_sync = now
                    self.do_sync()
        finally:
            self._shutdown()


def run():
    try:
        MDbListService().run()
    except Exception as exc:
        log_error(f'Service crashed: {exc}\n{traceback.format_exc()}')
