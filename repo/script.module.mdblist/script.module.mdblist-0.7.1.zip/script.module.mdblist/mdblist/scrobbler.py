# -*- coding: utf-8 -*-
"""Scrobble playback progress to MDBList (start/pause/stop).

Identification is delegated to the shared mdblist.identify module, which
collects ids/titles from every source Kodi exposes and resolves them via
existing ids, the Kodi library or a title search. A scrobble rejected
with 404 (unknown id) is retried once with a fresh title-search id before
giving up. Payloads follow the MDBList API spec: episodes use nested
season structures and numeric tmdb/trakt/tvdb ids.

Pause and stop events that cannot be sent because the API quota is
exhausted (or the network/5xx fails) are written to the scrobble outbox
(see mdblist/scrobble_queue.py) and replayed once requests work again.
"""
import time
import uuid
from datetime import datetime, timezone

from . import identify, resume
from .api.mapping import typed_ids
from .api.ratelimit import rate_limits
from .api.request import MDbListError, MDbListRateLimitError
from .logger import log_debug, log_error
from .scrobble_queue import get_queue
from .sync.lock import SyncLock
from .utils import (datetime_to_iso, get_setting, localized, notify)

# /scrobble/stop and /scrobble/pause mark an item watched from this progress
# on (https://api.mdblist.com/schema/). The cutoff is fixed server-side, so a
# higher local threshold can only be honoured through the value we report.
SERVER_WATCHED_PERCENT = 80.0
# methods the cutoff applies to; 'start' only updates the session and 'clear'
# carries no progress, so both are reported unchanged
WATCHED_METHODS = ('stop', 'pause')
# how often a queued entry may fail with 404/4xx before it is discarded
QUEUE_MAX_ATTEMPTS = 3
# only one "scrobbles buffered" notification per process
_QUEUE_NOTICE_SHOWN = False


class _QueueUnresolved(Exception):
    """A queued item could not be identified yet and should be retried."""


class ScrobbledItem(object):
    """Wraps a MediaInfo for scrobbling; provider/media_id are filled by
    the identification chain while the scrobble is sent."""

    def __init__(self, info, session_key=None):
        self.info = info
        self.provider = info.provider
        self.media_id = info.media_id
        self.session_key = session_key

    @property
    def mediatype(self):
        return self.info.mediatype

    @property
    def season(self):
        return self.info.season

    @property
    def episode(self):
        return self.info.episode

    @property
    def title(self):
        return self.info.search_title or self.info.title

    @property
    def year(self):
        return self.info.year

    @property
    def file_path(self):
        return self.info.file_path

    @property
    def valid(self):
        return self.info.valid

    def build_payload(self, progress=0):
        payload = {'progress': round(float(progress or 0), 2)}
        ids = typed_ids({self.provider: self.media_id})
        if self.mediatype == 'episode':
            if self.season is None or self.episode is None:
                return None
            payload['show'] = {
                'ids': ids,
                'season': {'number': int(self.season),
                           'episode': {'number': int(self.episode)}},
            }
        else:
            payload['movie'] = {'ids': ids}
        return payload


class Scrobbler(object):

    def __init__(self, api=None, min_percent=5, cache=None,
                 watched_percent=None, queue=None):
        from . import get_api
        from .cache import get_cache
        self.api = api or get_api(cache=False)
        self.cache = cache or get_cache()
        self.min_percent = max(int(min_percent), 0)
        # None = read the setting on every send; the player caches this
        # instance, so a frozen value would need a Kodi restart to take effect
        self.watched_percent = watched_percent
        self.queue = queue or get_queue()

    def _watched_threshold(self):
        """Progress at which the user considers an item watched (80-100)."""
        value = self.watched_percent
        if value is None:
            value = get_setting('watched_min_percent', 'int')
        try:
            value = float(value or SERVER_WATCHED_PERCENT)
        except (TypeError, ValueError):
            value = SERVER_WATCHED_PERCENT
        return max(SERVER_WATCHED_PERCENT, min(value, 100.0))

    def _reported_progress(self, method, progress):
        """Map the local progress onto the server's fixed watched cutoff.

        Reaching the threshold is reported as 100 so the item is definitely
        marked watched; below it the value is held just under the server
        cutoff, which keeps the item unwatched and leaves a resume point
        instead. Anything below that cutoff passes through untouched, so the
        default threshold of 80 behaves exactly like no mapping at all."""
        progress = float(progress or 0)
        if method not in WATCHED_METHODS:
            return progress
        threshold = self._watched_threshold()
        if progress >= threshold:
            return 100.0
        return min(progress, SERVER_WATCHED_PERCENT - 1.0)

    # ------------------------------------------------------------------ #
    # identification                                                     #
    # ------------------------------------------------------------------ #

    def _identify(self, item):
        """Resolve provider+media_id; returns the identification source."""
        info = identify.resolve(item.info, api=self.api, cache=self.cache)
        if info is None:
            return None
        item.provider = info.provider
        item.media_id = info.media_id
        return info.source or 'unknown'

    # ------------------------------------------------------------------ #
    # scrobbling                                                         #
    # ------------------------------------------------------------------ #

    def _post(self, method, item, progress, payload=None):
        """Send one scrobble request; returns the parsed response."""
        payload = payload or item.build_payload(progress)
        if payload is None:
            raise ValueError('incomplete episode info')
        return self.api.scrobble(method, movie=payload.get('movie'),
                                 show=payload.get('show'),
                                 progress=payload['progress'])

    def _remember_session(self, method, item, progress, response):
        """Note the paused session this device just created on MDBList.

        The sync needs that to tell its own session apart from another
        device's: without it every sync would rewrite the resume point of
        the item that was just played here, derived from a runtime that
        need not match the local file.
        """
        if method not in ('pause', 'stop'):
            return
        if progress >= SERVER_WATCHED_PERCENT:
            return  # above the cutoff MDBList marks it watched instead
        if not item.provider or not item.media_id:
            return
        if item.mediatype == 'episode' and (item.season is None or
                                            item.episode is None):
            return
        data = response if isinstance(response, dict) else {}
        try:
            session_id = int(data['id']) if data.get('id') is not None \
                else None
        except (TypeError, ValueError):
            session_id = None
        # 'pause' answers with the session's own paused_at (server clock),
        # 'stop' documents only 'progress' - then our send time is the best
        # available reference, and remote_is_newer() treats it as uncertain
        paused_at = (data.get('paused_at') or data.get('updated_at') or
                     resume.now_iso())
        if item.mediatype == 'episode':
            key = resume.episode_key(item.provider, item.media_id,
                                     item.season, item.episode)
        else:
            key = resume.movie_key(item.provider, item.media_id)
        resume.mark_pushed(key, progress, session_id, paused_at)

    def _remember_payload_session(self, entry, payload, response):
        """Store the resume record of a replayed queue entry."""
        method = entry.get('method')
        progress = float(entry.get('progress') or 0)
        if method not in ('pause', 'stop') or \
                progress >= SERVER_WATCHED_PERCENT:
            return
        data = response if isinstance(response, dict) else {}
        try:
            session_id = int(data['id']) if data.get('id') is not None \
                else None
        except (TypeError, ValueError):
            session_id = None
        event_at = entry.get('event_at')
        try:
            event_iso = datetime_to_iso(
                datetime.fromtimestamp(float(event_at), timezone.utc))
        except (TypeError, ValueError, OverflowError, OSError):
            event_iso = resume.now_iso()
        paused_at = (data.get('paused_at') or data.get('updated_at') or
                     event_iso)
        if payload.get('movie'):
            ids = payload['movie'].get('ids') or {}
            provider = _first_id(ids)
            if not provider:
                return
            key = resume.movie_key(provider, ids[provider])
        else:
            show = payload.get('show') or {}
            ids = show.get('ids') or {}
            provider = _first_id(ids)
            season = (show.get('season') or {}).get('number')
            episode = ((show.get('season') or {}).get('episode') or {}).get(
                'number')
            if not provider or season is None or episode is None:
                return
            key = resume.episode_key(provider, ids[provider], season, episode)
        resume.mark_pushed(key, progress, session_id, paused_at)

    def _retry_via_search(self, method, item, progress):
        """After a 404: retry once with a fresh title-search id.
        Returns (retried_ok, response)."""
        failed = (item.provider, str(item.media_id))
        saved = (item.provider, item.media_id)
        # search without the cache so a possibly stale id is not reused
        provider, media_id = identify.search_lookup(item.info, self.api,
                                                    cache=None)
        if not provider or (provider, str(media_id)) == failed:
            item.provider, item.media_id = saved
            return False, None
        item.provider, item.media_id = provider, str(media_id)
        log_debug(f'SCROBBLE [{method}] 404 for {failed[0]}:{failed[1]}, '
                  f'retrying via search id {item.provider}:{item.media_id}')
        try:
            response = self._post(method, item, progress)
        except MDbListRateLimitError:
            # keep the fresh id: the caller will queue the payload with it
            raise
        except Exception as exc:
            log_error(f'SCROBBLE [{method}] retry failed for '
                      f'{item.provider}:{item.media_id}: {exc}')
            item.provider, item.media_id = saved
            return False, None
        self._notify(method, item)
        return True, response

    # ------------------------------------------------------------------ #
    # outbox                                                             #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _info_dict(info):
        if info is None:
            return None
        return {
            'mediatype': info.mediatype,
            'title': info.title,
            'original_title': info.original_title,
            'year': info.year,
            'show_title': info.show_title,
            'season': info.season,
            'episode': info.episode,
            'file_path': info.file_path,
            'ids': dict(info.ids or {}),
        }

    @staticmethod
    def _info_from_dict(data):
        if not isinstance(data, dict):
            return None
        return identify.MediaInfo(
            mediatype=data.get('mediatype'),
            title=data.get('title'),
            original_title=data.get('original_title'),
            year=data.get('year'),
            show_title=data.get('show_title'),
            season=data.get('season'),
            episode=data.get('episode'),
            file_path=data.get('file_path'),
            ids=data.get('ids') or {})

    @staticmethod
    def _media_key(item):
        if not item.provider or not item.media_id:
            return ''
        key = '{}:{}'.format(item.provider, item.media_id)
        if item.mediatype == 'episode':
            key += ':S{}E{}'.format(item.season, item.episode)
        return key

    def _queue_event(self, method, item, progress, session_key=None,
                     payload=None, error=None):
        """Store one pause/stop event for later delivery.

        ``start`` is intentionally not queued: it only affects the live
        now-playing feed and would be stale after a longer limit."""
        if method not in ('pause', 'stop') or self.queue is None:
            return False
        session_key = (session_key or getattr(item, 'session_key', None) or
                       uuid.uuid4().hex)
        info = self._info_dict(item.info)
        entry_id = self.queue.enqueue(
            getattr(self.api, 'api_key', '') or '', session_key,
            self._media_key(item), method, payload=payload, info=info,
            progress=progress, event_at=time.time())
        if not entry_id:
            log_error(f'SCROBBLE [{method}] could not be buffered: '
                      f'{item.provider}:{item.media_id}')
            return False
        log_debug(f'SCROBBLE [{method}] buffered for later delivery '
                  f'({error or "no response"}): '
                  f'{item.provider}:{item.media_id} "{item.title}"')
        self._notify_queued()
        return True

    def _notify_queued(self):
        global _QUEUE_NOTICE_SHOWN
        if _QUEUE_NOTICE_SHOWN:
            return
        _QUEUE_NOTICE_SHOWN = True
        if not get_setting('show_notifications', 'bool'):
            return
        message = localized(32153)
        if message:
            pending = self.queue.count(getattr(self.api, 'api_key', '') or '')
            notify(message.format(pending))

    def _clear_queued_session(self, item, session_key=None):
        """Drop buffered events superseded by a successful live send."""
        if self.queue is None:
            return
        session_key = session_key or getattr(item, 'session_key', None)
        if session_key:
            self.queue.delete_session(
                getattr(self.api, 'api_key', '') or '', session_key,
                before=time.time())

    def _send_entry(self, entry):
        """Replay one queue entry; returns the API response."""
        payload = entry.get('payload')
        info = self._info_from_dict(entry.get('info'))
        if not payload:
            if info is None:
                raise _QueueUnresolved('no payload or media info')
            resolved = identify.resolve(info, api=self.api, cache=self.cache)
            if resolved is None:
                raise _QueueUnresolved('could not identify item')
            payload = ScrobbledItem(resolved).build_payload(entry['progress'])
            if payload is None:
                raise _QueueUnresolved('incomplete episode info')
        response = self.api.scrobble(
            entry['method'], movie=payload.get('movie'),
            show=payload.get('show'), progress=entry['progress'])
        try:
            self._remember_payload_session(entry, payload, response)
        except Exception as exc:
            log_debug(f'Scrobble queue resume bookkeeping failed: {exc}')
        return response

    def _retry_entry_via_search(self, entry):
        """Resolve a queued 404 entry again by title and replay it."""
        info = self._info_from_dict(entry.get('info'))
        if info is None:
            return False
        provider, media_id = identify.search_lookup(info, self.api, cache=None)
        if not provider:
            return False
        info.provider, info.media_id = provider, str(media_id)
        payload = ScrobbledItem(info).build_payload(entry['progress'])
        if payload is None:
            return False
        response = self.api.scrobble(
            entry['method'], movie=payload.get('movie'),
            show=payload.get('show'), progress=entry['progress'])
        try:
            self._remember_payload_session(entry, payload, response)
        except Exception as exc:
            log_debug(f'Scrobble queue resume bookkeeping failed: {exc}')
        log_debug(f'Scrobble queue: replayed {entry["method"]} for '
                  f'{provider}:{media_id} via search')
        return True

    def flush_pending(self, limit=50, should_abort=None):
        """Send buffered scrobbles until the queue is empty or blocked.

        Returns a small summary dict; a 429/network failure keeps the
        remaining entries for the next attempt. ``should_abort`` is polled
        between entries so a service shutdown does not flush the whole
        outbox before Kodi's thread timeout."""
        api_key = getattr(self.api, 'api_key', '') or ''
        if not get_setting('enable_scrobbling', 'bool'):
            return {'status': 'disabled',
                    'pending': self.queue.count(api_key) if api_key else 0}
        if not api_key:
            return {'status': 'no_key', 'pending': self.queue.count()}
        blocked = rate_limits.status(api_key)
        if blocked.get('blocked'):
            return {'status': 'rate_limited',
                    'pending': self.queue.count(api_key),
                    'reset_at': blocked.get('blocked_until')}
        if should_abort is not None and should_abort():
            return {'status': 'aborted', 'pending': self.queue.count(api_key)}
        lock = SyncLock('scrobble_queue', ttl=600)
        if not lock.acquire(timeout=30):
            return {'status': 'busy', 'pending': self.queue.count(api_key)}
        sent = dropped = 0
        status = 'ok'
        try:
            entries = self.queue.pending(api_key, limit=limit)
            for entry in entries:
                if should_abort is not None and should_abort():
                    status = 'aborted'
                    break
                try:
                    self._send_entry(entry)
                except MDbListRateLimitError as exc:
                    status = 'rate_limited'
                    log_debug(f'Scrobble queue paused: {exc}')
                    break
                except _QueueUnresolved as exc:
                    attempts = self.queue.mark_attempt(entry['id'], exc)
                    if attempts >= QUEUE_MAX_ATTEMPTS:
                        self.queue.delete(entry['id'])
                        dropped += 1
                    continue
                except MDbListError as exc:
                    if exc.status_code == 404:
                        try:
                            retried = self._retry_entry_via_search(entry)
                        except MDbListRateLimitError as rate_exc:
                            status = 'rate_limited'
                            log_debug(f'Scrobble queue paused: {rate_exc}')
                            break
                        except Exception as retry_exc:
                            retried = False
                            log_debug(f'Scrobble queue 404 retry failed: '
                                      f'{retry_exc}')
                        if retried:
                            self.queue.delete(entry['id'])
                            sent += 1
                            continue
                        attempts = self.queue.mark_attempt(
                            entry['id'], exc)
                        if attempts >= QUEUE_MAX_ATTEMPTS:
                            self.queue.delete(entry['id'])
                            dropped += 1
                        continue
                    if exc.status_code in (401, 403):
                        status = 'auth_failed'
                        break
                    if exc.status_code is None or exc.status_code >= 500:
                        self.queue.mark_attempt(entry['id'], exc)
                        status = 'transient'
                        break
                    attempts = self.queue.mark_attempt(entry['id'], exc)
                    if attempts >= QUEUE_MAX_ATTEMPTS:
                        self.queue.delete(entry['id'])
                        dropped += 1
                    continue
                except Exception as exc:
                    self.queue.mark_attempt(entry['id'], exc)
                    status = 'error'
                    break
                self.queue.delete(entry['id'])
                sent += 1
                if rate_limits.is_blocked(api_key):
                    status = 'rate_limited'
                    break
        finally:
            lock.release()
        pending = self.queue.count(api_key)
        result = {'status': status, 'sent': sent, 'dropped': dropped,
                  'pending': pending}
        log_debug(f'Scrobble queue flush: {result}')
        if sent and get_setting('show_notifications', 'bool'):
            message = localized(32154)
            if message:
                notify(message.format(sent))
        return result

    # ------------------------------------------------------------------ #
    # sending                                                            #
    # ------------------------------------------------------------------ #

    def send(self, method, item, progress=0, session_key=None):
        if not item or not item.valid:
            log_debug('SCROBBLE skipped: no identifiable item')
            return None
        try:
            source = self._identify(item)
        except MDbListRateLimitError as exc:
            reported = self._reported_progress(method, progress)
            payload = item.build_payload(reported) \
                if item.provider and item.media_id else None
            self._queue_event(method, item, reported, session_key,
                              payload=payload, error=exc)
            return None
        if not source:
            log_error(f'SCROBBLE skipped: could not resolve '
                      f'"{item.title}" ({item.mediatype})')
            return None
        reported = self._reported_progress(method, progress)
        mapped = '' if reported == float(progress or 0) else \
            f' (reported as {reported:.1f}%, threshold ' \
            f'{self._watched_threshold():.0f}%)'
        log_debug(f'SCROBBLE [{method}] (id: {source}) '
                  f'{item.provider}:{item.media_id} '
                  f'"{item.title}" at {progress}%{mapped}')
        payload = item.build_payload(reported)
        try:
            response = self._post(method, item, reported, payload=payload)
        except MDbListRateLimitError as exc:
            self._queue_event(method, item, reported, session_key,
                              payload=payload, error=exc)
            return None
        except MDbListError as exc:
            if exc.status_code == 404:
                try:
                    retried, response = self._retry_via_search(
                        method, item, reported)
                except MDbListRateLimitError as rate_exc:
                    self._queue_event(
                        method, item, reported, session_key,
                        payload=item.build_payload(reported), error=rate_exc)
                    return None
                if retried:
                    self._remember_session(method, item, reported, response)
                    self._clear_queued_session(item, session_key)
                    return item
            elif exc.status_code is None or exc.status_code >= 500:
                self._queue_event(method, item, reported, session_key,
                                  payload=payload, error=exc)
                log_error(f'SCROBBLE [{method}] buffered after transient '
                          f'failure for {item.provider}:{item.media_id} '
                          f'"{item.title}": {exc}')
                return None
            log_error(f'SCROBBLE [{method}] failed for {item.provider}:'
                      f'{item.media_id} "{item.title}": {exc}')
            return None
        except ValueError:
            log_debug('SCROBBLE skipped: incomplete episode info')
            return None
        except Exception as exc:  # never block playback on api errors
            log_error(f'SCROBBLE [{method}] failed for {item.provider}:'
                      f'{item.media_id}: {exc}')
            return None
        self._remember_session(method, item, reported, response)
        self._clear_queued_session(item, session_key)
        self._notify(method, item)
        return item

    @staticmethod
    def _notify(method, item):
        if not get_setting('show_notifications', 'bool'):
            return
        if method not in ('start', 'stop'):
            return
        label = localized(32127) or 'Scrobbling'
        notify('{}: {}'.format(label, item.title))


def _first_id(ids):
    for provider in ('tmdb', 'tvdb', 'imdb', 'trakt', 'mal'):
        if ids.get(provider) not in (None, ''):
            return provider
    return None
