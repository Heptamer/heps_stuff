# MDBList Addon – Anleitung (Deutsch)

[English guide](GUIDE.md) · [English README](README.md) · [Deutsches README](README.de.md)

`script.module.mdblist` verbindet Kodi mit [MDBList.com](https://mdblist.com):
Scrobbling der Wiedergabe, Synchronisierung zwischen Kodi-Bibliothek und
MDBList-Konto sowie ein Python-Modul für andere Addons.

## Voraussetzungen

- Kodi 19 (Matrix) oder neuer
- Kostenloser MDBList-Account mit API-Key:
  auf mdblist.com einloggen → *Preferences* → *API key* kopieren
- Den Key im Addon eintragen: *Addons → Meine Addons → MDBList → Einstellungen
  → Allgemein → API-Key*

## Scrobbling

Solange der Hintergrunddienst läuft, wird jede Film-/Serienwiedergabe an
MDBList gemeldet:

| Ereignis | Wird gesendet | Kodi-Benachrichtigung |
|---|---|---|
| Wiedergabestart | `start` | ja |
| **Pause** | `pause` | **nein (bewusst)** |
| Fortsetzen | `start` (mit aktuellem Fortschritt) | ja |
| Stopp / Ende | `stop` | ja |

> **Hinweis zu Pause:** Pausieren wird vollständig ausgewertet und an MDBList
> übertragen – es erscheint nur absichtlich keine Benachrichtigung, damit
> häufiges Pausieren keine Notify-Flut erzeugt. Auf mdblist.com ist der Titel
> trotzdem korrekt als „pausiert" markiert. Wer das prüfen möchte: Debug-Log
> aktivieren, beim Pausieren erscheint `SCROBBLE [pause] …`.

Einstellungen:

- **Scrobbling aktivieren** (Standard: an)
- **Mindestfortschritt in %**: Stopps unterhalb dieses Wertes werden nicht als
  „gesehen" gewertet (Standard 5 %). Der Titel wird trotzdem als `stop` an
  MDBList gemeldet, damit er nicht in „Now Playing" / der Live-Aktivität
  hängen bleibt – als gesehen markiert wird er dabei nicht.
- **Als gesehen zählen ab (%)** (80-100, Standard 80): MDBList wertet einen
  Titel ab 80 % des gemeldeten Fortschritts als gesehen, und diese Grenze ist
  serverseitig nicht änderbar. Ein höherer Wert hält den gemeldeten
  Fortschritt daher knapp darunter, bis die eigene Schwelle erreicht ist –
  der Titel bleibt dann ungesehen und erhält einen Fortsetzungspunkt statt
  eines Gesehen-Eintrags.
- **Auch für Kodis Gesehen-Zähler übernehmen** (Standard: aus): Kodi markiert
  Titel standardmäßig ab 90 % als gesehen, und der Bibliotheks-Sync überträgt,
  was Kodi gezählt hat – das würde eine höhere Schwelle (s. o.) unterlaufen.
  Der Schalter gleicht Kodis eigene Einstellung an (Standard aus, da eine
  globale Kodi-Einstellung verändert wird).

### Bewertungs-Popup nach der Wiedergabe

Optional (Standard: aus): Nach Ende einer Film-/Serienepisode – oder wenn
jenseits der Schwelle manuell gestoppt wird – öffnet das Addon einen
Auswahldialog (*Keine Bewertung, 1 ★ … 10 ★*) und überträgt die Wahl an
MDBList.

- **Nach Wiedergabe nach Bewertung fragen**: Feature einschalten
- **Mindestfortschritt für Bewertungsfrage (%)**: Slider, Minimum 75 %
  (Standard 85 %)
- **Bewertungsfrage für**: Filme und Serien / Nur Filme / Nur Serien

Hinweise:

- Das Popup setzt aktives Scrobbling voraus (die Identifikation hängt daran)
  und erscheint nur bei erfolgreich identifizierten Inhalten.
- Episoden werden auf mdblist.com auf **Episoden-Ebene** bewertet. Der
  Ratings-Pull liest derzeit nur Filme zurück nach Kodi – Episoden-Bewertungen
  kommen also (noch) nicht zurück.
- Derselbe Sterne-Picker ersetzt beim Bewerten über das Kontextmenü das alte
  Zahlenfeld.

### Erkennung von Inhalten

Das Addon identifiziert abgespielte Inhalte in dieser Reihenfolge:

1. Provider-IDs aus allen lokalen Quellen: die VideoInfoTag des ListItems
   (`getUniqueID(...)` für tmdb/tvdb/imdb/trakt/anidb, `getIMDBNumber`),
   gängige ListItem-Properties (`tmdb_id`, `imdb_id`, ...) und die
   VideoPlayer-Infolabels (`VideoPlayer.UniqueID(<provider>)`,
   `VideoPlayer.IMDBNumber`). `Player.GetItem` dient als letzter Ausweg.
2. Rückwärtssuche in der Kodi-Bibliothek: zuerst über den Dateipfad, dann
   über Titel/Jahr (Filme) bzw. Serientitel + Staffel/Episode (Episoden).
   Das deckt auch Plugin-Streams ab, deren Dateipfad nicht passt.
3. Titel-Suche über die MDBList-API, Ergebnis wird 30 Tage
   zwischengespeichert. Zuerst wird der Originaltitel versucht, dann der
   lokalisierte Titel und bereinigte Varianten (Jahres-/Qualitäts-Suffixe
   entfernt, Umlaute transliteriert), mit Vorzug auf exakten
   Jahres-Treffer und Rückfall auf das beste Ergebnis.

Episode-ListItems/-Infolabels tragen Episoden-IDs, die keine gültigen
Serien-IDs sind und daher nie direkt verwendet werden; Serien werden
stattdessen über die Bibliothek oder die Titelsuche aufgelöst. Dieselbe
Kette nutzen auch die Kontextmenü-Aktionen, sodass sie ebenso für
Widget-/Plugin-Wiedergabe funktionieren.

## Synchronisierung

Jede Richtung ist einzeln abschaltbar (*Einstellungen → Sync*):

- **Gesehen-Status**: Push und Pull für Filme und Episoden. Es zählen die
  Abspielanzahl (plays); bei Gleichstand gewinnt der neuere Zeitstempel.
  MDBList ist beim Pull **führend**, aber nur für Einträge, die MDBList
  tatsächlich kennt:
  - Als gesehen geführte Einträge → in Kodi als gesehen markiert.
  - Als **explizit ungesehen** geführte Einträge (aus dem MDBList-Sync-Journal)
    → in Kodi als ungesehen markiert (`playcount` 0, Gesehen-Datum geleert).
    Hat ein solcher Eintrag in Kodi aktuell einen Fortsetzungspunkt (als
    „teilweise angesehen" angezeigt), wird dieser ebenfalls entfernt, sodass
    er nicht mehr als angespielt erscheint.
  - Einträge, die MDBList unbekannt sind, bleiben in Kodi unangetastet.
  Um eine Endlosschleife zu vermeiden, überspringt der **Push** alles, was
  MDBList aktuell als explizit ungesehen führt: Ein auf MDBList als ungesehen
  markierter Titel wird vom nächsten Push nie still heimlich wieder als
  gesehen gemeldet, selbst wenn Kodi ihn noch als gesehen zählt.
  - Der **Push** meldet außerdem lokale „ungesehen"-Änderungen an MDBList:
    Ein Film oder eine Episode, die in Kodi zuvor als gesehen galten und nun
    auf ungesehen gesetzt wurden, wird über den watched-remove-Endpoint
    entfernt, bevor der Pull läuft – eine bewusste Rücksetzung wird also
    nicht mehr vom nächsten Sync (z. B. nach einem Kodi-Neustart) rückgängig
    gemacht. Die Erkennung basiert auf einer Baseline der lokal gesehenen
    IDs im Cache: Eine frische Installation oder ein geleerter Cache legt
    nur die Baseline an und löscht nichts auf MDBList; ein
    Bibliotheks-Scan/-Clean nach der Baseline unterdrückt den Push, damit
    eine gelöschte und neu hinzugefügte Serie weiterhin aus MDBList
    restauriert wird. Nach einem Update einmalig betroffene Titel zurücksetzen,
    damit die Baseline steht und die Änderung an MDBList gemeldet wird.
  - Eine **lokale Wiederholung nach einer solchen Rücksetzung** gewinnt
    ebenfalls: Jede Journal-Löschzeile trägt die serverseitige Zeit der
    Entfernung (*action_at*), und eine lokal neuere Gesehen-Marke als
    dieser Zeitstempel wird weder vom Pull zurückgesetzt noch vom Push
    blockiert – eine direkt nach dem Reset (oder nach einer Löschung auf
    mdblist.com) wieder als gesehen markierte Serie erreicht MDBList. Ein
    lokales Protokoll der eigenen Remove-Pushes dient als Fallback für
    Journal-Zeilen ohne verwertbaren Zeitstempel. Journal-Löschungen, die
    neuer als die lokale Gesehen-Marke sind, setzen Kodi weiterhin zurück.
  Serien werden ausschließlich auf **Episodenebene** synchronisiert: Episoden
  werden mit ihrer eigenen Episoden-ID gepusht (der dokumentierte flache
  `episodes`-Bucket), und der Pull zieht nach, was auf MDBList als einzelne
  Episode als gesehen (oder als ungesehen markiert) geführt ist.
  Staffel-Kennzeichen („ganze Staffel gesehen") von MDBList werden ignoriert,
  da MDBList sie inkonsistent setzen kann; Kodi leitet eine gesehene Staffel
  selbst aus ihren gesehenen Episoden ab.
- **Bewertungen**: Kodi-*userrating* ↔ MDBList-Rating (Filme; Serien folgen).
- **Weiterschauen-Fortschritt** (Standard: an, nur Pull): MDBList legt für
  jeden Film/jede Episode, die unterhalb der Gesehen-Schwelle gestoppt wurde,
  eine pausierte Wiedergabe-Sitzung an – das Scrobble hat sie bereits
  hochgeladen. Diese Option liest die Sitzungen zurück und setzt den
  passenden Fortsetzungspunkt in Kodi, sodass ein auf einem Gerät
  unterbrochener Titel auf einem anderen fortgesetzt werden kann.
  - Von diesem Gerät selbst gesendete Sitzungen werden erkannt und
    übersprungen, damit die eigene Wiedergabe nicht den gerade gesetzten
    Fortsetzungspunkt wieder überschreibt.
  - Bereits hier gesehene Titel bleiben unverändert – der Gesehen-Status hat
    Vorrang vor einer übrig gebliebenen Sitzung.
  - Der Fortschritt wird in **Prozent** verglichen, nicht in Sekunden, weil
    die Laufzeit auf MDBList von der lokalen Datei abweichen kann. Eine
    Position innerhalb von 1 % zur lokalen wird nicht überschrieben, bei
    wiederholten Syncs ändert sich also nichts.
  - Eine Remote-Position *hinter* der lokalen wird nur übernommen, wenn diese
    Sitzung eindeutig neuer ist (ein anderes Gerät hat den Titel bewusst neu
    gestartet); sonst bleibt die lokale Position stehen und das Log meldet
    `behind local position`.
  - Der Pull läuft nach dem Gesehen-Pull und nur dann, wenn MDBList eine neue
    oder geänderte Sitzung meldet – kostet im ruhigen Betrieb also keinen
    zusätzlichen Request.
  - Entfernen ist manuell: **Weiterschauen-Eintrag entfernen** im Kontextmenü
    des laufenden Titels oder
    `RunScript(script.module.mdblist, action=clearprogress)`. Ohne
    `id`/`type` werden nach einer Rückfrage **alle** Sitzungen des Kontos auf
    allen Geräten gelöscht. Das Addon löst das nie automatisch aus – sonst
    würde eine bereinigte Kodi-Bibliothek die Fortsetzungspunkte aller
    anderen Geräte mitlöschen.
- **Bibliothek → Sammlung** (Standard: aus): Gleicht die gesamte
  Kodi-Bibliothek mit der MDBList-Collection ab – Filme **und einzelne
  Episoden**. Es wird nur hinzugefügt: Löschen aus der Kodi-Bibliothek
  entfernt nichts aus der Collection. Erst mit dieser Option erscheinen auch
  **ungesehene** Filme/Serien auf mdblist.com.

Wichtig zum Verständnis der Log-/Zusammenfassungsangaben: Die Zahlen bedeuten
immer „in diesem Lauf **neu** übertragen". Steht dort `movies: 0`, heißt das
„nichts Neues" – nicht „Sammlung leer".

Weitere Einstellungen:

- **Startverzögerung**: Wartezeit nach Kodi-Start vor dem ersten Sync
  (Standard 120 s)
- **Intervall**: periodischer Sync in Minuten, 0 = aus
- **Sync nach Bibliotheksaktualisierung**: Sync nach jedem Scan/Clean. Ein
  Rescan kann bedeuten, dass eine Serie gelöscht und neu hinzugefügt wurde
  (Kodi setzt dabei die Gesehen-Zähler zurück), daher läuft dieser Sync
  erzwungen: Der Remote-Gesehen-Status wird erneut angewendet, selbst wenn
  sich das MDBList-Aktivitäts-Watermark nicht geändert hat.

### Manueller Sync

Kontextmenü im Addon → **Jetzt synchronisieren**, oder
`RunScript(script.module.mdblist, action=sync)`.

Der manuelle Sync wartet bis zu 45 Sekunden, falls gerade ein
Dienst-Sync läuft, statt sofort abzubrechen. Erscheint die Meldung
„Es läuft bereits eine Synchronisierung", war innerhalb dieser Zeit kein
Slot frei – einfach erneut versuchen. Nach echtem Abschluss folgt eine
Bestätigung.

### API-Limit und Scrobble-Outbox

Jede MDBList-Antwort meldet das Tageskontingent in ihren Headern
(`X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`), eine
`429`-Antwort zusätzlich `Retry-After`. Das Addon speichert diesen Zustand:

- Ist das Kontingent erschöpft, werden **alle Anfragen bis zum Reset
  gestoppt**. Syncs werden übersprungen (ein manueller Sync meldet „API-Limit
  erreicht – Sync pausiert bis ..."), und der Dienst nimmt nach dem Reset
  automatisch wieder einen Sync auf.
- Ein langes `Retry-After` wird nie in einem Sync-/Scrobble-Thread
  abgewartet. Nur sehr kurze Wartezeiten (bis 10 Sekunden, typischerweise das
  5-Minuten-Lese-/Schreibfenster) werden direkt erneut versucht.
- **Pause- und Stop-Scrobbles, die nicht gesendet werden können**, landen in
  der kleinen SQLite-Outbox `scrobbles.db` im Addon-Profil. Das gilt auch für
  einen kurzen Netzwerk-/5xx-Fehler. Nach dem Reset wird die Outbox
  automatisch geleert (beim Start, vor dem nächsten Sync und periodisch), und
  die nachgesendete Sitzung wird als eigene markiert, damit der
  Fortschritts-Pull sie unangetastet lässt. `start`-/Resume-Events werden
  nicht gepuffert: Sie steuern nur den Live-Status und wären nach einer
  längeren Sperre veraltet. Innerhalb einer Wiedergabe bleibt nur das neueste
  Ereignis erhalten – auf eine Pause folgt also ein einzelner Stop.
- Der Scrobble-Endpoint kennt **kein `watched_at`**. Ein nachgesendeter Stop
  markiert den Titel daher mit dem Zeitpunkt des Nachsendens als gesehen. Für
  Titel in der Kodi-Bibliothek lässt sich das über den anschließenden Sync
  (oder `action=repair_watched_dates`) korrigieren; reine Streaming-Titel
  behalten die Nachsende-Zeit. Gesehen-Status und Fortsetzungspunkt selbst
  bleiben erhalten.
- Abfragen mit **API-Limit...** im Kontextmenü oder
  `RunScript(script.module.mdblist, action=apilimit)`. Angezeigt werden
  verbrauchte/verbleibende Anfragen, der Reset in lokaler Zeit und die Anzahl
  wartender Scrobbles. Ist das Limit bereits erschöpft, wird der Cache gelesen,
  statt einen weiteren Request für `/user` zu verbrauchen.

## Aktionen (RunScript)

```text
RunScript(script.module.mdblist, action=sync)              # Sync erzwingen
RunScript(script.module.mdblist, action=rate, id=tmdb:769, rating=9)
RunScript(script.module.mdblist, action=unrate, id=tmdb:769)
RunScript(script.module.mdblist, action=markwatched, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=markunwatched, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=togglewatched, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=addtowatchlist, type=show, id=tmdb:1399)
RunScript(script.module.mdblist, action=removefromwatchlist, type=show, id=tmdb:1399)
RunScript(script.module.mdblist, action=repair_watched_dates[, limit=3])
RunScript(script.module.mdblist, action=clearprogress[, id=tmdb:769])
RunScript(script.module.mdblist, action=auth_info)         # Key-Status zeigen
RunScript(script.module.mdblist, action=apilimit)          # API-Kontingent + Outbox
RunScript(script.module.mdblist, action=contextmenu)       # Dialog öffnen
```

`id` akzeptiert `tmdb:`, `imdb:`, `trakt:`, `tvdb:` oder eine nackte Zahl.
Ohne `id`/`type` wird der aktuell abgespielte Titel verwendet.

## Fehlerbehebung

1. *Debug-Logging* in den Addon-Einstellungen aktivieren
2. Kodi-Neustart bzw. manuellen Sync auslösen
3. Log prüfen (`kodi.log`), relevante Zeilen beginnen mit
   `[script.module.mdblist]`

Typische Zeilen:

```text
SCROBBLE [start] (id: library) tmdb:1399 "Serie X" at 3%
SCROBBLE [pause] …            ← Pause wurde gesendet (keine Notify dazu)
Remote watched snapshot: movies=3 shows=0 seasons=1 episodes=3 total=7 complete=True
Watched pull: {'movies': 0, 'episodes': 3, 'unwatched_movies': 0, 'unwatched_episodes': 0, 'resume_reset': 0}
Progress sync: 4 remote playback sessions
Progress pull: {'status': 'ok', 'movies': 1, 'episodes': 0, 'skipped': {'own session': 2, 'watched locally': 1}}
Progress pull: movie 42 resumed at 37.5% (1350s of 3600s)
Watched push: 3 entries (movies=1 episodes=2)
Watched push response: {'updated': 2, 'not_found': 0, 'errors': 0, 'plays': 0}
              (raw: ['{"updated":{"episodes":[{"tvdb":123}]},"not_found":{"episodes":[]},"errors":[],"plays":[]}'])
Collection remote snapshot: movies=12 shows=2
Collection diff: movies=0 show payloads=1 episodes=14 unresolved=0
Collection push: {'status': 'ok', 'movies': 0, 'episodes': 14}
Scrobble queue flush: {'status': 'ok', 'sent': 2, 'dropped': 0, 'pending': 0}
MDBList API limit reached; pausing requests until 2026-11-08 01:00
Sync finished in 16.4s: {…}
```

Die Zahlen in `Watched push response` sind Eintragszahlen, aufsummiert über
die Medientyp-Buckets der Server-Antwort. `updated`, `history_only` und
`plays` sind dort einfache Zahlen, `not_found`/`errors` sind Listen; beide
Formen werden gezählt.

Häufige Fälle:

- **In Kodi gesehene Episoden/Serien erreichen mdblist.com nicht**: Vor 0.1.8
  nutzte der Episoden-Sync das verschachtelte Payload
  `shows[].seasons[].episodes[].number`, das MDBList zwar annimmt, aber
  stillschweigend ignoriert. Seit 0.1.8 wird der dokumentierte flache
  `episodes`-Bucket mit der eigenen Provider-ID der Episode gepusht. Eine
  Serie muss in der Bibliothek gescrapet sein, damit ihre Episoden
  `uniqueid`s tragen – andernfalls kann kein Eintrag identifiziert werden;
  das Sync-Log warnt dann mit der Anzahl übersprungener Episoden.
- **Inhalte fehlen in der Sammlung**: `unresolved=` > 0 bedeutet, dass eine
  Serie weder IDs noch per Titelsuche aufgelöst werden konnte. Serien mit
  TVDB-only-IDs werden direkt als solche übertragen (MDBList akzeptiert
  tmdb/tvdb/imdb/trakt).
- **Rate-Limit**: Der kostenlose API-Tarif erlaubt 1000 Requests/Tag; die
  Caches (Remote-Snapshots 6 h, ID-Auflösungen 30 Tage) halten das Aufkommen
  niedrig. Der Weiterschauen-Pull ist an die `paused_at`-Wasserstandsmarke
  aus `/sync/last_activities` gekoppelt und holt `/sync/playback` nur, wenn
  sich tatsächlich eine Sitzung geändert hat. Ist das Kontingent erschöpft,
  pausiert das Addon alle Anfragen bis zum Reset; ausstehende Pause-/Stop-
  Scrobbles bleiben in `scrobbles.db` und werden danach gesendet.
  `action=apilimit` zeigt das verbleibende Kontingent und die Outbox.
- **Jeder Sync lief alle Pulls**: `/sync/last_activities` liefert als
  `server_time` die Zeit der Anfrage; vor 0.2.3 wurde dieses Feld wie eine
  echte Wasserstandsmarke verglichen, dadurch galt nie ein Lauf als
  „unverändert" und der Bewertungs-Pull/-Push lief endlos erneut. `server_time`
  wird nun ignoriert.
- **„script didn't stop in 5 seconds" / SystemExit beim Kodi-Beenden**:
  Kodis Python-Invoker wartet bis zu 5 Sekunden auf alle Addon-Threads,
  einschließlich Daemon-Threads. Bis 0.7.0 lief der Positions-Sampler
  dauerhaft, sodass der Service dieses Timeout immer erreichte und gekillt
  wurde; die `Exception ignored in threading._shutdown`-Meldung ist nur die
  Folge des erzwungenen Stopps. Seit 0.7.1 wird der Sampler beim Abort
  gestoppt, der Startup-Timer storniert und Sync-/Flush-Worker prüfen
  zwischen den Schritten ein Stop-Flag, sodass der Service innerhalb des
  5-Sekunden-Fensters endet. Erscheint die Meldung weiterhin, läuft noch ein
  Netzwerk-Request in einem Scrobble-/Sync-Thread und wird nach dem Timeout
  beendet.
- **Alles zurücksetzen**: Im Profilordner des Addons die `cache.db` löschen
  (und `scrobbles.db`, wenn auch gepufferte Scrobbles verworfen werden sollen)
  und Kodi neu starten.
