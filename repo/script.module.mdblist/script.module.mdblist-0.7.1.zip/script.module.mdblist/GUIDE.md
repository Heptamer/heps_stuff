# MDBList Addon – User Guide (English)

[Deutsche Anleitung](GUIDE.de.md) · [English README](README.md) · [German README](README.de.md)

`script.module.mdblist` connects Kodi to [MDBList.com](https://mdblist.com):
playback scrobbling, synchronisation between the Kodi library and your
MDBList account, plus a Python module for third-party addons.

## Requirements

- Kodi 19 (Matrix) or newer
- Free MDBList account with an API key: log in at mdblist.com →
  *Preferences* → *API key*
- Enter the key in the addon: *Addons → My add-ons → MDBList → Configure →
  General → API key*

## Scrobbling

While the background service runs, every movie/episode playback is reported
to MDBList:

| Event | Sent | Kodi notification |
|---|---|---|
| Playback started | `start` | yes |
| **Paused** | `pause` | **no (by design)** |
| Resumed | `start` (with current progress) | yes |
| Stopped / ended | `stop` | yes |

> **About pause:** Pausing is fully evaluated and transmitted to MDBList —
> it just deliberately shows no notification, so frequent pausing does not
> spam you. mdblist.com still marks the item as paused. To verify: enable
> debug logging; pausing logs `SCROBBLE [pause] …`.

Settings:

- **Enable scrobbling** (default: on)
- **Minimum progress %**: stops below this value do not count as watched
  (default 5 %). The item is still reported as `stop` to MDBList so it does
  not stay stuck in "Now Playing" / the live activity feed — it is simply not
  marked watched.
- **Count as watched from (%)** (80-100, default 80): MDBList itself marks
  an item watched from 80 % of the reported progress and that cutoff cannot
  be changed server-side. A higher value holds the reported progress just
  below it until your threshold is reached - the item then stays unwatched
  and gets a resume point instead of a watched entry.
- **Also apply to Kodi's play count threshold** (default: off): Kodi marks
  items watched from 90 % by default, and the library sync pushes whatever
  Kodi counted - that would undercut a higher threshold above. Enabling this
  aligns Kodi's own setting (off by default, because it changes a global
  Kodi setting).

### Rating prompt after playback

Optional (off by default): after a movie/episode finishes — or is stopped
past the threshold — the addon opens a picker dialog
(*No rating, 1 ★ … 10 ★*) and pushes the choice to MDBList.

- **Ask for a rating after playback**: enable the feature
- **Minimum progress for rating prompt (%)**: slider, minimum 75 %
  (default 85 %)
- **Ask for rating on**: movies and episodes / movies only / episodes only

Notes:

- The prompt requires scrobbling to be enabled (identification depends on it)
  and only appears when the item could be identified.
- Episodes are rated at **episode level** on mdblist.com. The ratings *pull*
  currently reads movies back into Kodi only, so episode ratings do not sync
  back yet.
- The same star picker replaces the old numeric keypad when rating via the
  context menu.

### How content is identified

Played items are identified in this order:

1. Provider ids from every local source: the ListItem's VideoInfoTag
   (`getUniqueID(...)` for tmdb/tvdb/imdb/trakt/anidb, `getIMDBNumber`),
   common ListItem properties (`tmdb_id`, `imdb_id`, ...) and the
   VideoPlayer InfoLabels (`VideoPlayer.UniqueID(<provider>)`,
   `VideoPlayer.IMDBNumber`). `Player.GetItem` is used as a last resort.
2. Reverse lookup in the Kodi library: by playing file path first, then
   by title/year (movies) or show title + season/episode (episodes). This
   also covers plugin streams whose file path does not match.
3. Title search via the MDBList API, cached for 30 days. The original
   title is tried first, then the localized title and cleaned variants
   (year/quality suffixes removed, umlauts transliterated), preferring an
   exact year match and falling back to the best-scoring result.

Episode ListItems/InfoLabels carry episode ids, which are not valid show
ids, so they are never used directly; shows are resolved via the library
or the title search instead. The same chain is used by the context menu
actions, so they also work for widget/plugin playback.

## Synchronisation

Each direction can be toggled separately (*Settings → Sync*):

- **Watched status**: push and pull for movies and episodes. Play counts are
  compared; on ties the newer timestamp wins. MDBList is **authoritative** on
  the pull, but only for items MDBList actually knows about:
  - Items it lists as watched → marked watched in Kodi.
  - Items it lists as **explicitly unwatched** (from the MDBList sync journal)
    → marked unwatched in Kodi (`playcount` 0, watch date cleared). If such an
    item currently has a resume point in Kodi (shown as "partially watched"),
    that resume point is removed as well, so it no longer shows as started.
  - Items MDBList knows nothing about → left untouched in Kodi.
  To avoid an endless loop, the **push** skips anything MDBList currently
  lists as explicitly unwatched: marking an item unwatched on MDBList is
  never silently undone by the next push, even while Kodi still counts it
  watched.
  - The **push** also reports local "mark unwatched" changes to MDBList: a
    movie or episode that was watched in Kodi and is now marked unwatched is
    removed through the watched-remove endpoint before the pull runs, so a
    deliberate reset is no longer reverted by the next sync (most visibly
    after a Kodi restart). Detection is based on a cache baseline of the
    locally watched ids: a fresh install or a cleared cache only stores the
    baseline and never removes anything on MDBList; a library scan/clean
    after the baseline suppresses the push as well, so a deleted and
    re-added show still gets its watched state restored from MDBList. After
    updating, reset the affected titles once so the baseline is recorded and
    the change reaches MDBList.
  - A local **re-watch after such a reset** wins as well: every journal
    removal row carries the server-side time of the removal (*action_at*),
    and a local watch newer than that timestamp is neither downgraded by
    the pull nor blocked from the push — marking a series watched again
    right after resetting it (or after a removal done on mdblist.com)
    reaches MDBList. A local record of this addon's own remove-pushes
    serves as a fallback for journal rows without a usable timestamp.
    Journal removals newer than the local watch still downgrade Kodi as
    before.
  Shows are synced strictly on the **episode level**: episodes are pushed with
  their own episode id (the flat documented `episodes` bucket), and the pull
  applies what MDBList lists as a watched (or explicitly-unwatched) individual
  episode. Whole-season flags ("whole season watched") from MDBList are
  ignored, because MDBList can set them inconsistently; Kodi derives a watched
  season from its own watched episodes.
- **Ratings**: Kodi *userrating* ↔ MDBList rating (movies; shows to follow).
- **Continue-watching progress** (default: on, pull only): MDBList keeps a
  paused playback session for every movie/episode you stopped below the
  watched threshold — the scrobble already uploaded it. This option reads
  those sessions back and sets the matching resume point in Kodi, so a title
  stopped on one device can be continued on another.
  - Sessions this device pushed itself are recognised and skipped, so your
    own playback never rewrites the resume point it just set.
  - Items you already watched here are left alone — the watched state wins
    over a leftover session.
  - Progress is compared in **percent**, not seconds, because MDBList's
    runtime can differ from your local file. A position within 1 % of the
    local one is not rewritten, so nothing changes on repeated syncs.
  - A remote position *behind* the local one is only adopted when that
    session is clearly newer (another device deliberately restarted the
    item); otherwise the local position stays and the log says
    `behind local position`.
  - The pull runs after the watched pull and only when MDBList reports a new
    or changed paused session, so it costs no extra request on a quiet run.
  - Removing an entry is manual: **Remove continue-watching entry** in the
    context menu of the playing item, or
    `RunScript(script.module.mdblist, action=clearprogress)`. Without
    `id`/`type` it clears **all** sessions of your account on all devices,
    after a confirmation dialog. The addon never does that automatically —
    clearing the Kodi library would otherwise wipe the resume points of
    every other device.
- **Library → collection** (default: off): syncs the whole Kodi library with
  the MDBList collection — movies **and individual episodes**. Add-only:
  removing files from Kodi never removes them from the collection. Only this
  option makes **unwatched** movies/shows visible on mdblist.com.

Important when reading logs/summaries: numbers always mean "newly
transferred **in this run**". `movies: 0` means "nothing new" — not "the
collection is empty".

Further settings:

- **Startup delay**: wait after Kodi start before the first sync
  (default 120 s)
- **Interval**: periodic sync in minutes, 0 = off
- **Sync after library update**: sync after every scan/clean. A rescan can
  mean a show was deleted and re-added (Kodi resets its playcounts then), so
  this sync runs forced: it re-applies the remote watched state even when the
  MDBList activity watermark is unchanged.

### Manual sync

Context menu of the addon → **Sync now**, or
`RunScript(script.module.mdblist, action=sync)`.

A manual sync waits up to 45 seconds if a service sync is currently running
instead of failing instantly. If you see "a sync is already running", no slot
was free within that window — simply try again. A confirmation appears after
real completion.

### API limit and scrobble outbox

Every MDBList response reports the daily quota in its headers
(`X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`), and a
`429` adds `Retry-After`. The addon persists that state:

- When the quota is exhausted, **all requests stop until the reset**. Syncs
  are skipped (a manual sync shows "API limit reached - sync paused until
  ..."), and the service automatically resumes with a sync after the reset.
- A long `Retry-After` is never slept through inside a sync/scrobble thread.
  Only very short waits (up to 10 seconds, typically the 5-minute read/write
  window) are still retried directly.
- **Pause and stop scrobbles that cannot be sent** are written to the small
  sqlite outbox `scrobbles.db` in the addon profile. This also covers a short
  network/5xx failure. After the reset, the outbox is flushed automatically
  (at startup, before the next sync and periodically) and the entries are
  marked as this device's own session so the progress pull leaves them alone.
  `start`/resume events are not buffered: they only drive the live feed and
  would be stale after a longer outage. Within one playback session only the
  newest event is kept, so a pause followed by a stop is sent as a single
  stop.
- The scrobble endpoint has **no watch-date parameter**. A replayed stop
  therefore marks the item watched at replay time. For items in the Kodi
  library the subsequent sync (or `action=repair_watched_dates`) can correct
  the date; purely streamed titles keep the replay time. The watched state and
  resume position themselves are preserved.
- Query the current state with **API limit...** in the context menu or
  `RunScript(script.module.mdblist, action=apilimit)`. It shows used and
  remaining requests, the reset in local time and the number of waiting
  scrobbles. When the limit is already exhausted, it reads the cached state
  instead of spending another request on `/user`.

## Actions (RunScript)

```text
RunScript(script.module.mdblist, action=sync)              # force a sync
RunScript(script.module.mdblist, action=rate, id=tmdb:769, rating=9)
RunScript(script.module.mdblist, action=unrate, id=tmdb:769)
RunScript(script.module.mdblist, action=markwatched, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=markunwatched, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=togglewatched, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=addtowatchlist, type=show, id=tmdb:1399)
RunScript(script.module.mdblist, action=removefromwatchlist, type=show, id=tmdb:1399)
RunScript(script.module.mdblist, action=repair_watched_dates[, limit=3])
RunScript(script.module.mdblist, action=clearprogress[, id=tmdb:769])
RunScript(script.module.mdblist, action=auth_info)         # show key status
RunScript(script.module.mdblist, action=apilimit)          # API quota + outbox
RunScript(script.module.mdblist, action=contextmenu)       # open dialog
```

`id` accepts `tmdb:`, `imdb:`, `trakt:`, `tvdb:` or a bare number. Without
`id`/`type` the currently playing item is used.

## Troubleshooting

1. Enable *Debug logging* in the addon settings
2. Restart Kodi or trigger a manual sync
3. Check the log (`kodi.log`); relevant lines start with
   `[script.module.mdblist]`

Typical lines:

```text
SCROBBLE [start] (id: library) tmdb:1399 "Show X" at 3%
SCROBBLE [pause] …            ← pause was sent (no notification by design)
Remote watched snapshot: movies=3 shows=0 seasons=1 episodes=3 total=7 complete=True
Watched pull: {'movies': 0, 'episodes': 3, 'unwatched_movies': 0, 'unwatched_episodes': 0, 'resume_reset': 0}
Progress sync: 4 remote playback sessions
Progress pull: {'status': 'ok', 'movies': 1, 'episodes': 0, 'skipped': {'own session': 2, 'watched locally': 1}}
Progress pull: movie 42 resumed at 37.5% (1350s of 3600s)
Watched push: 3 entries (movies=1 episodes=2)
Watched push response: {'updated': 2, 'not_found': 0, 'errors': 0, 'plays': 0}
              (raw: ['{"updated":{"episodes":[{"tvdb":123}]},"not_found":{"episodes":[]},"errors":[],"plays":[]}'])
Collection remote snapshot: movies=12 shows=2
Collection diff: movies=0 show payloads=1 episodes=14 unresolved=0
Collection push: {'status': 'ok', 'movies': 0, 'episodes': 14}
Scrobble queue flush: {'status': 'ok', 'sent': 2, 'dropped': 0, 'pending': 0}
MDBList API limit reached; pausing requests until 2026-11-08 01:00
Sync finished in 16.4s: {…}
```

The numbers in `Watched push response` are entry counts summed across the
media-type buckets of the server reply. `updated`, `history_only` and
`plays` are plain integers there, `not_found`/`errors` are lists; both
shapes are counted.

Common cases:

- **Episodes/series watched in Kodi never reach mdblist.com**: before 0.1.8
  the episode sync used the nested `shows[].seasons[].episodes[].number`
  payload, which MDBList accepted but silently ignored. v0.1.8 pushes the
  documented flat `episodes` bucket keyed by the episode's own provider id.
  A show must be scraped so its episodes carry `uniqueid`s, otherwise the
  entries cannot be identified — the sync log then shows a warning with the
  number of episodes skipped.
- **Items missing from the collection**: `unresolved=` > 0 means a series
  could be neither matched by ids nor resolved via title search. Shows with
  TVDB-only ids are sent as such directly (MDBList accepts tmdb/tvdb/imdb/
  trakt).
- **Rate limit**: The free API tier allows 1000 requests/day; the caches
  (remote snapshots 6 h, id resolutions 30 days) keep usage low. The
  continue-watching pull is gated by the `paused_at` watermark of
  `/sync/last_activities`, so it only fetches `/sync/playback` when a
  session actually changed. When the quota is exhausted the addon pauses all
  requests until the reset, and pending pause/stop scrobbles are kept in
  `scrobbles.db` and sent afterwards. Use `action=apilimit` to see the
  remaining quota and the outbox count.
- **Every sync ran all pulls**: `/sync/last_activities` returns the request
  time as `server_time`; before 0.2.3 that field was compared like a real
  watermark, so no run was ever "unchanged" and the ratings pull/push
  repeated endlessly. `server_time` is now ignored.
- **"script didn't stop in 5 seconds" / SystemExit on Kodi exit**: Kodi's
  Python invoker waits up to 5 seconds for every addon thread, including
  daemon threads. Up to 0.7.0 the playback position sampler ran forever, so
  the service always hit that timeout and was killed; the
  `Exception ignored in threading._shutdown` trace is only the consequence
  of that forced stop. Since 0.7.1 the sampler is stopped on abort, the
  startup timer is cancelled and sync/flush workers check a stop flag
  between steps, so the service ends inside the 5-second window. If the
  message still appears, a network request in a scrobble/sync thread is
  still running and is killed after the timeout.
- **Reset everything**: delete `cache.db` (and `scrobbles.db` if you also
  want to discard buffered scrobbles) in the addon profile folder and
  restart Kodi.
