# -*- coding: utf-8 -*-
"""Central identification of movies and episodes.

Kodi addons expose the metadata of the playing item in many different
ways and places, depending on how playback was started:

1. the playing ListItem's VideoInfoTag (uniqueids, title, original title,
   year, show title, season/episode)
2. arbitrary ListItem properties some addons set for their own use
3. the VideoPlayer InfoLabels (including ``VideoPlayer.UniqueID(<provider>)``
   and ``VideoPlayer.OriginalTitle``, Kodi >= 19)
4. the Kodi library, reached through the playing file path or through
   title/year (movies) and show title + season/episode (episodes)
5. a title search against MDBList, using the original title first and
   several cleaned variants afterwards
6. ``Player.GetItem`` via JSON-RPC as a last resort (only useful for
   items that live in Kodi's database)

``collect()`` gathers everything from sources 1-3 (and 6 as a fallback)
without any network access, so it is cheap enough to run on the player
thread. ``resolve()`` then walks the identification chain - existing ids,
library lookup, title search - and is meant to run in the background.
"""
import re
import unicodedata

import xbmc

from .api.mapping import entry_ids
from .library import (lookup_by_file, lookup_by_metadata,
                      lookup_movie_by_metadata)
from .logger import log_debug
from .utils import jsonrpc, parse_id

# providers the MDBList API accepts, best first
PROVIDER_ORDER = ('tmdb', 'tvdb', 'imdb', 'trakt', 'anidb', 'mal')
# providers whose uniqueid can be read from a Kodi tag/infolabel
ID_PROVIDERS = ('tmdb', 'tvdb', 'imdb', 'trakt', 'anidb')

# ListItem property names addons commonly use for provider ids
ID_PROPERTY_KEYS = {
    'tmdb': ('tmdb_id', 'tmdbid', 'tmdbID', 'tmdb'),
    'tvdb': ('tvdb_id', 'tvdbid', 'tvdbID', 'tvdb'),
    'imdb': ('imdb_id', 'imdbid', 'imdbID', 'imdbnumber', 'imdb'),
    'trakt': ('trakt_id', 'traktid', 'traktID', 'trakt'),
    'anidb': ('anidb_id', 'anidbid', 'anidbID', 'anidb'),
}

# search results are cached for 30 days, matching the previous behaviour
SEARCH_TTL = 30 * 86400

# suffixes addons append to titles that would break a title search
_YEAR_SUFFIX = re.compile(r'[(\[]\s*(?:19|20)\d{2}\s*[)\]]')
# a trailing bracket that merely contains a year, e.g. "[HD | 1985 | 116min]"
_BRACKET_YEAR = re.compile(r'\s*[\[(][^\])]*\b(?:19|20)\d{2}\b[^\])]*[\])]')
_QUALITY_SUFFIX = re.compile(
    r'\s*[-–\[|(]?\s*\b(?:2160p|1080p|720p|480p|4k|uhd|bluray|blu-?ray|'
    r'web-?dl|web-?rip|hdtv|dvd-?rip|bd-?rip|x264|x265|h\.?264|h\.?265|'
    r'hevc|aac|ac3|dts|dd5\.?1)\b.*$',
    re.IGNORECASE)
_TRANSLIT = {
    'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss',
    'Ä': 'Ae', 'Ö': 'Oe', 'Ü': 'Ue',
}


class MediaInfo(object):
    """Normalized identification data of a playing or known item."""

    def __init__(self, mediatype=None, title=None, original_title=None,
                 year=None, show_title=None, season=None, episode=None,
                 file_path=None, ids=None):
        self.mediatype = mediatype          # 'movie' | 'episode'
        self.title = title or ''
        self.original_title = original_title or ''
        self.year = year
        self.show_title = show_title or ''
        self.season = int(season) if season is not None else None
        self.episode = int(episode) if episode is not None else None
        self.file_path = file_path
        self.ids = dict(ids or {})          # provider -> value
        self.provider = None
        self.media_id = None
        self.source = None                  # listitem|infolabel|library|search

    @property
    def valid(self):
        if self.mediatype not in ('movie', 'episode'):
            return False
        return bool(self.media_id or self.title or self.show_title)

    @property
    def search_title(self):
        """Title to use for a title search (show name for episodes)."""
        return self.show_title or self.title

    def best_id(self):
        """Best available provider:id pair from the collected ids."""
        for provider in PROVIDER_ORDER:
            value = self.ids.get(provider)
            if value not in (None, ''):
                return provider, value
        return None, None

    def add_id(self, provider, value):
        if provider and value not in (None, '') and provider not in self.ids:
            self.ids[provider] = value


# ---------------------------------------------------------------------- #
# collection (no network)                                                #
# ---------------------------------------------------------------------- #

def collect(listitem=None):
    """Gather metadata from all local sources into a MediaInfo.

    Returns None when nothing identifiable could be found. Never raises."""
    info = MediaInfo()
    if listitem is None:
        try:
            listitem = xbmc.Player().getPlayingItem()
        except Exception:
            listitem = None
    if listitem is not None:
        _collect_from_listitem(info, listitem)
    _collect_from_infolabels(info)
    if not info.ids:
        _collect_from_playitem(info)
    return info if info.valid else None


def _collect_from_listitem(info, listitem):
    try:
        tag = listitem.getVideoInfoTag()
    except Exception:
        tag = None
    if tag is not None:
        _merge_tag(info, tag)
    # episode items expose episode ids; they are not valid show ids
    if info.mediatype == 'episode':
        return
    for provider, keys in ID_PROPERTY_KEYS.items():
        for key in keys:
            try:
                value = listitem.getProperty(key)
            except Exception:
                value = None
            if value:
                info.add_id(provider, value)
                break


def _merge_tag(info, tag):
    """Read everything the InfoTagVideo exposes. Never raises."""
    def call(name, default=None):
        func = getattr(tag, name, None)
        if func is None:
            return default
        try:
            return func()
        except Exception:
            return default

    mediatype = (call('getMediaType') or '').lower()
    if mediatype in ('movie', 'episode'):
        info.mediatype = mediatype

    title = call('getTitle')
    if title and not info.title:
        info.title = title
    original = call('getOriginalTitle')
    if original and not info.original_title:
        info.original_title = original
    year = _to_int(call('getYear'))
    if year and not info.year:
        info.year = year
    show_title = call('getTVShowTitle')
    if show_title and not info.show_title:
        info.show_title = show_title
    if info.season is None:
        season = _to_int(call('getSeason'))
        if season is not None and season >= 0:
            info.season = season
    if info.episode is None:
        episode = _to_int(call('getEpisode'))
        if episode is not None and episode >= 0:
            info.episode = episode

    # episode listitems carry EPISODE ids, which the API would reject as
    # show ids, so they are not used for identification
    if info.mediatype == 'episode':
        return
    for provider in ID_PROVIDERS:
        value = _tag_uniqueid(tag, provider)
        if value:
            info.add_id(provider, value)
    # some addons set a default uniqueid without a provider type
    _add_parsed_id(info, _tag_uniqueid(tag, ''))
    _add_parsed_id(info, _tag_uniqueid(tag, 'default'))
    imdb = call('getIMDBNumber')
    _add_imdb_number(info, imdb)


def _tag_uniqueid(tag, provider):
    func = getattr(tag, 'getUniqueID', None)
    if func is None:
        return None
    try:
        return func(provider)
    except Exception:
        return None


def _collect_from_infolabels(info):
    """Read the VideoPlayer InfoLabels (works for widget/plugin playback)."""
    def label(name):
        try:
            return xbmc.getInfoLabel(name)
        except Exception:
            return ''

    season = label('VideoPlayer.Season')
    episode = label('VideoPlayer.Episode')
    show_title = label('VideoPlayer.TVShowTitle')
    ep_title = label('VideoPlayer.EpisodeName')
    title = label('VideoPlayer.Title')
    original = label('VideoPlayer.OriginalTitle')
    year = label('VideoPlayer.Year')

    season_n = _to_int(season)
    episode_n = _to_int(episode)

    if season_n is not None and season_n >= 0 and episode_n and episode_n > 0 \
            and (show_title or ep_title):
        if info.mediatype != 'movie':
            info.mediatype = 'episode'
        if not info.show_title:
            info.show_title = show_title or ep_title or title
        if info.season is None:
            info.season = season_n
        if info.episode is None:
            info.episode = episode_n
    elif info.mediatype not in ('movie', 'episode'):
        info.mediatype = 'movie'

    if title and not info.title:
        info.title = title
    if original and not info.original_title:
        info.original_title = original
    year_n = _to_int(year)
    if year_n and not info.year:
        info.year = year_n

    # episode infolabels expose episode ids, not show ids
    if info.mediatype == 'episode':
        return
    for provider in ID_PROVIDERS:
        value = label('VideoPlayer.UniqueID({})'.format(provider))
        if value:
            info.add_id(provider, value)
    _add_imdb_number(info, label('VideoPlayer.IMDBNumber'))


def _collect_from_playitem(info):
    """Last resort: Player.GetItem reads from Kodi's database.

    Plugin streams usually are not in the database, so this only helps for
    library playback. Failures are swallowed."""
    for playerid in (1, 0):
        result = jsonrpc('Player.GetItem', {
            'playerid': playerid,
            'properties': ['title', 'originaltitle', 'year', 'showtitle',
                           'season', 'episode', 'uniqueid', 'imdbnumber',
                           'file']})
        item = (result.get('result') or {}).get('item')
        if not isinstance(item, dict):
            continue
        mediatype = (item.get('type') or '').lower()
        if mediatype not in ('movie', 'episode'):
            continue
        if not info.mediatype:
            info.mediatype = mediatype
        if not info.title:
            info.title = item.get('title') or ''
        if not info.original_title:
            info.original_title = item.get('originaltitle') or ''
        if not info.year and item.get('year'):
            info.year = _to_int(item.get('year'))
        if not info.show_title:
            info.show_title = item.get('showtitle') or ''
        if info.season is None:
            info.season = _to_int(item.get('season'))
        if info.episode is None:
            info.episode = _to_int(item.get('episode'))
        if info.mediatype == 'movie':
            uniqueids = item.get('uniqueid')
            if isinstance(uniqueids, dict):
                for provider in ID_PROVIDERS:
                    value = uniqueids.get(provider)
                    if value:
                        info.add_id(provider, value)
            _add_imdb_number(info, item.get('imdbnumber'))
        return


def _add_parsed_id(info, value):
    """Add an id from a raw Kodi value like 'tmdb:105' or 'tt0088763'."""
    if not value:
        return
    provider, media_id = parse_id(value)
    if provider:
        info.add_id(provider, media_id)


def _add_imdb_number(info, value):
    """Kodi's IMDBNumber sometimes carries a TMDB id instead.

    Only a 'tt...' value is certainly IMDb; a bare number is treated as a
    TMDB id only when no other id is present yet."""
    if not value:
        return
    provider, media_id = parse_id(value)
    if provider == 'imdb':
        info.add_id('imdb', media_id)
    elif provider == 'tmdb':
        info.add_id('tmdb', media_id)


# ---------------------------------------------------------------------- #
# resolution (library + title search)                                    #
# ---------------------------------------------------------------------- #

def resolve(info, api=None, cache=None):
    """Resolve provider+media_id for a MediaInfo.

    Order: ids already collected -> Kodi library -> title search. Returns
    the MediaInfo with ``provider``/``media_id``/``source`` set, or None."""
    if info is None:
        return None
    provider, media_id = info.best_id()
    if provider:
        info.provider, info.media_id = provider, str(media_id)
        info.source = info.source or 'listitem'
        return info
    if library_lookup(info):
        return info
    if api is not None:
        provider, media_id = search_lookup(info, api, cache)
        if provider:
            info.provider, info.media_id = provider, str(media_id)
            info.source = 'search'
            return info
    log_debug('identify: unresolved {}'.format(describe(info)))
    return None


def describe(info):
    """Compact dump of a MediaInfo for the log (diagnosing failed cases)."""
    if info is None:
        return '<no info>'
    return ('type={} title={!r} original={!r} show={!r} S{}E{} year={} '
            'ids={} file={!r}'.format(
                info.mediatype, info.title, info.original_title,
                info.show_title, info.season, info.episode, info.year,
                info.ids, info.file_path))


def identify(api=None, cache=None, listitem=None):
    """Collect and resolve the currently playing item in one call."""
    return resolve(collect(listitem), api=api, cache=cache)


def library_lookup(info):
    """Fill provider/media_id from the Kodi library. Returns True on hit."""
    if info.file_path:
        result = lookup_by_file(info.file_path)
        if result:
            return _apply_library_result(info, result)
    if info.mediatype == 'episode':
        result = lookup_by_metadata(info.show_title or info.title,
                                    info.season, info.episode)
    else:
        result = lookup_movie_by_metadata(info.title, info.year,
                                          info.original_title)
    if result:
        return _apply_library_result(info, result)
    return False


def _apply_library_result(info, result):
    info.provider = result['provider']
    info.media_id = str(result['media_id'])
    info.source = 'library'
    if result.get('mediatype') == 'episode':
        info.mediatype = 'episode'
        if info.season is None and result.get('season') is not None:
            info.season = result['season']
        if info.episode is None and result.get('episode') is not None:
            info.episode = result['episode']
    return True


def search_lookup(info, api, cache=None):
    """Resolve provider+media_id via MDBList title search.

    Tries the original title first, then the localized title and cleaned
    variants. Returns (provider, media_id) or (None, None)."""
    search_type = 'show' if info.mediatype == 'episode' else 'movie'
    titles = candidate_titles(info)
    for title in titles:
        provider, media_id = _search_one(title, search_type, info, api, cache)
        if provider:
            log_debug(f'id-search: "{title}" -> {provider}:{media_id}')
            return provider, media_id
    log_debug('id-search: no result for {}'.format(
        ' / '.join(titles) or info.title))
    return None, None


def _search_one(title, search_type, info, api, cache):
    key = search_cache_key(title, search_type, info.year)
    if cache is not None:
        cached = cache.get(key)
        if cached:
            return cached[0], str(cached[1])
    try:
        response = api.search_media(title, search_type)
    except Exception as exc:
        log_debug(f'id-search failed for "{title}": {exc}')
        return None, None
    match = pick_match(response, search_type, info.year)
    if not match:
        return None, None
    provider, media_id = best_entry_id(match)
    if not provider:
        log_debug('id-search: no usable ids in '
                  f'{str(match)[:200]}')
        return None, None
    if cache is not None:
        cache.set(key, [provider, str(media_id)], ttl=SEARCH_TTL)
    return provider, str(media_id)


def search_cache_key(title, search_type, year=None):
    return 'scrobble-id:{}:{}'.format(
        'show' if search_type == 'show' else 'movie',
        '{}:{}'.format((title or '').lower(), year or '').strip(':'))


def best_entry_id(entry):
    """Best provider:id pair of a search entry (tmdb > tvdb > imdb > ...)."""
    ids = entry_ids(entry)
    for provider in PROVIDER_ORDER:
        value = ids.get(provider)
        if value not in (None, ''):
            return provider, value
    return None, None


def candidate_titles(info):
    """Ordered, deduplicated title candidates for a search."""
    if info.mediatype == 'episode':
        bases = [info.show_title, info.title]
    else:
        bases = [info.original_title, info.title]
    titles = []
    for raw in bases:
        for variant in _title_variants(raw):
            if variant and variant not in titles:
                titles.append(variant)
    return titles


def _title_variants(raw):
    value = ' '.join(str(raw or '').split())
    if not value:
        return []
    variants = [value]
    cleaned = _clean_title(value)
    if cleaned and cleaned not in variants:
        variants.append(cleaned)
    for base in list(variants):
        for transform in (_transliterate, _strip_diacritics):
            converted = transform(base)
            if converted and converted not in variants:
                variants.append(converted)
    return variants


def _clean_title(value):
    value = _BRACKET_YEAR.sub(' ', value)
    value = _YEAR_SUFFIX.sub(' ', value)
    value = _QUALITY_SUFFIX.sub('', value)
    return ' '.join(value.split()).strip(' -–:.')


def _transliterate(value):
    return ''.join(_TRANSLIT.get(char, char) for char in value)


def _strip_diacritics(value):
    decomposed = unicodedata.normalize('NFKD', value)
    return ''.join(c for c in decomposed if not unicodedata.combining(c))


def pick_match(response, search_type, year=None):
    """Pick the best entry from a search response.

    Prefers an exact year match; when none is found (or no year is known)
    it falls back to the highest-scored entry so a slightly different
    release year does not discard an otherwise valid result."""
    entries = _search_entries(response, search_type)
    if not entries:
        return None
    if year:
        wanted = int(year)
        for entry in entries:
            entry_year = _entry_year(entry)
            if entry_year is not None and entry_year == wanted:
                return entry
        return max(entries, key=_entry_score)
    return entries[0]


def _search_entries(response, search_type='movie'):
    if isinstance(response, list):
        return [e for e in response if isinstance(e, dict)]
    if isinstance(response, dict):
        # documented bucket is 'search'; keep legacy keys as fallback
        for key in ('search', search_type + 's', 'results', 'items',
                    'searchresults'):
            if isinstance(response.get(key), list):
                return [e for e in response[key] if isinstance(e, dict)]
        nested = [v for v in response.values() if isinstance(v, dict)]
        if not nested:
            log_debug('id-search: empty response '
                      f'{str(response)[:200]}')
        return nested
    return []


def _entry_year(entry):
    entry_year = entry.get('year')
    if entry_year is not None:
        return _to_int(entry_year)
    release = str(entry.get('release_date') or entry.get('first_air_date')
                  or '')
    return int(release[:4]) if release[:4].isdigit() else None


def _entry_score(entry):
    try:
        return float(entry.get('score') or 0)
    except (TypeError, ValueError):
        return 0.0


def _to_int(value):
    if value in (None, ''):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
