# -*- coding: utf-8 -*-
"""Scrobble playback progress to MDBList (start/pause/stop).

Identification is delegated to the shared mdblist.identify module, which
collects ids/titles from every source Kodi exposes and resolves them via
existing ids, the Kodi library or a title search. A scrobble rejected
with 404 (unknown id) is retried once with a fresh title-search id before
giving up. Payloads follow the MDBList API spec: episodes use nested
season structures and numeric tmdb/trakt/tvdb ids.
"""
from . import identify
from .api.mapping import typed_ids
from .api.request import MDbListError
from .logger import log_debug, log_error
from .utils import get_setting, localized, notify

# /scrobble/stop and /scrobble/pause mark an item watched from this progress
# on (https://api.mdblist.com/schema/). The cutoff is fixed server-side, so a
# higher local threshold can only be honoured through the value we report.
SERVER_WATCHED_PERCENT = 80.0
# methods the cutoff applies to; 'start' only updates the session and 'clear'
# carries no progress, so both are reported unchanged
WATCHED_METHODS = ('stop', 'pause')


class ScrobbledItem(object):
    """Wraps a MediaInfo for scrobbling; provider/media_id are filled by
    the identification chain while the scrobble is sent."""

    def __init__(self, info):
        self.info = info
        self.provider = info.provider
        self.media_id = info.media_id

    @property
    def mediatype(self):
        return self.info.mediatype

    @property
    def season(self):
        return self.info.season

    @property
    def episode(self):
        return self.info.episode

    @property
    def title(self):
        return self.info.search_title or self.info.title

    @property
    def year(self):
        return self.info.year

    @property
    def file_path(self):
        return self.info.file_path

    @property
    def valid(self):
        return self.info.valid

    def build_payload(self, progress=0):
        payload = {'progress': round(float(progress or 0), 2)}
        ids = typed_ids({self.provider: self.media_id})
        if self.mediatype == 'episode':
            if self.season is None or self.episode is None:
                return None
            payload['show'] = {
                'ids': ids,
                'season': {'number': int(self.season),
                           'episode': {'number': int(self.episode)}},
            }
        else:
            payload['movie'] = {'ids': ids}
        return payload


class Scrobbler(object):

    def __init__(self, api=None, min_percent=5, cache=None,
                 watched_percent=None):
        from . import get_api
        from .cache import get_cache
        self.api = api or get_api(cache=False)
        self.cache = cache or get_cache()
        self.min_percent = max(int(min_percent), 0)
        # None = read the setting on every send; the player caches this
        # instance, so a frozen value would need a Kodi restart to take effect
        self.watched_percent = watched_percent

    def _watched_threshold(self):
        """Progress at which the user considers an item watched (80-100)."""
        value = self.watched_percent
        if value is None:
            value = get_setting('watched_min_percent', 'int')
        try:
            value = float(value or SERVER_WATCHED_PERCENT)
        except (TypeError, ValueError):
            value = SERVER_WATCHED_PERCENT
        return max(SERVER_WATCHED_PERCENT, min(value, 100.0))

    def _reported_progress(self, method, progress):
        """Map the local progress onto the server's fixed watched cutoff.

        Reaching the threshold is reported as 100 so the item is definitely
        marked watched; below it the value is held just under the server
        cutoff, which keeps the item unwatched and leaves a resume point
        instead. Anything below that cutoff passes through untouched, so the
        default threshold of 80 behaves exactly like no mapping at all."""
        progress = float(progress or 0)
        if method not in WATCHED_METHODS:
            return progress
        threshold = self._watched_threshold()
        if progress >= threshold:
            return 100.0
        return min(progress, SERVER_WATCHED_PERCENT - 1.0)

    # ------------------------------------------------------------------ #
    # identification                                                     #
    # ------------------------------------------------------------------ #

    def _identify(self, item):
        """Resolve provider+media_id; returns the identification source."""
        info = identify.resolve(item.info, api=self.api, cache=self.cache)
        if info is None:
            return None
        item.provider = info.provider
        item.media_id = info.media_id
        return info.source or 'unknown'

    # ------------------------------------------------------------------ #
    # scrobbling                                                         #
    # ------------------------------------------------------------------ #

    def _post(self, method, item, progress):
        """Send one scrobble request; returns the parsed response."""
        payload = item.build_payload(progress)
        if payload is None:
            raise ValueError('incomplete episode info')
        return self.api.scrobble(method, movie=payload.get('movie'),
                                 show=payload.get('show'),
                                 progress=payload['progress'])

    def _remember_session(self, method, item, progress, response):
        """Note the paused session this device just created on MDBList.

        The sync needs that to tell its own session apart from another
        device's: without it every sync would rewrite the resume point of
        the item that was just played here, derived from a runtime that
        need not match the local file.
        """
        from . import resume
        if method not in ('pause', 'stop'):
            return
        if progress >= SERVER_WATCHED_PERCENT:
            return  # above the cutoff MDBList marks it watched instead
        if not item.provider or not item.media_id:
            return
        if item.mediatype == 'episode' and (item.season is None or
                                            item.episode is None):
            return
        data = response if isinstance(response, dict) else {}
        try:
            session_id = int(data['id']) if data.get('id') is not None \
                else None
        except (TypeError, ValueError):
            session_id = None
        # 'pause' answers with the session's own paused_at (server clock),
        # 'stop' documents only 'progress' - then our send time is the best
        # available reference, and remote_is_newer() treats it as uncertain
        paused_at = (data.get('paused_at') or data.get('updated_at') or
                     resume.now_iso())
        if item.mediatype == 'episode':
            key = resume.episode_key(item.provider, item.media_id,
                                     item.season, item.episode)
        else:
            key = resume.movie_key(item.provider, item.media_id)
        resume.mark_pushed(key, progress, session_id, paused_at)

    def _retry_via_search(self, method, item, progress):
        """After a 404: retry once with a fresh title-search id.
        Returns (retried_ok, response)."""
        failed = (item.provider, str(item.media_id))
        saved = (item.provider, item.media_id)
        # search without the cache so a possibly stale id is not reused
        provider, media_id = identify.search_lookup(item.info, self.api,
                                                    cache=None)
        if not provider or (provider, str(media_id)) == failed:
            item.provider, item.media_id = saved
            return False, None
        item.provider, item.media_id = provider, str(media_id)
        log_debug(f'SCROBBLE [{method}] 404 for {failed[0]}:{failed[1]}, '
                  f'retrying via search id {item.provider}:{item.media_id}')
        try:
            response = self._post(method, item, progress)
        except Exception as exc:
            log_error(f'SCROBBLE [{method}] retry failed for '
                      f'{item.provider}:{item.media_id}: {exc}')
            item.provider, item.media_id = saved
            return False, None
        self._notify(method, item)
        return True, response

    def send(self, method, item, progress=0):
        if not item or not item.valid:
            log_debug('SCROBBLE skipped: no identifiable item')
            return None
        source = self._identify(item)
        if not source:
            log_error(f'SCROBBLE skipped: could not resolve '
                      f'"{item.title}" ({item.mediatype})')
            return None
        reported = self._reported_progress(method, progress)
        mapped = '' if reported == float(progress or 0) else \
            f' (reported as {reported:.1f}%, threshold ' \
            f'{self._watched_threshold():.0f}%)'
        log_debug(f'SCROBBLE [{method}] (id: {source}) '
                  f'{item.provider}:{item.media_id} '
                  f'"{item.title}" at {progress}%{mapped}')
        try:
            response = self._post(method, item, reported)
        except MDbListError as exc:
            if exc.status_code == 404:
                retried, response = self._retry_via_search(method, item,
                                                           reported)
                if retried:
                    self._remember_session(method, item, reported, response)
                    return item
            log_error(f'SCROBBLE [{method}] failed for {item.provider}:'
                      f'{item.media_id} "{item.title}": {exc}')
            return None
        except ValueError:
            log_debug('SCROBBLE skipped: incomplete episode info')
            return None
        except Exception as exc:  # never block playback on api errors
            log_error(f'SCROBBLE [{method}] failed for {item.provider}:'
                      f'{item.media_id}: {exc}')
            return None
        self._remember_session(method, item, reported, response)
        self._notify(method, item)
        return item

    @staticmethod
    def _notify(method, item):
        if not get_setting('show_notifications', 'bool'):
            return
        if method not in ('start', 'stop'):
            return
        label = localized(32127) or 'Scrobbling'
        notify('{}: {}'.format(label, item.title))
