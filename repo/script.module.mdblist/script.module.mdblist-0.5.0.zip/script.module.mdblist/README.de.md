# script.module.mdblist

[English](README.md) | [Deutsch](README.de.md)

Ausführliche Anleitung: [Deutsch](GUIDE.de.md) · [English](GUIDE.md)

MDBList.com-Integration für Kodi — Scrobbling, Bibliotheks-Synchronisierung
und ein Python-Modul für Drittanbieter-Addons. Funktioniert wie das
Trakt-Addon, nur für [MDBList](https://mdblist.com).

Benötigt einen kostenlosen API-Schlüssel: auf mdblist.com anmelden →
Preferences → API key, dann in den Addon-Einstellungen eintragen.

## Funktionen

- **Dienst** (`xbmc.service`): Scrobbling des Wiedergabefortschritts zu MDBList
  (start/pause/stop), optionales Bewertungs-Popup nach der Wiedergabe
  (Episoden auf Episoden-Ebene), geplante und ereignisgesteuerte
  Synchronisierungen (nach Bibliotheksaktualisierung, Intervall-Timer,
  Startverzögerung).
- **Robuste Identifikation** für Wiedergabe aus Widgets/Streaming-Addons
  (z. B. xStream, TMDbHelper): IDs und Titel werden aus allen Quellen
  gesammelt, die Kodi bietet (ListItem-UniqueIDs und -Properties,
  VideoPlayer-Infolabels inkl. `VideoPlayer.UniqueID(...)`,
  `Player.GetItem`) und danach über die Kodi-Bibliothek (Dateipfad,
  Titel/Jahr, Serie + Staffel/Episode) sowie eine Titelsuche aufgelöst, die
  zuerst den Originaltitel und dann bereinigte/transliterierte Varianten
  probiert und jede Provider-ID akzeptiert. Dieselbe Kette nutzt auch das
  Kontextmenü, sodass diese Aktionen auch bei Plugin-Wiedergabe funktionieren.
- **Skript-Aktionen** (`xbmc.python.script`), aufrufbar aus Skins,
  Kontextmenüs oder anderen Addons:
  ```
  RunScript(script.module.mdblist, action=contextmenu)
  RunScript(script.module.mdblist, action=sync)
  RunScript(script.module.mdblist, action=repair_watched_dates[,limit=3])
  RunScript(script.module.mdblist, action=rate,type=movie,id=tmdb:769,rating=9)
  RunScript(script.module.mdblist, action=addtowatchlist,type=show,id=tmdb:1399)
  RunScript(script.module.mdblist, action=removefromwatchlist,...)
  RunScript(script.module.mdblist, action=togglewatched,...)
   RunScript(script.module.mdblist, action=markwatched|markunwatched,...)
   RunScript(script.module.mdblist, action=unrate,...)
   RunScript(script.module.mdblist, action=clearprogress[,type=...,id=...])
   RunScript(script.module.mdblist, action=auth_info)
  ```
  `id` akzeptiert `tmdb:12345`, `imdb:tt0117731`, `trakt:...`, `tvdb:...`.
  Ohne `id`/`type` wird der aktuell abgespielte Titel verwendet.
- **Synchronisierung** (bidirektional, jede Richtung einzeln abschaltbar):
  - Gesehen-Status für Filme + Episoden (plays-bewusst, neuester
    Zeitstempel gewinnt; Episoden über den dokumentierten flachen
    episodes-Bucket gepusht; Serien ausschließlich auf Episodenebene,
    Staffel-Flags „ganze Staffel gesehen" werden ignoriert; MDBList ist
    beim Pull führend — dort als gesehen geführte Einträge werden in
    Kodi als gesehen markiert, dort als explizit ungesehen geführte
    Einträge werden in Kodi als ungesehen markiert (Gesehen-Zähler,
    Sehdatum und evtl. Fortsetzungspunkt zurückgesetzt), alles, was MDBList
    nicht kennt, bleibt unverändert)
  - Fortsetzungspositionen („Weiterschauen", nur Pull, standardmäßig
    aktiv): Der Fortsetzungspunkt von Filmen und Episoden wird aus den
    pausierten Wiedergabe-Sitzungen von MDBList übernommen, sodass ein auf
    einem Gerät unterbrochener Titel auf einem anderen fortgesetzt werden
    kann. Von diesem Gerät selbst gesendete Sitzungen werden ignoriert,
    bereits hier gesehene Titel bleiben unverändert, und der Fortschritt
    wird in Prozent verglichen — eine nur geringfügig weiter reichende
    Position wird daher nicht überschrieben
  - Bewertungen (Kodi-*userrating* ↔ MDBList-Bewertung)
  - optional: Kodi-Bibliothek mit der MDBList-Sammlung abgleichen
    (Filme + Episoden, nur Hinzufügen; standardmäßig aus)
- **Python-Modul** für andere Addons:

  ```xml
  <import addon="script.module.mdblist" version="0.1.0"/>
  ```

  ```python
  import mdblist

  api = mdblist.get_api()          # nutzt den konfigurierten Benutzer-Schlüssel
  info = api.get_media_info('769', 'movie', 'tmdb')       # Bewertungen, Score, ...
  api.add_watchlist_items(movies=[{'tmdb': 769}])
  api.push_ratings([{'type': 'movie', 'ids': {'tmdb': 769}, 'rating': 9}])
  for item in api.iter_all('watchlist/items'):
      ...
  listen = api.get_top_lists() or api.search_lists('star wars')
  items = api.get_list_items(list_id, {'sort': 'score', 'order': 'desc'})
  ```

  Weitere Helfer: `mdblist.has_api_key()` (ist ein Schlüssel konfiguriert),
  `mdblist.parse_id('tmdb:769')` → `('tmdb', '769')` (akzeptiert auch
  `imdb:tt...`), der Alias `mdblist.get_client` zu `get_api`,
  `mdblist.__version__` und `api.is_authorized()` zum Prüfen des Schlüssels.

## API-Abdeckung (Client)

Medieninfos & Batch, Bewertungs-Abfrage, Watchprovider-Links, Suche · Listen:
top/user/curated/official/liked/recommended/search/share/external + vollständiges
CRUD (erstellen/ändern/löschen/Titel hinzufügen & entfernen/like/membership/
changes) · Merkliste get/add/remove · Sync: watched/collection/ratings/dropped
(+Staffeln)/last_activities/journal/item state/history/playback sessions ·
Scrobble start/pause/stop/clear + now-playing · Check-in CRUD · UpNext
(+upcoming/watchlist) · Kalender-Events + Benachrichtigungs-Einstellungen ·
Benutzer/Profil/Statistiken · Genres, Updates, JustWatch-Streaming-Charts.

Low-Level-Helfer für alles ohne eigene Methode:
`api.get_json/post_json/put_json/patch_json/delete_json(path, ...)` und
`api.get_response(path, ...)` für die rohe Antwort (z. B. Pagination-Header).

Pagination-Helfer:

```python
for item in api.iter_all('watchlist/items'):
    ...
```

## Einstellungen

| Kategorie | Einstellung |
|---|---|
| Allgemein | API-Schlüssel, Debug-Protokollierung, Benachrichtigungen anzeigen |
| Scrobbeln | aktivieren, Mindestfortschritt (%), als gesehen zählen ab (%) (80-100, Standard 80), auch für Kodis Gesehen-Zähler übernehmen, Bewertungs-Popup (aus, Mindestfortschritt ≥ 75 %, Filme/Serien-Filter) |
| Synchronisierung | Gesehen Push/Pull, Bewertungen Push/Pull, Weiterschauen-Fortschritt importieren, Bibliothek → Sammlung (aus), Startverzögerung, Intervall (0 = aus), Sync nach Bibliotheksaktualisierung |

## Tests

Unit-Tests für die Identifikationslogik laufen außerhalb von Kodi (die
Kodi-Module werden in `tests/conftest.py` gestubbt):

```
python -m pytest tests
```

## Hinweise zum Rate-Limit

Ein kostenloses MDBList-Konto erlaubt 1.000 Anfragen/Tag. Das Addon cacht
deshalb aggressiv (SQLite), nutzt `/sync/last_activities`, um Pull-Syncs ohne
entfernte Änderungen zu überspringen, und vergleicht Pushes gegen einen
gecachten Remote-Snapshot.

## Lizenz

GPL-2.0-only — siehe LICENSE.txt.
