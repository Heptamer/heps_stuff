# -*- coding: utf-8 -*-
"""Bookkeeping for MDBList playback progress ("resume points").

MDBList keeps a paused playback session for every movie/episode that was
stopped below the watched threshold; those sessions are what
``GET /sync/playback`` returns and what lets another device pick the item
back up. Two things about them have to survive the end of the process
that created them, so both are stored in the addon cache (30 days):

1. *which session this device pushed itself*. Without that, a sync cannot
   tell its own scrobble apart from another device's session and would
   rewrite the resume point of the very movie that was just played here -
   once per sync, with a position derived from a different runtime.
2. *when that happened*. A remote session that is older than our own push
   must not pull the resume point backwards.

Keys are built from the item's provider ids, so the scrobbler (which knows
one resolved id) and the sync engine (which knows every id a library entry
carries) end up on the same key through :func:`keys`.
"""
from datetime import datetime, timezone

from .utils import datetime_to_iso, iso_to_datetime

# cache entries only have to outlive the server side session expiry
TTL = 30 * 86400
CACHE_PREFIX = 'resume:'
# provider ids a key can be built from, in the order the sync engine prefers
PROVIDERS = ('tmdb', 'tvdb', 'imdb', 'trakt', 'mal')
# progress difference below which two positions are considered the same
PROGRESS_TOLERANCE = 0.5
# progress difference below which a resume point is not rewritten at all
POSITION_TOLERANCE = 1.0
# a remote timestamp within this distance of our own push counts as
# "cannot tell" (device clock vs. server clock); 6 h absorbs a device clock
# that is off by hours without letting yesterday's session pass for today's
CLOCK_TOLERANCE = 6 * 3600


def _normalize_id(value):
    try:
        return str(int(value))
    except (TypeError, ValueError):
        return str(value)


def movie_key(provider, media_id):
    """Cache key of a movie's resume state."""
    return '{}:{}'.format(_normalize_id(provider), _normalize_id(media_id))


def episode_key(provider, show_id, season, episode):
    """Cache key of an episode's resume state (keyed by its show id, the
    same id the scrobble payloads use)."""
    return 'episode:{}:{}:{}:{}'.format(
        _normalize_id(provider), _normalize_id(show_id),
        int(season), int(episode))


def keys(mediatype, ids, season=None, episode=None):
    """All cache keys of one item, one per provider id it carries.

    An item reached by any of its ids is the same item, so the caller can
    look the state up under each of them instead of having to agree on a
    single preferred provider with the writer of the record.
    """
    result = []
    is_episode = (mediatype == 'episode' and
                  season is not None and episode is not None)
    for provider in PROVIDERS:
        value = (ids or {}).get(provider)
        if value in (None, ''):
            continue
        result.append(episode_key(provider, value, season, episode)
                      if is_episode else movie_key(provider, value))
    return result


def load(key):
    """Stored resume state of one key, or None."""
    from .cache import get_cache
    return get_cache().get(CACHE_PREFIX + str(key))


def load_any(keys):
    """First stored record for any of keys -> (key, record) or (None, None)."""
    for key in keys or ():
        record = load(key)
        if record:
            return key, record
    return None, None


def clear_any(keys):
    """Forget every record of an item (after its session was deleted)."""
    from .cache import get_cache
    cache = get_cache()
    for key in keys or ():
        cache.delete(CACHE_PREFIX + str(key))
    return len(keys or ())


def _store(key, fields):
    from .cache import get_cache
    record = load(key) or {}
    record.update({k: v for k, v in fields.items() if v is not None})
    get_cache().set(CACHE_PREFIX + str(key), record, ttl=TTL)
    return record


def mark_pushed(key, progress, session_id=None, at=None):
    """Remember the session this device just pushed for an item.

    ``at`` is the session's own server timestamp when the API returned
    one, otherwise the moment the request went out (see the scrobbler).
    """
    return _store(key, {'pushed_progress': round(float(progress or 0), 2),
                        'pushed_session': session_id, 'pushed_at': at})


def mark_applied(key, progress, session_id=None, at=None):
    """Remember the remote session that was written to the library."""
    return _store(key, {'applied_progress': round(float(progress or 0), 2),
                        'applied_session': session_id, 'applied_at': at})


def now_iso():
    return datetime_to_iso(datetime.now(timezone.utc))


def is_own(record, progress, session_id=None,
           tolerance=PROGRESS_TOLERANCE):
    """True when the remote session is the one this device pushed.

    Matched on the session id when both sides have one, otherwise on the
    reported progress - the same movie stopped twice at the same position
    is indistinguishable anyway, and both cases mean "do not touch it".
    """
    if not record:
        return False
    own_session = record.get('pushed_session')
    if session_id is not None and own_session is not None:
        if int(session_id) == int(own_session):
            return True
    own_progress = record.get('pushed_progress')
    if own_progress is None:
        return False
    try:
        return abs(float(own_progress) - float(progress)) <= tolerance
    except (TypeError, ValueError):
        return False


def pushed_at(record):
    """ISO timestamp of our own last push, or None."""
    return (record or {}).get('pushed_at')


def remote_is_newer(record, remote_at, tolerance=CLOCK_TOLERANCE):
    """True when a remote session is clearly newer than our own push.

    Only asked when the remote progress is *behind* the local one, i.e.
    whether another device deliberately restarted the item. A missing
    timestamp on either side counts as "cannot tell" and answers False,
    so an unclear comparison keeps the local position instead of moving it
    backwards - clock drift may then delay an update, never cause one.
    """
    remote_dt = iso_to_datetime(remote_at)
    own_dt = iso_to_datetime(pushed_at(record))
    if remote_dt is None or own_dt is None:
        return False
    try:
        # a naive remote timestamp cannot be compared against our aware one
        return (remote_dt - own_dt).total_seconds() > tolerance
    except TypeError:
        return False