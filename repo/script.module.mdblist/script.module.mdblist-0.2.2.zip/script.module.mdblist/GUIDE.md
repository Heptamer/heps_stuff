# MDBList Addon – User Guide (English)

[Deutsche Anleitung](GUIDE.de.md) · [English README](README.md) · [German README](README.de.md)

`script.module.mdblist` connects Kodi to [MDBList.com](https://mdblist.com):
playback scrobbling, synchronisation between the Kodi library and your
MDBList account, plus a Python module for third-party addons.

## Requirements

- Kodi 19 (Matrix) or newer
- Free MDBList account with an API key: log in at mdblist.com →
  *Preferences* → *API key*
- Enter the key in the addon: *Addons → My add-ons → MDBList → Configure →
  General → API key*

## Scrobbling

While the background service runs, every movie/episode playback is reported
to MDBList:

| Event | Sent | Kodi notification |
|---|---|---|
| Playback started | `start` | yes |
| **Paused** | `pause` | **no (by design)** |
| Resumed | `start` (with current progress) | yes |
| Stopped / ended | `stop` | yes |

> **About pause:** Pausing is fully evaluated and transmitted to MDBList —
> it just deliberately shows no notification, so frequent pausing does not
> spam you. mdblist.com still marks the item as paused. To verify: enable
> debug logging; pausing logs `SCROBBLE [pause] …`.

Settings:

- **Enable scrobbling** (default: on)
- **Minimum progress %**: stops below this value do not count as watched
  (default 5 %). The item is still reported as `stop` to MDBList so it does
  not stay stuck in "Now Playing" / the live activity feed — it is simply not
  marked watched.
- **Count as watched from (%)** (80-100, default 80): MDBList itself marks
  an item watched from 80 % of the reported progress and that cutoff cannot
  be changed server-side. A higher value holds the reported progress just
  below it until your threshold is reached - the item then stays unwatched
  and gets a resume point instead of a watched entry.
- **Also apply to Kodi's play count threshold** (default: off): Kodi marks
  items watched from 90 % by default, and the library sync pushes whatever
  Kodi counted - that would undercut a higher threshold above. Enabling this
  aligns Kodi's own setting (off by default, because it changes a global
  Kodi setting).

### Rating prompt after playback

Optional (off by default): after a movie/episode finishes — or is stopped
past the threshold — the addon opens a picker dialog
(*No rating, 1 ★ … 10 ★*) and pushes the choice to MDBList.

- **Ask for a rating after playback**: enable the feature
- **Minimum progress for rating prompt (%)**: slider, minimum 75 %
  (default 85 %)
- **Ask for rating on**: movies and episodes / movies only / episodes only

Notes:

- The prompt requires scrobbling to be enabled (identification depends on it)
  and only appears when the item could be identified.
- Episodes are rated at **episode level** on mdblist.com. The ratings *pull*
  currently reads movies back into Kodi only, so episode ratings do not sync
  back yet.
- The same star picker replaces the old numeric keypad when rating via the
  context menu.

### How content is identified

Played items are identified in this order:

1. TMDB/IMDB id of the Kodi ListItem (library items)
2. VideoPlayer InfoLabels (show title, season, episode, year) when the
   ListItem carries no mediatype (widget/plugin playback, e.g. TMDbHelper)
3. Reverse lookup of the playing file path in the Kodi library (e.g. for
   strm files from xStream that carry no ids); episodes additionally by
   show title + season/episode
4. Title/year search via the MDBList API (items not in any library),
   cached for 30 days

## Synchronisation

Each direction can be toggled separately (*Settings → Sync*):

- **Watched status**: push and pull for movies and episodes. Play counts are
  compared; on ties the newer timestamp wins. MDBList is **authoritative** on
  the pull, but only for items MDBList actually knows about:
  - Items it lists as watched → marked watched in Kodi.
  - Items it lists as **explicitly unwatched** (from the MDBList sync journal)
    → marked unwatched in Kodi (`playcount` 0, watch date cleared). If such an
    item currently has a resume point in Kodi (shown as "partially watched"),
    that resume point is removed as well, so it no longer shows as started.
  - Items MDBList knows nothing about → left untouched in Kodi.
  To avoid an endless loop, the **push** skips anything MDBList currently
  lists as explicitly unwatched: marking an item unwatched on MDBList is
  never silently undone by the next push, even while Kodi still counts it
  watched.
  Shows are synced strictly on the **episode level**: episodes are pushed with
  their own episode id (the flat documented `episodes` bucket), and the pull
  applies what MDBList lists as a watched (or explicitly-unwatched) individual
  episode. Whole-season flags ("whole season watched") from MDBList are
  ignored, because MDBList can set them inconsistently; Kodi derives a watched
  season from its own watched episodes.
- **Ratings**: Kodi *userrating* ↔ MDBList rating (movies; shows to follow).
- **Library → collection** (default: off): syncs the whole Kodi library with
  the MDBList collection — movies **and individual episodes**. Add-only:
  removing files from Kodi never removes them from the collection. Only this
  option makes **unwatched** movies/shows visible on mdblist.com.

Important when reading logs/summaries: numbers always mean "newly
transferred **in this run**". `movies: 0` means "nothing new" — not "the
collection is empty".

Further settings:

- **Startup delay**: wait after Kodi start before the first sync
  (default 120 s)
- **Interval**: periodic sync in minutes, 0 = off
- **Sync after library update**: sync after every scan/clean. A rescan can
  mean a show was deleted and re-added (Kodi resets its playcounts then), so
  this sync runs forced: it re-applies the remote watched state even when the
  MDBList activity watermark is unchanged.

### Manual sync

Context menu of the addon → **Sync now**, or
`RunScript(script.module.mdblist, action=sync)`.

A manual sync waits up to 45 seconds if a service sync is currently running
instead of failing instantly. If you see "a sync is already running", no slot
was free within that window — simply try again. A confirmation appears after
real completion.

## Actions (RunScript)

```text
RunScript(script.module.mdblist, action=sync)              # force a sync
RunScript(script.module.mdblist, action=rate, id=tmdb:769, rating=9)
RunScript(script.module.mdblist, action=unrate, id=tmdb:769)
RunScript(script.module.mdblist, action=markwatched, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=markunwatched, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=togglewatched, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=addtowatchlist, type=show, id=tmdb:1399)
RunScript(script.module.mdblist, action=removefromwatchlist, type=show, id=tmdb:1399)
RunScript(script.module.mdblist, action=repair_watched_dates[, limit=3])
RunScript(script.module.mdblist, action=auth_info)         # show key status
RunScript(script.module.mdblist, action=contextmenu)       # open dialog
```

`id` accepts `tmdb:`, `imdb:`, `trakt:`, `tvdb:` or a bare number. Without
`id`/`type` the currently playing item is used.

## Troubleshooting

1. Enable *Debug logging* in the addon settings
2. Restart Kodi or trigger a manual sync
3. Check the log (`kodi.log`); relevant lines start with
   `[script.module.mdblist]`

Typical lines:

```text
SCROBBLE [start] (id: library) tmdb:1399 "Show X" at 3%
SCROBBLE [pause] …            ← pause was sent (no notification by design)
Remote watched snapshot: movies=3 shows=0 seasons=1 episodes=3 total=7 complete=True
Watched pull: {'movies': 0, 'episodes': 3, 'unwatched_movies': 0, 'unwatched_episodes': 0, 'resume_reset': 0}
Watched push: 3 entries (movies=1 episodes=2)
Watched push response: {'updated': 2, 'not_found': 0, 'errors': 0, 'plays': 0}
              (raw: ['{"updated":{"episodes":[{"tvdb":123}]},"not_found":{"episodes":[]},"errors":[],"plays":[]}'])
Collection remote snapshot: movies=12 shows=2
Collection diff: movies=0 show payloads=1 episodes=14 unresolved=0
Collection push: {'status': 'ok', 'movies': 0, 'episodes': 14}
Sync finished in 16.4s: {…}
```

Common cases:

- **Episodes/series watched in Kodi never reach mdblist.com**: before 0.1.8
  the episode sync used the nested `shows[].seasons[].episodes[].number`
  payload, which MDBList accepted but silently ignored. v0.1.8 pushes the
  documented flat `episodes` bucket keyed by the episode's own provider id.
  A show must be scraped so its episodes carry `uniqueid`s, otherwise the
  entries cannot be identified — the sync log then shows a warning with the
  number of episodes skipped.
- **Items missing from the collection**: `unresolved=` > 0 means a series
  could be neither matched by ids nor resolved via title search. Shows with
  TVDB-only ids are sent as such directly (MDBList accepts tmdb/tvdb/imdb/
  trakt).
- **Rate limit**: The free API tier allows 1000 requests/day; the caches
  (remote snapshots 6 h, id resolutions 30 days) keep usage low.
- **Reset everything**: delete `cache.db` in the addon profile folder and
  restart Kodi.
