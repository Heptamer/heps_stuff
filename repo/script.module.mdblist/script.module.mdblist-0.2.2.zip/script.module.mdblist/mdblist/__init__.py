# -*- coding: utf-8 -*-
"""Public interface of the script.module.mdblist python module.

Third-party addons:
    <import addon="script.module.mdblist" version="0.1.0"/>

    from mdblist import get_api, MDbListError

    api = get_api()               # uses the user's configured API key
    info = api.get_media_info('769', 'movie', 'tmdb')
"""
from .api.client import MDbList
from .api.request import BASE_URL, MDbListError, RequestAPI  # noqa: F401
from .utils import ADDON_ID, parse_id  # noqa: F401

__version__ = '0.2.2'
__all__ = ['get_api', 'get_client', 'MDbList', 'MDbListError',
           'RequestAPI', 'BASE_URL', 'parse_id', 'ADDON_ID', '__version__']


def get_api(api_key=None, cache=True):
    """Return a ready-to-use MDbList client.

    api_key: explicit key; when omitted the key from addon settings is used.
    cache:   enable sqlite response caching for GET requests (recommended)."""
    from .cache import get_cache as _get_cache
    if not api_key:
        from .utils import get_setting
        api_key = get_setting('api_key', 'str')
    return MDbList(api_key=api_key,
                   cache=_get_cache() if (cache and api_key) else None)


# alias for convenience
get_client = get_api


def has_api_key():
    from .utils import has_api_key as _has_key
    return _has_key()
