# -*- coding: utf-8 -*-
# Script entry point (xbmc.python.script).
# Usage: RunScript(script.module.mdblist, action=sync|contextmenu|rate|unrate|togglewatched|markwatched|markunwatched|addtowatchlist|removefromwatchlist|repair_watched_dates|auth_info[, type=movie|show][, id=tmdb:12345][, season=1][, episode=2][, rating=8][, limit=3])
from mdblist.actions import run

if __name__ == '__main__':
    run()
