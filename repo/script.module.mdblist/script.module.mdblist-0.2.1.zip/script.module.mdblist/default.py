# -*- coding: utf-8 -*-
# Service entry point (xbmc.service) - started automatically by Kodi.
from mdblist.service import run

if __name__ == '__main__':
    run()
