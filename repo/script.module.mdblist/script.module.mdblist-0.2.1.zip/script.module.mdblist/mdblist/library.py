# -*- coding: utf-8 -*-
"""Reverse identification of playing items through the Kodi video library.

When addons (e.g. xStream) start playback with their own ListItem, the
playing item carries no uniqueids even though the underlying .strm is a
scraped library entry. The playing file path matches the library entry,
so we can look up tmdb/imdb ids locally via JSON-RPC."""
from urllib.parse import unquote

from .logger import log_debug
from .utils import jsonrpc


def _query_ids_by_file(method, list_property, path, operator):
    result = jsonrpc(method, {
        'filter': {'field': 'file', 'operator': operator, 'value': path},
        'properties': ['uniqueid'],
    }).get('result') or {}
    items = result.get(list_property) or []
    return items[0] if items else None


def _best_uniqueid(ids):
    """Prefer tmdb over imdb."""
    ids = ids or {}
    if ids.get('tmdb'):
        return 'tmdb', str(ids['tmdb'])
    if ids.get('imdb'):
        return 'imdb', str(ids['imdb'])
    return None, None


def _shows_with_ids():
    """List all TV shows with their uniqueids."""
    return ((jsonrpc('VideoLibrary.GetTvShows',
                     {'properties': ['title', 'uniqueid']}).get('result') or {})
            .get('tvshows') or [])


def _norm_title(value):
    return ' '.join(str(value or '').lower().split())


def _episode_exists(tvshowid, season, episode):
    """True when the library holds this season/episode under the show."""
    result = jsonrpc('VideoLibrary.GetEpisodes', {
        'tvshowid': int(tvshowid), 'season': int(season),
        'properties': ['season', 'episode']}).get('result') or {}
    wanted = int(episode)
    for entry in result.get('episodes') or []:
        try:
            if int(entry.get('episode') or -1) == wanted:
                return True
        except (TypeError, ValueError):
            continue
    return False


def lookup_by_metadata(show_title, season, episode):
    """Resolve show ids via playing metadata (title + season/episode).

    Used when the playing file is a strm (getPlayingFile() reports the
    inner stream url, so a file path lookup fails). Returns
      {'mediatype': 'episode', 'provider': .., 'media_id': ..,
       'season': int, 'episode': int}
    or None."""
    if not (show_title and season is not None and episode is not None):
        return None
    wanted = _norm_title(show_title)
    if not wanted:
        return None
    try:
        shows = _shows_with_ids()
    except Exception as exc:
        log_debug(f'Library metadata lookup error: {exc}')
        return None
    for candidate in shows:
        if _norm_title(candidate.get('title')) != wanted:
            continue
        if not _episode_exists(candidate.get('tvshowid'), season, episode):
            continue
        provider, media_id = _best_uniqueid(candidate.get('uniqueid'))
        if media_id:
            return {'mediatype': 'episode', 'provider': provider,
                    'media_id': media_id,
                    'season': int(season), 'episode': int(episode)}
    log_debug(f'Library metadata lookup: no entry for "{show_title}" '
              f'S{season}E{episode}')
    return None


def lookup_by_file(file_path):
    """Find library metadata for an exact playing file path.
    Returns dict or None:
      movie:   {'mediatype': 'movie', 'provider': .., 'media_id': ..}
      episode: {'mediatype': 'episode', 'provider': .., 'media_id': ..,
                'season': int, 'episode': int}"""
    if not file_path:
        return None
    path = unquote(str(file_path))

    # movies ---------------------------------------------------------- #
    movie = (_query_ids_by_file('VideoLibrary.GetMovies', 'movies', path, 'is')
             or _query_ids_by_file('VideoLibrary.GetMovies', 'movies',
                                   path, 'contains'))
    if movie:
        provider, media_id = _best_uniqueid(movie.get('uniqueid'))
        if media_id:
            return {'mediatype': 'movie', 'provider': provider,
                    'media_id': media_id}

    # episodes -> show ids -------------------------------------------- #
    ep_filter = path
    episode = (_query_ids_by_file('VideoLibrary.GetEpisodes', 'episodes',
                                  ep_filter, 'is')
               or _query_ids_by_file('VideoLibrary.GetEpisodes', 'episodes',
                                     ep_filter, 'contains'))
    if episode:
        tvshowid = episode.get('tvshowid')
        show = None
        for candidate in _shows_with_ids():
            if candidate.get('tvshowid') == tvshowid:
                show = candidate
                break
        if show:
            provider, media_id = _best_uniqueid(show.get('uniqueid'))
            if media_id:
                return {'mediatype': 'episode', 'provider': provider,
                        'media_id': media_id,
                        'season': int(episode.get('season') or 0),
                        'episode': int(episode.get('episode') or 0)}

    log_debug(f'Library lookup: no entry for "{path}"')
    return None
