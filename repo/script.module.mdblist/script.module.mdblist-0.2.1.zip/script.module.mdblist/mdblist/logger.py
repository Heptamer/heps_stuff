# -*- coding: utf-8 -*-
import xbmc

ADDON_ID = 'script.module.mdblist'
LOG_PREFIX = f'[{ADDON_ID}]'


def log(message, level=1):
    """Log a message via xbmc.log. level 0=debug(warning gate), 1=info, 2=warning, 3=error."""
    if level == 0:
        level = xbmc.LOGDEBUG
    elif level == 1:
        level = xbmc.LOGINFO
    elif level == 2:
        level = xbmc.LOGWARNING
    else:
        level = xbmc.LOGERROR
    xbmc.log(f'{LOG_PREFIX} {message}', level)


def log_debug(message):
    if is_debug():
        log(message, 1)


def log_error(message):
    log(message, 3)


def is_debug():
    from .utils import get_setting
    return bool(get_setting('debug_logging', 'bool'))
