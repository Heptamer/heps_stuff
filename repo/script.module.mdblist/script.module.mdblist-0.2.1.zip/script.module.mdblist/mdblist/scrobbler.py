# -*- coding: utf-8 -*-
"""Scrobble playback progress to MDBList (start/pause/stop).

Identification strategy:
1. TMDB/IMDB uniqueid of the ListItem (movies; episode listitems carry
   episode-level ids which are NOT valid show ids, so they are ignored)
2. VideoPlayer InfoLabels (show title, season, episode, year) for
   widget/plugin playback where the ListItem has no mediatype set
3. Kodi library reverse lookup via the playing file path (strm items
   whose playback was started by addons like xStream with their own
   ListItem, losing the library metadata)
4. title/year search via MDBList API (items not in any library),
   resolved once and cached for 30 days.

A scrobble rejected with 404 (unknown id) is retried once with a fresh
title-search id before giving up. Payloads follow the MDBList API spec:
episodes use nested season structures and numeric tmdb/trakt/tvdb ids.
"""
from .api.mapping import entry_ids, typed_ids
from .api.request import MDbListError
from .logger import log_debug, log_error
from .utils import get_setting, localized, notify, parse_id

# /scrobble/stop and /scrobble/pause mark an item watched from this progress
# on (https://api.mdblist.com/schema/). The cutoff is fixed server-side, so a
# higher local threshold can only be honoured through the value we report.
SERVER_WATCHED_PERCENT = 80.0
# methods the cutoff applies to; 'start' only updates the session and 'clear'
# carries no progress, so both are reported unchanged
WATCHED_METHODS = ('stop', 'pause')


class ScrobbledItem(object):
    """Holds identification data of the currently scrobbled item."""

    def __init__(self, mediatype=None, provider='tmdb', media_id=None,
                 season=None, episode=None, title=None, year=None,
                 file_path=None):
        self.mediatype = mediatype          # 'movie' | 'episode'
        self.provider = provider
        self.media_id = media_id
        self.season = int(season) if season is not None else None
        self.episode = int(episode) if episode is not None else None
        self.title = title or ''
        self.year = year
        self.file_path = file_path

    @property
    def valid(self):
        if self.mediatype not in ('movie', 'episode'):
            return False
        return bool(self.media_id or self.title)

    def build_payload(self, progress=0):
        payload = {'progress': round(float(progress or 0), 2)}
        ids = typed_ids({self.provider: self.media_id})
        if self.mediatype == 'episode':
            if self.season is None or self.episode is None:
                return None
            payload['show'] = {
                'ids': ids,
                'season': {'number': int(self.season),
                           'episode': {'number': int(self.episode)}},
            }
        else:
            payload['movie'] = {'ids': ids}
        return payload

    @classmethod
    def from_listitem(cls, listitem):
        """Build identification from a Kodi ListItem (video only)."""
        try:
            tag = listitem.getVideoInfoTag()
        except AttributeError:
            return None
        mediatype = (tag.getMediaType() or '').lower()
        if mediatype not in ('movie', 'episode'):
            return None
        title = tag.getTitle() or ''
        year = tag.getYear() or None
        item = cls(mediatype=mediatype, title=title,
                   year=int(year) if year else None)
        if mediatype == 'episode':
            item.season = tag.getSeason()
            item.episode = tag.getEpisode()
            showtitle = tag.getTVShowTitle()
            if showtitle:
                # search by show name, not by episode title
                item.title = showtitle
                item.year = None
            # listitem uniqueids of strm/library items carry EPISODE ids,
            # which the API would reject as show ids -> leave them unset
            # and resolve via library lookup / title search instead.
            item.provider = None
            return item
        media_id = tag.getUniqueID('tmdb')
        provider = 'tmdb'
        if not media_id:
            imdb = tag.getUniqueID('imdb')
            if imdb:
                media_id = imdb
                provider = 'imdb'
        if not media_id:
            # fall back to uniqueid values like 'tmdb://12345'
            raw = tag.getUniqueID() or ''
            provider, media_id = parse_id(raw)
        item.provider = provider
        item.media_id = media_id
        return item

    @classmethod
    def from_infolabels(cls):
        """Fallback: identify playing item via VideoPlayer InfoLabels.
        Used when the ListItem carries no mediatype (widget/plugin playback)."""
        import xbmc
        season = xbmc.getInfoLabel('VideoPlayer.Season')
        episode = xbmc.getInfoLabel('VideoPlayer.Episode')
        showtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
        ep_title = xbmc.getInfoLabel('VideoPlayer.EpisodeName')
        title = xbmc.getInfoLabel('VideoPlayer.Title')
        year = xbmc.getInfoLabel('VideoPlayer.Year')

        try:
            season_n = int(season) if season else -1
            episode_n = int(episode) if episode else -1
        except (ValueError, TypeError):
            season_n = episode_n = -1

        if season_n >= 0 and episode_n > 0 and (showtitle or ep_title):
            return cls(mediatype='episode',
                       title=showtitle or ep_title or title,
                       season=season_n, episode=episode_n)

        if title and year and season_n < 0:
            try:
                year_n = int(year)
            except (ValueError, TypeError):
                year_n = None
            return cls(mediatype='movie', title=title, year=year_n)

        return None


class Scrobbler(object):

    SEARCH_TTL = 30 * 86400

    def __init__(self, api=None, min_percent=5, cache=None,
                 watched_percent=None):
        from . import get_api
        from .cache import get_cache
        self.api = api or get_api(cache=False)
        self.cache = cache or get_cache()
        self.min_percent = max(int(min_percent), 0)
        # None = read the setting on every send; the player caches this
        # instance, so a frozen value would need a Kodi restart to take effect
        self.watched_percent = watched_percent

    def _watched_threshold(self):
        """Progress at which the user considers an item watched (80-100)."""
        value = self.watched_percent
        if value is None:
            value = get_setting('watched_min_percent', 'int')
        try:
            value = float(value or SERVER_WATCHED_PERCENT)
        except (TypeError, ValueError):
            value = SERVER_WATCHED_PERCENT
        return max(SERVER_WATCHED_PERCENT, min(value, 100.0))

    def _reported_progress(self, method, progress):
        """Map the local progress onto the server's fixed watched cutoff.

        Reaching the threshold is reported as 100 so the item is definitely
        marked watched; below it the value is held just under the server
        cutoff, which keeps the item unwatched and leaves a resume point
        instead. Anything below that cutoff passes through untouched, so the
        default threshold of 80 behaves exactly like no mapping at all."""
        progress = float(progress or 0)
        if method not in WATCHED_METHODS:
            return progress
        threshold = self._watched_threshold()
        if progress >= threshold:
            return 100.0
        return min(progress, SERVER_WATCHED_PERCENT - 1.0)

    # ------------------------------------------------------------------ #
    # identification                                                     #
    # ------------------------------------------------------------------ #

    def _resolve_from_library(self, item):
        """Reverse lookup via the playing file path in the Kodi library.
        strm items report their inner stream url as playing file, so for
        episodes a metadata lookup (show title + s/e) runs afterwards."""
        result = None
        if item.file_path:
            try:
                from .library import lookup_by_file
                result = lookup_by_file(item.file_path)
            except Exception as exc:
                log_debug(f'Library lookup error: {exc}')
                result = None
        if not result and item.mediatype == 'episode':
            try:
                from .library import lookup_by_metadata
                result = lookup_by_metadata(item.title, item.season,
                                            item.episode)
            except Exception as exc:
                log_debug(f'Library metadata lookup error: {exc}')
                return False
        if not result:
            return False
        item.provider = result['provider']
        item.media_id = result['media_id']
        if result['mediatype'] == 'episode':
            if result.get('season') and item.season is None:
                item.season = result['season']
            if result.get('episode') and item.episode is None:
                item.episode = result['episode']
        return True

    @staticmethod
    def _search_cache_key(item):
        return 'scrobble-id:{}:{}'.format(
            'show' if item.mediatype == 'episode' else 'movie',
            '{}:{}'.format((item.title or '').lower(),
                           item.year or '').strip(':'))

    def _resolve_item(self, item):
        """Find the remote id for items without uniqueid via title search."""
        cache_key = self._search_cache_key(item)
        cached = self.cache.get(cache_key)
        if cached:
            item.provider, item.media_id = cached
            return True

        search_type = 'show' if item.mediatype == 'episode' else 'movie'
        try:
            response = self.api.search_media(item.title, search_type)
        except Exception as exc:
            log_debug(f'SCROBBLE id-search failed: {exc}')
            return False
        match = self._pick_match(response, search_type, item.year)
        if not match:
            log_debug(f'SCROBBLE id-search: no result for "{item.title}"')
            return False
        ids = entry_ids(match)
        media_id = ids.get('tmdb') or ids.get('imdb')
        if not media_id:
            log_debug(f'SCROBBLE id-search: no usable ids in '
                      f'{str(match)[:200]}')
            return False
        item.provider = 'tmdb' if ids.get('tmdb') else 'imdb'
        item.media_id = str(media_id)
        self.cache.set(cache_key, [item.provider, item.media_id],
                       ttl=self.SEARCH_TTL)
        return True

    @staticmethod
    def _pick_match(response, search_type, year=None):
        entries = []
        if isinstance(response, list):
            entries = response
        elif isinstance(response, dict):
            # documented bucket is 'search'; keep legacy keys as fallback
            for key in ('search', search_type + 's', 'results', 'items',
                        'searchresults'):
                if isinstance(response.get(key), list):
                    entries = response[key]
                    break
            if not entries:
                entries = [v for v in response.values() if isinstance(v, dict)]
                if not entries:
                    log_debug(f'SCROBBLE id-search: unrecognized response: '
                              f'{str(response)[:200]}')
        best = None
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            entry_year = entry.get('year')
            if entry_year is None:
                release = str(entry.get('release_date')
                              or entry.get('first_air_date') or '')
                entry_year = int(release[:4]) if release[:4].isdigit() else None
            if year and entry_year and int(entry_year) != int(year):
                continue
            best = entry
            break
        return best

    # ------------------------------------------------------------------ #
    # scrobbling                                                         #
    # ------------------------------------------------------------------ #

    def _identify(self, item):
        """Resolve provider+media_id; returns the identification source."""
        if item.media_id:
            return 'listitem'
        if self._resolve_from_library(item):
            return 'library'
        if self._resolve_item(item):
            return 'search'
        return None

    def _post(self, method, item, progress):
        """Send one scrobble request; raises on API errors."""
        payload = item.build_payload(progress)
        if payload is None:
            raise ValueError('incomplete episode info')
        self.api.scrobble(method, movie=payload.get('movie'),
                          show=payload.get('show'),
                          progress=payload['progress'])

    def _retry_via_search(self, method, item, progress):
        """After a 404: retry once with a fresh title-search id.
        Returns True when the retry succeeded."""
        failed = (item.provider, str(item.media_id))
        saved = (item.provider, item.media_id)
        cache_key = self._search_cache_key(item)
        if cache_key:
            # drop a possibly stale cached id so the search runs fresh
            try:
                self.cache.delete(cache_key)
            except Exception:
                pass
        item.provider = item.media_id = None
        if not self._resolve_item(item) or \
                (item.provider, str(item.media_id)) == failed:
            item.provider, item.media_id = saved
            return False
        log_debug(f'SCROBBLE [{method}] 404 for {failed[0]}:{failed[1]}, '
                  f'retrying via search id {item.provider}:{item.media_id}')
        try:
            self._post(method, item, progress)
        except Exception as exc:
            log_error(f'SCROBBLE [{method}] retry failed for '
                      f'{item.provider}:{item.media_id}: {exc}')
            item.provider, item.media_id = saved
            return False
        self._notify(method, item)
        return True

    def send(self, method, item, progress=0):
        if not item or not item.valid:
            log_debug('SCROBBLE skipped: no identifiable item')
            return None
        source = self._identify(item)
        if not source:
            log_error(f'SCROBBLE skipped: could not resolve '
                      f'"{item.title}" ({item.mediatype})')
            return None
        reported = self._reported_progress(method, progress)
        mapped = '' if reported == float(progress or 0) else \
            f' (reported as {reported:.1f}%, threshold ' \
            f'{self._watched_threshold():.0f}%)'
        log_debug(f'SCROBBLE [{method}] (id: {source}) '
                  f'{item.provider}:{item.media_id} '
                  f'"{item.title}" at {progress}%{mapped}')
        try:
            self._post(method, item, reported)
        except MDbListError as exc:
            if exc.status_code == 404 and self._retry_via_search(
                    method, item, reported):
                return item
            log_error(f'SCROBBLE [{method}] failed for {item.provider}:'
                      f'{item.media_id} "{item.title}": {exc}')
            return None
        except ValueError:
            log_debug('SCROBBLE skipped: incomplete episode info')
            return None
        except Exception as exc:  # never block playback on api errors
            log_error(f'SCROBBLE [{method}] failed for {item.provider}:'
                      f'{item.media_id}: {exc}')
            return None
        self._notify(method, item)
        return item

    @staticmethod
    def _notify(method, item):
        if not get_setting('show_notifications', 'bool'):
            return
        if method not in ('start', 'stop'):
            return
        label = localized(32127) or 'Scrobbling'
        notify('{}: {}'.format(label, item.title))
