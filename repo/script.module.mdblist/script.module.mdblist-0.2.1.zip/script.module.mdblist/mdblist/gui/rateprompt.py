# -*- coding: utf-8 -*-
"""Rating picker dialog and the post-playback rating prompt.

The prompt fires after a successful stop-checkin (see player._dispatch)
and asks the user to rate the finished movie/episode. Episodes are rated
at episode level (show ids + season/episode); the API client converts
these to the nested shows[].seasons[].episodes[] payload format.
"""
import xbmcgui

from ..logger import log_debug
from ..utils import get_setting, localized, notify


def pick_rating(title=''):
    """Select dialog with 'no rating' plus 1-10 stars; returns int or None."""
    heading = localized(32110) or 'Rate this item'
    if title:
        heading = '{}: {}'.format(heading, title)
    choices = [localized(32134) or 'No rating']
    choices += ['{} \u2605'.format(i) for i in range(1, 11)]
    selected = xbmcgui.Dialog().select(heading, choices)
    return selected if selected > 0 else None


def _rating_entry(item, rating):
    ids = {item.provider: item.media_id}
    if item.mediatype == 'episode':
        if item.season is None or item.episode is None:
            return None
        return {'type': 'episode', 'ids': ids, 'season': int(item.season),
                'episode': int(item.episode), 'rating': rating}
    return {'type': 'movie', 'ids': ids, 'rating': rating}


def _prompt_wanted(mediatype, progress):
    if not get_setting('rate_prompt_enabled', 'bool'):
        return False
    mode = int(get_setting('rate_prompt_media', 'int') or 0)
    if mode == 1 and mediatype != 'movie':
        return False
    if mode == 2 and mediatype != 'episode':
        return False
    threshold = max(int(get_setting('rate_prompt_min_percent', 'int')
                        or 85), 75)
    if progress < threshold:
        log_debug(f'Rating prompt skipped ({progress:.1f}% < {threshold}%)')
        return False
    return True


def prompt_rating(item, progress):
    """May open the rating dialog for a just-finished item (resolved)."""
    if not item or not _prompt_wanted(item.mediatype, progress):
        return
    rating = pick_rating(item.title)
    if rating is None:
        return
    entry = _rating_entry(item, rating)
    if entry is None:
        log_debug('Rating prompt skipped: incomplete episode info')
        return
    try:
        from .. import get_api
        get_api(cache=False).push_ratings([entry])
    except Exception as exc:
        log_debug(f'Rating push failed: {exc}')
        return
    notify(localized(32115) or 'Rating saved')
