# -*- coding: utf-8 -*-
import xbmcgui

from ..actions import from_playing_item
from ..logger import log_debug
from ..utils import get_addon, has_api_key, localized


class ContextMenu(object):
    """Simple select dialog offering the available MDBList actions."""

    def open(self):
        addon = get_addon()
        if not has_api_key():
            xbmcgui.Dialog().ok(
                localized(32100) or 'MDBList',
                localized(32108) or 'No API key configured.')
            if addon is not None:
                addon.openSettings()
            return

        playing_ref = from_playing_item()
        options = []
        handlers = []

        if playing_ref is not None:
            options.append(localized(32102) or 'Rate...')
            handlers.append('rate')
            options.append(localized(32103) or 'Remove rating')
            handlers.append('unrate')
            options.append(localized(32104) or 'Mark as watched')
            handlers.append('markwatched')
            options.append(localized(32105) or 'Mark as unwatched')
            handlers.append('markunwatched')
            options.append(localized(32106) or 'Add to watchlist')
            handlers.append('addtowatchlist')
            options.append(localized(32107) or 'Remove from watchlist')
            handlers.append('removefromwatchlist')

        options.append(localized(32101) or 'Sync now')
        handlers.append('sync')

        selected = xbmcgui.Dialog().select(
            localized(32123) or 'Select action', options)
        if selected < 0:
            return
        action = handlers[selected]
        args = {'action': action}
        if playing_ref is not None and action != 'sync':
            args['id'] = '{}:{}'.format(playing_ref.provider, playing_ref.media_id)
            args['type'] = playing_ref.mediatype
        log_debug(f'ContextMenu -> {action}')
        from ..actions import HANDLERS
        HANDLERS.get(action, lambda a: None)(args)
