# -*- coding: utf-8 -*-
import time

import requests

from ..logger import log_debug, log_error

BASE_URL = 'https://api.mdblist.com'


class MDbListError(Exception):
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


class RequestAPI(object):
    """HTTP layer for the MDBList API.
    - apikey is always appended as query parameter
    - retries with exponential backoff on connection errors / 5xx
    - honours Retry-After on 429 once per attempt budget"""

    def __init__(self, api_key=None, base_url=BASE_URL, timeout=15):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key or ''
        self.timeout = timeout
        self.session = requests.Session()

    def build_url(self, path):
        return '{}/{}'.format(self.base_url, str(path).lstrip('/'))

    def build_params(self, params):
        merged = dict(params or {})
        merged.setdefault('apikey', self.api_key)
        return merged

    def request(self, method, path, params=None, json_data=None, data=None,
                headers=None, retries=3):
        url = self.build_url(path)
        request_params = self.build_params(params)
        attempt = 0
        while True:
            attempt += 1
            try:
                response = self.session.request(
                    method, url, params=request_params, json=json_data, data=data,
                    headers=headers, timeout=self.timeout)
            except requests.exceptions.RequestException as exc:
                if attempt > retries:
                    raise MDbListError(f'Network error: {exc}') from exc
                wait = min(2 ** attempt, 8)
                log_debug(f'Request failed ({exc}), retry {attempt}/{retries} in {wait}s')
                time.sleep(wait)
                continue
            if response.status_code == 429 and attempt <= retries:
                retry_after = response.headers.get('Retry-After')
                try:
                    wait = int(retry_after)
                except (TypeError, ValueError):
                    wait = 5
                log_debug(f'Rate limited, waiting {wait}s (attempt {attempt}/{retries})')
                time.sleep(wait)
                continue
            if response.status_code >= 500 and attempt <= retries:
                wait = min(2 ** attempt, 8)
                log_debug(f'Server error {response.status_code}, retrying in {wait}s')
                time.sleep(wait)
                continue
            return response

    def get(self, path, **kwargs):
        return self.request('GET', path, **kwargs)

    def post(self, path, **kwargs):
        return self.request('POST', path, **kwargs)

    def put(self, path, **kwargs):
        return self.request('PUT', path, **kwargs)

    def patch(self, path, **kwargs):
        return self.request('PATCH', path, **kwargs)

    def delete(self, path, **kwargs):
        return self.request('DELETE', path, **kwargs)

    @staticmethod
    def parse(response):
        """Parse a Response into python data; raise MDbListError on HTTP errors."""
        if response is None:
            return None
        if not (200 <= getattr(response, 'status_code', 500) < 300):
            body = ''
            try:
                body = response.text[:200]
            except AttributeError:
                pass
            log_error(f'API error {response.status_code}: {body}')
            raise MDbListError(
                f'MDBList API error {response.status_code}', response.status_code)
        try:
            return response.json()
        except ValueError:
            return None
