# -*- coding: utf-8 -*-
"""Normalization helpers for MDBList data (ratings, ids, timestamps)."""

# providers whose ids the MDBList API expects as numbers
# (imdb and mdblist ids are strings)
NUMERIC_ID_PROVIDERS = ('tmdb', 'trakt', 'tvdb', 'kitsu')

# provider names accepted as flat '<provider>id' keys on search entries
FLAT_ID_PROVIDERS = ('imdb', 'tmdb', 'trakt', 'tvdb', 'mal')


def typed_id(provider, value):
    """Convert a single provider id to the type the API expects."""
    if value is None:
        return None
    if provider in NUMERIC_ID_PROVIDERS:
        try:
            return int(str(value).strip())
        except (TypeError, ValueError):
            pass
    return str(value)


def typed_ids(ids):
    """Normalize an ids dict {provider: value} into API-typed values."""
    return {provider: typed_id(provider, value)
            for provider, value in (ids or {}).items() if value}


def _provider_from_key(key):
    """Map an id key ('tmdb', 'tmdbid', 'imdbid', ...) to its provider."""
    if key in FLAT_ID_PROVIDERS:
        return key
    if key.endswith('id'):
        name = key[:-2]
        if name in FLAT_ID_PROVIDERS:
            return name
    return None


def entry_ids(entry):
    """Collect provider ids from a search/media entry.

    The search endpoint returns suffixed keys both on the entry itself
    and inside its ids dict ({'ids': {'tmdbid': 1}}); other endpoints use
    plain names ({'ids': {'tmdb': 1}}). All variants merge here, later
    sources taking precedence, keyed by plain provider name."""
    sources = []
    if isinstance(entry, dict):
        sources.append(entry)
        nested = entry.get('ids')
        if isinstance(nested, dict):
            sources.append(nested)
    ids = {}
    for source in sources:
        for key, value in source.items():
            if isinstance(value, bool) or \
                    not isinstance(value, (str, int)) or not value:
                continue
            name = _provider_from_key(str(key))
            if name:
                ids[name] = value
    return ids


def bucket_items(payload, buckets=('movies', 'shows', 'seasons', 'episodes',
                                   'items', 'lists', 'people')):
    """Collect list entries from any known response bucket into one list."""
    items = []
    if isinstance(payload, list):
        return payload
    for bucket in buckets:
        values = (payload or {}).get(bucket)
        if isinstance(values, list):
            items.extend(values)
    return items


def episode_media(entry):
    """Inner object of a watched list entry.

    /sync/watched can wrap episodes like movies/shows
    ({"watched_at": ..., "episode": {...}}); unwrapped entries are the
    episode dict itself. Both shapes are normalized here."""
    if isinstance(entry, dict) and isinstance(entry.get('episode'), dict):
        return entry['episode']
    return entry


def season_media(entry):
    """Inner object of a season-level watched list entry."""
    if isinstance(entry, dict) and isinstance(entry.get('season'), dict):
        return entry['season']
    return entry


def watched_entry_ids(entry):
    """Return the inner media object of a sync/watched list entry."""
    if not isinstance(entry, dict):
        return {}
    for key in ('movie', 'show'):
        if isinstance(entry.get(key), dict):
            return entry[key]
    return {}


def watched_timestamp(entry):
    """Watch timestamp of a sync entry.

    /sync/watched names it 'watched_at'; older/other payloads use
    'last_watched_at'. Both are accepted. Wrapped episode entries carry
    the timestamp on the wrapper."""
    if not isinstance(entry, dict):
        return None
    value = entry.get('watched_at') or entry.get('last_watched_at')
    if value:
        return value
    inner = entry.get('episode')
    if isinstance(inner, dict):
        return inner.get('watched_at') or inner.get('last_watched_at')
    return None


def _plays_count(entry):
    """Play count of a sync entry; presence of a timestamp counts as one.

    /sync/watched carries no 'plays' field at all – an entry existing with
    a 'watched_at' means the item is watched, which is one play."""
    if not isinstance(entry, dict):
        return 0
    plays = entry.get('plays', entry.get('watched'))
    if plays is None:
        return 1 if watched_timestamp(entry) else 0
    if isinstance(plays, bool):
        return 1 if plays else 0
    try:
        return int(plays or 0)
    except (TypeError, ValueError):
        return 0


def episode_plays(season_entry):
    """Normalize the episode list of a nested season entry."""
    episodes = (season_entry or {}).get('episodes') or []
    result = {}
    for ep in episodes:
        number = ep.get('number')
        if number is None:
            continue
        try:
            number = int(number)
        except (TypeError, ValueError):
            continue
        result[number] = {
            'plays': _plays_count(ep),
            'last_watched_at': watched_timestamp(ep),
        }
    return result


def movie_plays(movie_entry):
    return _plays_count(movie_entry)


def _episode_numbers(entry):
    """Season/episode numbers of a flat episode entry.

    Tolerates both {'season': 1, 'episode': 2} and the nested
    {'season': {'number': 1}, 'number': 2} / {'episode': {'number': 2}}
    variants, and the wrapped {'episode': {...}} list form."""
    entry = episode_media(entry)
    season = entry.get('season')
    if isinstance(season, dict):
        season = season.get('number')
    episode = entry.get('episode')
    if isinstance(episode, dict):
        episode = episode.get('number')
    if episode is None:
        episode = entry.get('number')
    if season is None or episode is None:
        return None
    try:
        return int(season), int(episode)
    except (TypeError, ValueError):
        return None


def _show_ids_of_episode(entry):
    """Parent show ids of a flat episode or season entry.

    A wrapped entry may carry the show reference either on the wrapper or
    inside the episode/season object."""
    inner = episode_media(season_media(entry))
    for source in (inner, entry):
        if not isinstance(source, dict):
            continue
        for key in ('show', 'tvshow'):
            nested = source.get(key)
            if isinstance(nested, dict):
                ids = entry_ids(nested)
                if ids:
                    return ids
        ids = source.get('show_ids')
        if isinstance(ids, dict):
            normalized = entry_ids({'ids': ids})
            if normalized:
                return normalized
    return {}


def watched_episodes(payload):
    """Episode state of a /sync/watched or /sync/collection payload.

    Shows are handled strictly on the episode level. Whole-season flags
    (the 'seasons' bucket) are intentionally ignored: MDBList can set them
    inconsistently and Kodi derives a watched season from its watched
    episodes itself, so trusting them would over-mark a local library
    (e.g. every episode of a freshly re-added season).

    Returns (by_show, by_episode_id):

    by_show          {(provider, show_id): {(season, episode): state}}
    by_episode_id    {(provider, episode_id): state}

    state is {'plays': int, 'watched_at': iso|None}.

    Every provider id an item carries yields its own key, so a local show
    known only by tvdb still matches a remote show carrying tmdb.

    Both response shapes are read: the flat top-level 'episodes' bucket
    (what the documented API returns, where 'ids' identifies the *episode*)
    and episodes nested inside shows[].seasons[].episodes[]. Flat entries
    without a parent show object can only be matched through the episode's
    own id, hence the second index."""
    index = {}
    by_episode_id = {}

    def _store(show_ids, season, episode, state):
        for key in id_keys(show_ids):
            index.setdefault(key, {})[(season, episode)] = state

    for entry in (payload or {}).get('episodes') or []:
        if not isinstance(entry, dict):
            continue
        state = {'plays': _plays_count(entry),
                 'watched_at': watched_timestamp(entry)}
        show_ids = _show_ids_of_episode(entry)
        numbers = _episode_numbers(entry)
        if show_ids and numbers is not None:
            _store(show_ids, numbers[0], numbers[1], state)
        # 'ids' on a flat episode entry identifies the episode itself
        # (raised to the wrapper on {'episode': {...}} list entries)
        for key in id_keys(entry_ids(episode_media(entry))
                           or entry_ids(entry)):
            by_episode_id[key] = state

    for entry in (payload or {}).get('shows') or []:
        if not isinstance(entry, dict):
            continue
        show = watched_entry_ids(entry) or entry
        show_ids = entry_ids(show) or entry_ids(entry)
        if not show_ids:
            continue
        seasons = show.get('seasons') or entry.get('seasons') or []
        for season in seasons:
            if not isinstance(season, dict):
                continue
            s_num = season.get('number')
            if s_num is None:
                continue
            try:
                s_num = int(s_num)
            except (TypeError, ValueError):
                continue
            for e_num, state in episode_plays(season).items():
                _store(show_ids, s_num, e_num,
                       {'plays': state['plays'],
                        'watched_at': state['last_watched_at']})

    return index, by_episode_id


def id_keys(ids):
    """Canonical comparison keys for every provider id in an ids dict.

    Mirrors the key format used by the sync engine so remote and local
    items can be matched on any shared provider id."""
    for provider in ('tmdb', 'tvdb', 'imdb', 'trakt'):
        value = (ids or {}).get(provider)
        if value in (None, ''):
            continue
        try:
            yield (provider, str(int(value)))
        except (TypeError, ValueError):
            yield (provider, str(value))


def watched_removed(payload):
    """Items currently removed from watched per the /sync/journal payload.

    The journal is a last-state upsert table: each retained row describes the
    most recent action for one item, so a ``category='watched'`` row with
    ``status='removed'`` means the item is currently unwatched on MDBList.
    That is the precise "explicitly marked unwatched" signal the watched pull
    needs to downgrade a local Kodi item, without relying on a full existence
    snapshot (the journal only retains a 30-day window, and the user's MDBList
    collection is unmaintained).

    Returns (movie_keys, show_removed, episode_removed):
      movie_keys     set of canonical keys of unwatched movies
      show_removed   set of canonical show keys whose whole content (the show
                     itself, or a season within it) is unwatched
      episode_removed {(provider, show_id): {(season, episode), ...}} for
                     specific unwatched episodes
    """
    movie_keys = set()
    show_removed = set()
    episode_removed = {}
    for row in (payload or {}).get('journal') or []:
        if not isinstance(row, dict):
            continue
        if row.get('category') != 'watched' or row.get('status') != 'removed':
            continue
        item_type = row.get('item_type')
        if item_type == 'movie':
            for key in id_keys(entry_ids({'ids': row.get('ids') or {}})):
                movie_keys.add(key)
            continue
        if item_type not in ('show', 'season', 'episode'):
            continue
        show_keys = list(id_keys(entry_ids({'ids': row.get('ids') or {}})))
        if not show_keys:
            continue
        if item_type == 'episode':
            season = row.get('season')
            episode = row.get('episode')
            if season is None or episode is None:
                continue
            try:
                pair = (int(season), int(episode))
            except (TypeError, ValueError):
                continue
            for key in show_keys:
                episode_removed.setdefault(key, set()).add(pair)
        else:
            # a show/season removal marks everything below it unwatched
            for key in show_keys:
                show_removed.add(key)
    return movie_keys, show_removed, episode_removed


def rating_entries(payload, mediatype_key):
    """Extract rating entries for a given key ('movies','shows','episodes')."""
    entries = (payload or {}).get(mediatype_key) or []
    result = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        nested = entry.get(mediatype_key.rstrip('s'))
        ids = entry_ids(nested) if isinstance(nested, dict) else {}
        if not ids:
            ids = entry_ids(entry)
        rating = entry.get('rating')
        if rating is None and isinstance(nested, dict):
            rating = nested.get('rating')
        result.append({'ids': ids,
                       'rating': rating,
                       'rated_at': entry.get('rated_at') or
                       (nested or {}).get('rated_at')})
    return result
