# -*- coding: utf-8 -*-
"""MDBList API client covering the documented v1 endpoint groups.
https://api.mdblist.com/docs/

All methods return parsed python data (dict/list) or None on empty bodies,
and raise mdblist.api.request.MDbListError on HTTP/network errors."""
from .mapping import bucket_items, typed_ids
from .request import RequestAPI


class MDbList(object):
    def __init__(self, api_key=None, cache=None):
        self.api = RequestAPI(api_key=api_key)
        self._cache = cache

    # ------------------------------------------------------------------ #
    # low level helpers                                                  #
    # ------------------------------------------------------------------ #

    @property
    def api_key(self):
        return self.api.api_key

    def get_response(self, path, params=None, **kwargs):
        """Perform a GET and return the raw Response (needed for pagination headers)."""
        return self.api.get(path, params=params, **kwargs)

    def get_json(self, path, params=None, cache_ttl=None, **kwargs):
        """GET with optional sqlite caching. cache_ttl in seconds (None = no cache)."""
        if not cache_ttl or self._cache is None:
            return self.api.parse(self.api.get(path, params=params, **kwargs))
        key = 'GET:{}:{}'.format(path, sorted((params or {}).items()))
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        data = self.api.parse(self.api.get(path, params=params, **kwargs))
        if data is not None:
            self._cache.set(key, data, ttl=cache_ttl)
        return data

    def post_json(self, path, json_data=None, **kwargs):
        return self.api.parse(self.api.post(path, json_data=json_data, **kwargs))

    def put_json(self, path, json_data=None, **kwargs):
        return self.api.parse(self.api.put(path, json_data=json_data, **kwargs))

    def patch_json(self, path, json_data=None, **kwargs):
        return self.api.parse(self.api.patch(path, json_data=json_data, **kwargs))

    def delete_json(self, path, **kwargs):
        return self.api.parse(self.api.delete(path, **kwargs))

    def is_authorized(self):
        try:
            return bool(self.get_user())
        except Exception:  # MDbListError / network issues
            return False

    # ------------------------------------------------------------------ #
    # media info & ratings                                               #
    # ------------------------------------------------------------------ #

    def get_media_info(self, media_id, media_type='movie', provider='tmdb'):
        """GET /{provider}/{media_type}/{media_id}/"""
        return self.get_json(f'{provider}/{media_type}/{media_id}')

    def get_media_info_batch(self, items, media_type='movie', provider='tmdb',
                             append_to_response=None):
        """POST /{provider}/{media_type}/ with {'items': [...]}"""
        payload = {'items': list(items)}
        params = {}
        if append_to_response:
            params['append_to_response'] = append_to_response
        return self.post_json(f'{provider}/{media_type}', json_data=payload, params=params)

    def lookup_ratings(self, media_ids, media_type='movie', provider='tmdb',
                       return_rating='mdblist'):
        """POST /rating/{media_type}/{return_rating} batch ratings lookup."""
        payload = {f'{media_type}s': [
            i if isinstance(i, dict) else {provider: i} for i in media_ids]}
        return self.post_json(
            f'rating/{media_type}/{return_rating}', json_data=payload)

    def get_watchprovider_links(self, media_id, media_type='movie', provider='tmdb'):
        return self.get_json(f'{provider}/{media_type}/{media_id}/watchprovider_links')

    def search_media(self, query, media_type='movie'):
        """GET /search/{media_type}?query=..."""
        return self.get_json(f'search/{media_type}', params={'query': query})

    # ------------------------------------------------------------------ #
    # lists                                                              #
    # ------------------------------------------------------------------ #

    def get_top_lists(self, params=None):
        return self.get_json('lists/top', params=params)

    def get_user_lists(self, userid=None):
        if userid:
            return self.get_json(f'lists/user/{userid}')
        return self.get_json('lists/user')

    def get_curated_lists(self, params=None):
        return self.get_json('lists/curated', params=params)

    def get_official_lists(self, params=None):
        return self.get_json('lists/official', params=params)

    def get_official_list(self, slug):
        return self.get_json(f'lists/official/{slug}')

    def get_official_list_items(self, slug, params=None):
        return self.get_json(f'lists/official/{slug}/items', params=params)

    def get_liked_lists(self, params=None):
        return self.get_json('lists/liked', params=params)

    def get_recommended_sections(self, section=None, params=None):
        if section:
            return self.get_json(f'lists/recommended/{section}', params=params)
        return self.get_json('lists/recommended', params=params)

    def get_recommended_items(self, section, params=None):
        return self.get_json(f'lists/recommended/{section}/items', params=params)

    def search_lists(self, query, params=None):
        merged = dict(params or {})
        merged['query'] = query
        return self.get_json('lists/search', params=merged)

    def get_shared_list(self, token):
        return self.get_json(f'lists/share/{token}')

    def get_shared_list_items(self, token, params=None):
        return self.get_json(f'lists/share/{token}/items', params=params)

    def get_external_lists(self, params=None):
        return self.get_json('external/lists/user', params=params)

    def get_external_list(self, listid, params=None):
        return self.get_json(f'external/lists/{listid}', params=params)

    def get_external_list_items(self, listid, params=None):
        return self.get_json(f'external/lists/{listid}/items', params=params)

    def get_list_info(self, listid):
        return self.get_json(f'lists/{listid}')

    def update_list_info(self, listid, metadata):
        return self.put_json(f'lists/{listid}', json_data=metadata)

    def delete_list(self, listid):
        return self.delete_json(f'lists/{listid}')

    def create_list(self, name, description=None, public=False):
        payload = {'name': name, 'public': bool(public)}
        if description:
            payload['description'] = description
        return self.post_json('lists/user/add', json_data=payload)

    def get_list_items(self, listid, params=None):
        return self.get_json(f'lists/{listid}/items', params=params)

    def add_list_items(self, listid, movies=None, shows=None):
        return self.modify_list_items(listid, 'add', movies=movies, shows=shows)

    def remove_list_items(self, listid, movies=None, shows=None):
        return self.modify_list_items(listid, 'remove', movies=movies, shows=shows)

    def modify_list_items(self, listid, action, movies=None, shows=None):
        payload = {}
        if movies:
            payload['movies'] = self._normalize_items(movies)
        if shows:
            payload['shows'] = self._normalize_items(shows)
        return self.post_json(f'lists/{listid}/items/{action}', json_data=payload)

    def like_list(self, listid):
        return self.put_json(f'lists/{listid}/like')

    def unlike_list(self, listid):
        return self.delete_json(f'lists/{listid}/like')

    def get_list_changes(self, listid, since=None, params=None):
        merged = dict(params or {})
        if since:
            merged['since'] = since
        return self.get_json(f'lists/{listid}/changes', params=merged)

    def get_list_membership(self, media_id, media_type='movie', provider='tmdb'):
        params = {provider: media_id}
        return self.get_json('lists/user/membership', params=params)

    # ------------------------------------------------------------------ #
    # watchlist                                                          #
    # ------------------------------------------------------------------ #

    def get_watchlist_items(self, mediatype=None, params=None):
        path = 'watchlist/items'
        if mediatype in ('movie', 'show', 'season', 'episode'):
            path += f'/{mediatype}'
        return self.get_json(path, params=params)

    def add_watchlist_items(self, movies=None, shows=None):
        return self._modify_watchlist('add', movies, shows)

    def remove_watchlist_items(self, movies=None, shows=None):
        return self._modify_watchlist('remove', movies, shows)

    @staticmethod
    def _normalize_items(items):
        """Accept bare id dicts ({'tmdb': 1}) or full items
        ({'ids': {...}, ...}); return API-shaped entries with typed ids."""
        normalized = []
        for item in items or []:
            if not isinstance(item, dict):
                continue
            if 'ids' in item:
                entry = dict(item)
                entry['ids'] = typed_ids(entry.get('ids'))
            else:
                entry = {'ids': typed_ids(item)}
            normalized.append(entry)
        return normalized

    @classmethod
    def _watchlist_payload(cls, movies, shows, episodes=None):
        payload = {}
        if movies:
            payload['movies'] = cls._normalize_items(movies)
        if shows:
            payload['shows'] = cls._normalize_items(shows)
        if episodes:
            payload['episodes'] = cls._normalize_items(episodes)
        return payload

    def _modify_watchlist(self, action, movies, shows):
        return self.post_json(
            f'watchlist/items/{action}', json_data=self._watchlist_payload(
                movies, shows))

    # ------------------------------------------------------------------ #
    # sync                                                               #
    # ------------------------------------------------------------------ #

    def get_last_activities(self):
        return self.get_json('sync/last_activities')

    # buckets every /sync snapshot endpoint may return
    SYNC_BUCKETS = ('movies', 'shows', 'seasons', 'episodes')
    # max page size the API accepts together with a cursor
    SYNC_PAGE_SIZE = 1000
    # backstop against a server that keeps handing out cursors
    SYNC_MAX_PAGES = 200

    def paginate_sync(self, path, params=None, page_size=None):
        """Fetch a complete /sync snapshot, following pagination.next_cursor.

        The snapshot endpoints page at 100 items by default and return the
        cursor in the response *body* (not in headers). Without following it
        a client only ever sees the first page, which makes any local/remote
        diff report the rest of the library as missing.

        The merged result carries '_complete': False when the snapshot could
        not be read to the end, so callers can refuse to act on a partial
        picture."""
        merged = {bucket: [] for bucket in self.SYNC_BUCKETS}
        pagination = {}
        cursor = None
        seen_cursors = set()
        complete = False
        for _ in range(self.SYNC_MAX_PAGES):
            request_params = dict(params or {})
            request_params['limit'] = page_size or self.SYNC_PAGE_SIZE
            if cursor:
                request_params['cursor'] = cursor
            data = self.api.parse(self.api.get(path, params=request_params))
            if not isinstance(data, dict):
                # empty body: nothing more to read, snapshot ends here
                complete = True
                break
            for bucket in self.SYNC_BUCKETS:
                values = data.get(bucket)
                if isinstance(values, list):
                    merged[bucket].extend(values)
            pagination = data.get('pagination') or {}
            cursor = pagination.get('next_cursor')
            if not cursor or cursor in seen_cursors:
                complete = True
                break
            seen_cursors.add(cursor)
        merged['pagination'] = pagination
        merged['_complete'] = complete
        return merged

    def get_watched(self, mediatype=None, params=None):
        return self.paginate_sync(
            'sync/watched', params=self._sync_params(mediatype, params))

    def push_watched(self, movies=None, shows=None, episodes=None):
        payload = self._watchlist_payload(movies, shows, episodes)
        return self.post_json('sync/watched', json_data=payload)

    def remove_watched(self, movies=None, shows=None, episodes=None):
        payload = self._watchlist_payload(movies, shows, episodes)
        return self.post_json('sync/watched/remove', json_data=payload)
    def get_collection(self, mediatype=None, params=None):
        return self.paginate_sync(
            'sync/collection', params=self._sync_params(mediatype, params))

    def add_collection_items(self, movies=None, shows=None):
        payload = self._watchlist_payload(movies, shows)
        return self.post_json('sync/collection', json_data=payload)

    def remove_collection_items(self, movies=None, shows=None):
        payload = self._watchlist_payload(movies, shows)
        return self.post_json('sync/collection/remove', json_data=payload)

    def get_ratings(self, mediatype=None, params=None):
        return self.paginate_sync(
            'sync/ratings', params=self._sync_params(mediatype, params))

    @staticmethod
    def _rating_ids(entry):
        return typed_ids(entry.get('ids') or {})

    @classmethod
    def _nested_episode_shows(cls, entries):
        """Group trakt-style episode entries into the nested
        shows[].seasons[].episodes[] format the sync/ratings endpoints
        expect. Carries rating/rated_at when present."""
        buckets = {}
        order = []
        for entry in entries:
            ids = cls._rating_ids(entry)
            try:
                season = int(entry['season'])
                number = int(entry['episode'])
            except (KeyError, TypeError, ValueError):
                continue
            key = repr(sorted(ids.items()))
            bucket = buckets.get(key)
            if bucket is None:
                bucket = buckets[key] = {'ids': ids, '_seasons': {}}
                order.append(bucket)
            episode_item = {'number': number}
            if entry.get('rating') is not None:
                episode_item['rating'] = int(entry['rating'])
            if entry.get('rated_at'):
                episode_item['rated_at'] = entry['rated_at']
            bucket['_seasons'].setdefault(season, []).append(episode_item)
        shows = []
        for bucket in order:
            shows.append({'ids': bucket['ids'], 'seasons': [
                {'number': season, 'episodes': episodes}
                for season, episodes in sorted(bucket['_seasons'].items())]})
        return shows

    def push_ratings(self, entries):
        """entries: list of trakt-style dicts {'type': 'movie'|'show'|
        'episode', 'ids': {...}, 'rating': 1..10}; episode entries use
        show-level ids plus season/episode and are converted to the
        nested API format (or raw payload dicts)."""
        payload = {}
        episodes = []
        for entry in entries:
            etype = entry.get('type')
            if etype == 'episode':
                episodes.append(entry)
                continue
            item = {'ids': self._rating_ids(entry)}
            if entry.get('rating') is not None:
                item['rating'] = int(entry['rating'])
            payload.setdefault(etype + 's', []).append(item)
        if episodes:
            payload['shows'] = (
                payload.get('shows') or []) + self._nested_episode_shows(episodes)
        return self.post_json('sync/ratings', json_data=payload)

    def remove_ratings(self, entries):
        payload = {}
        episodes = []
        for entry in entries:
            etype = entry.get('type')
            if etype == 'episode':
                episodes.append(entry)
                continue
            payload.setdefault(etype + 's', []).append(
                {'ids': self._rating_ids(entry)})
        if episodes:
            payload['shows'] = (
                payload.get('shows') or []) + self._nested_episode_shows(episodes)
        return self.post_json('sync/ratings/remove', json_data=payload)

    def get_dropped_shows(self, params=None):
        return self.get_json('sync/dropped', params=params)

    def mark_dropped_shows(self, shows):
        return self.post_json('sync/dropped', json_data={'shows': shows})

    def unmark_dropped_shows(self, shows):
        return self.post_json('sync/dropped/remove', json_data={'shows': shows})

    def get_dropped_seasons(self, params=None):
        return self.get_json('sync/seasons/dropped', params=params)

    def get_sync_journal(self, params=None):
        return self.get_json('sync/journal', params=params)

    def paginate_sync_journal(self, params=None, page_size=None):
        """Fetch a complete /sync/journal, following pagination.next_cursor.

        Like paginate_sync for the watch/rating snapshots, but the journal is
        a cursor-paginated list of last-state rows instead of the fixed
        movie/show/season/episode bucket shape. Replays until the last page
        and marks '_complete' so callers can refuse to act on a partial view.
        """
        merged = {'journal': []}
        pagination = {}
        cursor = None
        seen_cursors = set()
        complete = False
        for _ in range(self.SYNC_MAX_PAGES):
            request_params = dict(params or {})
            request_params['limit'] = page_size or self.SYNC_PAGE_SIZE
            if cursor:
                request_params['cursor'] = cursor
            data = self.api.parse(self.api.get('sync/journal',
                                                params=request_params))
            if not isinstance(data, dict):
                complete = True
                break
            rows = data.get('journal')
            if isinstance(rows, list):
                merged['journal'].extend(rows)
            pagination = data.get('pagination') or {}
            cursor = pagination.get('next_cursor')
            if not cursor or cursor in seen_cursors:
                complete = True
                break
            seen_cursors.add(cursor)
        merged['pagination'] = pagination
        merged['_complete'] = complete
        return merged

    def get_item_state(self, media_id, media_type='movie', provider='tmdb'):
        return self.post_json(
            f'sync/state/{media_type}/{provider}',
            json_data={f'{media_type}s': [{provider: media_id}]})

    def get_item_history(self, media_id, mediatype='movie', provider='tmdb'):
        return self.get_json(f'sync/history/{mediatype}/{provider}/{media_id}')

    def get_playback_sessions(self, params=None):
        return self.get_json('sync/playback', params=params)

    @staticmethod
    def _sync_params(mediatype, params):
        merged = dict(params or {})
        if mediatype in ('episode', 'movie', 'season', 'show'):
            merged.setdefault('mediatype', mediatype)
        return merged

    # ------------------------------------------------------------------ #
    # scrobble                                                           #
    # ------------------------------------------------------------------ #

    def scrobble(self, method, movie=None, show=None, progress=0):
        """method: start|pause|stop|clear. Payload per docs:
        movie:   {'movie': {'ids': {...}}, 'progress': float}
        episode: {'show': {'ids': {...},
                           'season': {'number': n,
                                      'episode': {'number': m}}},
                  'progress': float}"""
        payload = {}
        if movie:
            payload['movie'] = movie
        if show:
            payload['show'] = show
        payload['progress'] = round(float(progress or 0), 2)
        return self.post_json(f'scrobble/{method}', json_data=payload)

    def get_now_playing(self):
        return self.get_json('sync/now-playing')

    # ------------------------------------------------------------------ #
    # checkin                                                            #
    # ------------------------------------------------------------------ #

    def get_checkin(self):
        return self.get_json('checkin')

    def start_checkin(self, movie=None, show=None, message=None):
        payload = {}
        if movie:
            payload['movie'] = movie
        if show:
            payload['show'] = show
        if message:
            payload['message'] = message
        return self.post_json('checkin', json_data=payload)

    def stop_checkin(self):
        return self.delete_json('checkin')

    # ------------------------------------------------------------------ #
    # upnext                                                             #
    # ------------------------------------------------------------------ #

    def get_upnext(self, media_id=None, media_type='show', provider='tmdb'):
        params = {provider: media_id} if media_id else None
        return self.get_json('upnext', params=params)

    def get_upnext_upcoming(self, params=None):
        return self.get_json('upnext/upcoming', params=params)

    def get_upnext_watchlist(self, params=None):
        return self.get_json('upnext/watchlist', params=params)

    # ------------------------------------------------------------------ #
    # calendar / notifications                                           #
    # ------------------------------------------------------------------ #

    def get_calendar_events(self, params=None):
        return self.get_json('calendar/events', params=params)

    def get_notification_preferences(self):
        return self.get_json('calendar/notifications/preferences')

    def update_notification_preferences(self, preferences, method='patch'):
        if method == 'put':
            return self.put_json(
                'calendar/notifications/preferences', json_data=preferences)
        return self.patch_json(
            'calendar/notifications/preferences', json_data=preferences)

    # ------------------------------------------------------------------ #
    # user / misc                                                        #
    # ------------------------------------------------------------------ #

    def get_user(self):
        return self.get_json('user')

    def get_user_stats(self, params=None):
        return self.get_json('user/stats', params=params)

    def get_public_user(self, username):
        return self.get_json(f'users/{username}')

    def get_genres(self):
        return self.get_json('genres')

    def get_movie_updates(self, params=None):
        return self.get_json('movies/updates', params=params)

    def get_show_updates(self, params=None):
        return self.get_json('shows/updates', params=params)

    def get_streaming_charts(self, media_type='movie', params=None):
        return self.get_json(f'justwatch/streaming-charts/{media_type}', params=params)

    def iter_all(self, path, params=None, page_size=100):
        """Cursor-paginated generator over any listing endpoint.
        Yields combined item lists from every response bucket."""
        cursor = None
        while True:
            request_params = dict(params or {})
            request_params.setdefault('limit', page_size)
            if cursor:
                request_params['cursor'] = cursor
            response = self.get_response(path, params=request_params)
            data = RequestAPI.parse(response)
            if not data:
                break
            yield from bucket_items(data)
            # cursor lives in the response body; the x-* headers are only a
            # fallback for endpoints that expose it there instead
            next_cursor = None
            if isinstance(data, dict):
                next_cursor = (data.get('pagination') or {}).get('next_cursor')
            if not next_cursor:
                headers = getattr(response, 'headers', {}) or {}
                if str(headers.get('x-has-more', '')).lower() == 'true':
                    next_cursor = headers.get('x-next-cursor')
            if not next_cursor or next_cursor == cursor:
                break
            cursor = next_cursor
