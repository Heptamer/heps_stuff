# -*- coding: utf-8 -*-
from .player import MDbListPlayer  # noqa: F401
