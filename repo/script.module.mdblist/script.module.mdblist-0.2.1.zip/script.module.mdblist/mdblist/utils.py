# -*- coding: utf-8 -*-
import json
from datetime import datetime, timezone

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'script.module.mdblist'
MEDIA_PROVIDERS = ('tmdb', 'imdb', 'trakt', 'tvdb', 'mal')


def has_api_key():
    return bool(get_setting('api_key', 'str'))


def get_addon():
    try:
        return xbmcaddon.Addon(ADDON_ID)
    except RuntimeError:
        return None


def get_setting(setting_id, setting_type='str'):
    addon = get_addon()
    if addon is None:
        return None
    if setting_type == 'bool':
        return addon.getSettingBool(setting_id)
    if setting_type == 'int':
        return addon.getSettingInt(setting_id)
    if setting_type == 'number':
        return addon.getSettingNumber(setting_id)
    return addon.getSettingString(setting_id)


def localized(string_id):
    addon = get_addon()
    try:
        return addon.getLocalizedString(string_id) if addon else ''
    except (RuntimeError, AttributeError):
        return ''


def notify(message='', header=None, icon=None, time_ms=3000):
    header = header or localized(32100) or 'MDBList'
    if icon is None:
        icon = xbmcaddon.Addon(ADDON_ID).getAddonInfo('icon')
    try:
        xbmcgui.Dialog().notification(header, message, icon, time_ms)
    except (RuntimeError, SystemError):
        pass


def translate_path(path):
    return xbmcvfs.translatePath(path)


def get_profile_dir():
    path = translate_path('special://profile/addon_data/{}/'.format(ADDON_ID))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdir(path)
    return path


def parse_id(value):
    """Parse an id string like 'tmdb:12345' or plain number (assumed tmdb).
    Returns (provider, id) or (None, None)."""
    if value is None:
        return None, None
    value = str(value).strip().lower()
    if ':' in value:
        provider, _, item_id = value.partition(':')
        provider = provider.strip()
        item_id = item_id.strip()
        if provider in MEDIA_PROVIDERS and item_id:
            return provider, item_id
        return None, None
    if value.isdigit():
        return 'tmdb', value
    if value.startswith('tt'):
        return 'imdb', value
    return None, None


def jsonrpc(method, params=None):
    """Execute a JSON-RPC call against Kodi and return the parsed response dict."""
    query = {'jsonrpc': '2.0', 'method': method, 'params': params or {}, 'id': 1}
    try:
        response = xbmc.executeJSONRPC(json.dumps(query))
        return json.loads(response)
    except (ValueError, TypeError, RuntimeError):
        return {}


def get_kodi_setting(setting_id):
    """Read one of Kodi's own settings; None when unavailable.

    Not every setting id exists in every Kodi version, and some are not
    exposed in the GUI at all, so an unknown id must stay harmless."""
    response = jsonrpc('Settings.GetSettingValue', {'setting': setting_id})
    if response.get('error'):
        return None
    result = response.get('result')
    if not isinstance(result, dict):
        return None
    return result.get('value')


def set_kodi_setting(setting_id, value):
    """Write one of Kodi's own settings; True when it was accepted."""
    response = jsonrpc('Settings.SetSettingValue',
                       {'setting': setting_id, 'value': value})
    if response.get('error'):
        return False
    return bool(response.get('result'))


def jsonrpc_paginate(method, list_property, base_params=None, page_size=200):
    """Iterate all items of a paged VideoLibrary.* listing."""
    start = 0
    while True:
        params = dict(base_params or {})
        params['limits'] = {'start': start, 'end': start + page_size}
        result = jsonrpc(method, params).get('result') or {}
        items = result.get(list_property) or []
        yield from items
        total = (result.get('limits') or {}).get('total', 0)
        start += len(items)
        if not items or start >= total:
            break


def iso_to_kodi(value):
    """Convert ISO8601 timestamp to Kodi lastplayed format '%Y-%m-%d %H:%M:%S'.

    Kodi stores lastplayed in local time, so a UTC timestamp has to be
    converted first – otherwise the written date is off by the UTC offset."""
    dt = iso_to_datetime(value)
    if dt is None:
        return None
    if dt.tzinfo is not None:
        dt = dt.astimezone()
    return dt.strftime('%Y-%m-%d %H:%M:%S')


def iso_to_datetime(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    except ValueError:
        return None


def datetime_to_iso(dt):
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat()


def kodi_date_to_iso(value):
    """Convert a Kodi date ('lastplayed') to a UTC ISO8601 timestamp.

    Kodi writes these in local time, so the naive value is anchored to the
    system timezone before conversion."""
    if not value:
        return None
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
        try:
            local = datetime.strptime(str(value), fmt)
        except ValueError:
            continue
        try:
            return datetime_to_iso(local.astimezone())
        except (OverflowError, OSError, ValueError):
            return None
    return str(value)
