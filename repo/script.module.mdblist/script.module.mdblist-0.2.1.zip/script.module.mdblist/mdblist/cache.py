# -*- coding: utf-8 -*-
import json
import sqlite3
import threading

from .logger import log_debug, log_error
from .utils import get_profile_dir


class SimpleCache(object):
    """Tiny sqlite backed key/value cache with per-entry expiry.
    Safe for concurrent use from service and script processes."""

    def __init__(self, filename='cache.db'):
        self._lock = threading.Lock()
        self.db_path = get_profile_dir() + filename
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.execute(
            'CREATE TABLE IF NOT EXISTS cache '
            '(key TEXT PRIMARY KEY, value TEXT NOT NULL, expires REAL NOT NULL)')
        self._conn.commit()

    def _key(self, key):
        return str(key)

    def get(self, key):
        import time
        with self._lock:
            row = self._conn.execute(
                'SELECT value FROM cache WHERE key = ? AND expires > ?',
                (self._key(key), time.time())).fetchone()
        if row is None:
            return None
        try:
            return json.loads(row[0])
        except ValueError:
            return None

    def set(self, key, value, ttl=300):
        import time
        expires = time.time() + max(int(ttl), 1)
        payload = json.dumps(value)
        try:
            with self._lock:
                self._conn.execute(
                    'INSERT OR REPLACE INTO cache (key, value, expires) VALUES (?, ?, ?)',
                    (self._key(key), payload, expires))
                self._conn.commit()
        except sqlite3.Error as exc:
            log_error(f'Cache write error: {exc}')

    def delete(self, key):
        with self._lock:
            self._conn.execute('DELETE FROM cache WHERE key = ?', (self._key(key),))
            self._conn.commit()

    def cleanup(self):
        import time
        with self._lock:
            self._conn.execute('DELETE FROM cache WHERE expires <= ?', (time.time(),))
            self._conn.commit()

    def clear(self):
        log_debug('Cache cleared')
        with self._lock:
            self._conn.execute('DELETE FROM cache')
            self._conn.commit()

    def close(self):
        try:
            self._conn.close()
        except sqlite3.Error:
            pass


_cache = None


def get_cache():
    global _cache
    if _cache is None:
        _cache = SimpleCache()
    return _cache
