# -*- coding: utf-8 -*-
import sqlite3
import time

from ..logger import log_debug
from ..utils import get_profile_dir


class SyncLock(object):
    """Cross-process mutex stored in sqlite with stale-lock timeout."""

    def __init__(self, name='sync', ttl=1800):
        self.name = name
        self.ttl = ttl
        self.db_path = get_profile_dir() + 'locks.db'
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.execute(
            'CREATE TABLE IF NOT EXISTS locks '
            '(name TEXT PRIMARY KEY, timestamp REAL NOT NULL)')
        self._conn.commit()
        self._acquired = False

    def acquire(self, timeout=0):
        """Acquire the lock, optionally waiting up to timeout seconds."""
        deadline = time.time() + max(float(timeout or 0), 0)
        while True:
            if self._try_acquire():
                return True
            if time.time() >= deadline:
                return False
            time.sleep(0.5)

    def _try_acquire(self):
        now = time.time()
        try:
            with self._conn:
                row = self._conn.execute(
                    'SELECT timestamp FROM locks WHERE name = ?', (self.name,)).fetchone()
                if row is not None and (now - float(row[0])) < self.ttl:
                    return False  # someone else holds a fresh lock
                if row is not None:
                    log_debug(f'Removing stale lock {self.name} '
                              f'(age {int(now - float(row[0]))}s)')
                self._conn.execute(
                    'INSERT OR REPLACE INTO locks (name, timestamp) VALUES (?, ?)',
                    (self.name, now))
            self._acquired = True
            return True
        except sqlite3.Error:
            # on db errors be permissive rather than blocking syncs forever
            return True

    def release(self):
        if not self._acquired:
            return
        try:
            with self._conn:
                self._conn.execute('DELETE FROM locks WHERE name = ?', (self.name,))
        except sqlite3.Error:
            pass
        self._acquired = False

    def __enter__(self):
        return self.acquire()

    def __exit__(self, exc_type, exc_value, traceback):
        self.release()
        return False

    def close(self):
        try:
            self._conn.close()
        except sqlite3.Error:
            pass
