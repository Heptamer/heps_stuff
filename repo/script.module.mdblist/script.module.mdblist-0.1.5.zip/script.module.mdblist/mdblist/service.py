# -*- coding: utf-8 -*-
"""Background service: player monitoring (scrobbling) + scheduled syncs."""
import threading
import time
import traceback

import xbmc

from .logger import log_debug, log_error
from .monitor.player import MDbListPlayer
from .sync.engine import SyncEngine
from .utils import get_setting, has_api_key, localized, notify


class MDbListService(xbmc.Monitor):

    def __init__(self):
        super().__init__()
        self.player = MDbListPlayer(sync_callback=self.do_sync)
        self._pending_sync = False
        self._last_interval_sync = time.time()

    # ------------------------------------------------------------------ #
    # monitor callbacks                                                  #
    # ------------------------------------------------------------------ #

    def onNotification(self, sender, method, data):
        if method in ('VideoLibrary.OnScanFinished',
                      'VideoLibrary.OnCleanFinished'):
            if get_setting('sync_on_update', 'bool'):
                log_debug(f'Library event ({method}), scheduling sync')
                self._pending_sync = True

    def onSettingsChanged(self):
        log_debug('Settings changed')

    # ------------------------------------------------------------------ #
    # sync execution                                                     #
    # ------------------------------------------------------------------ #

    def do_sync(self, force=False, silent=True):
        if not has_api_key():
            log_debug('Sync skipped: no API key')
            return

        def _worker():
            started = time.time()
            try:
                summary = SyncEngine().run(force=force)
                log_debug(f'Sync finished in {time.time() - started:.1f}s: {summary}')
                if not silent:
                    notify(localized(32112) or 'Sync finished')
            except Exception as exc:
                log_error(f'Sync failed: {exc}\n{traceback.format_exc()}')
                if not silent:
                    notify(localized(32125) or 'Sync failed')

        threading.Thread(target=_worker, daemon=True).start()

    def startup_sync(self):
        delay = int(get_setting('sync_startup_delay', 'int') or 0)
        if not has_api_key():
            log_debug('No API key configured yet')
            return
        log_debug(f'Startup sync in {delay}s')
        timer = threading.Timer(delay, self.do_sync)
        timer.daemon = True
        timer.start()

    # ------------------------------------------------------------------ #
    # main loop                                                          #
    # ------------------------------------------------------------------ #

    def run(self):
        log_debug('Service starting')
        self.startup_sync()
        while not self.waitForAbort(30):
            now = time.time()
            if self._pending_sync:
                self._pending_sync = False
                self.do_sync()
                self._last_interval_sync = now
                continue
            interval_minutes = int(get_setting('sync_interval', 'int') or 0)
            if interval_minutes > 0 and \
                    now - self._last_interval_sync >= interval_minutes * 60:
                log_debug('Interval sync due')
                self._last_interval_sync = now
                self.do_sync()
        log_debug('Service stopped')


def run():
    try:
        MDbListService().run()
    except Exception as exc:
        log_error(f'Service crashed: {exc}\n{traceback.format_exc()}')
