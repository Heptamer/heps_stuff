# -*- coding: utf-8 -*-
"""RunScript action dispatcher.

Actions (RunScript(script.module.mdblist, key=value, ...)):
    contextmenu                     open the MDBList action dialog
    sync                            manual full sync
    rate[, type=][, id=][, rating=] rate item on MDBList (dialog when rating missing)
    unrate                          remove remote rating
    togglewatched                   toggle remote watched state
    markwatched / markunwatched     explicit watched state changes
    addtowatchlist                  add to watchlist
    removefromwatchlist             remove from watchlist
    auth_info                       show account info

Item identification: id=tmdb:12345 | imdb:tt0117731 (type=movie|show).
When omitted, the currently playing item is used.
"""
import threading
import traceback

import xbmc
import xbmcgui

from .logger import log_debug, log_error
from .utils import has_api_key, localized, notify, parse_id

MANUAL_SYNC_WAIT = 45  # seconds to wait for a running sync to finish


def parse_args(argv):
    args = {}
    for raw in argv[1:]:
        if '=' not in raw:
            continue
        key, _, value = raw.partition('=')
        args[key.strip().lower()] = value.strip()
    return args


def run():
    args = parse_args(list(sys_argv()))
    action = (args.get('action') or 'contextmenu').lower()
    safe_args = {k: ('***' if k == 'api_key' else v) for k, v in args.items()}
    log_debug(f'Action requested: {action} {safe_args}')
    try:
        handler = HANDLERS.get(action)
        if handler is None:
            notify(localized(32123) or 'Unknown action')
            return
        handler(args)
    except Exception as exc:
        log_error(f'Action {action} failed: {exc}\n{traceback.format_exc()}')
        notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR)


def sys_argv():
    import sys
    return list(sys.argv)


# ---------------------------------------------------------------------- #
# helpers                                                                #
# ---------------------------------------------------------------------- #

class MediaRef(object):
    """Identifies a movie or show via provider id."""

    def __init__(self, mediatype=None, provider=None, media_id=None,
                 season=None, episode=None):
        self.mediatype = mediatype
        self.provider = provider
        self.media_id = media_id
        self.season = season
        self.episode = episode

    @property
    def valid(self):
        return bool(self.provider and self.media_id and
                    self.mediatype in ('movie', 'show'))

    def ids_dict(self):
        return {self.provider: self.media_id}


def resolve_media(args):
    """Build a MediaRef from script arguments, falling back to the playing item."""
    ref = MediaRef()
    id_value = args.get('id')
    if id_value:
        ref.provider, ref.media_id = parse_id(id_value)
        mediatype = (args.get('type') or '').lower()
        if mediatype in ('movie', 'show', 'tvshow'):
            ref.mediatype = 'show' if mediatype == 'tvshow' else mediatype
        else:
            # guess by id shape: tt... -> movie is a bad guess; require type
            ref.mediatype = 'movie' if ref.provider == 'tmdb' else None
    if ref.provider and ref.media_id:
        if ref.valid:
            return ref
        # provider+id known but mediatype missing/invalid – try playing item
        player_item = from_playing_item()
        if player_item:
            return player_item
        return None
    player_item = from_playing_item()
    if player_item:
        return player_item
    return None


def from_playing_item():
    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            return None
        listitem = player.getPlayingItem()
    except RuntimeError:
        return None
    from .scrobbler import ScrobbledItem
    item = ScrobbledItem.from_listitem(listitem)
    if item is None:
        item = ScrobbledItem.from_infolabels()
    if item is None:
        return None
    try:
        item.file_path = player.getPlayingFile()
    except RuntimeError:
        item.file_path = None
    ref = MediaRef(mediatype='movie' if item.mediatype == 'movie' else 'show',
                   provider=item.provider, media_id=item.media_id)
    if not ref.valid:
        # library reverse lookup for items without uniqueids (e.g. xStream)
        if item.file_path:
            from .library import lookup_by_file
            result = lookup_by_file(item.file_path)
            if result:
                ref = MediaRef(
                    mediatype='movie' if result['mediatype'] == 'movie'
                    else 'show',
                    provider=result['provider'], media_id=result['media_id'])
                return ref if ref.valid else None
        if item.title:
            return MediaRef(mediatype=item.mediatype,
                           provider=item.provider, media_id=item.media_id)
        return None
    return ref


def ensure_api(silent=False):
    if not has_api_key():
        if not silent:
            notify(localized(32108) or 'No API key configured.',
                   icon=xbmcgui.NOTIFICATION_WARNING)
        return None
    from . import get_api
    return get_api(cache=False)


# ---------------------------------------------------------------------- #
# actions                                                                #
# ---------------------------------------------------------------------- #

def action_contextmenu(args):
    from .gui.contextmenu import ContextMenu
    ContextMenu().open()


def action_sync(args):
    silent = str(args.get('silent', 'true')).lower() != 'false'
    if not silent:
        notify(localized(32111) or 'Sync started')
    from .sync.engine import SyncEngine

    def _worker():
        try:
            # the engine takes the lock itself; wait out a running sync
            summary = SyncEngine(api=ensure_api(silent=True)).run(
                force=True, wait_seconds=MANUAL_SYNC_WAIT)
        except Exception as exc:
            log_error(f'Manual sync failed: {exc}')
            notify(localized(32125) or 'Sync failed',
                   icon=xbmcgui.NOTIFICATION_ERROR)
            return
        if summary.get('skipped'):
            log_debug(f'Manual sync skipped after {MANUAL_SYNC_WAIT}s: '
                      'another sync is running')
            notify(localized(32113) or 'A sync is already running')
            return
        log_debug(f'Manual sync result: {summary}')
        notify(localized(32112) or 'Sync finished')

    threading.Thread(target=_worker, daemon=True).start()


def action_rate(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    rating = args.get('rating')
    if rating in (None, ''):
        from .gui.rateprompt import pick_rating
        rating = pick_rating(getattr(ref, 'title', '') or '')
    if rating is None:
        return
    try:
        rating = int(float(rating))
    except (TypeError, ValueError):
        return
    if not 1 <= rating <= 10:
        notify('1-10', icon=xbmcgui.NOTIFICATION_WARNING)
        return
    api.push_ratings([{'type': ref.mediatype, 'ids': ref.ids_dict(),
                       'rating': rating}])
    notify(localized(32115) or 'Rating saved')


def action_unrate(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    api.remove_ratings([{'type': ref.mediatype, 'ids': ref.ids_dict()}])
    notify(localized(32116) or 'Rating removed')


def action_togglewatched(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    state = api.get_item_state(ref.media_id, ref.mediatype, ref.provider) or {}
    watched = bool(state.get('watched')) if isinstance(state, dict) else False
    if watched:
        action_markunwatched(args)
    else:
        action_markwatched(args)


def action_markwatched(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        return
    payload = {'movies': [ref.ids_dict()]} if ref.mediatype == 'movie' \
        else {'shows': [ref.ids_dict()]}
    api.push_watched(**payload)
    notify(localized(32114) or 'Watched state updated')


def action_markunwatched(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        return
    payload = {'movies': [ref.ids_dict()]} if ref.mediatype == 'movie' \
        else {'shows': [ref.ids_dict()]}
    api.remove_watched(**payload)
    notify(localized(32114) or 'Watched state updated')


def action_addtowatchlist(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    payload = {'movies': [ref.ids_dict()]} if ref.mediatype == 'movie' \
        else {'shows': [ref.ids_dict()]}
    if ref.mediatype == 'movie':
        api.add_watchlist_items(movies=payload['movies'])
    else:
        api.add_watchlist_items(shows=payload['shows'])
    notify(localized(32117) or 'Added to watchlist')


def action_removefromwatchlist(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    if ref.mediatype == 'movie':
        api.remove_watchlist_items(movies=[ref.ids_dict()])
    else:
        api.remove_watchlist_items(shows=[ref.ids_dict()])
    notify(localized(32118) or 'Removed from watchlist')


def action_auth_info(args):
    api = ensure_api()
    if api is None:
        return
    try:
        user = api.get_user() or {}
        name = user.get('name') or user.get('username') or '?'
        xbmcgui.Dialog().ok(
            localized(32100) or 'MDBList',
            localized(32121).format(name) if '%s' in (localized(32121) or '')
            else f'{localized(32120)}: {name}')
    except Exception as exc:
        log_error(f'auth_info failed: {exc}')
        xbmcgui.Dialog().ok(localized(32100) or 'MDBList',
                            localized(32122) or 'Not authenticated')


HANDLERS = {
    'contextmenu': action_contextmenu,
    'sync': action_sync,
    'rate': action_rate,
    'unrate': action_unrate,
    'togglewatched': action_togglewatched,
    'markwatched': action_markwatched,
    'markunwatched': action_markunwatched,
    'addtowatchlist': action_addtowatchlist,
    'removefromwatchlist': action_removefromwatchlist,
    'auth_info': action_auth_info,
}
