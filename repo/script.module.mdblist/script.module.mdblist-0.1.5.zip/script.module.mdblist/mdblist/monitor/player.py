# -*- coding: utf-8 -*-
import threading

import xbmc

from ..logger import log_debug
from ..scrobbler import ScrobbledItem, Scrobbler
from ..utils import get_setting


class MDbListPlayer(xbmc.Player):
    """Watches playback events and forwards them to the scrobbler.
    All API calls run in daemon threads so playback is never blocked."""

    def __init__(self, sync_callback=None):
        super().__init__()
        self.scrobbler = None
        self.current = None          # ScrobbledItem of current playback
        self.last_progress = 0.0
        self._lock = threading.Lock()
        self._sync_callback = sync_callback

    @property
    def enabled(self):
        return bool(get_setting('enable_scrobbling', 'bool'))

    def _get_scrobbler(self):
        if self.scrobbler is None:
            min_percent = get_setting('scrobble_min_percent', 'int') or 5
            self.scrobbler = Scrobbler(min_percent=min_percent)
        return self.scrobbler

    def _progress(self):
        try:
            total_time = self.getTotalTime()
            if not total_time or total_time <= 0:
                return 0.0
            progress = (self.getTime() / float(total_time)) * 100
            return max(0.0, min(progress, 100.0))
        except (RuntimeError, TypeError, ZeroDivisionError):
            return 0.0

    def _dispatch(self, method, item=None, progress=None, on_sent=None):
        target_item = item or self.current
        if not target_item:
            return
        value = self._progress() if progress is None else progress

        def _run():
            sent = self._get_scrobbler().send(
                method, target_item, round(value, 2))
            if on_sent is not None and sent:
                try:
                    on_sent(sent)
                except Exception as exc:
                    log_debug(f'Post-stop hook failed: {exc}')

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()

    # ------------------------------------------------------------------ #
    # player callbacks                                                   #
    # ------------------------------------------------------------------ #

    def onAVStarted(self):
        """Fired once playback actually started and duration is available."""
        with self._lock:
            try:
                listitem = self.getPlayingItem()
            except RuntimeError:
                listitem = None
            item = ScrobbledItem.from_listitem(listitem) if listitem else None
            if not item or not item.valid:
                item = ScrobbledItem.from_infolabels()
            if not item or not item.valid:
                self.current = None
                log_debug('Player: nothing identifiable playing')
                return
            try:
                item.file_path = self.getPlayingFile()
            except RuntimeError:
                item.file_path = None
            self.current = item
            self.last_progress = self._progress()
        if not self.enabled:
            return
        self._dispatch('start')

    def onPlayBackResumed(self):
        if not self.enabled or not self.current:
            return
        self._dispatch('start')

    def onPlayBackPaused(self):
        if not self.enabled or not self.current:
            return
        self.last_progress = self._progress()
        self._dispatch('pause', progress=self.last_progress)

    def onPlayBackSeek(self, time_s, seek_offset):
        if self.current:
            self.last_progress = self._progress()

    def onPlayBackStopped(self):
        self._on_end()

    def onPlayBackEnded(self):
        self._on_end()

    def _on_end(self):
        with self._lock:
            item = self.current
            self.current = None
        if not self.enabled or not item:
            return
        # after end events getTime()/getTotalTime() raise; Kodi logs the
        # raw exception even when caught, so only ask while still playing
        progress = self.last_progress
        if self.isPlaying():
            progress = max(progress, self._progress())
        if progress < (get_setting('scrobble_min_percent', 'int') or 5):
            log_debug(f'Playback ended below scrobble threshold ({progress:.1f}%)')
            return

        def _ask(resolved):
            from ..gui.rateprompt import prompt_rating
            prompt_rating(resolved, progress)

        self._dispatch('stop', item=item, progress=progress, on_sent=_ask)
        if self._sync_callback is not None:
            try:
                self._sync_callback()
            except Exception as exc:
                log_debug(f'Post-scrobble sync trigger failed: {exc}')
