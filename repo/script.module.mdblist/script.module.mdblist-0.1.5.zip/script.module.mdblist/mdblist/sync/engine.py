# -*- coding: utf-8 -*-
"""Bidirectional sync between the Kodi library and MDBList.

Directions (each individually switchable in settings):
- watched: pull remote plays -> Kodi playcount, push local playcount -> remote
- ratings: pull remote rating -> Kodi userrating, push local userrating -> remote

Incremental strategy:
- Pulls fetch /sync/last_activities first and are skipped when the relevant
  activity timestamp is unchanged since the last successful sync.
- Pushes compare the local library against the cached remote state
  (long TTL) so local changes never need extra API calls.
"""
from ..api import mapping
from ..logger import log_debug, log_error
from ..utils import (get_setting, iso_to_kodi, jsonrpc,
                     jsonrpc_paginate, kodi_date_to_iso, notify, localized)
from .lock import SyncLock

try:
    from xbmcgui import NOTIFICATION_ERROR
except ImportError:
    NOTIFICATION_ERROR = 'error'

CACHE_TTL_REMOTE = 6 * 3600


class SyncEngine(object):

    def __init__(self, api=None):
        from .. import get_api
        self.api = api or get_api()
        from ..cache import get_cache
        self.cache = get_cache()

    # ------------------------------------------------------------------ #
    # orchestration                                                      #
    # ------------------------------------------------------------------ #

    def run(self, force=False, wait_seconds=0):
        """Run all enabled sync parts. Returns a summary dict.

        wait_seconds: how long to wait for the lock when another sync
        is running (manual syncs pass ~45s, service runs don't wait).
        """
        lock = SyncLock('engine')
        acquired = lock.acquire(timeout=wait_seconds)
        try:
            if not acquired:
                log_debug('Sync skipped: another sync is running')
                return {'skipped': True}
            summary = {}
            activities = self._get_activities(force)
            if get_setting('enable_sync_watched_pull', 'bool'):
                summary['watched_pull'] = self._watched_pull(activities, force)
            if get_setting('enable_sync_watched_push', 'bool'):
                summary['watched_push'] = self._watched_push()
            if get_setting('enable_sync_collection', 'bool'):
                summary['collection'] = self._collection_push()
            if get_setting('enable_sync_ratings_pull', 'bool'):
                summary['ratings_pull'] = self._ratings_pull(activities, force)
            if get_setting('enable_sync_ratings_push', 'bool'):
                summary['ratings_push'] = self._ratings_push(activities, force)
            if force and activities:
                self._store_activities(activities)
            return summary
        finally:
            lock.release()

    def _get_activities(self, force=False):
        try:
            activities = self.api.get_last_activities() or {}
        except Exception as exc:
            log_error(f'last_activities failed: {exc}')
            return None
        if force:
            return activities
        stored = self.cache.get('activities') or {}
        if not stored:
            return activities
        if all((stored.get(k) == v) for k, v in activities.items()):
            log_debug('Sync: no remote activity changes')
            return None
        return activities

    def _store_activities(self, activities):
        if activities:
            self.cache.set('activities', activities, ttl=30 * 86400)

    # ------------------------------------------------------------------ #
    # local library access                                               #
    # ------------------------------------------------------------------ #

    def _get_local_movies(self):
        """Returns {canonical_key: {movieid, playcount, ..., ids}}."""
        movies = {}
        for item in jsonrpc_paginate(
                'VideoLibrary.GetMovies', 'movies',
                {'properties': ['playcount', 'lastplayed', 'userrating',
                                'uniqueid']}):
            ids = item.get('uniqueid') or {}
            key = self._show_key(ids)
            if key is None:
                continue
            movies[key] = {
                'movieid': item.get('movieid'),
                'playcount': int(item.get('playcount') or 0),
                'lastplayed': item.get('lastplayed'),
                'userrating': int(item.get('userrating') or 0),
                'ids': ids,
            }
        return movies

    def _get_tvshow_map(self):
        """Returns {canonical_key: {tvshowid, ids}}."""
        shows = {}
        for show in jsonrpc_paginate(
                'VideoLibrary.GetTvShows', 'tvshows',
                {'properties': ['uniqueid']}):
            ids = show.get('uniqueid') or {}
            key = self._show_key(ids)
            if key:
                shows[key] = {
                    'tvshowid': show.get('tvshowid'),
                    'ids': ids,
                }
        return shows

    def _get_local_episodes(self):
        """Returns ({canonical_key: {tvshowid, ids}}, {tvshowid: {(s,e): ep}})."""
        show_map = self._get_tvshow_map()
        episodes = {}
        for ep in jsonrpc_paginate(
                'VideoLibrary.GetEpisodes', 'episodes',
                {'properties': ['playcount', 'lastplayed', 'userrating',
                                'season', 'episode', 'tvshowid']}):
            tvshowid = ep.get('tvshowid')
            key = (int(ep.get('season') or 0), int(ep.get('episode') or 0))
            episodes.setdefault(tvshowid, {})[key] = {
                'episodeid': ep.get('episodeid'),
                'playcount': int(ep.get('playcount') or 0),
                'lastplayed': ep.get('lastplayed'),
                'userrating': int(ep.get('userrating') or 0),
            }
        return show_map, episodes

    # ------------------------------------------------------------------ #
    # id helpers                                                         #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _show_key(ids):
        """Normalize a provider id dict into a comparable key tuple."""
        for provider in ('tmdb', 'tvdb', 'imdb', 'trakt'):
            value = ids.get(provider)
            if not value:
                continue
            try:
                return (provider, str(int(value)))
            except (TypeError, ValueError):
                return (provider, str(value))
        return None

    @staticmethod
    def _ids_for_push(ids_dict):
        """Extract the best available provider:id pair for API payloads."""
        for provider in ('tmdb', 'tvdb', 'imdb', 'trakt'):
            value = ids_dict.get(provider)
            if value is not None:
                try:
                    return {provider: int(value)}
                except (TypeError, ValueError):
                    return {provider: value}
        return {}

    @staticmethod
    def _keys_from_ids(ids):
        """Yield all canonical keys from a provider ids dict.

        Used to index remote entries by every ID they carry so that a
        local show with tvdb can match a remote entry that only has tmdb.
        """
        for provider in ('tmdb', 'tvdb', 'imdb', 'trakt'):
            value = ids.get(provider)
            if value is not None:
                try:
                    yield (provider, str(int(value)))
                except (TypeError, ValueError):
                    yield (provider, str(value))

    # ------------------------------------------------------------------ #
    # watched                                                            #
    # ------------------------------------------------------------------ #

    def _remote_watched(self):
        cached = self.cache.get('sync_watched')
        if cached is not None:
            return cached
        data = self.api.get_watched() or {}
        self.cache.set('sync_watched', data, ttl=CACHE_TTL_REMOTE)
        return data

    @staticmethod
    def _newer(remote_iso, kodi_value):
        """True when remote timestamp is strictly newer than the kodi value.

        Kodi stores *lastplayed* in the local system time; we detect the
        current UTC offset so both timestamps live in the same frame.
        During DST transitions the offset may be off by ≤1 h – acceptable
        for a tie-breaker comparison."""
        from datetime import datetime, timezone

        from ..utils import iso_to_datetime

        remote_dt = iso_to_datetime(remote_iso)
        if not remote_dt:
            return False
        if not kodi_value:
            return True
        local_tz = datetime.now(timezone.utc).astimezone().tzinfo
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
            try:
                local_dt = datetime.strptime(str(kodi_value), fmt)
            except ValueError:
                continue
            local_dt = local_dt.replace(tzinfo=local_tz)
            return remote_dt > local_dt
        return False

    def _watched_pull(self, activities=None, force=False):
        if not force and activities is None:
            return {'status': 'skipped'}
        remote = self._remote_watched()
        changed_movies = changed_episodes = 0

        # Index remote movies by all provider IDs they carry
        remote_movies = {}
        for entry in remote.get('movies') or []:
            ids = (mapping.watched_entry_ids(entry).get('ids') or {})
            for key in self._keys_from_ids(ids):
                remote_movies[key] = entry

        movies = self._local_movie_cache()
        for key, local in movies.items():
            entry = remote_movies.get(key)
            if entry is None:
                continue
            plays = mapping.movie_plays(entry)
            last_at = entry.get('last_watched_at')
            if plays <= 0:
                continue
            if local['playcount'] < plays or (
                    local['playcount'] == plays and
                    self._newer(last_at, local['lastplayed'])):
                params = {'movieid': local['movieid'],
                          'playcount': max(plays, 1)}
                kodi_date = iso_to_kodi(last_at)
                if kodi_date:
                    params['lastplayed'] = kodi_date
                if jsonrpc('VideoLibrary.SetMovieDetails',
                           params).get('result'):
                    changed_movies += 1

        show_map, episodes_by_show = self._get_local_episodes()

        # Index remote shows by all provider IDs
        remote_shows = {}
        for entry in remote.get('shows') or []:
            ids = (mapping.watched_entry_ids(entry).get('ids') or {})
            for key in self._keys_from_ids(ids):
                remote_shows[key] = entry

        for key, info in show_map.items():
            entry = remote_shows.get(key)
            if entry is None:
                continue
            tvshowid = info['tvshowid']
            local_eps = episodes_by_show.get(tvshowid, {})
            for season in entry.get('seasons') or []:
                season_number = season.get('number')
                eps = mapping.episode_plays(season)
                for (s_num, e_num), local in local_eps.items():
                    if s_num != season_number or e_num not in eps:
                        continue
                    remote_ep = eps[e_num]
                    if local['playcount'] < remote_ep['plays']:
                        params = {'episodeid': local['episodeid'],
                                  'playcount': max(remote_ep['plays'], 1)}
                        kodi_date = iso_to_kodi(
                            remote_ep.get('last_watched_at'))
                        if kodi_date:
                            params['lastplayed'] = kodi_date
                        if jsonrpc('VideoLibrary.SetEpisodeDetails',
                                   params).get('result'):
                            changed_episodes += 1

        result = {'movies': changed_movies, 'episodes': changed_episodes}
        log_debug(f'Watched pull: {result}')
        return result

    def _local_movie_cache(self):
        if getattr(self, '_movies_cache', None) is None:
            self._movies_cache = self._get_local_movies()
        return self._movies_cache

    def _watched_push(self):
        remote = self._remote_watched()

        # Index remote movies by all provider IDs
        remote_movies = {}
        for entry in remote.get('movies') or []:
            ids = (mapping.watched_entry_ids(entry).get('ids') or {})
            for key in self._keys_from_ids(ids):
                remote_movies[key] = entry

        push_movies = []
        for key, local in self._get_local_movies().items():
            if local['playcount'] <= 0:
                continue
            entry = remote_movies.get(key)
            remote_plays = mapping.movie_plays(entry) if entry else 0
            if remote_plays >= local['playcount']:
                continue
            push_movies.append({'ids': self._ids_for_push(local['ids'])})

        show_map, episodes_by_show = self._get_local_episodes()

        # Index remote shows by all provider IDs
        remote_shows = {}
        for entry in remote.get('shows') or []:
            ids = (mapping.watched_entry_ids(entry).get('ids') or {})
            for key in self._keys_from_ids(ids):
                remote_shows[key] = entry

        push_shows = []
        for key, info in show_map.items():
            tvshowid = info['tvshowid']
            local_eps = episodes_by_show.get(tvshowid, {})
            watched = {(s, e): d for (s, e), d in local_eps.items()
                       if d['playcount'] > 0}
            if not watched:
                continue
            seasons = {}
            for (s_num, e_num), data in watched.items():
                seasons.setdefault(s_num, []).append((e_num, data))
            remote_entry = remote_shows.get(key) or {}
            remote_seasons = {}
            for rs in remote_entry.get('seasons') or []:
                remote_seasons[rs.get('number')] = mapping.episode_plays(rs)
            season_payload = []
            for s_num, eps in seasons.items():
                remote_eps = remote_seasons.get(s_num, {})
                ep_payload = []
                for e_num, data in eps:
                    r_eps = remote_eps.get(e_num) or {}
                    if r_eps.get('plays', 0) >= data['playcount']:
                        continue
                    item = {'number': e_num}
                    ep_payload.append(item)
                if ep_payload:
                    season_payload.append({'number': s_num,
                                           'episodes': ep_payload})
            if season_payload:
                push_shows.append({
                    'ids': self._ids_for_push(info['ids']),
                    'seasons': season_payload,
                })

        if not push_movies and not push_shows:
            return {'status': 'ok', 'pushed': 0}
        try:
            self.api.push_watched(movies=push_movies or None,
                                  shows=push_shows or None)
        except Exception as exc:
            log_error(f'Watched push failed: {exc}')
            notify(localized(32125) or 'Sync failed',
                   icon=NOTIFICATION_ERROR)
            return {'status': 'error'}
        self.cache.delete('sync_watched')
        pushed = len(push_movies) + len(push_shows)
        log_debug(f'Watched push: {pushed} entries')
        return {'status': 'ok', 'pushed': pushed}

    # ------------------------------------------------------------------ #
    # collection                                                         #
    # ------------------------------------------------------------------ #

    def _remote_collection(self):
        cached = self.cache.get('sync_collection')
        if cached is not None:
            return cached
        data = self.api.get_collection() or {}
        self.cache.set('sync_collection', data, ttl=CACHE_TTL_REMOTE)
        return data

    def _parse_collection(self, data):
        """Returns ({movie_key}, {show_key: {(season, episode), ...}})."""
        movie_ids = set()
        for entry in (data or {}).get('movies') or []:
            ids = (mapping.watched_entry_ids(entry).get('ids') or {})
            key = self._show_key(ids)
            if key:
                movie_ids.add(key)
        episodes_by_show = {}
        for entry in (data or {}).get('shows') or []:
            show = mapping.watched_entry_ids(entry)
            key = self._show_key(show.get('ids') or {})
            if key is None and isinstance(entry, dict):
                key = self._show_key(entry.get('ids') or {})
            if key is None:
                continue
            eps = episodes_by_show.setdefault(key, set())
            # seasons live inside the show object; tolerate entry-level too
            seasons = show.get('seasons') or (
                entry.get('seasons') if isinstance(entry, dict) else []) or []
            for season in seasons:
                s_num = season.get('number')
                if s_num is None:
                    continue
                for ep in season.get('episodes') or []:
                    number = ep.get('number')
                    if number is not None:
                        eps.add((int(s_num), int(number)))
        return movie_ids, episodes_by_show

    def _get_show_index(self):
        """All library shows as {key: {tvshowid,title,year}} for the diff."""
        index = {}
        for show in jsonrpc_paginate(
                'VideoLibrary.GetTvShows', 'tvshows',
                {'properties': ['title', 'premiered', 'uniqueid']}):
            premiered = str(show.get('premiered') or '')
            key = self._show_key(show.get('uniqueid') or {}) or \
                ('noid', str(show.get('tvshowid')))
            index[key] = {
                'tvshowid': show.get('tvshowid'),
                'title': show.get('title') or '',
                'year': int(premiered[:4]) if premiered[:4].isdigit() else None,
            }
        no_ids = sum(1 for k in index if k[0] == 'noid')
        log_debug(f'Collection: {len(index)} shows in library, '
                  f'{no_ids} without uniqueid')
        return index

    def _resolve_by_title(self, title, year):
        """Last-resort show identification via MDBList search (30d cache)."""
        if not title:
            return None
        cache_key = f'sync-show-id:{title.lower()}:{year or ""}'
        cached = self.cache.get(cache_key)
        if cached:
            return (cached[0], str(cached[1]))
        try:
            response = self.api.search_media(title, 'show')
        except Exception as exc:
            log_debug(f'Show title-search failed ({title}): {exc}')
            return None
        from ..scrobbler import Scrobbler
        match = Scrobbler._pick_match(response, 'show', year)
        key = self._show_key((match or {}).get('ids') or {})
        if key is None:
            log_debug(f'Show title-search: no result for "{title}"')
            return None
        self.cache.set(cache_key, [key[0], key[1]], ttl=30 * 86400)
        return key

    @staticmethod
    def _missing_episodes_payload(show_key, local_eps, remote_eps):
        """Show payload containing only episodes missing from the collection."""
        seasons = {}
        for (s_num, e_num) in local_eps:
            if (s_num, e_num) in remote_eps:
                continue
            seasons.setdefault(s_num, []).append({'number': e_num})
        if not seasons:
            return None
        provider, value = show_key
        try:
            value = int(value)
        except ValueError:
            pass
        return {'ids': {provider: value},
                'seasons': [{'number': s_num, 'episodes': eps}
                            for s_num, eps in sorted(seasons.items())]}

    @staticmethod
    def _chunks(items, size=100):
        for start in range(0, len(items), size):
            yield items[start:start + size]

    def _collection_push(self):
        try:
            remote = self._remote_collection()
        except Exception as exc:
            log_error(f'Collection fetch failed: {exc}')
            return {'status': 'error'}
        remote_movie_ids, remote_eps_by_show = self._parse_collection(remote)
        log_debug(f'Collection remote snapshot: movies={len(remote_movie_ids)} '
                  f'shows={len(remote_eps_by_show)}')

        local_movies = self._get_local_movies()
        push_movies = [{'ids': self._ids_for_push(info['ids'])}
                       for key, info in local_movies.items()
                       if key not in remote_movie_ids]

        show_index = self._get_show_index()
        _, episodes_by_show = self._get_local_episodes()
        push_shows = []
        added_episodes = 0
        unresolved = 0
        for key in list(show_index):
            info = show_index.pop(key)
            if key[0] == 'noid':
                resolved = self._resolve_by_title(info['title'], info['year'])
                if resolved is None:
                    unresolved += 1
                    continue
                key = resolved
            local_eps = set(episodes_by_show.get(info['tvshowid'], {}))
            payload = self._missing_episodes_payload(
                key, local_eps, remote_eps_by_show.get(key, set()))
            if payload:
                push_shows.append(payload)
                added_episodes += sum(len(s['episodes'])
                                      for s in payload['seasons'])
        log_debug(f'Collection diff: movies={len(push_movies)} '
                  f'show payloads={len(push_shows)} episodes={added_episodes} '
                  f'unresolved={unresolved}')

        if not push_movies and not push_shows:
            return {'status': 'ok', 'movies': 0, 'episodes': 0}
        try:
            for chunk in self._chunks(push_movies):
                self.api.add_collection_items(movies=chunk)
            for chunk in self._chunks(push_shows):
                self.api.add_collection_items(shows=chunk)
        except Exception as exc:
            log_error(f'Collection push failed: {exc}')
            return {'status': 'error'}
        # merge pushed items into the cached snapshot so reruns stay silent
        movies_bucket = remote.setdefault('movies', [])
        for payload in push_movies:
            movies_bucket.append({'movie': {'ids': {
                str(p): str(v) for p, v in payload['ids'].items()}}})
        shows_bucket = remote.setdefault('shows', [])
        for payload in push_shows:
            shows_bucket.append({'show': {
                'ids': {p: str(v) for p, v in payload['ids'].items()},
                'seasons': [{'number': s['number'],
                             'episodes': [dict(ep) for ep in s['episodes']]}
                            for s in payload['seasons']]}})
        self.cache.set('sync_collection', remote, ttl=CACHE_TTL_REMOTE)
        result = {'status': 'ok', 'movies': len(push_movies),
                  'episodes': added_episodes}
        log_debug(f'Collection push: {result}')
        return result

    # ------------------------------------------------------------------ #
    # ratings                                                            #
    # ------------------------------------------------------------------ #

    def _ratings_pull(self, activities=None, force=False):
        if not force and activities is None:
            return {'status': 'skipped'}
        try:
            remote = self.api.get_ratings() or {}
        except Exception as exc:
            log_error(f'Ratings pull failed: {exc}')
            return {'status': 'error'}
        changed = 0
        movies = self._local_movie_cache()
        for entry in mapping.rating_entries(remote, 'movies'):
            ids = entry.get('ids') or {}
            rating = entry.get('rating')
            if not rating:
                continue
            key = self._show_key(ids)
            if key is None:
                continue
            local = movies.get(key)
            if local is None or local['userrating'] == int(rating):
                continue
            if self._newer(entry.get('rated_at'),
                           local.get('lastplayed')) or local['userrating'] == 0:
                if jsonrpc('VideoLibrary.SetMovieDetails',
                           {'movieid': local['movieid'],
                            'userrating': int(rating)}).get('result'):
                    changed += 1
        result = {'movies': changed, 'note': 'shows/episodes follow in later version'}
        log_debug(f'Ratings pull: {result}')
        return result

    def _ratings_push(self, activities=None, force=False):
        if not force and activities is None:
            return {'status': 'skipped'}
        try:
            remote = self.api.get_ratings() or {}
        except Exception as exc:
            log_error(f'Ratings push failed: {exc}')
            return {'status': 'error'}
        remote_movie_ratings = {}
        for entry in mapping.rating_entries(remote, 'movies'):
            key = self._show_key(entry.get('ids') or {})
            if key:
                remote_movie_ratings[key] = entry.get('rating')
        entries = []
        removed = []
        for key, local in self._get_local_movies().items():
            userrating = local['userrating']
            remote_rating = remote_movie_ratings.get(key)
            push_ids = self._ids_for_push(local['ids'])
            if userrating > 0 and userrating != remote_rating:
                entries.append({'type': 'movie', 'ids': push_ids,
                                'rating': userrating})
            elif userrating == 0 and remote_rating:
                removed.append({'type': 'movie', 'ids': push_ids})
        if not entries and not removed:
            return {'status': 'ok', 'pushed': 0}
        try:
            if entries:
                self.api.push_ratings(entries)
            if removed:
                self.api.remove_ratings(removed)
        except Exception as exc:
            log_error(f'Ratings push request failed: {exc}')
            return {'status': 'error'}
        result = {'pushed': len(entries), 'removed': len(removed)}
        log_debug(f'Ratings push: {result}')
        return result
