# -*- coding: utf-8 -*-
"""Normalization helpers for MDBList data (ratings, ids, timestamps)."""

# providers whose ids the MDBList API expects as numbers
# (imdb and mdblist ids are strings)
NUMERIC_ID_PROVIDERS = ('tmdb', 'trakt', 'tvdb', 'kitsu')

# provider names accepted as flat '<provider>id' keys on search entries
FLAT_ID_PROVIDERS = ('imdb', 'tmdb', 'trakt', 'tvdb', 'mal')


def typed_id(provider, value):
    """Convert a single provider id to the type the API expects."""
    if value is None:
        return None
    if provider in NUMERIC_ID_PROVIDERS:
        try:
            return int(str(value).strip())
        except (TypeError, ValueError):
            pass
    return str(value)


def typed_ids(ids):
    """Normalize an ids dict {provider: value} into API-typed values."""
    return {provider: typed_id(provider, value)
            for provider, value in (ids or {}).items() if value}


def _provider_from_key(key):
    """Map an id key ('tmdb', 'tmdbid', 'imdbid', ...) to its provider."""
    if key in FLAT_ID_PROVIDERS:
        return key
    if key.endswith('id'):
        name = key[:-2]
        if name in FLAT_ID_PROVIDERS:
            return name
    return None


def entry_ids(entry):
    """Collect provider ids from a search/media entry.

    The search endpoint returns suffixed keys both on the entry itself
    and inside its ids dict ({'ids': {'tmdbid': 1}}); other endpoints use
    plain names ({'ids': {'tmdb': 1}}). All variants merge here, later
    sources taking precedence, keyed by plain provider name."""
    sources = []
    if isinstance(entry, dict):
        sources.append(entry)
        nested = entry.get('ids')
        if isinstance(nested, dict):
            sources.append(nested)
    ids = {}
    for source in sources:
        for key, value in source.items():
            if isinstance(value, bool) or \
                    not isinstance(value, (str, int)) or not value:
                continue
            name = _provider_from_key(str(key))
            if name:
                ids[name] = value
    return ids


def bucket_items(payload, buckets=('movies', 'shows', 'seasons', 'episodes',
                                   'items', 'lists', 'people')):
    """Collect list entries from any known response bucket into one list."""
    items = []
    if isinstance(payload, list):
        return payload
    for bucket in buckets:
        values = (payload or {}).get(bucket)
        if isinstance(values, list):
            items.extend(values)
    return items


def watched_entry_ids(entry):
    """Return the inner media object of a sync/watched list entry."""
    if not isinstance(entry, dict):
        return {}
    for key in ('movie', 'show'):
        if isinstance(entry.get(key), dict):
            return entry[key]
    return {}


def episode_plays(season_entry):
    """Normalize an episode list of a season entry."""
    episodes = season_entry.get('episodes') or []
    result = {}
    for ep in episodes:
        number = ep.get('number')
        if number is None:
            continue
        plays = ep.get('plays', ep.get('watched'))
        if plays is None:
            plays = 1 if ep.get('last_watched_at') else 0
        result[int(number)] = {
            'plays': int(plays or 0),
            'last_watched_at': ep.get('last_watched_at'),
        }
    return result


def movie_plays(movie_entry):
    plays = movie_entry.get('plays', movie_entry.get('watched'))
    if plays is None:
        plays = 1 if movie_entry.get('last_watched_at') else 0
    return int(plays or 0)


def rating_entries(payload, mediatype_key):
    """Extract rating entries for a given key ('movies','shows','episodes')."""
    entries = (payload or {}).get(mediatype_key) or []
    result = []
    for entry in entries:
        ids = (entry.get(mediatype_key.rstrip('s')) or {}).get('ids') or entry.get('ids') or {}
        result.append({'ids': ids,
                       'rating': entry.get('rating'),
                       'rated_at': entry.get('rated_at')})
    return result
