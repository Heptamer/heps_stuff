# -*- coding: utf-8 -*-
"""Minimal xbmc/xbmcaddon/xbmcgui/xbmcvfs stand-ins for running the unit
tests outside of Kodi. install() must be called before importing mdblist."""
import os
import sys
import tempfile
import types

SETTINGS = {}
LOG_MESSAGES = []
PROFILE_DIR = None


def _module(name):
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    return mod


def install(profile_dir=None):
    global PROFILE_DIR
    if profile_dir:
        PROFILE_DIR = profile_dir
    elif PROFILE_DIR is None:
        PROFILE_DIR = tempfile.mkdtemp(prefix='mdblist-test-')
    if not PROFILE_DIR.endswith(os.sep):
        PROFILE_DIR += os.sep

    xbmc = _module('xbmc')
    xbmc.LOGDEBUG = 0
    xbmc.LOGINFO = 1
    xbmc.LOGWARNING = 2
    xbmc.LOGERROR = 3
    xbmc.log = lambda msg, level=1: LOG_MESSAGES.append((level, msg))

    class Monitor(object):
        def waitForAbort(self, timeout=0):
            return True

    class Player(object):
        def __init__(self, *args, **kwargs):
            pass

    xbmc.Monitor = Monitor
    xbmc.Player = Player
    xbmc.getCondVisibility = lambda condition: False
    xbmc.getInfoLabel = lambda label: ''
    xbmc.executeJSONRPC = lambda request: '{"result": {}}'
    xbmc.getLocalizedString = lambda string_id: ''

    xbmcaddon = _module('xbmcaddon')

    class Addon(object):
        def __init__(self, addon_id=None):
            pass

        def getSettingBool(self, key):
            return bool(SETTINGS.get(key))

        def getSettingInt(self, key):
            return int(SETTINGS.get(key) or 0)

        def getSettingNumber(self, key):
            return float(SETTINGS.get(key) or 0)

        def getSettingString(self, key):
            return str(SETTINGS.get(key) or '')

        def getLocalizedString(self, string_id):
            return ''

        def getAddonInfo(self, key):
            return {'path': os.getcwd(), 'profile': PROFILE_DIR,
                    'version': '0.0.0-test', 'icon': ''}.get(key, '')

    xbmcaddon.Addon = Addon

    xbmcgui = _module('xbmcgui')
    xbmcgui.NOTIFICATION_INFO = 'info'
    xbmcgui.NOTIFICATION_WARNING = 'warning'
    xbmcgui.NOTIFICATION_ERROR = 'error'

    class Dialog(object):
        def notification(self, *args, **kwargs):
            return True

        def yesno(self, *args, **kwargs):
            return False

        def ok(self, *args, **kwargs):
            return True

    xbmcgui.Dialog = Dialog

    xbmcvfs = _module('xbmcvfs')
    xbmcvfs.translatePath = lambda path: PROFILE_DIR
    xbmcvfs.exists = os.path.exists
    xbmcvfs.mkdir = lambda path: os.makedirs(path, exist_ok=True)
    xbmcvfs.mkdirs = xbmcvfs.mkdir


def reset(settings=None):
    del LOG_MESSAGES[:]
    SETTINGS.clear()
    if settings:
        SETTINGS.update(settings)
