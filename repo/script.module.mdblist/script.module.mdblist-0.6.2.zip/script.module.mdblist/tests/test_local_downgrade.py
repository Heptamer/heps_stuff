# -*- coding: utf-8 -*-
"""Tests for the local "mark unwatched" downgrade push (v0.6.0).

The watched pull treats MDBList as authoritative, so before this feature a
local unwatched reset was reverted by the next sync. The engine now keeps a
cache baseline of locally watched ids and reports deliberate resets through
/sync/watched/remove before the pull runs.
"""
import time
import unittest

from . import kodi_stubs

kodi_stubs.install()
kodi_stubs.reset({'enable_sync_watched_push': True,
                  'enable_sync_watched_pull': True,
                  'debug_logging': False})

from mdblist.sync import engine as engine_mod  # noqa: E402
from mdblist.sync.engine import SyncEngine  # noqa: E402


class FakeCache(object):
    def __init__(self):
        self.store = {}

    def get(self, key):
        return self.store.get(key)

    def set(self, key, value, ttl=300):
        self.store[key] = value

    def delete(self, key):
        self.store.pop(key, None)


class FakeApi(object):
    def __init__(self, watched=None, journal=None):
        self.watched = watched or {}
        self.journal = journal or {'journal': [], '_complete': True}
        self.remove_calls = []
        self.push_calls = []
        self.fail_remove = False

    def get_watched(self, mediatype=None, params=None):
        return self.watched

    def paginate_sync_journal(self, *args, **kwargs):
        return self.journal

    def remove_watched(self, movies=None, shows=None, episodes=None):
        if self.fail_remove:
            raise RuntimeError('network down')
        self.remove_calls.append({'movies': movies, 'shows': shows,
                                  'episodes': episodes})
        return {'updated': {}}

    def push_watched(self, movies=None, shows=None, episodes=None):
        self.push_calls.append({'movies': movies, 'shows': shows,
                                'episodes': episodes})
        return {'updated': {}}

    def get_last_activities(self):
        return {}

    def get_playback_sessions(self):
        return []


def make_movie(movieid, tmdb, playcount):
    return {'movieid': movieid, 'playcount': playcount,
            'lastplayed': '2024-01-01 20:00:00' if playcount else None,
            'userrating': 0, 'ids': {'tmdb': tmdb},
            'resume': False, 'resume_point': None}


def make_episode(episodeid, tvshowid, season, episode, tmdb_ep, playcount):
    return {'episodeid': episodeid, 'playcount': playcount,
            'lastplayed': '2024-01-01 20:00:00' if playcount else None,
            'userrating': 0, 'ids': {'tmdb': tmdb_ep},
            'resume': False, 'resume_point': None}


def remote_movie(tmdb):
    return {'ids': {'tmdb': tmdb}, 'watched_at': '2024-01-01T12:00:00Z'}


def remote_show(tmdb_show, season, episode):
    return {'ids': {'tmdb': tmdb_show},
            'seasons': [{'number': season,
                         'episodes': [{'number': episode,
                                       'watched_at':
                                           '2024-01-01T12:00:00Z'}]}]}


def make_engine(api, movies=None, show_map=None, episodes_by_show=None,
                snapshot=None, library_event=None):
    eng = SyncEngine(api=api)
    eng.cache = FakeCache()
    if snapshot is not None:
        eng.cache.set('local_watched', snapshot)
    if library_event is not None:
        eng.cache.set('library_event', library_event)
    eng._movies_cache = movies or {}
    show_map = show_map or {}
    episodes_by_show = episodes_by_show or {}
    eng._get_local_episodes = lambda: (show_map, episodes_by_show)
    return eng


def baseline(watched_movie_ids=(), watched_episode_ids=(), updated_at=None):
    return {'updated_at': updated_at if updated_at is not None else
            time.time() - 3600,
            'movies': list(watched_movie_ids),
            'episodes': list(watched_episode_ids)}


class LocalDowngradePushTests(unittest.TestCase):

    def test_first_run_stores_baseline_and_pushes_nothing(self):
        api = FakeApi(watched={'movies': [remote_movie(10)]})
        eng = make_engine(api, movies={('tmdb', '10'): make_movie(1, 10, 1)})
        result = eng._local_downgrade_push()
        self.assertEqual(result, {'status': 'ok', 'pushed': 0,
                                  'baseline': True})
        self.assertEqual(api.remove_calls, [])
        stored = eng.cache.get('local_watched')
        self.assertEqual(stored['movies'], ['1'])

    def test_fresh_kodi_never_wipes_remote_history(self):
        # new Kodi, everything unwatched locally, MDBList has history:
        # no baseline yet -> nothing is pushed even though remote is watched
        api = FakeApi(watched={'movies': [remote_movie(10), remote_movie(20)]})
        movies = {('tmdb', '10'): make_movie(1, 10, 0),
                  ('tmdb', '20'): make_movie(2, 20, 0)}
        eng = make_engine(api, movies=movies)
        result = eng._local_downgrade_push()
        self.assertTrue(result['baseline'])
        self.assertEqual(api.remove_calls, [])
        self.assertEqual(set(eng.cache.get('local_watched')['movies']),
                         set())  # nothing watched locally -> empty baseline

    def test_downgrade_pushes_removal_and_updates_baseline(self):
        api = FakeApi(watched={'movies': [remote_movie(10), remote_movie(20)]})
        movies = {('tmdb', '10'): make_movie(1, 10, 0),   # reset by user
                  ('tmdb', '20'): make_movie(2, 20, 1)}   # still watched
        eng = make_engine(
            api, movies=movies,
            snapshot=baseline(watched_movie_ids=['1', '2']))
        result = eng._local_downgrade_push()
        self.assertEqual(result, {'status': 'ok', 'pushed': 1})
        self.assertEqual(len(api.remove_calls), 1)
        self.assertEqual(api.remove_calls[0]['movies'],
                         [{'ids': {'tmdb': 10}}])
        self.assertIsNone(eng.cache.get('sync_watched'))  # invalidated
        self.assertEqual(eng.cache.get('local_watched')['movies'], ['2'])
        self.assertIn(('tmdb', '10'), eng._downgrade_skip['movies'])

    def test_items_not_in_baseline_are_not_pushed(self):
        # movie 2 was never watched locally: unwatched here AND unwatched
        # on MDBList -> nothing to remove (fresh/add-only library content)
        api = FakeApi(watched={'movies': [remote_movie(10)]})
        movies = {('tmdb', '10'): make_movie(1, 10, 1),
                  ('tmdb', '20'): make_movie(2, 20, 0)}
        eng = make_engine(api, movies=movies,
                          snapshot=baseline(watched_movie_ids=['1']))
        result = eng._local_downgrade_push()
        self.assertEqual(result, {'status': 'ok', 'pushed': 0})
        self.assertEqual(api.remove_calls, [])

    def test_scan_after_baseline_suppresses_push(self):
        api = FakeApi(watched={'movies': [remote_movie(10)]})
        movies = {('tmdb', '10'): make_movie(1, 10, 0)}
        snapshot = baseline(watched_movie_ids=['1'],
                            updated_at=time.time() - 3600)
        eng = make_engine(api, movies=movies, snapshot=snapshot,
                          library_event=time.time())
        result = eng._local_downgrade_push()
        self.assertTrue(result['baseline'])
        self.assertEqual(api.remove_calls, [])
        # baseline re-stored so a later scan is not compared against the
        # pre-scan state anymore
        self.assertGreater(eng.cache.get('local_watched')['updated_at'],
                           snapshot['updated_at'])

    def test_journal_removals_are_not_pushed_again(self):
        # the item is already marked unwatched on MDBList (journal); the
        # pull downgrades Kodi for those, so the push must not repeat them
        api = FakeApi(
            watched={'movies': []},
            journal={'journal': [{'category': 'watched', 'status': 'removed',
                                  'item_type': 'movie',
                                  'ids': {'tmdb': 10}}],
                     '_complete': True})
        movies = {('tmdb', '10'): make_movie(1, 10, 0)}
        eng = make_engine(api, movies=movies,
                          snapshot=baseline(watched_movie_ids=['1']))
        result = eng._local_downgrade_push()
        self.assertEqual(result, {'status': 'ok', 'pushed': 0})
        self.assertEqual(api.remove_calls, [])

    def test_push_failure_keeps_baseline_for_retry(self):
        api = FakeApi(watched={'movies': [remote_movie(10)]})
        api.fail_remove = True
        movies = {('tmdb', '10'): make_movie(1, 10, 0)}
        eng = make_engine(api, movies=movies,
                          snapshot=baseline(watched_movie_ids=['1']))
        result = eng._local_downgrade_push()
        self.assertEqual(result, {'status': 'error'})
        # snapshot untouched: next run retries the same downgrade
        self.assertEqual(eng.cache.get('local_watched')['movies'], ['1'])

    def test_episode_downgrade_uses_flat_episode_ids(self):
        api = FakeApi(watched={'shows': [remote_show(5, 1, 1),
                                         remote_show(5, 1, 2)]})
        show_map = {('tmdb', '5'): {'tvshowid': 1, 'ids': {'tmdb': 5}}}
        episodes = {1: {(1, 1): make_episode(11, 1, 1, 1, 101, 0),
                        (1, 2): make_episode(12, 1, 1, 2, 102, 1)}}
        eng = make_engine(api, show_map=show_map, episodes_by_show=episodes,
                          snapshot=baseline(watched_episode_ids=['11', '12']))
        result = eng._local_downgrade_push()
        self.assertEqual(result, {'status': 'ok', 'pushed': 1})
        self.assertEqual(api.remove_calls[0]['episodes'],
                         [{'ids': {'tmdb': 101}}])
        self.assertEqual(eng.cache.get('local_watched')['episodes'], ['12'])
        self.assertIn(('tmdb', '5'), eng._downgrade_skip['episodes'])
        self.assertIn((1, 1), eng._downgrade_skip['episodes'][('tmdb', '5')])


class RewatchAfterRemovalTests(unittest.TestCase):
    """A local re-watch newer than our own downgrade-push removal must beat
    the journal row that removal created: the pull keeps it, the push
    re-uploads it. The journal row itself only survives because we created
    it - it is not a user decision."""

    @staticmethod
    def _seed_removals(eng, movies=(), episodes=(), removed_at=None):
        """Record our own removals; default timestamp is 1 day ago."""
        if removed_at is None:
            removed_at = time.time() - 86400
        eng.cache.set('local_removals', {
            'movies': dict(movies), 'episodes': dict(episodes),
            'updated_at': removed_at})
        eng._local_removals_cache = None

    def test_downgrade_push_records_removals(self):
        api = FakeApi(watched={'movies': [remote_movie(10)],
                               'shows': [remote_show(5, 1, 1)]})
        movies = {('tmdb', '10'): make_movie(1, 10, 0)}
        show_map = {('tmdb', '5'): {'tvshowid': 1, 'ids': {'tmdb': 5}}}
        episodes = {1: {(1, 1): make_episode(11, 1, 1, 1, 101, 0)}}
        eng = make_engine(api, movies=movies, show_map=show_map,
                          episodes_by_show=episodes,
                          snapshot=baseline(watched_movie_ids=['1'],
                                            watched_episode_ids=['11']))
        result = eng._local_downgrade_push()
        self.assertEqual(result['pushed'], 2)
        record = eng.cache.get('local_removals')
        self.assertIn('tmdb:10', record['movies'])
        self.assertIn('tmdb:5:1:1', record['episodes'])

    def test_pull_keeps_movie_rewatched_after_our_removal(self):
        api = FakeApi(
            watched={'movies': []},
            journal={'journal': [{'category': 'watched', 'status': 'removed',
                                  'item_type': 'movie',
                                  'ids': {'tmdb': 10}}],
                     '_complete': True})
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        movies[('tmdb', '10')]['lastplayed'] = \
            time.strftime('%Y-%m-%d %H:%M:%S')
        eng = make_engine(api, movies=movies)
        self._seed_removals(eng, movies={'tmdb:10': time.time() - 86400})

        calls = []
        original_jsonrpc = engine_mod.jsonrpc

        def fake_jsonrpc(method, params=None):
            calls.append((method, params))
            return {'result': {'modified': True}}

        engine_mod.jsonrpc = fake_jsonrpc
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original_jsonrpc
        self.assertEqual(pull.get('local_rewatch_kept'), 1)
        self.assertEqual(pull['unwatched_movies'], 0)
        self.assertEqual(calls, [])  # no stomp
        self.assertEqual(movies[('tmdb', '10')]['playcount'], 1)

    def test_pull_still_stomps_when_rewatch_older_than_removal(self):
        # the removal by us is NEWER than the local watch: not a re-watch,
        # the journal stomp stays
        api = FakeApi(
            watched={'movies': []},
            journal={'journal': [{'category': 'watched', 'status': 'removed',
                                  'item_type': 'movie',
                                  'ids': {'tmdb': 10}}],
                     '_complete': True})
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}  # lastplayed 2024
        eng = make_engine(api, movies=movies)
        self._seed_removals(eng, movies={'tmdb:10': time.time() + 3600},
                            removed_at=time.time() + 3600)

        calls = []
        original_jsonrpc = engine_mod.jsonrpc

        def fake_jsonrpc(method, params=None):
            calls.append((method, params))
            return {'result': {'modified': True}}

        engine_mod.jsonrpc = fake_jsonrpc
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original_jsonrpc
        self.assertEqual(pull['unwatched_movies'], 1)
        self.assertEqual(len(calls), 1)
        self.assertEqual(movies[('tmdb', '10')]['playcount'], 0)

    def test_pull_without_removal_record_still_stomps(self):
        # web-side unwatch (no record of ours): unchanged behaviour
        api = FakeApi(
            watched={'movies': []},
            journal={'journal': [{'category': 'watched', 'status': 'removed',
                                  'item_type': 'movie',
                                  'ids': {'tmdb': 10}}],
                     '_complete': True})
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        eng = make_engine(api, movies=movies)
        original_jsonrpc = engine_mod.jsonrpc
        engine_mod.jsonrpc = lambda m, p=None: {'result': {'modified': True}}
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original_jsonrpc
        self.assertEqual(pull['unwatched_movies'], 1)

    def test_episode_pull_keeps_rewatch_after_our_removal(self):
        api = FakeApi(
            watched={'shows': []},
            journal={'journal': [{'category': 'watched', 'status': 'removed',
                                  'item_type': 'show',
                                  'ids': {'tmdb': 5},
                                  'season': 1, 'episode': 1}],
                     '_complete': True})
        show_map = {('tmdb', '5'): {'tvshowid': 1, 'ids': {'tmdb': 5}}}
        ep = make_episode(11, 1, 1, 1, 101, 1)
        ep['lastplayed'] = time.strftime('%Y-%m-%d %H:%M:%S')
        episodes = {1: {(1, 1): ep}}
        eng = make_engine(api, show_map=show_map, episodes_by_show=episodes)
        self._seed_removals(eng, episodes={'tmdb:5:1:1': time.time() - 86400})

        calls = []
        original_jsonrpc = engine_mod.jsonrpc

        def fake_jsonrpc(method, params=None):
            calls.append((method, params))
            return {'result': {'modified': True}}

        engine_mod.jsonrpc = fake_jsonrpc
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original_jsonrpc
        self.assertEqual(pull.get('local_rewatch_kept'), 1)
        self.assertEqual(pull['unwatched_episodes'], 0)
        self.assertEqual(calls, [])

    def test_push_reuploads_movie_rewatched_after_removal(self):
        api = FakeApi(
            watched={'movies': []},
            journal={'journal': [{'category': 'watched', 'status': 'removed',
                                  'item_type': 'movie',
                                  'ids': {'tmdb': 10}}],
                     '_complete': True})
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        movies[('tmdb', '10')]['lastplayed'] = \
            time.strftime('%Y-%m-%d %H:%M:%S')
        eng = make_engine(api, movies=movies)
        self._seed_removals(eng, movies={'tmdb:10': time.time() - 86400})
        result = eng._watched_push()
        self.assertEqual(result['pushed'], 1)
        pushed = api.push_calls[0]['movies']
        self.assertEqual(len(pushed), 1)
        self.assertEqual(pushed[0]['ids'], {'tmdb': 10})

    def test_push_still_skips_when_no_rewatch_record(self):
        api = FakeApi(
            watched={'movies': []},
            journal={'journal': [{'category': 'watched', 'status': 'removed',
                                  'item_type': 'movie',
                                  'ids': {'tmdb': 10}}],
                     '_complete': True})
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        eng = make_engine(api, movies=movies)
        result = eng._watched_push()
        self.assertEqual(result, {'status': 'ok', 'pushed': 0})
        self.assertEqual(api.push_calls, [])

    def test_push_reuploads_episode_rewatched_after_removal(self):
        api = FakeApi(
            watched={'shows': []},
            journal={'journal': [{'category': 'watched', 'status': 'removed',
                                  'item_type': 'show',
                                  'ids': {'tmdb': 5},
                                  'season': 1, 'episode': 1}],
                     '_complete': True})
        show_map = {('tmdb', '5'): {'tvshowid': 1, 'ids': {'tmdb': 5}}}
        ep = make_episode(11, 1, 1, 1, 101, 1)
        ep['lastplayed'] = time.strftime('%Y-%m-%d %H:%M:%S')
        episodes = {1: {(1, 1): ep}}
        eng = make_engine(api, show_map=show_map, episodes_by_show=episodes)
        self._seed_removals(eng, episodes={'tmdb:5:1:1': time.time() - 86400})
        result = eng._watched_push()
        self.assertEqual(result['pushed'], 1)
        pushed = api.push_calls[0]['episodes']
        self.assertEqual(len(pushed), 1)
        self.assertEqual(pushed[0]['ids'], {'tmdb': 101})

    def test_rewatch_without_lastplayed_is_not_protected(self):
        # no parseable lastplayed -> comparison impossible, journal wins
        api = FakeApi(
            watched={'movies': []},
            journal={'journal': [{'category': 'watched', 'status': 'removed',
                                  'item_type': 'movie',
                                  'ids': {'tmdb': 10}}],
                     '_complete': True})
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        movies[('tmdb', '10')]['lastplayed'] = None
        eng = make_engine(api, movies=movies)
        self._seed_removals(eng, movies={'tmdb:10': time.time() - 86400})
        original_jsonrpc = engine_mod.jsonrpc
        engine_mod.jsonrpc = lambda m, p=None: {'result': {'modified': True}}
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original_jsonrpc
        self.assertEqual(pull['unwatched_movies'], 1)


def iso_utc(epoch):
    """Journal-style action_at value ('...T...HH:MM:SS.000Z') for an epoch."""
    return time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime(epoch))


class ActionAtRewatchTests(unittest.TestCase):
    """v0.6.2: the journal row's own action_at decides rewatch vs stomp.

    The 0.6.1 record fallback only covers removals this install pushed
    itself; rows written before the record existed (or by another client)
    carried no usable timestamp and stomped every local re-watch. The
    journal's action_at is the server-side time of the removal, so the
    guard now compares watch time against it directly - the record stays
    only as a fallback for rows without a parseable action_at."""

    @staticmethod
    def _journal(*rows):
        return {'journal': [dict(r, category='watched', status='removed')
                            for r in rows], '_complete': True}

    @staticmethod
    def _patch_jsonrpc():
        calls = []
        original = engine_mod.jsonrpc

        def fake_jsonrpc(method, params=None):
            calls.append((method, params))
            return {'result': {'modified': True}}

        engine_mod.jsonrpc = fake_jsonrpc
        return calls, original

    def test_mapping_returns_action_at_epochs(self):
        from mdblist.api.mapping import watched_removed
        removed = time.time() - 86400
        data = self._journal(
            {'item_type': 'movie', 'ids': {'tmdb': 10},
             'action_at': iso_utc(removed)},
            {'item_type': 'show', 'ids': {'tmdb': 5},
             'action_at': iso_utc(removed)},
            {'item_type': 'episode', 'ids': {'tmdb': 5}, 'season': 1,
             'episode': 2, 'action_at': iso_utc(removed)})
        movies, shows, episodes = watched_removed(data)
        self.assertAlmostEqual(movies[('tmdb', '10')], removed, delta=1)
        self.assertAlmostEqual(shows[('tmdb', '5')], removed, delta=1)
        self.assertAlmostEqual(
            episodes[('tmdb', '5')][(1, 2)], removed, delta=1)

    def test_mapping_keeps_newest_row_per_key(self):
        from mdblist.api.mapping import watched_removed
        old = time.time() - 7200
        new = time.time() - 3600
        data = self._journal(
            {'item_type': 'movie', 'ids': {'tmdb': 10},
             'action_at': iso_utc(old)},
            {'item_type': 'movie', 'ids': {'tmdb': 10},
             'action_at': iso_utc(new)},
            # unparseable/missing action_at must not clobber a real ts
            {'item_type': 'movie', 'ids': {'tmdb': 10}})
        movies, _, _ = watched_removed(data)
        self.assertAlmostEqual(movies[('tmdb', '10')], new, delta=1)
        # the older row must not win
        self.assertGreater(movies[('tmdb', '10')], old)

    def test_mapping_row_without_action_at_is_none(self):
        from mdblist.api.mapping import watched_removed
        data = self._journal(
            {'item_type': 'movie', 'ids': {'tmdb': 10}})
        movies, _, _ = watched_removed(data)
        self.assertIn(('tmdb', '10'), movies)
        self.assertIsNone(movies[('tmdb', '10')])

    def test_iso_to_datetime_parses_journal_fraction(self):
        from mdblist.utils import iso_to_datetime
        dt = iso_to_datetime('2026-10-18T14:17:24.000Z')
        self.assertIsNotNone(dt)
        self.assertEqual(dt.year, 2026)
        self.assertEqual(dt.hour, 14)
        # and without fraction, still fine
        self.assertIsNotNone(iso_to_datetime('2026-10-18T14:17:24Z'))

    def test_pull_keeps_rewatch_via_action_at_without_record(self):
        # the 0.6.1 field bug: journal row with action_at, no local record
        # (reset done before the upgrade / from another client)
        removed = time.time() - 86400
        api = FakeApi(
            watched={'movies': []},
            journal=self._journal(
                {'item_type': 'movie', 'ids': {'tmdb': 10},
                 'action_at': iso_utc(removed)}))
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        movies[('tmdb', '10')]['lastplayed'] = \
            time.strftime('%Y-%m-%d %H:%M:%S')  # now > removed
        eng = make_engine(api, movies=movies)
        calls, original = self._patch_jsonrpc()
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original
        self.assertEqual(pull.get('local_rewatch_kept'), 1)
        self.assertEqual(pull['unwatched_movies'], 0)
        self.assertEqual(calls, [])
        self.assertEqual(movies[('tmdb', '10')]['playcount'], 1)

    def test_pull_still_stomps_when_action_at_newer_than_watch(self):
        # web-side unwatch AFTER the local watch: removal wins, no record
        removed = time.time() + 3600
        api = FakeApi(
            watched={'movies': []},
            journal=self._journal(
                {'item_type': 'movie', 'ids': {'tmdb': 10},
                 'action_at': iso_utc(removed)}))
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}  # lastplayed 2024
        eng = make_engine(api, movies=movies)
        calls, original = self._patch_jsonrpc()
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original
        self.assertEqual(pull['unwatched_movies'], 1)
        self.assertEqual(len(calls), 1)
        self.assertEqual(movies[('tmdb', '10')]['playcount'], 0)

    def test_episode_pull_uses_show_row_action_at(self):
        # show-level removal row with action_at covers the episode below it
        removed = time.time() - 86400
        api = FakeApi(
            watched={'shows': []},
            journal=self._journal(
                {'item_type': 'show', 'ids': {'tmdb': 5},
                 'action_at': iso_utc(removed)}))
        show_map = {('tmdb', '5'): {'tvshowid': 1, 'ids': {'tmdb': 5}}}
        ep = make_episode(11, 1, 1, 1, 101, 1)
        ep['lastplayed'] = time.strftime('%Y-%m-%d %H:%M:%S')
        episodes = {1: {(1, 1): ep}}
        eng = make_engine(api, show_map=show_map, episodes_by_show=episodes)
        calls, original = self._patch_jsonrpc()
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original
        self.assertEqual(pull.get('local_rewatch_kept'), 1)
        self.assertEqual(pull['unwatched_episodes'], 0)
        self.assertEqual(calls, [])

    def test_episode_pull_uses_newest_row_when_show_and_episode_match(self):
        # show row is NEWER than the local watch, episode row is older:
        # the newest removal action wins -> stomp stays
        api = FakeApi(
            watched={'shows': []},
            journal=self._journal(
                {'item_type': 'episode', 'ids': {'tmdb': 5}, 'season': 1,
                 'episode': 1, 'action_at': iso_utc(time.time() - 7200)},
                {'item_type': 'show', 'ids': {'tmdb': 5},
                 'action_at': iso_utc(time.time() + 3600)}))
        show_map = {('tmdb', '5'): {'tvshowid': 1, 'ids': {'tmdb': 5}}}
        ep = make_episode(11, 1, 1, 1, 101, 1)
        ep['lastplayed'] = time.strftime('%Y-%m-%d %H:%M:%S')
        episodes = {1: {(1, 1): ep}}
        eng = make_engine(api, show_map=show_map, episodes_by_show=episodes)
        calls, original = self._patch_jsonrpc()
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original
        self.assertEqual(pull['unwatched_episodes'], 1)
        self.assertEqual(len(calls), 1)
        self.assertEqual(ep['playcount'], 0)

    def test_push_reuploads_rewatch_via_action_at_without_record(self):
        removed = time.time() - 86400
        api = FakeApi(
            watched={'movies': []},
            journal=self._journal(
                {'item_type': 'movie', 'ids': {'tmdb': 10},
                 'action_at': iso_utc(removed)}))
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        movies[('tmdb', '10')]['lastplayed'] = \
            time.strftime('%Y-%m-%d %H:%M:%S')
        eng = make_engine(api, movies=movies)
        result = eng._watched_push()
        self.assertEqual(result['pushed'], 1)
        pushed = api.push_calls[0]['movies']
        self.assertEqual(pushed[0]['ids'], {'tmdb': 10})
        self.assertIn('watched_at', pushed[0])

    def test_push_skips_when_action_at_newer_than_watch(self):
        removed = time.time() + 3600
        api = FakeApi(
            watched={'movies': []},
            journal=self._journal(
                {'item_type': 'movie', 'ids': {'tmdb': 10},
                 'action_at': iso_utc(removed)}))
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        eng = make_engine(api, movies=movies)
        result = eng._watched_push()
        self.assertEqual(result, {'status': 'ok', 'pushed': 0})
        self.assertEqual(api.push_calls, [])

    def test_rewatch_without_lastplayed_still_stomps(self):
        # no parseable lastplayed -> comparison impossible, journal wins
        removed = time.time() - 86400
        api = FakeApi(
            watched={'movies': []},
            journal=self._journal(
                {'item_type': 'movie', 'ids': {'tmdb': 10},
                 'action_at': iso_utc(removed)}))
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        movies[('tmdb', '10')]['lastplayed'] = None
        eng = make_engine(api, movies=movies)
        calls, original = self._patch_jsonrpc()
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original
        self.assertEqual(pull['unwatched_movies'], 1)

    def test_record_still_fallback_when_action_at_missing(self):
        # rows without action_at fall back to the local record (0.6.1)
        api = FakeApi(
            watched={'movies': []},
            journal=self._journal(
                {'item_type': 'movie', 'ids': {'tmdb': 10}}))
        movies = {('tmdb', '10'): make_movie(1, 10, 1)}
        movies[('tmdb', '10')]['lastplayed'] = \
            time.strftime('%Y-%m-%d %H:%M:%S')
        eng = make_engine(api, movies=movies)
        eng.cache.set('local_removals', {
            'movies': {'tmdb:10': time.time() - 86400},
            'episodes': {}, 'updated_at': time.time() - 86400})
        eng._local_removals_cache = None
        calls, original = self._patch_jsonrpc()
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original
        self.assertEqual(pull.get('local_rewatch_kept'), 1)
        self.assertEqual(calls, [])


class PullSkipsDowngradedItemsTests(unittest.TestCase):

    def test_pull_does_not_reapply_just_removed_items(self):
        # MDBList still lists the reset movie as watched (stale snapshot);
        # the pull must not stomp the reset, while other items still upgrade
        api = FakeApi(watched={'movies': [remote_movie(10), remote_movie(30)]})
        movies = {('tmdb', '10'): make_movie(1, 10, 0),   # just reset
                  ('tmdb', '30'): make_movie(3, 30, 0)}   # should upgrade
        eng = make_engine(api, movies=movies,
                          snapshot=baseline(watched_movie_ids=['1']))
        downgrade = eng._local_downgrade_push()
        self.assertEqual(downgrade['pushed'], 1)

        calls = []
        original_jsonrpc = engine_mod.jsonrpc

        def fake_jsonrpc(method, params=None):
            calls.append((method, params))
            return {'result': {'modified': True}}

        engine_mod.jsonrpc = fake_jsonrpc
        try:
            pull = eng._watched_pull()
        finally:
            engine_mod.jsonrpc = original_jsonrpc
        self.assertEqual(pull['movies'], 1)  # only movie 3 upgraded
        upgraded = [params['movieid'] for method, params in calls
                    if method == 'VideoLibrary.SetMovieDetails']
        self.assertEqual(upgraded, [3])
        self.assertEqual(movies[('tmdb', '10')]['playcount'], 0)

    def test_resume_pull_skips_downgraded_items(self):
        api = FakeApi(watched={'movies': [remote_movie(10)]})
        movies = {('tmdb', '10'): make_movie(1, 10, 0)}
        eng = make_engine(api, movies=movies,
                          snapshot=baseline(watched_movie_ids=['1']))
        self.assertEqual(eng._local_downgrade_push()['pushed'], 1)
        # inject a fake session matching the downgraded movie
        session = {'kind': 'movie', 'ids': {'tmdb': 10}, 'progress': 50.0,
                   'runtime': 120, 'session_id': 'x', 'updated_at': None,
                   'expires_at': None}
        eng.api.get_playback_sessions = lambda: []
        original_sessions = engine_mod.mapping.playback_sessions
        engine_mod.mapping.playback_sessions = lambda payload: [session]
        try:
            result = eng._resume_pull(force=True)
        finally:
            engine_mod.mapping.playback_sessions = original_sessions
        self.assertEqual(result['movies'], 0)
        self.assertEqual(movies[('tmdb', '10')].get('resume'), False)


class ServiceLibraryEventTests(unittest.TestCase):

    def test_scan_and_clean_stamp_library_event(self):
        from mdblist.cache import get_cache
        from mdblist import service as service_mod
        svc = object.__new__(service_mod.MDbListService)
        svc._pending_sync = False
        cache = get_cache()
        cache.delete('library_event')
        svc.onNotification(None, 'VideoLibrary.OnScanFinished', '{}')
        self.assertIsNotNone(cache.get('library_event'))
        cache.delete('library_event')
        svc.onNotification(None, 'VideoLibrary.OnCleanFinished', '{}')
        self.assertIsNotNone(cache.get('library_event'))
        self.assertFalse(svc._pending_sync)  # sync_on_update off in tests


if __name__ == '__main__':
    unittest.main()
