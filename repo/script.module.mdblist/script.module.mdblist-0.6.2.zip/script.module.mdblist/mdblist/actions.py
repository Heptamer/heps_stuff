# -*- coding: utf-8 -*-
"""RunScript action dispatcher.

Actions (RunScript(script.module.mdblist, key=value, ...)):
    contextmenu                     open the MDBList action dialog
    sync                            manual full sync
    rate[, type=][, id=][, rating=] rate item on MDBList (dialog when rating missing)
    unrate                          remove remote rating
    togglewatched                   toggle remote watched state
    markwatched / markunwatched     explicit watched state changes
    repair_watched_dates[, limit=]  one-off: rewrite watch dates that older
                                    versions replaced with the sync time
    clearprogress[, type=][, id=]   delete the continue-watching entry of an
                                    item, or of the whole account when no
                                    item is given (with confirmation)
    addtowatchlist                  add to watchlist
    removefromwatchlist             remove from watchlist
    auth_info                       show account info

Item identification: id=tmdb:12345 | imdb:tt0117731 (type=movie|show).
When omitted, the currently playing item is used.
"""
import threading
import traceback

import xbmc
import xbmcgui

from .logger import log_debug, log_error
from .utils import has_api_key, localized, notify, parse_id

MANUAL_SYNC_WAIT = 45  # seconds to wait for a running sync to finish


def parse_args(argv):
    args = {}
    for raw in argv[1:]:
        if '=' not in raw:
            continue
        key, _, value = raw.partition('=')
        args[key.strip().lower()] = value.strip()
    return args


def run():
    args = parse_args(list(sys_argv()))
    action = (args.get('action') or 'contextmenu').lower()
    safe_args = {k: ('***' if k == 'api_key' else v) for k, v in args.items()}
    log_debug(f'Action requested: {action} {safe_args}')
    try:
        handler = HANDLERS.get(action)
        if handler is None:
            notify(localized(32123) or 'Unknown action')
            return
        handler(args)
    except Exception as exc:
        log_error(f'Action {action} failed: {exc}\n{traceback.format_exc()}')
        notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR)


def sys_argv():
    import sys
    return list(sys.argv)


# ---------------------------------------------------------------------- #
# helpers                                                                #
# ---------------------------------------------------------------------- #

class MediaRef(object):
    """Identifies a movie or show via provider id."""

    def __init__(self, mediatype=None, provider=None, media_id=None,
                 season=None, episode=None):
        self.mediatype = mediatype
        self.provider = provider
        self.media_id = media_id
        self.season = season
        self.episode = episode

    @property
    def valid(self):
        return bool(self.provider and self.media_id and
                    self.mediatype in ('movie', 'show'))

    def ids_dict(self):
        return {self.provider: self.media_id}


def resolve_media(args):
    """Build a MediaRef from script arguments, falling back to the playing item."""
    ref = MediaRef()
    id_value = args.get('id')
    if id_value:
        ref.provider, ref.media_id = parse_id(id_value)
        mediatype = (args.get('type') or '').lower()
        if mediatype in ('movie', 'show', 'tvshow'):
            ref.mediatype = 'show' if mediatype == 'tvshow' else mediatype
        else:
            # guess by id shape: tt... -> movie is a bad guess; require type
            ref.mediatype = 'movie' if ref.provider == 'tmdb' else None
    if ref.provider and ref.media_id:
        if ref.valid:
            return ref
        # provider+id known but mediatype missing/invalid – try playing item
        player_item = from_playing_item()
        if player_item:
            return player_item
        return None
    player_item = from_playing_item()
    if player_item:
        return player_item
    return None


def from_playing_item():
    """Identify the playing item via the shared identification chain.

    Uses every source Kodi exposes (ListItem, InfoLabels, library, title
    search) so context menu actions work for plugin playback too."""
    try:
        if not xbmc.Player().isPlayingVideo():
            return None
    except RuntimeError:
        return None
    from .identify import identify
    api = None
    cache = None
    if has_api_key():
        from . import get_api
        from .cache import get_cache
        api = get_api(cache=False)
        cache = get_cache()
    info = identify(api=api, cache=cache)
    if info is None or not info.provider or not info.media_id:
        return None
    ref = MediaRef(mediatype='movie' if info.mediatype == 'movie' else 'show',
                   provider=info.provider, media_id=info.media_id)
    return ref if ref.valid else None


def ensure_api(silent=False):
    if not has_api_key():
        if not silent:
            notify(localized(32108) or 'No API key configured.',
                   icon=xbmcgui.NOTIFICATION_WARNING)
        return None
    from . import get_api
    return get_api(cache=False)


# ---------------------------------------------------------------------- #
# actions                                                                #
# ---------------------------------------------------------------------- #

def action_contextmenu(args):
    from .gui.contextmenu import ContextMenu
    ContextMenu().open()


def action_sync(args):
    silent = str(args.get('silent', 'true')).lower() != 'false'
    if not silent:
        notify(localized(32111) or 'Sync started')
    from .sync.engine import SyncEngine

    def _worker():
        try:
            # the engine takes the lock itself; wait out a running sync
            summary = SyncEngine(api=ensure_api(silent=True)).run(
                force=True, wait_seconds=MANUAL_SYNC_WAIT)
        except Exception as exc:
            log_error(f'Manual sync failed: {exc}')
            notify(localized(32125) or 'Sync failed',
                   icon=xbmcgui.NOTIFICATION_ERROR)
            return
        if summary.get('skipped'):
            log_debug(f'Manual sync skipped after {MANUAL_SYNC_WAIT}s: '
                      'another sync is running')
            notify(localized(32113) or 'A sync is already running')
            return
        log_debug(f'Manual sync result: {summary}')
        notify(localized(32112) or 'Sync finished')

    threading.Thread(target=_worker, daemon=True).start()


def action_repair_watched_dates(args):
    """One-off repair of watch dates overwritten by versions up to 0.1.5.

    Those versions pushed watched items without a watched_at, so the server
    stamped the time of the sync run. This rewrites every affected entry
    with Kodi's own lastplayed date. Manual only – never runs on a timer.
    """
    api = ensure_api()
    if api is None:
        return
    try:
        limit = int(args.get('limit') or 0) or None
    except ValueError:
        limit = None

    from .sync.engine import SyncEngine
    engine = SyncEngine(api=api)
    plan = engine.plan_watched_date_repair(limit=limit)
    if plan is None:
        notify(localized(32125) or 'Sync failed',
               icon=xbmcgui.NOTIFICATION_ERROR)
        return
    total = len(plan['movies']) + len(plan['episodes'])
    if not total:
        notify(localized(32135) or 'No watch dates need repairing')
        return

    heading = localized(32100) or 'MDBList'
    question = localized(32136) or (
        'Rewrite the watch dates of {0} movies and {1} episodes '
        'with the dates from the Kodi library?')
    if not xbmcgui.Dialog().yesno(heading, question.format(
            len(plan['movies']), len(plan['episodes']))):
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create(heading, localized(32137) or 'Repairing watch dates')

    def _progress(done, steps):
        if dialog.iscanceled():
            return False
        dialog.update(int(done * 100 / steps) if steps else 100)
        return True

    try:
        result = engine.apply_watched_date_repair(plan, progress=_progress)
    finally:
        dialog.close()
    if result.get('status') == 'error':
        notify(localized(32125) or 'Sync failed',
               icon=xbmcgui.NOTIFICATION_ERROR)
        return
    log_debug(f'Watch date repair result: {result}')
    notify((localized(32138) or 'Watch dates repaired: {0}').format(
        result.get('repaired', 0)))


def action_rate(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    rating = args.get('rating')
    if rating in (None, ''):
        from .gui.rateprompt import pick_rating
        rating = pick_rating(getattr(ref, 'title', '') or '')
    if rating is None:
        return
    try:
        rating = int(float(rating))
    except (TypeError, ValueError):
        return
    if not 1 <= rating <= 10:
        notify('1-10', icon=xbmcgui.NOTIFICATION_WARNING)
        return
    api.push_ratings([{'type': ref.mediatype, 'ids': ref.ids_dict(),
                       'rating': rating}])
    notify(localized(32115) or 'Rating saved')


def action_unrate(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    api.remove_ratings([{'type': ref.mediatype, 'ids': ref.ids_dict()}])
    notify(localized(32116) or 'Rating removed')


def action_togglewatched(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    state = api.get_item_state(ref.media_id, ref.mediatype, ref.provider) or {}
    watched = bool(state.get('watched')) if isinstance(state, dict) else False
    if watched:
        action_markunwatched(args)
    else:
        action_markwatched(args)


def action_markwatched(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        return
    payload = {'movies': [ref.ids_dict()]} if ref.mediatype == 'movie' \
        else {'shows': [ref.ids_dict()]}
    api.push_watched(**payload)
    notify(localized(32114) or 'Watched state updated')


def action_markunwatched(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        return
    payload = {'movies': [ref.ids_dict()]} if ref.mediatype == 'movie' \
        else {'shows': [ref.ids_dict()]}
    api.remove_watched(**payload)
    notify(localized(32114) or 'Watched state updated')


def action_addtowatchlist(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    payload = {'movies': [ref.ids_dict()]} if ref.mediatype == 'movie' \
        else {'shows': [ref.ids_dict()]}
    if ref.mediatype == 'movie':
        api.add_watchlist_items(movies=payload['movies'])
    else:
        api.add_watchlist_items(shows=payload['shows'])
    notify(localized(32117) or 'Added to watchlist')


def action_removefromwatchlist(args):
    api = ensure_api()
    ref = resolve_media(args)
    if api is None or ref is None:
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    if ref.mediatype == 'movie':
        api.remove_watchlist_items(movies=[ref.ids_dict()])
    else:
        api.remove_watchlist_items(shows=[ref.ids_dict()])
    notify(localized(32118) or 'Removed from watchlist')


def action_clearprogress(args):
    """Delete paused playback sessions ("continue where you left off").

    Two forms:
    - with type= and id=, or while an item is playing: clears that item only.
    - without any item: clears every session of the account, which also
      removes the continue-watching entries on all other devices. Guarded by
      a confirmation dialog for that reason.
    """
    api = ensure_api()
    if api is None:
        return
    ref = resolve_media(args)
    if ref is None and args.get('id'):
        notify(localized(32119) or 'Could not identify item',
               icon=xbmcgui.NOTIFICATION_WARNING)
        return
    if ref is None:
        heading = localized(32100) or 'MDBList'
        question = localized(32143) or (
            'Remove all continue-watching entries from MDBList? '
            'This affects every device of your account.')
        if not xbmcgui.Dialog().yesno(heading, question):
            return
    try:
        api.clear_progress(movie=ref.ids_dict() if ref and
                           ref.mediatype == 'movie' else None,
                           show=ref.ids_dict() if ref and
                           ref.mediatype == 'show' else None)
    except Exception as exc:
        log_error(f'clearprogress failed: {exc}')
        notify(localized(32125) or 'Sync failed',
               icon=xbmcgui.NOTIFICATION_ERROR)
        return
    if ref is not None:
        # drop our own session record too, otherwise the sync keeps treating
        # the item as "pushed here" and would ignore the position another
        # device sets next
        from . import resume
        resume.clear_any(resume.keys('movie' if ref.mediatype == 'movie'
                                     else 'episode',
                                     ref.ids_dict()))
    notify(localized(32144) or 'Continue-watching cleared on MDBList')


def action_auth_info(args):
    api = ensure_api()
    if api is None:
        return
    try:
        user = api.get_user() or {}
        name = user.get('name') or user.get('username') or '?'
        xbmcgui.Dialog().ok(
            localized(32100) or 'MDBList',
            localized(32121).format(name) if '%s' in (localized(32121) or '')
            else f'{localized(32120)}: {name}')
    except Exception as exc:
        log_error(f'auth_info failed: {exc}')
        xbmcgui.Dialog().ok(localized(32100) or 'MDBList',
                            localized(32122) or 'Not authenticated')


HANDLERS = {
    'contextmenu': action_contextmenu,
    'sync': action_sync,
    'repair_watched_dates': action_repair_watched_dates,
    'clearprogress': action_clearprogress,
    'rate': action_rate,
    'unrate': action_unrate,
    'togglewatched': action_togglewatched,
    'markwatched': action_markwatched,
    'markunwatched': action_markunwatched,
    'addtowatchlist': action_addtowatchlist,
    'removefromwatchlist': action_removefromwatchlist,
    'auth_info': action_auth_info,
}
