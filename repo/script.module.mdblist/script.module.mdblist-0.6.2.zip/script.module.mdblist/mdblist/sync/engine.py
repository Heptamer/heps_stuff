# -*- coding: utf-8 -*-
"""Bidirectional sync between the Kodi library and MDBList.

Directions (each individually switchable in settings):
- watched: pull remote state -> Kodi (upgrades on /sync/watched, downgrades
  on /sync/journal removals), push local playcount -> remote, and report
  local "mark unwatched" resets back to remote via /sync/watched/remove
  (detected through a cached baseline of locally watched ids)
- ratings: pull remote rating -> Kodi userrating, push local userrating -> remote
- progress: pull paused playback sessions (/sync/playback) -> Kodi resume
  points. Pushed by the scrobbler when playback stops, never from here.

Incremental strategy:
- Pulls fetch /sync/last_activities first and are skipped when the relevant
  activity timestamp is unchanged since the last successful sync, except the
  watched pull which always runs so it can act on explicit unwatched removals
  surfaced through the sync journal.
- Pushes compare the local library against the cached remote state
  (long TTL) so local changes never need extra API calls.
"""
from .. import resume
from ..api import mapping
from ..logger import log_debug, log_error
from ..utils import (get_setting, iso_to_datetime, iso_to_kodi, jsonrpc,
                     jsonrpc_paginate, kodi_date_to_iso, notify, localized)
from .lock import SyncLock

try:
    from xbmcgui import NOTIFICATION_ERROR
except ImportError:
    NOTIFICATION_ERROR = 'error'

CACHE_TTL_REMOTE = 6 * 3600
# baseline of locally watched ids used to detect deliberate local
# "mark unwatched" resets (see _local_downgrade_push); long TTL so the
# baseline survives Kodi restarts, just not an absence of months
CACHE_TTL_LOCAL_WATCHED = 90 * 86400
# what the local downgrade push removed on MDBList, per entry with its
# removal time; lets a later local re-watch win over the journal row our
# own removal created (the journal retains removals for 30 days)
CACHE_TTL_LOCAL_REMOVALS = 31 * 86400
# the API rejects the whole request above this many show entries
MAX_SHOWS_PER_REQUEST = 200
# how far a remote watch date may sit from Kodi's play date before the
# repair action treats it as overwritten (seconds)
REPAIR_TOLERANCE = 12 * 3600
# /sync/last_activities fields that change on every request and therefore
# say nothing about remote changes (see _activities_unchanged)
VOLATILE_ACTIVITY_KEYS = frozenset(('server_time',))
# ...fields that move whenever a paused playback session is saved
PROGRESS_ACTIVITY_KEYS = ('paused_at', 'episode_paused_at')
# a remote session closer to the start/end than this (in seconds) is not
# worth a resume point locally - Kodi would offer "continue" for a 3 second
# position or seek into the credits
RESUME_MIN_POSITION = 10
# how many "not listed as watched, no journal removal matched" items to name
# individually before switching to a count (see _watched_pull)
MAX_UNMATCHED_LOG = 10


class SyncEngine(object):

    def __init__(self, api=None):
        from .. import get_api
        self.api = api or get_api()
        from ..cache import get_cache
        self.cache = get_cache()

    # ------------------------------------------------------------------ #
    # orchestration                                                      #
    # ------------------------------------------------------------------ #

    def run(self, force=False, wait_seconds=0):
        """Run all enabled sync parts. Returns a summary dict.

        wait_seconds: how long to wait for the lock when another sync
        is running (manual syncs pass ~45s, service runs don't wait).
        """
        lock = SyncLock('engine')
        acquired = lock.acquire(timeout=wait_seconds)
        try:
            if not acquired:
                log_debug('Sync skipped: another sync is running')
                return {'skipped': True}
            summary = {}
            activities = self._get_activities(force)
            # A local "mark unwatched" must reach MDBList *before* the
            # pull runs, otherwise the pull re-applies the remote watched
            # state and stomps the reset (seen after every Kodi restart).
            if get_setting('enable_sync_watched_push', 'bool'):
                summary['local_downgrade_push'] = \
                    self._local_downgrade_push()
            if get_setting('enable_sync_watched_pull', 'bool'):
                summary['watched_pull'] = self._watched_pull()
            # after the watched pull: an item that was just marked watched
            # must not receive a resume point from its leftover session
            if get_setting('enable_sync_progress_pull', 'bool'):
                summary['progress_pull'] = self._resume_pull(activities,
                                                             force)
            if get_setting('enable_sync_watched_push', 'bool'):
                summary['watched_push'] = self._watched_push()
            if get_setting('enable_sync_collection', 'bool'):
                summary['collection'] = self._collection_push()
            if get_setting('enable_sync_ratings_pull', 'bool'):
                summary['ratings_pull'] = self._ratings_pull(activities, force)
            if get_setting('enable_sync_ratings_push', 'bool'):
                summary['ratings_push'] = self._ratings_push(activities, force)
            # remember the remote state we just processed, so the next run
            # can skip the pulls; storing only on forced runs left the
            # watermark empty forever and re-ran every part every time
            if activities and not self._had_errors(summary):
                self._store_activities(activities)
            return summary
        finally:
            lock.release()

    @staticmethod
    def _had_errors(summary):
        """True when any part failed, so the watermark must not advance."""
        return any(isinstance(part, dict) and
                   part.get('status') in ('error', 'incomplete_snapshot')
                   for part in summary.values())

    def _get_activities(self, force=False):
        try:
            activities = self.api.get_last_activities() or {}
        except Exception as exc:
            log_error(f'last_activities failed: {exc}')
            return None
        if force:
            return activities
        stored = self.cache.get('activities') or {}
        if not stored:
            return activities
        if self._activities_unchanged(stored, activities):
            log_debug('Sync: no remote activity changes')
            return None
        return activities

    @staticmethod
    def _activities_unchanged(stored, activities):
        """True when no watermark field changed since the last sync.

        'server_time' is the request's own clock reading, so it differs on
        every single call. Comparing it would mark every bucket as changed
        and defeat the whole watermark - the pulls below would refetch their
        snapshots (and the rating pull would repush) on every run."""
        keys = (set(stored) | set(activities)) - VOLATILE_ACTIVITY_KEYS
        return all(stored.get(key) == activities.get(key) for key in keys)

    def _store_activities(self, activities):
        if activities:
            self.cache.set('activities', activities, ttl=30 * 86400)

    # ------------------------------------------------------------------ #
    # local library access                                               #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _resume_data(item):
        """{'resume': bool, 'resume_point': {position, total} | None}.

        Kodi returns the 'resume' property as a dict ({} when there is no
        resume point, so the raw value cannot be used as the flag). The
        position is only meaningful with a total - a leftover entry without
        one cannot be turned into a percentage."""
        point = item.get('resume') or {}
        try:
            position = float(point.get('position') or 0)
            total = float(point.get('total') or 0)
        except (TypeError, ValueError):
            position = total = 0.0
        return {'resume': bool(item.get('resume')),
                'resume_point': {'position': position, 'total': total}
                if position > 0 and total > 0 else None}

    def _get_local_movies(self):
        """Returns {canonical_key: {movieid, playcount, ..., ids}}."""
        movies = {}
        for item in jsonrpc_paginate(
                'VideoLibrary.GetMovies', 'movies',
                {'properties': ['playcount', 'lastplayed', 'userrating',
                                'uniqueid', 'resume']}):
            ids = item.get('uniqueid') or {}
            key = self._show_key(ids)
            if key is None:
                continue
            entry = {
                'movieid': item.get('movieid'),
                'playcount': int(item.get('playcount') or 0),
                'lastplayed': item.get('lastplayed'),
                'userrating': int(item.get('userrating') or 0),
                'ids': ids,
            }
            entry.update(self._resume_data(item))
            movies[key] = entry
        return movies

    def _get_tvshow_map(self):
        """Returns {canonical_key: {tvshowid, ids}}."""
        shows = {}
        for show in jsonrpc_paginate(
                'VideoLibrary.GetTvShows', 'tvshows',
                {'properties': ['uniqueid']}):
            ids = show.get('uniqueid') or {}
            key = self._show_key(ids)
            if key:
                shows[key] = {
                    'tvshowid': show.get('tvshowid'),
                    'ids': ids,
                }
        return shows

    def _get_local_episodes(self):
        """Returns ({canonical_key: {tvshowid, ids}}, {tvshowid: {(s,e): ep}}).

        'ids' on an episode holds its own provider ids (tmdb/tvdb episode
        ids), needed to match the flat 'episodes' bucket of /sync/watched,
        whose entries identify episodes directly rather than by number."""
        show_map = self._get_tvshow_map()
        episodes = {}
        for ep in jsonrpc_paginate(
                'VideoLibrary.GetEpisodes', 'episodes',
                {'properties': ['playcount', 'lastplayed', 'userrating',
                                'season', 'episode', 'tvshowid', 'uniqueid',
                                'resume']}):
            tvshowid = ep.get('tvshowid')
            key = (int(ep.get('season') or 0), int(ep.get('episode') or 0))
            episodes.setdefault(tvshowid, {})[key] = {
                'episodeid': ep.get('episodeid'),
                'playcount': int(ep.get('playcount') or 0),
                'lastplayed': ep.get('lastplayed'),
                'userrating': int(ep.get('userrating') or 0),
                'ids': ep.get('uniqueid') or {},
                **self._resume_data(ep),
            }
        return show_map, episodes

    # ------------------------------------------------------------------ #
    # id helpers                                                         #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _show_key(ids):
        """Normalize a provider id dict into a comparable key tuple."""
        for provider in ('tmdb', 'tvdb', 'imdb', 'trakt'):
            value = ids.get(provider)
            if not value:
                continue
            try:
                return (provider, str(int(value)))
            except (TypeError, ValueError):
                return (provider, str(value))
        return None

    @staticmethod
    def _ids_for_push(ids_dict):
        """Extract the best available provider:id pair for API payloads."""
        for provider in ('tmdb', 'tvdb', 'imdb', 'trakt'):
            value = ids_dict.get(provider)
            if value is not None:
                try:
                    return {provider: int(value)}
                except (TypeError, ValueError):
                    return {provider: value}
        return {}

    @staticmethod
    def _keys_from_ids(ids):
        """Yield all canonical keys from a provider ids dict.

        Used to index remote entries by every ID they carry so that a
        local show with tvdb can match a remote entry that only has tmdb.
        """
        for provider in ('tmdb', 'tvdb', 'imdb', 'trakt'):
            value = (ids or {}).get(provider)
            if value is not None:
                try:
                    yield (provider, str(int(value)))
                except (TypeError, ValueError):
                    yield (provider, str(value))

    def _lookup_any(self, index, ids):
        """First index hit for any provider id in ids.

        Both sides must be matched over all their ids: indexing the remote
        entries alone is not enough when the local item carries an extra
        provider the remote entry lacks (local key would be tmdb while the
        remote entry is only known by imdb)."""
        for key in self._keys_from_ids(ids):
            found = index.get(key)
            if found is not None:
                return found
        return None

    def _contains_any(self, keys, ids):
        """True when any provider id in ids is present in a key set."""
        return any(key in keys for key in self._keys_from_ids(ids))

    # ------------------------------------------------------------------ #
    # watched                                                            #
    # ------------------------------------------------------------------ #

    def _remote_watched(self):
        cached = self.cache.get('sync_watched')
        if cached is not None:
            return cached
        data = self.api.get_watched() or {}
        self._log_snapshot('watched', data)
        self.cache.set('sync_watched', data, ttl=CACHE_TTL_REMOTE)
        return data

    @staticmethod
    def _log_snapshot(name, data):
        """Log the parsed bucket sizes of a remote snapshot.

        Makes a future response-shape change visible in the Kodi log: if
        the buckets read as empty while items exist remotely, every local
        item looks unsynced and would be pushed again."""
        counts = ' '.join(
            f'{bucket}={len(data.get(bucket) or [])}'
            for bucket in ('movies', 'shows', 'seasons', 'episodes'))
        pagination = data.get('pagination') or {}
        log_debug(f'Remote {name} snapshot: {counts} '
                  f'total={pagination.get("total")} '
                  f'complete={data.get("_complete")}')

    @staticmethod
    def _snapshot_incomplete(data):
        """Reason string when a snapshot cannot be trusted for a diff.

        Pushing against a partial snapshot marks everything it is missing
        as unsynced, which re-uploads the whole library and overwrites the
        remote timestamps. Skipping the push is the safer choice.

        Only an unfinished pagination run counts as incomplete – it is the
        one signal we can read unambiguously. A parsed/total mismatch is
        merely logged by _log_snapshot, since the exact meaning of the
        server's 'total' across buckets is not guaranteed."""
        if not data.get('_complete', True):
            return 'pagination did not reach the last page'
        return None

    @staticmethod
    def _newer(remote_iso, kodi_value):
        """True when remote timestamp is strictly newer than the kodi value.

        Kodi stores *lastplayed* in the local system time; we detect the
        current UTC offset so both timestamps live in the same frame.
        During DST transitions the offset may be off by ≤1 h – acceptable
        for a tie-breaker comparison."""
        from datetime import datetime, timezone

        from ..utils import iso_to_datetime

        remote_dt = iso_to_datetime(remote_iso)
        if not remote_dt:
            return False
        if not kodi_value:
            return True
        local_tz = datetime.now(timezone.utc).astimezone().tzinfo
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
            try:
                local_dt = datetime.strptime(str(kodi_value), fmt)
            except ValueError:
                continue
            local_dt = local_dt.replace(tzinfo=local_tz)
            return remote_dt > local_dt
        return False

    def _remote_movie_index(self, remote):
        """Remote watched movies keyed by every provider id they carry."""
        index = {}
        for entry in remote.get('movies') or []:
            ids = (mapping.watched_entry_ids(entry).get('ids') or
                   mapping.entry_ids(entry))
            for key in self._keys_from_ids(ids):
                index[key] = entry
        return index

    def _watched_pull(self):
        remote = self._remote_watched()
        incomplete = self._snapshot_incomplete(remote)
        if incomplete:
            log_error(f'Watched pull skipped, remote snapshot unusable: '
                      f'{incomplete}')
            return {'status': 'incomplete_snapshot'}
        changed_movies = changed_episodes = 0
        unwatched_movies = unwatched_episodes = 0
        resume_reset = 0

        # MDBList is authoritative for both directions, but only over items
        # it actually knows about. The watched snapshot upgrades Kodi; a
        # separate journal read provides the precise "explicitly marked
        # unwatched on MDBList" signal for downgrading Kodi items. Items
        # MDBList knows nothing about are left untouched.
        unwatched = self._remote_journal_unwatched()
        # A downgrade needs a journal removal to match against. Without one
        # there is nothing to compare, so per-item "not matched" logging is
        # pure noise - on a large library it repeated for every watched item
        # on every single sync run.
        journal_removals = len(unwatched['movies']) + len(unwatched['shows']) + \
            sum(len(v) for v in unwatched['episodes'].values())
        unmatched_movies = 0

        remote_movies = self._remote_movie_index(remote)

        # Items the local downgrade push just removed on MDBList must not
        # be re-applied from the remote snapshot (which may still be the
        # cached one when that push failed midway).
        downgrade_movies = (getattr(self, '_downgrade_skip', None) or
                            {}).get('movies') or set()

        rewatch_kept = 0
        movies = self._local_movie_cache()
        for local in movies.values():
            if self._any_key_in(downgrade_movies, local['ids']):
                continue
            entry = self._lookup_any(remote_movies, local['ids'])
            if entry is None:
                matched, journal_ts = self._movie_removal_ts(
                    unwatched, local['ids'])
                if matched and (local['playcount'] > 0 or
                                local.get('resume')):
                    removal_ts = self._removal_ts(
                        journal_ts, 'movies', local['ids'])
                    if local['playcount'] > 0 and self._is_rewatch(
                            removal_ts, local.get('lastplayed')):
                        rewatch_kept += 1
                        log_debug(f'Watched pull: local rewatch kept, newer '
                                  f'than removal '
                                  f'ids={self._compact_json(local["ids"])} '
                                  f'lastplayed={local.get("lastplayed")!r} '
                                  f'removed_at={removal_ts}')
                    elif self._set_unwatched(local):
                        unwatched_movies += 1
                        if local.get('resume'):
                            resume_reset += 1
                elif local['playcount'] > 0 or local.get('resume'):
                    unmatched_movies += 1
                    if journal_removals and \
                            unmatched_movies <= MAX_UNMATCHED_LOG:
                        local_keys = sorted(self._keys_from_ids(local['ids']))
                        log_debug(f'Movie downgrade candidate NOT matched: '
                                  f'ids={self._compact_json(local["ids"])} '
                                  f'local_keys={local_keys} '
                                  f'journal_keys={sorted(unwatched["movies"])} '
                                  f'overlap={sorted(set(local_keys) & set(unwatched["movies"]))}')
                continue
            plays = mapping.movie_plays(entry)
            last_at = mapping.watched_timestamp(entry)
            if plays <= 0:
                continue
            if local['playcount'] < plays or (
                    local['playcount'] == plays and
                    self._newer(last_at, local['lastplayed'])):
                params = {'movieid': local['movieid'],
                          'playcount': max(plays, 1)}
                kodi_date = iso_to_kodi(last_at)
                if kodi_date:
                    params['lastplayed'] = kodi_date
                if jsonrpc('VideoLibrary.SetMovieDetails',
                           params).get('result'):
                    changed_movies += 1

        show_map, episodes_by_show = self._get_local_episodes()
        eps_by_show, eps_by_id = mapping.watched_episodes(remote)

        for info in show_map.values():
            remote_eps = self._lookup_any(eps_by_show, info['ids'])
            local_eps = episodes_by_show.get(info['tvshowid'], {})
            for (s_num, e_num), local in local_eps.items():
                if self._episode_downgraded(info['ids'], s_num, e_num):
                    continue
                remote_ep = (remote_eps or {}).get((s_num, e_num)) or \
                    self._remote_episode_by_id(eps_by_id, local)
                if not remote_ep:
                    matched, journal_ts = self._episode_removal_ts(
                        unwatched, info['ids'], s_num, e_num)
                    if matched and (local['playcount'] > 0 or
                                    local.get('resume')):
                        removal_ts = self._removal_ts(
                            journal_ts, 'episodes', info['ids'],
                            s_num, e_num)
                        if local['playcount'] > 0 and self._is_rewatch(
                                removal_ts, local.get('lastplayed')):
                            rewatch_kept += 1
                            log_debug(f'Watched pull: local rewatch kept, '
                                      f'newer than removal show='
                                      f'{self._compact_json(info["ids"])} '
                                      f'season={s_num} episode={e_num} '
                                      f'lastplayed='
                                      f'{local.get("lastplayed")!r} '
                                      f'removed_at={removal_ts}')
                        elif self._set_unwatched(local):
                            unwatched_episodes += 1
                            if local.get('resume'):
                                resume_reset += 1
                    continue
                if local['playcount'] >= remote_ep['plays']:
                    continue
                params = {'episodeid': local['episodeid'],
                          'playcount': max(remote_ep['plays'], 1)}
                kodi_date = iso_to_kodi(remote_ep.get('watched_at'))
                if kodi_date:
                    params['lastplayed'] = kodi_date
                if jsonrpc('VideoLibrary.SetEpisodeDetails',
                           params).get('result'):
                    changed_episodes += 1

        result = {'movies': changed_movies, 'episodes': changed_episodes,
                  'unwatched_movies': unwatched_movies,
                  'unwatched_episodes': unwatched_episodes,
                  'resume_reset': resume_reset}
        if rewatch_kept:
            result['local_rewatch_kept'] = rewatch_kept
        if unmatched_movies:
            result['unlisted_movies'] = unmatched_movies
            if journal_removals and unmatched_movies > MAX_UNMATCHED_LOG:
                log_debug(f'Watched pull: {unmatched_movies} local movies not '
                          f'listed as watched on MDBList and not matched by a '
                          f'journal removal')
        log_debug(f'Watched pull: {result}')
        return result

    def _any_key_in(self, keys, ids):
        """True when any canonical key of an ids dict is in a set of keys."""
        return any(key in keys for key in self._keys_from_ids(ids))

    @staticmethod
    def _episode_unwatched(unwatched, show_ids, s_num, e_num):
        """True when a local episode is known-unwatched on MDBList."""
        show_keys = [key for key in SyncEngine._keys_from_ids(show_ids)]
        if any(key in unwatched['shows'] for key in show_keys):
            return True
        for key in show_keys:
            eps = unwatched['episodes'].get(key)
            if eps and (s_num, e_num) in eps:
                return True
        return False

    def _movie_removal_ts(self, unwatched, ids):
        """(matched, action_at) of the journal removal covering this movie."""
        for key in self._keys_from_ids(ids):
            if key in unwatched['movies']:
                return True, unwatched['movies'].get(key)
        return False, None

    def _episode_removal_ts(self, unwatched, show_ids, s_num, e_num):
        """(matched, action_at) of the journal removal covering this episode.

        A show/season removal covers every episode below it, an episode
        removal just that one; when several rows match, the newest
        action_at wins (it is the most recent user decision for the item)."""
        matched = False
        newest = None
        for key in self._keys_from_ids(show_ids):
            if key in unwatched['shows']:
                matched = True
                ts = unwatched['shows'].get(key)
                if ts is not None and (newest is None or ts > newest):
                    newest = ts
            eps = unwatched['episodes'].get(key)
            if eps and (s_num, e_num) in eps:
                matched = True
                ts = eps.get((s_num, e_num))
                if ts is not None and (newest is None or ts > newest):
                    newest = ts
        return matched, newest

    def _removal_ts(self, journal_ts, kind, ids, s_num=None, e_num=None):
        """Effective removal timestamp: journal action_at, else own record.

        Rows written before action_at existed (or unparseable ones) fall
        back to the local downgrade-push record; when neither has a
        timestamp the comparison is impossible and None is returned."""
        if journal_ts is not None:
            try:
                return float(journal_ts)
            except (TypeError, ValueError):
                pass
        return self._record_removal_ts(kind, ids, s_num, e_num)

    @staticmethod
    def _is_rewatch(removal_ts, kodi_lastplayed):
        """True when the local watch is strictly newer than the removal.

        Conservative on purpose: both timestamps must parse, otherwise the
        journal wins (status quo stomp). Ties keep the removal, since the
        removal is the later action then."""
        if removal_ts is None:
            return False
        watch_epoch = SyncEngine._local_watch_epoch(kodi_lastplayed)
        if watch_epoch is None:
            return False
        try:
            return watch_epoch > float(removal_ts)
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _set_unwatched(item):
        """Set a local movie/episode to unwatched (playcount 0, clear date).

        When the item currently has a resume point ("partially watched" in
        Kodi), it is cleared as well so the item no longer shows as started."""
        kind = 'movie' if 'movieid' in item else 'episode'
        # The lastplayed field only accepts a date string, so it must be
        # cleared with an empty string (''), never an integer 0, or Kodi
        # rejects the whole call (that silently failed the downgrade).
        params = {f'{kind}id': item[f'{kind}id'], 'playcount': 0,
                  'lastplayed': ''}
        method = ('VideoLibrary.SetMovieDetails' if kind == 'movie'
                  else 'VideoLibrary.SetEpisodeDetails')
        if item.get('resume'):
            params['resume'] = {'position': 0.0, 'total': 0.0}
        if jsonrpc(method, params).get('result'):
            item['playcount'] = 0
            item['lastplayed'] = None
            return True
        return False

    def _remote_journal_unwatched(self):
        """Remote items explicitly unwatched, pulled from the sync journal.

        Fetched once per sync run: the pull needs it to downgrade Kodi, and
        the push needs it to avoid re-uploading the very items the user just
        marked unwatched on MDBList. Returns {'movies': {key: action_at},
        'shows': {key: action_at}, 'episodes': {show_key: {(s, e):
        action_at}}} for journal rows whose latest watched state is
        'removed'; action_at is unix epoch or None when the row carries no
        parseable timestamp. Falls back to empty dicts (no downgrades, no
        push exclusions) when the journal cannot be read or yields no
        removals."""
        cached = getattr(self, '_journal_unwatched_cache', None)
        if cached is not None:
            return cached
        result = self._fetch_journal_unwatched()
        self._journal_unwatched_cache = result
        return result

    def _fetch_journal_unwatched(self):
        try:
            data = self.api.paginate_sync_journal()
        except Exception as exc:
            log_error(f'Sync journal fetch failed: {exc}')
            return {'movies': {}, 'shows': {}, 'episodes': {}}
        if not data.get('_complete', True):
            log_error('Watched sync journal incomplete: downgrades and push '
                      'exclusions skipped')
            return {'movies': {}, 'shows': {}, 'episodes': {}}
        movies, shows, episodes = mapping.watched_removed(data)
        episode_count = sum(len(v) for v in episodes.values())
        log_debug(f'Journal unwatched: movies={len(movies)} '
                  f'shows={len(shows)} episodes={episode_count}')
        raw_rows = [r for r in (data or {}).get('journal') or []
                    if isinstance(r, dict)
                    and r.get('category') == 'watched'
                    and r.get('status') == 'removed']
        if raw_rows:
            # the first row in full, so a timestamp/status field the
            # mapping does not read yet becomes visible in the log
            log_debug(f'Journal first removal row: '
                      f'{self._compact_json(raw_rows[0])}')
        removed_rows = [
            {'item_type': r.get('item_type'), 'ids': r.get('ids'),
             'season': r.get('season'), 'episode': r.get('episode')}
            for r in raw_rows]
        if removed_rows:
            log_debug(f'Journal unwatched rows: '
                      f'{self._compact_json(removed_rows)}')
        log_debug(f'Journal unwatched movie keys: '
                  f'{sorted(movies)}')
        return {'movies': movies, 'shows': shows, 'episodes': episodes}

    def _remote_episode_by_id(self, eps_by_id, local_episode):
        """Remote state of an episode matched on its own provider id.

        Fallback for remote entries that identify episodes directly instead
        of by show plus season/episode number."""
        if not eps_by_id:
            return None
        for key in self._keys_from_ids(local_episode.get('ids') or {}):
            state = eps_by_id.get(key)
            if state:
                return state
        return None

    def _local_movie_cache(self):
        if getattr(self, '_movies_cache', None) is None:
            self._movies_cache = self._get_local_movies()
        return self._movies_cache

    def _watched_push(self):
        remote = self._remote_watched()
        incomplete = self._snapshot_incomplete(remote)
        if incomplete:
            log_error(f'Watched push skipped, remote snapshot unusable: '
                      f'{incomplete}')
            return {'status': 'incomplete_snapshot'}

        remote_movies = self._remote_movie_index(remote)
        unwatched = self._remote_journal_unwatched()

        push_movies = []
        push_movies_skipped_unwatched = 0
        for local in self._local_movie_cache().values():
            if local['playcount'] <= 0:
                continue
            # Never re-upload an item the user just marked unwatched on
            # MDBList: the pull downgrades it, and pushing here would undo
            # that decision and re-open the watched<->unwatched loop.
            # Exception: a local watch newer than the removal (its own
            # action_at, else our removal record) is a deliberate re-watch
            # the journal row must not suppress.
            matched, journal_ts = self._movie_removal_ts(
                unwatched, local['ids'])
            if matched and not self._is_rewatch(
                    self._removal_ts(journal_ts, 'movies', local['ids']),
                    local.get('lastplayed')):
                push_movies_skipped_unwatched += 1
                continue
            entry = self._lookup_any(remote_movies, local['ids'])
            remote_plays = mapping.movie_plays(entry) if entry else 0
            if remote_plays >= local['playcount']:
                continue
            push_movies.append(self._dated_payload(
                {'ids': self._ids_for_push(local['ids'])},
                local['lastplayed']))
        if push_movies_skipped_unwatched:
            log_debug(f'Watched push: {push_movies_skipped_unwatched} movies '
                      f'skipped (marked unwatched on MDBList)')

        show_map, episodes_by_show = self._get_local_episodes()
        eps_by_show, eps_by_id = mapping.watched_episodes(remote)

        # Episodes are pushed through the flat 'episodes' bucket, keyed by
        # the *episode's* own provider id (as returned by /sync/watched).
        # The nested shows[].seasons[].episodes[].number shape uses show ids
        # plus numbers, which MDBList's /sync/watched accepts but silently
        # drops, so it is not used here. Whole-season flags are not bridged
        # here either: shows are handled on the episode level only.
        push_episodes = []
        episodes_without_ids = 0
        push_episodes_skipped_unwatched = 0
        for info in show_map.values():
            local_eps = episodes_by_show.get(info['tvshowid'], {})
            remote_eps = self._lookup_any(eps_by_show, info['ids']) or {}
            for (s_num, e_num), data in sorted(local_eps.items()):
                if data['playcount'] <= 0:
                    continue
                matched, journal_ts = self._episode_removal_ts(
                    unwatched, info['ids'], s_num, e_num)
                if matched and not self._is_rewatch(
                        self._removal_ts(journal_ts, 'episodes',
                                         info['ids'], s_num, e_num),
                        data.get('lastplayed')):
                    push_episodes_skipped_unwatched += 1
                    continue
                remote_ep = remote_eps.get((s_num, e_num)) or \
                    self._remote_episode_by_id(eps_by_id, data)
                if remote_ep and remote_ep['plays'] >= data['playcount']:
                    continue
                ep_ids = self._ids_for_push(data['ids'])
                if not ep_ids:
                    episodes_without_ids += 1
                    continue
                push_episodes.append(self._dated_payload(
                    {'ids': ep_ids}, data['lastplayed']))
        if episodes_without_ids:
            log_debug(f'Watched push: {episodes_without_ids} watched '
                      f'episodes skipped (no episode id)')
        if push_episodes_skipped_unwatched:
            log_debug(f'Watched push: {push_episodes_skipped_unwatched} '
                      f'episodes skipped (marked unwatched on MDBList)')

        if not push_movies and not push_episodes:
            return {'status': 'ok', 'pushed': 0}
        try:
            for chunk in self._chunks(push_movies):
                self.api.push_watched(movies=chunk)
            episode_responses = []
            for chunk in self._chunks(push_episodes):
                episode_responses.append(
                    self.api.push_watched(episodes=chunk) or {})
        except Exception as exc:
            log_error(f'Watched push failed: {exc}')
            notify(localized(32125) or 'Sync failed',
                   icon=NOTIFICATION_ERROR)
            return {'status': 'error'}
        self.cache.delete('sync_watched')
        pushed = len(push_movies) + len(push_episodes)
        log_debug(f'Watched push: {pushed} entries '
                  f'(movies={len(push_movies)} episodes={len(push_episodes)})')
        if push_movies:
            log_debug(f'Watched push sample movie payloads: '
                      f'{self._compact_json(push_movies[:3])}')
        if push_episodes:
            raw = [self._compact_json(r) for r in episode_responses]
            counts = self._response_counts(episode_responses)
            log_debug(f'Watched push response: {counts} '
                      f'(raw: {raw}) '
                      f'(sample episode payloads: '
                      f'{self._compact_json(push_episodes[:3])})')
            if counts.get('updated') == 0:
                # a no-op update on ids that are not flagged not_found
                # usually means the ids were not recognised at all: check
                # whether they were even present in the remote snapshot
                already = sum(
                    1 for p in push_episodes
                    if self._remote_episode_by_id(eps_by_id, p))
                log_debug(f'Watched push: server updated nothing; '
                          f'{already}/{len(push_episodes)} pushed episodes '
                          f'were already in the remote snapshot')
        return {'status': 'ok', 'pushed': pushed}

    @staticmethod
    def _response_counts(responses):
        """Per-field totals across POST /sync/watched responses.

        updated/not_found are objects keyed by media type
        (movies/shows/seasons/episodes) whose values hold the affected
        entries, so counting the top-level dict keys would always read 4.
        Summing each bucket's value length yields the real entry count."""
        counts = {}
        for key in ('updated', 'not_found', 'errors', 'plays', 'history_only'):
            total = 0
            for resp in responses:
                value = (resp or {}).get(key)
                if isinstance(value, dict):
                    total += sum(len(v) for v in value.values()
                                 if isinstance(v, (list, dict)))
                elif isinstance(value, list):
                    total += len(value)
            counts[key] = total
        return counts

    @staticmethod
    def _compact_json(data, limit=4000):
        """Compact JSON representation of a response, truncated for logging."""
        import json
        try:
            text = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
        except (TypeError, ValueError):
            text = str(data)
        if len(text) > limit:
            return text[:limit] + f'…(+{len(text) - limit} chars)'
        return text

    @staticmethod
    def _dated_payload(base, kodi_date, field='watched_at'):
        """Add Kodi's play date to a push entry.

        Without an explicit timestamp the server stamps the current time,
        so every push would overwrite the real watch date with the time of
        the sync."""
        payload = dict(base)
        timestamp = kodi_date_to_iso(kodi_date)
        if timestamp:
            payload[field] = timestamp
        return payload

    # ------------------------------------------------------------------ #
    # local "mark unwatched" -> remote watched removals                   #
    # ------------------------------------------------------------------ #

    def _local_downgrade_push(self):
        """Report movies/episodes the user marked unwatched in Kodi to MDBList.

        The watched pull treats MDBList as authoritative, so a plain "mark
        unwatched" in Kodi used to be reverted on the next sync run - most
        visibly after a Kodi restart, when the startup sync re-applied the
        remote watched state. To tell a deliberate reset apart from a fresh
        or re-added library item, the ids of every locally watched movie
        and episode are kept in a cache snapshot: only an item that was
        watched in the previous snapshot and is unwatched *now* counts as
        a local downgrade and is removed on MDBList via /sync/watched/remove.

        A missing snapshot (fresh install, cleared cache) only stores the
        current state as the baseline and pushes nothing, so adding a new
        library never wipes remote history. The same applies when a library
        scan/clean finished after the baseline was taken (the service
        stamps 'library_event'): a rescan can reset the playcounts of a
        deleted and re-added item, and that case belongs to the pull, not
        to a removal push. Items already removed on MDBList through the
        journal are skipped - the pull downgrades those on its own.
        """
        self._downgrade_skip = {'movies': set(), 'episodes': {}}
        snapshot = self.cache.get('local_watched')
        movies = self._local_movie_cache()
        show_map, episodes_by_show = self._get_local_episodes()
        if snapshot is None or self._library_event_after(snapshot):
            reason = ('library changed since the baseline' if snapshot
                      else 'no baseline yet')
            self._store_local_watched(movies, episodes_by_show)
            log_debug(f'Local unwatched push: {reason}, baseline stored, '
                      'nothing pushed')
            return {'status': 'ok', 'pushed': 0, 'baseline': True}

        remote = self._remote_watched()
        incomplete = self._snapshot_incomplete(remote)
        if incomplete:
            log_error(f'Local unwatched push skipped, remote snapshot '
                      f'unusable: {incomplete}')
            return {'status': 'incomplete_snapshot'}

        watched_movies = set(snapshot.get('movies') or [])
        watched_episodes = set(snapshot.get('episodes') or [])
        remote_movies = self._remote_movie_index(remote)
        eps_by_show, eps_by_id = mapping.watched_episodes(remote)
        unwatched = self._remote_journal_unwatched()

        down_movies = []
        removed_movie_ids = []
        for local in movies.values():
            if local['playcount'] > 0 or \
                    str(local['movieid']) not in watched_movies:
                continue
            if self._any_key_in(unwatched['movies'], local['ids']):
                continue  # already removed on MDBList, pull handles Kodi
            entry = self._lookup_any(remote_movies, local['ids'])
            if not entry or mapping.movie_plays(entry) <= 0:
                continue  # not watched remotely, nothing to remove
            down_movies.append({'ids': self._ids_for_push(local['ids'])})
            removed_movie_ids.append(local['ids'])
            self._downgrade_skip['movies'].update(
                self._keys_from_ids(local['ids']))

        down_episodes = []
        removed_episode_keys = []
        episodes_without_ids = 0
        for info in show_map.values():
            local_eps = episodes_by_show.get(info['tvshowid'], {})
            remote_eps = self._lookup_any(eps_by_show, info['ids']) or {}
            for (s_num, e_num), data in sorted(local_eps.items()):
                if data['playcount'] > 0 or \
                        str(data['episodeid']) not in watched_episodes:
                    continue
                if self._episode_unwatched(
                        unwatched, info['ids'], s_num, e_num):
                    continue
                remote_ep = (remote_eps.get((s_num, e_num)) or
                             self._remote_episode_by_id(eps_by_id, data))
                if not remote_ep or remote_ep['plays'] <= 0:
                    continue
                ep_ids = self._ids_for_push(data['ids'])
                if not ep_ids:
                    episodes_without_ids += 1
                    continue
                down_episodes.append({'ids': ep_ids})
                removed_episode_keys.append((info['ids'], s_num, e_num))
                for show_key in self._keys_from_ids(info['ids']):
                    self._downgrade_skip['episodes'].setdefault(
                        show_key, set()).add((s_num, e_num))

        if not down_movies and not down_episodes:
            # refresh the baseline so ids of deleted items do not pile up
            self._store_local_watched(movies, episodes_by_show)
            return {'status': 'ok', 'pushed': 0}
        try:
            for chunk in self._chunks(down_movies):
                self.api.remove_watched(movies=chunk)
            for chunk in self._chunks(down_episodes):
                self.api.remove_watched(episodes=chunk)
        except Exception as exc:
            # no baseline update: the same downgrades are retried next run
            log_error(f'Local unwatched push failed: {exc}')
            notify(localized(32125) or 'Sync failed',
                   icon=NOTIFICATION_ERROR)
            return {'status': 'error'}
        self.cache.delete('sync_watched')
        self._record_local_removals(removed_movie_ids, removed_episode_keys)
        self._store_local_watched(movies, episodes_by_show)
        if episodes_without_ids:
            log_debug(f'Local unwatched push: {episodes_without_ids} '
                      'episodes skipped (no episode id)')
        log_debug(f'Local unwatched push: {len(down_movies)} movies, '
                  f'{len(down_episodes)} episodes removed on MDBList')
        return {'status': 'ok',
                'pushed': len(down_movies) + len(down_episodes)}

    def _library_event_after(self, snapshot):
        """True when a library scan/clean finished after the baseline."""
        event = self.cache.get('library_event')
        if not event:
            return False
        try:
            return float(event) > float(snapshot.get('updated_at') or 0)
        except (TypeError, ValueError):
            return False

    # ---- local removal record ---------------------------------------- #

    def _local_removals(self):
        """Cached record of what our own downgrade push removed on MDBList.

        The sync journal only tells us 'removed', not when; without our own
        timestamp a deliberate re-watch of the same item would lose against
        the journal row our own removal created (the pull would stomp the
        newer local watch, the push would skip the re-upload)."""
        if getattr(self, '_local_removals_cache', None) is None:
            self._local_removals_cache = self.cache.get('local_removals') or {}
        return self._local_removals_cache

    @staticmethod
    def _local_watch_epoch(kodi_date):
        """Local Kodi lastplayed value as unix epoch seconds."""
        iso = kodi_date_to_iso(kodi_date)
        if not iso:
            return None
        dt = iso_to_datetime(iso)
        if dt is None:
            return None
        try:
            return dt.timestamp()
        except (OverflowError, OSError, ValueError):
            return None

    def _record_removal_ts(self, kind, ids, s_num=None, e_num=None):
        """Timestamp our own downgrade push recorded for this item, else None.

        Fallback for journal rows written before action_at existed: the
        record only covers removals we pushed ourselves, so a genuine
        web-side removal yields None (and with it the conservative
        journal-wins behaviour)."""
        bucket = self._local_removals().get(kind) or {}
        for provider, value in self._keys_from_ids(ids):
            if kind == 'episodes':
                key = '%s:%s:%s:%s' % (provider, value, s_num, e_num)
            else:
                key = '%s:%s' % (provider, value)
            removal_epoch = bucket.get(key)
            if removal_epoch is not None:
                try:
                    return float(removal_epoch)
                except (TypeError, ValueError):
                    return None
        return None

    def _record_local_removals(self, movie_ids_list, episode_keys):
        """Persist removal ids from a successful downgrade push with the
        current time, merged into the existing record (per-entry timestamps,
        TTL matching the journal retention window)."""
        import time
        now = time.time()
        record = self._local_removals()
        movies = dict(record.get('movies') or {})
        episodes = dict(record.get('episodes') or {})
        for ids in movie_ids_list:
            for provider, value in self._keys_from_ids(ids):
                movies['%s:%s' % (provider, value)] = now
        for show_ids, s_num, e_num in episode_keys:
            for provider, value in self._keys_from_ids(show_ids):
                episodes['%s:%s:%s:%s' % (provider, value, s_num, e_num)] = now
        payload = {'movies': movies, 'episodes': episodes, 'updated_at': now}
        self.cache.set('local_removals', payload,
                       ttl=CACHE_TTL_LOCAL_REMOVALS)
        self._local_removals_cache = payload


    def _store_local_watched(self, movies, episodes_by_show):
        """Store the current locally watched ids as the downgrade baseline."""
        import time
        self.cache.set('local_watched', {
            'updated_at': time.time(),
            'movies': [str(m['movieid']) for m in movies.values()
                       if m['playcount'] > 0],
            'episodes': [str(ep['episodeid'])
                         for eps in episodes_by_show.values()
                         for ep in eps.values() if ep['playcount'] > 0],
        }, ttl=CACHE_TTL_LOCAL_WATCHED)

    def _episode_downgraded(self, show_ids, s_num, e_num):
        """True when this episode was just removed on MDBList as a local
        downgrade (the pull and the resume pull must leave it alone)."""
        episodes = (getattr(self, '_downgrade_skip', None) or
                    {}).get('episodes') or {}
        for key in self._keys_from_ids(show_ids):
            numbers = episodes.get(key)
            if numbers and (s_num, e_num) in numbers:
                return True
        return False

    # ------------------------------------------------------------------ #
    # playback progress (resume points)                                   #
    # ------------------------------------------------------------------ #

    def _resume_pull(self, activities=None, force=False):
        """Restore the resume points of paused MDBList sessions locally.

        Pull only: sessions are pushed by the scrobbler when playback stops
        on this device, and that same scrobble is recorded in the resume
        cache - which is what lets the pull tell its own sessions apart from
        another device's and leave them alone."""
        if not force and not self._progress_changed(activities):
            return {'status': 'skipped'}
        try:
            sessions = mapping.playback_sessions(
                self.api.get_playback_sessions())
        except Exception as exc:
            log_error(f'Playback sessions fetch failed: {exc}')
            return {'status': 'error'}
        log_debug(f'Progress sync: {len(sessions)} remote playback sessions')
        if not sessions:
            return {'status': 'ok', 'movies': 0, 'episodes': 0}

        movies_by_key = {}
        eps_by_show, eps_by_id = {}, {}
        for session in sessions:
            if session['kind'] == 'movie':
                for key in self._keys_from_ids(session['ids']):
                    movies_by_key.setdefault(key, session)
                continue
            if session['season'] is None or session['episode'] is None:
                continue
            number = (session['season'], session['episode'])
            for key in self._keys_from_ids(session['show_ids']):
                eps_by_show.setdefault(key, {})[number] = session
            for key in self._keys_from_ids(session['ids']):
                eps_by_id.setdefault(key, session)

        skipped = {}
        movies = self._local_movie_cache()
        applied_movies = 0
        downgrade_movies = (getattr(self, '_downgrade_skip', None) or
                            {}).get('movies') or set()
        for local in movies.values():
            # an item just marked unwatched locally must not be turned
            # back into "partly watched" by a leftover session
            if self._any_key_in(downgrade_movies, local['ids']):
                continue
            session = self._lookup_any(movies_by_key, local['ids'])
            if session is None:
                continue
            record_keys = resume.keys('movie', local['ids'])
            applied, reason = self._apply_resume(session, local, 'movie',
                                                record_keys)
            if applied:
                applied_movies += 1
            else:
                skipped[reason] = skipped.get(reason, 0) + 1

        show_map, episodes_by_show = self._get_local_episodes()
        applied_episodes = 0
        for info in show_map.values():
            remote_eps = self._lookup_any(eps_by_show, info['ids']) or {}
            local_eps = episodes_by_show.get(info['tvshowid'], {})
            for (s_num, e_num), local in sorted(local_eps.items()):
                if self._episode_downgraded(info['ids'], s_num, e_num):
                    continue
                session = (remote_eps.get((s_num, e_num)) or
                           self._remote_episode_by_id(eps_by_id, local))
                if session is None:
                    continue
                # the scrobbler keyed its record by the resolved show id,
                # the library entry by the episode's own ids - look in both
                record_keys = (resume.keys('episode', info['ids'],
                                           s_num, e_num) +
                               resume.keys('episode',
                                           local.get('ids') or {},
                                           s_num, e_num))
                applied, reason = self._apply_resume(session, local, 'episode',
                                                    record_keys)
                if applied:
                    applied_episodes += 1
                else:
                    skipped[reason] = skipped.get(reason, 0) + 1

        result = {'status': 'ok', 'movies': applied_movies,
                  'episodes': applied_episodes, 'skipped': skipped}
        log_debug(f'Progress pull: {result}')
        return result

    @staticmethod
    def _progress_changed(activities):
        """True when MDBList reports a new/changed paused session.

        'paused_at' and 'episode_paused_at' of /sync/last_activities move
        whenever a session is saved, so they gate the pull without a
        /sync/playback request on every run."""
        if activities is None:
            return False
        return any(activities.get(key) for key in PROGRESS_ACTIVITY_KEYS)

    @staticmethod
    def _session_expired(session):
        """True when MDBList has already dropped the session."""
        from datetime import datetime, timezone

        from ..utils import iso_to_datetime
        expires = iso_to_datetime(session.get('expires_at'))
        return bool(expires and
                    expires < datetime.now(timezone.utc))

    def _apply_resume(self, session, local, kind, record_keys):
        """Write one remote session into a local item's resume point.

        Returns (applied, reason); reason is logged when an existing session
        is not taken over. Progress is compared in percent, not seconds:
        the remote runtime describes MDBList's copy of the item, while the
        local resume position refers to this device's file."""
        progress = session.get('progress')
        if progress is None or progress <= 0 or progress >= 100:
            return False, 'no usable progress'
        if local['playcount'] > 0:
            # the item is watched here - the watched pull owns that state,
            # a leftover session must not resurrect it as "partly watched"
            return False, 'watched locally'
        if self._session_expired(session):
            return False, 'session expired'
        record_key, record = resume.load_any(record_keys)
        if resume.is_own(record, progress, session.get('session_id')):
            return False, 'own session'
        point = local.get('resume_point') or {}
        total = float(point.get('total') or 0)
        local_progress = (point['position'] / total * 100.0) if total else 0.0
        if abs(progress - local_progress) <= resume.POSITION_TOLERANCE:
            return False, 'position unchanged'
        if progress < local_progress and not resume.remote_is_newer(
                record, session.get('updated_at')):
            # another device restarted the item further back; only accept
            # that on a clearly newer session, never on a clock guess
            return False, 'behind local position'
        total = total or float(session.get('runtime') or 0) * 60.0
        if total <= 0:
            return False, 'no runtime'
        position = round(total * progress / 100.0, 1)
        if not RESUME_MIN_POSITION <= position <= total - RESUME_MIN_POSITION:
            return False, 'outside usable range'
        method = ('VideoLibrary.SetMovieDetails' if kind == 'movie'
                  else 'VideoLibrary.SetEpisodeDetails')
        params = {f'{kind}id': local[f'{kind}id'],
                  'resume': {'position': position, 'total': total}}
        if not jsonrpc(method, params).get('result'):
            log_debug(f'Progress pull: Kodi rejected the resume point for '
                      f'{kind} {local[f"{kind}id"]} ({progress:.1f}%)')
            return False, 'jsonrpc failed'
        if record_key:
            resume.mark_applied(record_key, progress,
                                session.get('session_id'),
                                session.get('updated_at'))
        local['resume_point'] = {'position': position, 'total': total}
        local['resume'] = True
        log_debug(f'Progress pull: {kind} {local[f"{kind}id"]} resumed at '
                  f'{progress:.1f}% ({position:.0f}s of {total:.0f}s)')
        return True, 'applied'

    # ------------------------------------------------------------------ #
    # one-off repair of watch dates overwritten by earlier versions       #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _dates_disagree(remote_iso, kodi_date, tolerance=REPAIR_TOLERANCE):
        """True when a remote watch date is far off Kodi's play date.

        Used to find entries whose timestamp was replaced by the time of a
        sync run. The tolerance keeps timezone quirks and the usual small
        drift between scrobble and library update out of the result."""
        from ..utils import iso_to_datetime
        remote_dt = iso_to_datetime(remote_iso)
        local_dt = iso_to_datetime(kodi_date_to_iso(kodi_date))
        if remote_dt is None or local_dt is None:
            return False
        return abs((remote_dt - local_dt).total_seconds()) > tolerance

    def plan_watched_date_repair(self, limit=None):
        """Remote watched entries whose date disagrees with the library.

        Returns {'movies': [payload], 'episodes': [payload]} where each
        payload already carries the corrected watched_at. Episodes are
        flat entries keyed by the episode's own provider id."""
        remote = self._remote_watched()
        incomplete = self._snapshot_incomplete(remote)
        if incomplete:
            log_error(f'Repair aborted, remote snapshot unusable: {incomplete}')
            return None

        remote_movies = self._remote_movie_index(remote)
        movies = []
        for local in self._get_local_movies().values():
            if local['playcount'] <= 0 or not local['lastplayed']:
                continue
            entry = self._lookup_any(remote_movies, local['ids'])
            if entry is None:
                continue
            if not self._dates_disagree(mapping.watched_timestamp(entry),
                                        local['lastplayed']):
                continue
            movies.append(self._dated_payload(
                {'ids': self._ids_for_push(local['ids'])},
                local['lastplayed']))

        show_map, episodes_by_show = self._get_local_episodes()
        eps_by_show, eps_by_id = mapping.watched_episodes(remote)
        repair_episodes = []
        for info in show_map.values():
            remote_eps = self._lookup_any(eps_by_show, info['ids']) or {}
            for (s_num, e_num), data in sorted(
                    episodes_by_show.get(info['tvshowid'], {}).items()):
                if data['playcount'] <= 0 or not data['lastplayed']:
                    continue
                remote_ep = remote_eps.get((s_num, e_num)) or \
                    self._remote_episode_by_id(eps_by_id, data)
                if not remote_ep:
                    continue
                if not self._dates_disagree(remote_ep.get('watched_at'),
                                            data['lastplayed']):
                    continue
                ep_ids = self._ids_for_push(data['ids'])
                if not ep_ids:
                    continue
                repair_episodes.append(self._dated_payload(
                    {'ids': ep_ids}, data['lastplayed']))

        if limit:
            movies = movies[:limit]
            repair_episodes = repair_episodes[:limit]
        plan = {'movies': movies, 'episodes': repair_episodes}
        log_debug(f'Watch date repair plan: movies={len(movies)} '
                  f'episodes={len(repair_episodes)}')
        return plan

    @classmethod
    def _without_timestamps(cls, entry):
        """Copy of a push entry with every watched_at removed."""
        clean = {k: v for k, v in entry.items() if k != 'watched_at'}
        if 'seasons' in clean:
            clean['seasons'] = [
                {'number': season['number'],
                 'episodes': [cls._without_timestamps(ep)
                              for ep in season.get('episodes') or []]}
                for season in clean['seasons']]
        return clean

    def apply_watched_date_repair(self, plan, progress=None):
        """Rewrite the planned entries with their correct watch date.

        Remove-then-add rather than a plain re-push: adding a back-dated
        play can collapse into the existing wrong one or create a second
        play instead of correcting it."""
        steps = []
        for chunk in self._chunks(plan.get('movies') or []):
            steps.append(('movies', chunk))
        for chunk in self._chunks(plan.get('episodes') or []):
            steps.append(('episodes', chunk))
        done = 0
        repaired = 0
        for kind, chunk in steps:
            if progress is not None and progress(done, len(steps)) is False:
                log_debug('Watch date repair cancelled')
                break
            stripped = [self._without_timestamps(entry) for entry in chunk]
            try:
                self.api.remove_watched(**{kind: stripped})
                self.api.push_watched(**{kind: chunk})
            except Exception as exc:
                log_error(f'Watch date repair failed on {kind}: {exc}')
                self.cache.delete('sync_watched')
                return {'status': 'error', 'repaired': repaired}
            repaired += len(chunk)
            done += 1
        self.cache.delete('sync_watched')
        if progress is not None:
            progress(len(steps), len(steps))
        log_debug(f'Watch date repair: {repaired} entries rewritten')
        return {'status': 'ok', 'repaired': repaired}

    # ------------------------------------------------------------------ #
    # collection                                                         #
    # ------------------------------------------------------------------ #

    def _remote_collection(self):
        cached = self.cache.get('sync_collection')
        if cached is not None:
            return cached
        data = self.api.get_collection() or {}
        self._log_snapshot('collection', data)
        self.cache.set('sync_collection', data, ttl=CACHE_TTL_REMOTE)
        return data

    def _parse_collection(self, data):
        """Returns ({movie_key}, {show_key: {(season, episode), ...}}).

        Remote entries are indexed under every provider id they carry, so a
        local item known by a different provider still matches."""
        movie_ids = set()
        for entry in (data or {}).get('movies') or []:
            ids = (mapping.watched_entry_ids(entry).get('ids') or
                   mapping.entry_ids(entry))
            movie_ids.update(self._keys_from_ids(ids))
        eps_by_show, _ = mapping.watched_episodes(data)
        episodes_by_show = {key: set(eps) for key, eps in eps_by_show.items()}
        return movie_ids, episodes_by_show

    def _get_show_index(self):
        """All library shows as {key: {tvshowid,title,year}} for the diff."""
        index = {}
        for show in jsonrpc_paginate(
                'VideoLibrary.GetTvShows', 'tvshows',
                {'properties': ['title', 'premiered', 'uniqueid']}):
            premiered = str(show.get('premiered') or '')
            ids = show.get('uniqueid') or {}
            key = self._show_key(ids) or ('noid', str(show.get('tvshowid')))
            index[key] = {
                'tvshowid': show.get('tvshowid'),
                'title': show.get('title') or '',
                'year': int(premiered[:4]) if premiered[:4].isdigit() else None,
                'ids': ids,
            }
        no_ids = sum(1 for k in index if k[0] == 'noid')
        log_debug(f'Collection: {len(index)} shows in library, '
                  f'{no_ids} without uniqueid')
        return index

    def _resolve_by_title(self, title, year):
        """Last-resort show identification via MDBList search (30d cache)."""
        if not title:
            return None
        cache_key = f'sync-show-id:{title.lower()}:{year or ""}'
        cached = self.cache.get(cache_key)
        if cached:
            return (cached[0], str(cached[1]))
        try:
            response = self.api.search_media(title, 'show')
        except Exception as exc:
            log_debug(f'Show title-search failed ({title}): {exc}')
            return None
        from ..identify import pick_match
        match = pick_match(response, 'show', year)
        key = self._show_key((match or {}).get('ids') or {})
        if key is None:
            log_debug(f'Show title-search: no result for "{title}"')
            return None
        self.cache.set(cache_key, [key[0], key[1]], ttl=30 * 86400)
        return key

    @classmethod
    def _missing_episodes_payload(cls, show_key, local_eps, remote_eps):
        """Show payload containing only episodes missing from the collection.

        local_eps maps (season, episode) to the local episode record so the
        real play date can travel with the entry."""
        seasons = {}
        for (s_num, e_num), data in sorted(local_eps.items()):
            if (s_num, e_num) in remote_eps:
                continue
            seasons.setdefault(s_num, []).append(cls._dated_payload(
                {'number': e_num}, (data or {}).get('lastplayed'),
                field='collected_at'))
        if not seasons:
            return None
        provider, value = show_key
        try:
            value = int(value)
        except ValueError:
            pass
        return {'ids': {provider: value},
                'seasons': [{'number': s_num, 'episodes': eps}
                            for s_num, eps in sorted(seasons.items())]}

    @staticmethod
    def _chunks(items, size=100):
        for start in range(0, len(items), size):
            yield items[start:start + size]

    def _collection_push(self):
        try:
            remote = self._remote_collection()
        except Exception as exc:
            log_error(f'Collection fetch failed: {exc}')
            return {'status': 'error'}
        incomplete = self._snapshot_incomplete(remote)
        if incomplete:
            log_error(f'Collection push skipped, remote snapshot unusable: '
                      f'{incomplete}')
            return {'status': 'incomplete_snapshot'}
        remote_movie_ids, remote_eps_by_show = self._parse_collection(remote)
        log_debug(f'Collection remote snapshot: movies={len(remote_movie_ids)} '
                  f'shows={len(remote_eps_by_show)}')

        local_movies = self._get_local_movies()
        push_movies = [self._dated_payload(
            {'ids': self._ids_for_push(info['ids'])}, info['lastplayed'],
            field='collected_at')
            for info in local_movies.values()
            if not self._contains_any(remote_movie_ids, info['ids'])]

        show_index = self._get_show_index()
        _, episodes_by_show = self._get_local_episodes()
        push_shows = []
        added_episodes = 0
        unresolved = 0
        for key in list(show_index):
            info = show_index.pop(key)
            ids = info['ids']
            if key[0] == 'noid':
                resolved = self._resolve_by_title(info['title'], info['year'])
                if resolved is None:
                    unresolved += 1
                    continue
                key = resolved
                ids = {resolved[0]: resolved[1]}
            local_eps = episodes_by_show.get(info['tvshowid'], {})
            remote_eps = self._lookup_any(remote_eps_by_show, ids) or set()
            payload = self._missing_episodes_payload(key, local_eps, remote_eps)
            if payload:
                push_shows.append(payload)
                added_episodes += sum(len(s['episodes'])
                                      for s in payload['seasons'])
        log_debug(f'Collection diff: movies={len(push_movies)} '
                  f'show payloads={len(push_shows)} episodes={added_episodes} '
                  f'unresolved={unresolved}')

        if not push_movies and not push_shows:
            return {'status': 'ok', 'movies': 0, 'episodes': 0}
        try:
            for chunk in self._chunks(push_movies):
                self.api.add_collection_items(movies=chunk)
            for chunk in self._chunks(push_shows, MAX_SHOWS_PER_REQUEST):
                self.api.add_collection_items(shows=chunk)
        except Exception as exc:
            log_error(f'Collection push failed: {exc}')
            return {'status': 'error'}
        # merge pushed items into the cached snapshot so reruns stay silent
        movies_bucket = remote.setdefault('movies', [])
        for payload in push_movies:
            movies_bucket.append({'movie': {'ids': {
                str(p): str(v) for p, v in payload['ids'].items()}}})
        shows_bucket = remote.setdefault('shows', [])
        for payload in push_shows:
            shows_bucket.append({'show': {
                'ids': {p: str(v) for p, v in payload['ids'].items()},
                'seasons': [{'number': s['number'],
                             'episodes': [dict(ep) for ep in s['episodes']]}
                            for s in payload['seasons']]}})
        self.cache.set('sync_collection', remote, ttl=CACHE_TTL_REMOTE)
        result = {'status': 'ok', 'movies': len(push_movies),
                  'episodes': added_episodes}
        log_debug(f'Collection push: {result}')
        return result

    # ------------------------------------------------------------------ #
    # ratings                                                            #
    # ------------------------------------------------------------------ #

    def _ratings_pull(self, activities=None, force=False):
        if not force and activities is None:
            return {'status': 'skipped'}
        try:
            remote = self.api.get_ratings() or {}
        except Exception as exc:
            log_error(f'Ratings pull failed: {exc}')
            return {'status': 'error'}
        changed = 0
        movies = self._local_movie_cache()
        local_by_id = {}
        for local in movies.values():
            for key in self._keys_from_ids(local['ids']):
                local_by_id[key] = local
        for entry in mapping.rating_entries(remote, 'movies'):
            rating = entry.get('rating')
            if not rating:
                continue
            local = self._lookup_any(local_by_id, entry.get('ids') or {})
            if local is None or local['userrating'] == int(rating):
                continue
            if self._newer(entry.get('rated_at'),
                           local.get('lastplayed')) or local['userrating'] == 0:
                if jsonrpc('VideoLibrary.SetMovieDetails',
                           {'movieid': local['movieid'],
                            'userrating': int(rating)}).get('result'):
                    changed += 1
        result = {'movies': changed, 'note': 'shows/episodes follow in later version'}
        log_debug(f'Ratings pull: {result}')
        return result

    def _ratings_push(self, activities=None, force=False):
        if not force and activities is None:
            return {'status': 'skipped'}
        try:
            remote = self.api.get_ratings() or {}
        except Exception as exc:
            log_error(f'Ratings push failed: {exc}')
            return {'status': 'error'}
        remote_movie_ratings = {}
        for entry in mapping.rating_entries(remote, 'movies'):
            # normalize so a remote '7' or 7.0 does not read as a change
            # against Kodi's integer userrating and get pushed every run
            try:
                rating = int(float(entry.get('rating')))
            except (TypeError, ValueError):
                continue
            for key in self._keys_from_ids(entry.get('ids') or {}):
                remote_movie_ratings[key] = rating
        entries = []
        removed = []
        for local in self._get_local_movies().values():
            userrating = local['userrating']
            remote_rating = self._lookup_any(remote_movie_ratings, local['ids'])
            push_ids = self._ids_for_push(local['ids'])
            if userrating > 0 and userrating != remote_rating:
                entries.append({'type': 'movie', 'ids': push_ids,
                                'rating': userrating})
            elif userrating == 0 and remote_rating:
                removed.append({'type': 'movie', 'ids': push_ids})
        if not entries and not removed:
            return {'status': 'ok', 'pushed': 0}
        try:
            if entries:
                self.api.push_ratings(entries)
            if removed:
                self.api.remove_ratings(removed)
        except Exception as exc:
            log_error(f'Ratings push request failed: {exc}')
            return {'status': 'error'}
        result = {'pushed': len(entries), 'removed': len(removed)}
        log_debug(f'Ratings push: {result}')
        return result
