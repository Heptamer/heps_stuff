# -*- coding: utf-8 -*-
"""Background service: player monitoring (scrobbling) + scheduled syncs."""
import threading
import time
import traceback

import xbmc

from .logger import log_debug, log_error
from .monitor.player import MDbListPlayer
from .sync.engine import SyncEngine
from .utils import (get_kodi_setting, get_setting, has_api_key, localized,
                    notify, set_kodi_setting)

# Kodi's own watched threshold; it drives playcount, which in turn drives
# what the library sync pushes
KODI_PLAYCOUNT_SETTING = 'videolibrary.playcountminimumpercent'


class MDbListService(xbmc.Monitor):

    def __init__(self):
        super().__init__()
        self.player = MDbListPlayer(sync_callback=self.do_sync)
        self._pending_sync = False
        self._last_interval_sync = time.time()

    # ------------------------------------------------------------------ #
    # monitor callbacks                                                  #
    # ------------------------------------------------------------------ #

    def onNotification(self, sender, method, data):
        if method in ('VideoLibrary.OnScanFinished',
                      'VideoLibrary.OnCleanFinished'):
            if get_setting('sync_on_update', 'bool'):
                log_debug(f'Library event ({method}), scheduling sync')
                self._pending_sync = True

    def onSettingsChanged(self):
        log_debug('Settings changed')
        self._align_watched_threshold()

    # ------------------------------------------------------------------ #
    # watched threshold                                                  #
    # ------------------------------------------------------------------ #

    def _align_watched_threshold(self):
        """Keep Kodi's playcount threshold in step with our own.

        The scrobbler honours 'watched_min_percent' on its own, but the
        library sync pushes whatever Kodi counted as watched. If Kodi's
        threshold is the lower one, it would mark items watched below our
        threshold and the next sync would push them anyway."""
        own = int(get_setting('watched_min_percent', 'int') or 80)
        kodi = get_kodi_setting(KODI_PLAYCOUNT_SETTING)
        if kodi is None:
            log_debug(f'Kodi setting {KODI_PLAYCOUNT_SETTING} unavailable, '
                      'watched threshold not compared')
            return
        try:
            kodi = int(kodi)
        except (TypeError, ValueError):
            return
        if not get_setting('watched_apply_to_kodi', 'bool'):
            if own > kodi:
                log_debug(f'Watched threshold is {own}% but Kodi counts from '
                          f'{kodi}%, so the library sync can still report '
                          'items as watched below the threshold – enable '
                          '"apply to Kodi" to align both')
            return
        if kodi == own:
            return
        if set_kodi_setting(KODI_PLAYCOUNT_SETTING, own):
            log_debug(f'Kodi playcount threshold aligned: {kodi}% -> {own}%')
        else:
            log_error(f'Could not set {KODI_PLAYCOUNT_SETTING} to {own}%')

    # ------------------------------------------------------------------ #
    # sync execution                                                     #
    # ------------------------------------------------------------------ #

    def do_sync(self, force=False, silent=True):
        if not has_api_key():
            log_debug('Sync skipped: no API key')
            return

        def _worker():
            started = time.time()
            try:
                summary = SyncEngine().run(force=force)
                log_debug(f'Sync finished in {time.time() - started:.1f}s: {summary}')
                if not silent:
                    notify(localized(32112) or 'Sync finished')
            except Exception as exc:
                log_error(f'Sync failed: {exc}\n{traceback.format_exc()}')
                if not silent:
                    notify(localized(32125) or 'Sync failed')

        threading.Thread(target=_worker, daemon=True).start()

    def startup_sync(self):
        delay = int(get_setting('sync_startup_delay', 'int') or 0)
        if not has_api_key():
            log_debug('No API key configured yet')
            return
        log_debug(f'Startup sync in {delay}s')
        timer = threading.Timer(delay, self.do_sync)
        timer.daemon = True
        timer.start()

    # ------------------------------------------------------------------ #
    # main loop                                                          #
    # ------------------------------------------------------------------ #

    def run(self):
        log_debug('Service starting')
        self._align_watched_threshold()
        self.startup_sync()
        while not self.waitForAbort(30):
            now = time.time()
            if self._pending_sync:
                self._pending_sync = False
                self.do_sync()
                self._last_interval_sync = now
                continue
            interval_minutes = int(get_setting('sync_interval', 'int') or 0)
            if interval_minutes > 0 and \
                    now - self._last_interval_sync >= interval_minutes * 60:
                log_debug('Interval sync due')
                self._last_interval_sync = now
                self.do_sync()
        log_debug('Service stopped')


def run():
    try:
        MDbListService().run()
    except Exception as exc:
        log_error(f'Service crashed: {exc}\n{traceback.format_exc()}')
