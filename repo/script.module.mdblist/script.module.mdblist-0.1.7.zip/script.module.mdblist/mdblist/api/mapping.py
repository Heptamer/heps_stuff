# -*- coding: utf-8 -*-
"""Normalization helpers for MDBList data (ratings, ids, timestamps)."""

# providers whose ids the MDBList API expects as numbers
# (imdb and mdblist ids are strings)
NUMERIC_ID_PROVIDERS = ('tmdb', 'trakt', 'tvdb', 'kitsu')

# provider names accepted as flat '<provider>id' keys on search entries
FLAT_ID_PROVIDERS = ('imdb', 'tmdb', 'trakt', 'tvdb', 'mal')


def typed_id(provider, value):
    """Convert a single provider id to the type the API expects."""
    if value is None:
        return None
    if provider in NUMERIC_ID_PROVIDERS:
        try:
            return int(str(value).strip())
        except (TypeError, ValueError):
            pass
    return str(value)


def typed_ids(ids):
    """Normalize an ids dict {provider: value} into API-typed values."""
    return {provider: typed_id(provider, value)
            for provider, value in (ids or {}).items() if value}


def _provider_from_key(key):
    """Map an id key ('tmdb', 'tmdbid', 'imdbid', ...) to its provider."""
    if key in FLAT_ID_PROVIDERS:
        return key
    if key.endswith('id'):
        name = key[:-2]
        if name in FLAT_ID_PROVIDERS:
            return name
    return None


def entry_ids(entry):
    """Collect provider ids from a search/media entry.

    The search endpoint returns suffixed keys both on the entry itself
    and inside its ids dict ({'ids': {'tmdbid': 1}}); other endpoints use
    plain names ({'ids': {'tmdb': 1}}). All variants merge here, later
    sources taking precedence, keyed by plain provider name."""
    sources = []
    if isinstance(entry, dict):
        sources.append(entry)
        nested = entry.get('ids')
        if isinstance(nested, dict):
            sources.append(nested)
    ids = {}
    for source in sources:
        for key, value in source.items():
            if isinstance(value, bool) or \
                    not isinstance(value, (str, int)) or not value:
                continue
            name = _provider_from_key(str(key))
            if name:
                ids[name] = value
    return ids


def bucket_items(payload, buckets=('movies', 'shows', 'seasons', 'episodes',
                                   'items', 'lists', 'people')):
    """Collect list entries from any known response bucket into one list."""
    items = []
    if isinstance(payload, list):
        return payload
    for bucket in buckets:
        values = (payload or {}).get(bucket)
        if isinstance(values, list):
            items.extend(values)
    return items


def watched_entry_ids(entry):
    """Return the inner media object of a sync/watched list entry."""
    if not isinstance(entry, dict):
        return {}
    for key in ('movie', 'show'):
        if isinstance(entry.get(key), dict):
            return entry[key]
    return {}


def watched_timestamp(entry):
    """Watch timestamp of a sync entry.

    /sync/watched names it 'watched_at'; older/other payloads use
    'last_watched_at'. Both are accepted."""
    if not isinstance(entry, dict):
        return None
    return entry.get('watched_at') or entry.get('last_watched_at')


def _plays_count(entry):
    """Play count of a sync entry; presence of a timestamp counts as one.

    /sync/watched carries no 'plays' field at all – an entry existing with
    a 'watched_at' means the item is watched, which is one play."""
    if not isinstance(entry, dict):
        return 0
    plays = entry.get('plays', entry.get('watched'))
    if plays is None:
        return 1 if watched_timestamp(entry) else 0
    if isinstance(plays, bool):
        return 1 if plays else 0
    try:
        return int(plays or 0)
    except (TypeError, ValueError):
        return 0


def episode_plays(season_entry):
    """Normalize the episode list of a nested season entry."""
    episodes = (season_entry or {}).get('episodes') or []
    result = {}
    for ep in episodes:
        number = ep.get('number')
        if number is None:
            continue
        try:
            number = int(number)
        except (TypeError, ValueError):
            continue
        result[number] = {
            'plays': _plays_count(ep),
            'last_watched_at': watched_timestamp(ep),
        }
    return result


def movie_plays(movie_entry):
    return _plays_count(movie_entry)


def _episode_numbers(entry):
    """Season/episode numbers of a flat episode entry.

    Tolerates both {'season': 1, 'episode': 2} and the nested
    {'season': {'number': 1}, 'number': 2} / {'episode': {'number': 2}}
    variants."""
    season = entry.get('season')
    if isinstance(season, dict):
        season = season.get('number')
    episode = entry.get('episode')
    if isinstance(episode, dict):
        episode = episode.get('number')
    if episode is None:
        episode = entry.get('number')
    if season is None or episode is None:
        return None
    try:
        return int(season), int(episode)
    except (TypeError, ValueError):
        return None


def _show_ids_of_episode(entry):
    """Parent show ids of a flat episode entry."""
    for key in ('show', 'tvshow'):
        nested = entry.get(key)
        if isinstance(nested, dict):
            ids = entry_ids(nested)
            if ids:
                return ids
    ids = entry.get('show_ids')
    if isinstance(ids, dict):
        normalized = entry_ids({'ids': ids})
        if normalized:
            return normalized
    return {}


def watched_episodes(payload):
    """Episode state of a /sync/watched or /sync/collection payload.

    Returns (by_show, by_episode_id):

    by_show       {(provider, show_id): {(season, episode): state}}
    by_episode_id {(provider, episode_id): state}

    state is {'plays': int, 'watched_at': iso|None}.

    Every provider id an item carries yields its own key, so a local show
    known only by tvdb still matches a remote show carrying tmdb.

    Both response shapes are read: the flat top-level 'episodes' bucket
    (what the documented API returns, where 'ids' identifies the *episode*)
    and episodes nested inside shows[].seasons[].episodes[]. Flat entries
    without a parent show object can only be matched through the episode's
    own id, hence the second index."""
    index = {}
    by_episode_id = {}

    def _store(show_ids, season, episode, state):
        for key in id_keys(show_ids):
            index.setdefault(key, {})[(season, episode)] = state

    for entry in (payload or {}).get('episodes') or []:
        if not isinstance(entry, dict):
            continue
        state = {'plays': _plays_count(entry),
                 'watched_at': watched_timestamp(entry)}
        show_ids = _show_ids_of_episode(entry)
        numbers = _episode_numbers(entry)
        if show_ids and numbers is not None:
            _store(show_ids, numbers[0], numbers[1], state)
        # 'ids' on a flat episode entry identifies the episode itself
        for key in id_keys(entry_ids(entry)):
            by_episode_id[key] = state

    for entry in (payload or {}).get('shows') or []:
        if not isinstance(entry, dict):
            continue
        show = watched_entry_ids(entry) or entry
        show_ids = entry_ids(show) or entry_ids(entry)
        if not show_ids:
            continue
        seasons = show.get('seasons') or entry.get('seasons') or []
        for season in seasons:
            if not isinstance(season, dict):
                continue
            s_num = season.get('number')
            if s_num is None:
                continue
            try:
                s_num = int(s_num)
            except (TypeError, ValueError):
                continue
            for e_num, state in episode_plays(season).items():
                _store(show_ids, s_num, e_num,
                       {'plays': state['plays'],
                        'watched_at': state['last_watched_at']})

    # seasons marked watched as a whole carry no episode numbers; they are
    # ignored here on purpose – a season-level flag cannot tell us which
    # episodes the local library holds.
    return index, by_episode_id


def id_keys(ids):
    """Canonical comparison keys for every provider id in an ids dict.

    Mirrors the key format used by the sync engine so remote and local
    items can be matched on any shared provider id."""
    for provider in ('tmdb', 'tvdb', 'imdb', 'trakt'):
        value = (ids or {}).get(provider)
        if value in (None, ''):
            continue
        try:
            yield (provider, str(int(value)))
        except (TypeError, ValueError):
            yield (provider, str(value))


def rating_entries(payload, mediatype_key):
    """Extract rating entries for a given key ('movies','shows','episodes')."""
    entries = (payload or {}).get(mediatype_key) or []
    result = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        nested = entry.get(mediatype_key.rstrip('s'))
        ids = entry_ids(nested) if isinstance(nested, dict) else {}
        if not ids:
            ids = entry_ids(entry)
        rating = entry.get('rating')
        if rating is None and isinstance(nested, dict):
            rating = nested.get('rating')
        result.append({'ids': ids,
                       'rating': rating,
                       'rated_at': entry.get('rated_at') or
                       (nested or {}).get('rated_at')})
    return result
