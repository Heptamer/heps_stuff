# MDBList Addon – User Guide (English)

[Deutsche Anleitung](GUIDE.de.md) · [English README](README.md) · [German README](README.de.md)

`script.module.mdblist` connects Kodi to [MDBList.com](https://mdblist.com):
playback scrobbling, synchronisation between the Kodi library and your
MDBList account, plus a Python module for third-party addons.

## Requirements

- Kodi 19 (Matrix) or newer
- Free MDBList account with an API key: log in at mdblist.com →
  *Preferences* → *API key*
- Enter the key in the addon: *Addons → My add-ons → MDBList → Configure →
  General → API key*

## Scrobbling

While the background service runs, every movie/episode playback is reported
to MDBList:

| Event | Sent | Kodi notification |
|---|---|---|
| Playback started | `start` | yes |
| **Paused** | `pause` | **no (by design)** |
| Resumed | `start` (with current progress) | yes |
| Stopped / ended | `stop` | yes |

> **About pause:** Pausing is fully evaluated and transmitted to MDBList —
> it just deliberately shows no notification, so frequent pausing does not
> spam you. mdblist.com still marks the item as paused. To verify: enable
> debug logging; pausing logs `SCROBBLE [pause] …`.

Settings:

- **Enable scrobbling** (default: on)
- **Minimum progress %**: stops below this value do not count as watched
  (default 5 %)

### Rating prompt after playback

Optional (off by default): after a movie/episode finishes — or is stopped
past the threshold — the addon opens a picker dialog
(*No rating, 1 ★ … 10 ★*) and pushes the choice to MDBList.

- **Ask for a rating after playback**: enable the feature
- **Minimum progress for rating prompt (%)**: slider, minimum 75 %
  (default 85 %)
- **Ask for rating on**: movies and episodes / movies only / episodes only

Notes:

- The prompt requires scrobbling to be enabled (identification depends on it)
  and only appears when the item could be identified.
- Episodes are rated at **episode level** on mdblist.com. The ratings *pull*
  currently reads movies back into Kodi only, so episode ratings do not sync
  back yet.
- The same star picker replaces the old numeric keypad when rating via the
  context menu.

### How content is identified

Played items are identified in this order:

1. TMDB/IMDB id of the Kodi ListItem (library items)
2. Reverse lookup of the playing file path in the Kodi library (e.g. for
   strm files from xStream that carry no ids)
3. Title/year search via the MDBList API (items not in any library),
   cached for 30 days

## Synchronisation

Each direction can be toggled separately (*Settings → Sync*):

- **Watched status**: push and pull for movies and episodes. Play counts are
  compared; on ties the newer timestamp wins.
- **Ratings**: Kodi *userrating* ↔ MDBList rating (movies; shows to follow).
- **Library → collection** (default: off): syncs the whole Kodi library with
  the MDBList collection — movies **and individual episodes**. Add-only:
  removing files from Kodi never removes them from the collection. Only this
  option makes **unwatched** movies/shows visible on mdblist.com.

Important when reading logs/summaries: numbers always mean "newly
transferred **in this run**". `movies: 0` means "nothing new" — not "the
collection is empty".

Further settings:

- **Startup delay**: wait after Kodi start before the first sync
  (default 120 s)
- **Interval**: periodic sync in minutes, 0 = off
- **Sync after library update**: sync after every scan/clean

### Manual sync

Context menu of the addon → **Sync now**, or
`RunScript(script.module.mdblist, action=sync)`.

A manual sync waits up to 45 seconds if a service sync is currently running
instead of failing instantly. If you see "a sync is already running", no slot
was free within that window — simply try again. A confirmation appears after
real completion.

## Actions (RunScript)

```text
RunScript(script.module.mdblist, action=sync)              # force a sync
RunScript(script.module.mdblist, action=rate, id=tmdb:769, rating=9)
RunScript(script.module.mdblist, action=watchlist,
          operation=add, id=imdb:tt0117731)
RunScript(script.module.mdblist, action=list,
          list_id=123, operation=add, id=tmdb:769)
RunScript(script.module.mdblist, action=auth_info)         # show key status
RunScript(script.module.mdblist, action=contextmenu)       # open dialog
```

`id` accepts `tmdb:`, `imdb:`, `trakt:`, `tvdb:` or a bare number. Without
`id`/`type` the currently playing item is used.

## Troubleshooting

1. Enable *Debug logging* in the addon settings
2. Restart Kodi or trigger a manual sync
3. Check the log (`kodi.log`); relevant lines start with
   `[script.module.mdblist]`

Typical lines:

```text
SCROBBLE [start] (id: library) tmdb:1399 "Show X" at 3%
SCROBBLE [pause] …            ← pause was sent (no notification by design)
Collection remote snapshot: movies=12 shows=2
Collection diff: movies=0 show payloads=1 episodes=14 unresolved=0
Collection push: {'status': 'ok', 'movies': 0, 'episodes': 14}
Sync finished in 16.4s: {…}
```

Common cases:

- **Items missing from the collection**: `unresolved=` > 0 means a series
  could be neither matched by ids nor resolved via title search. Shows with
  TVDB-only ids are sent as such directly (MDBList accepts tmdb/tvdb/imdb/
  trakt).
- **Rate limit**: The free API tier allows 1000 requests/day; the caches
  (remote snapshots 6 h, id resolutions 30 days) keep usage low.
- **Reset everything**: delete `cache.db` in the addon profile folder and
  restart Kodi.
